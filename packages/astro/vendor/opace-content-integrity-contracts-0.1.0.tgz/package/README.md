# @opace/content-integrity-contracts

Package containing the frozen Opace AI Content Integrity v1 TypeScript contract declarations and cross-surface constants.

- Schema version: `1.0`
- Contract version: `1.0.0`
- Source of truth: the repository JSON Schemas under `schemas/v1/`
- Runtime behaviour: no transport, telemetry or content processing
- Licence: MIT for the Opace-authored package

Generated declarations must remain schema-checked. Unsupported, unavailable, not configured, not run, inconclusive and error states must never be converted to pass.

Repository-wide dependency, contract and provenance evidence is recorded in `THIRD_PARTY_NOTICES.md`, `MODEL_AND_DATA_PROVENANCE.md` and `docs/legal/DEPENDENCY-LEDGER.md` at the project root.

## Install

```sh
npm install @opace/content-integrity-contracts
```

## Use and compatibility

```js
import {
  CONTRACT_VERSION,
  SCHEMA_VERSION,
  METHOD_STATUSES,
  PRIVACY_ROUTES,
} from '@opace/content-integrity-contracts';
```

Readers accept additive fields from the same contract major and fail closed on an unknown status or wrong major. Every consuming surface must preserve the canonical statuses and the `browser`, `wordpress_local`, `local_service`, `hub_provider` and `commercial_byok` privacy routes. Do not infer availability from a missing method.

Run `npm test` in this package after a declaration change, then run the repository G1 and G2 gates. Contract or schema changes require compatibility review; editing generated declarations alone is not supported.

## Privacy, security and licence

This package performs no I/O and contains no content processor, network client or install hook. It is safe to import in browser and server builds, but it does not validate untrusted runtime payloads by itself; use the schema/semantic validators at the relevant boundary.

See the repository [security policy](https://github.com/OpaceDigitalAgency/opace-content-integrity/blob/main/SECURITY.md) before reporting a vulnerability. Opace-authored code is available under the [MIT Licence](https://github.com/OpaceDigitalAgency/opace-content-integrity/blob/main/LICENSE).
