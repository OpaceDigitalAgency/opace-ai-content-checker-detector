# @opace/content-integrity-browser

Browser adapter for Opace AI Content Integrity. It provides deterministic DOM visible-text projection and a module Worker client over the frozen core and contracts.

- Consumes `@opace/content-integrity-core` and `@opace/content-integrity-contracts`
- No analysis-time telemetry, provider call or remote module
- Default Worker target is packaged at `dist/worker/entry.js`
- Licence: MIT for the Opace-authored package

Dependency and provenance evidence is recorded in the project-root `THIRD_PARTY_NOTICES.md`, `MODEL_AND_DATA_PROVENANCE.md` and `docs/legal/DEPENDENCY-LEDGER.md`.

## Install

```sh
npm install @opace/content-integrity-browser
```

## Use

The adapter projects rendered, visible body text with stable block and line-break semantics, excluding scripts, styles, templates, noscript and hidden descendants. Its Worker client carries schema-valid messages and supports cancellation without retaining content.

```js
import { projectDomVisibleText, createInspectionWorker } from '@opace/content-integrity-browser';
```

Create the Worker only after an explicit user action. The default worker asset is packaged with the module, so consumers do not need a remote script or CDN.

## Verify

```sh
npm ci
npm run typecheck
npm test
```

Rendered consumers should also test their own CSP, Worker URL resolution, cancellation, narrow layouts and network boundary. A successful projection does not authorise content storage or transmission.

## Accessibility, security and licence

This library does not render controls. The consuming toolbar or extension owns accessible names, focus order, live status and reduced-motion behaviour. Report vulnerabilities through the repository [security policy](https://github.com/OpaceDigitalAgency/opace-content-integrity/blob/main/SECURITY.md). Opace-authored code is available under the [MIT Licence](https://github.com/OpaceDigitalAgency/opace-content-integrity/blob/main/LICENSE).
