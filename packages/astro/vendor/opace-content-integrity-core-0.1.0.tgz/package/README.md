# @opace/content-integrity-core

Deterministic, offline Opace AI Content Integrity inspection, protected spans, writing-pattern evidence, safe-fix previews, diffs, gates and RFC 8785 receipts.

- Consumes `@opace/content-integrity-contracts` contract `1.0.0`
- Browser/SSR-safe and transport-free by design
- No detector model, provider call, telemetry or postinstall download
- `watermark.anthropic` remains visibly unsupported
- Licence: MIT for the Opace-authored package

The runtime dependency `canonicalize@4.0.0` is Apache-2.0 and supplies RFC 8785 JSON canonicalisation. It is installed as a separate dependency rather than copied into this package. Exact dependency and provenance evidence is recorded in the project-root `THIRD_PARTY_NOTICES.md` and `docs/legal/DEPENDENCY-LEDGER.md`.

A pass applies only to its named disclosed check and does not prove authorship or detector clearance.

## Install

```sh
npm install @opace/content-integrity-core
```

## Capabilities

The package exposes deterministic Unicode inspection, visible writing-pattern evidence, protected-span checks, reviewed patch/diff helpers and canonical hash-only receipts. Results retain method versions, limitations and privacy routes from the frozen contract.

```js
import { inspect, buildReceipt } from '@opace/content-integrity-core';
```

Use the typed exports from the package rather than copying algorithms into a consumer. Browser, Astro, CLI and extension adapters must produce the same stable fields for the same projected input.

## Test and integration boundary

```sh
npm ci
npm test
npm run pack:check
```

The package is designed for browser and server ESM. It has no postinstall step, remote import or hidden provider fallback. Consumers remain responsible for explicit user consent before inspecting content and for keeping content out of logs and receipts.

Report security concerns through the repository [security policy](https://github.com/OpaceDigitalAgency/opace-content-integrity/blob/main/SECURITY.md). Opace-authored code is available under the [MIT Licence](https://github.com/OpaceDigitalAgency/opace-content-integrity/blob/main/LICENSE).
