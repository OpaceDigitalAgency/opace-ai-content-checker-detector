// ../shared/highlight-dom.mjs
var HIGHLIGHT_ATTRIBUTE = "data-oaci-highlight";
var HIGHLIGHT_CLASS = "oaci-page-highlight";
var ELEMENT_NODE = 1;
var TEXT_NODE = 3;
var CLOSED = /* @__PURE__ */ new Set([
  "SCRIPT",
  "STYLE",
  "NOSCRIPT",
  "TEMPLATE",
  "TEXTAREA",
  "INPUT",
  "SELECT",
  "OPTION",
  "OPTGROUP",
  "SVG",
  "CANVAS",
  "IFRAME",
  "FRAME",
  "FRAMESET",
  "OBJECT",
  "EMBED",
  "VIDEO",
  "AUDIO",
  "MAP",
  "HEAD"
]);
var BLOCK = /* @__PURE__ */ new Set([
  "ADDRESS",
  "ARTICLE",
  "ASIDE",
  "BLOCKQUOTE",
  "BR",
  "DD",
  "DIV",
  "DL",
  "DT",
  "FIELDSET",
  "FIGCAPTION",
  "FIGURE",
  "FOOTER",
  "FORM",
  "H1",
  "H2",
  "H3",
  "H4",
  "H5",
  "H6",
  "HEADER",
  "HR",
  "LI",
  "MAIN",
  "NAV",
  "OL",
  "P",
  "PRE",
  "SECTION",
  "TABLE",
  "TBODY",
  "TD",
  "TFOOT",
  "TH",
  "THEAD",
  "TR",
  "UL"
]);
var children = (node) => node && node.childNodes ? [...node.childNodes] : [];
var tagOf = (node) => String(node.nodeName ?? "").toUpperCase();
function collectTextChunks(root, options = {}) {
  const isVisible = typeof options.isVisible === "function" ? options.isVisible : () => true;
  const chunks = [];
  const boundary = () => {
    const last = chunks[chunks.length - 1];
    if (chunks.length && !(last.node === null)) chunks.push({ node: null, text: "\n" });
  };
  const walk = (node) => {
    if (!node) return;
    if (node.nodeType === TEXT_NODE) {
      if (typeof node.data === "string" && node.data.length) chunks.push({ node, text: node.data });
      return;
    }
    if (node.nodeType !== ELEMENT_NODE) return;
    const tag = tagOf(node);
    if (CLOSED.has(tag)) return;
    if (typeof node.getAttribute === "function" && node.getAttribute("aria-hidden") === "true") return;
    if (typeof node.hasAttribute === "function" && node.hasAttribute(HIGHLIGHT_ATTRIBUTE)) {
      for (const child of children(node)) walk(child);
      return;
    }
    if (!isVisible(node)) return;
    const block = BLOCK.has(tag);
    if (block) boundary();
    for (const child of children(node)) walk(child);
    if (block) boundary();
  };
  walk(root);
  return chunks;
}
function applyHighlight(document2, chunks, segments, attributes = {}) {
  const ordered = [...segments].filter((segment) => chunks[segment.chunk] && chunks[segment.chunk].node).sort((a, b) => a.chunk === b.chunk ? b.start - a.start : b.chunk - a.chunk);
  const wrappers = [];
  for (const segment of ordered) {
    const node = chunks[segment.chunk].node;
    if (typeof node.splitText !== "function" || !node.parentNode) continue;
    const length = segment.end - segment.start;
    if (length <= 0) continue;
    const middle = segment.start > 0 ? node.splitText(segment.start) : node;
    if (middle.data.length > length) middle.splitText(length);
    const span = document2.createElement("span");
    span.setAttribute(HIGHLIGHT_ATTRIBUTE, "");
    span.setAttribute("class", HIGHLIGHT_CLASS);
    for (const [name, value] of Object.entries(attributes)) span.setAttribute(name, value);
    middle.parentNode.replaceChild(span, middle);
    span.appendChild(middle);
    wrappers.push(span);
  }
  return wrappers.reverse();
}
function mergeAdjacentText(parent) {
  if (!parent) return;
  let previous = null;
  for (const child of children(parent)) {
    if (child.nodeType !== TEXT_NODE) {
      previous = null;
      continue;
    }
    if (child.data === "") {
      parent.removeChild(child);
      continue;
    }
    if (previous) {
      previous.data += child.data;
      parent.removeChild(child);
      continue;
    }
    previous = child;
  }
}
function clearHighlight(root) {
  if (!root) return 0;
  let removed = 0;
  const parents = /* @__PURE__ */ new Set();
  const walk = (node) => {
    if (!node || node.nodeType !== ELEMENT_NODE) return;
    if (typeof node.hasAttribute === "function" && node.hasAttribute(HIGHLIGHT_ATTRIBUTE)) {
      const parent = node.parentNode;
      if (parent) {
        for (const child of children(node)) parent.insertBefore(child, node);
        parent.removeChild(node);
        parents.add(parent);
        removed += 1;
      }
      return;
    }
    for (const child of children(node)) walk(child);
  };
  walk(root);
  for (const parent of parents) mergeAdjacentText(parent);
  return removed;
}

// ../shared/passage-locator.mjs
var SPACE = /[\s\u200b\u200c\u200d\ufeff]/u;
var MIN_ANCHOR_LENGTH = 48;
var isSpace = (character) => SPACE.test(character);
function collapseWhitespace(value) {
  if (typeof value !== "string") return "";
  let out = "";
  let pending = false;
  for (const character of value) {
    if (isSpace(character)) {
      pending = out.length > 0;
      continue;
    }
    if (pending) {
      out += " ";
      pending = false;
    }
    out += character;
  }
  return out;
}
function buildTextIndex(chunks) {
  const source = Array.isArray(chunks) ? chunks : [];
  let text = "";
  const chunkIndex = [];
  const offsets = [];
  let pending = null;
  for (let index = 0; index < source.length; index += 1) {
    const value = typeof source[index] === "string" ? source[index] : "";
    for (let position = 0; position < value.length; position += 1) {
      const character = value[position];
      if (isSpace(character)) {
        if (text.length > 0 && !pending) pending = { chunk: index, offset: position };
        continue;
      }
      if (pending) {
        text += " ";
        chunkIndex.push(pending.chunk);
        offsets.push(pending.offset);
        pending = null;
      }
      text += character;
      chunkIndex.push(index);
      offsets.push(position);
    }
  }
  return { text, chunkIndex, offsets, chunks: source };
}
function allOccurrences(haystack, needle) {
  const found = [];
  if (!needle) return found;
  let from = 0;
  for (; ; ) {
    const at = haystack.indexOf(needle, from);
    if (at === -1) return found;
    found.push(at);
    from = at + 1;
    if (found.length >= 64) return found;
  }
}
function anchorsFor(needle) {
  const anchors = [];
  const push = (value) => {
    const trimmed = value.trim();
    if (trimmed.length >= MIN_ANCHOR_LENGTH && !anchors.includes(trimmed)) anchors.push(trimmed);
  };
  const sentence = needle.slice(0, 400).match(/^[\s\S]*?[.!?](?=\s|$)/u);
  if (sentence) push(sentence[0]);
  for (const length of [200, 120, MIN_ANCHOR_LENGTH]) push(needle.slice(0, length));
  const tail = needle.slice(-120);
  push(tail);
  return anchors;
}
function pick(starts, length, total, hint) {
  if (starts.length === 1 || hint === null) return { start: starts[0], end: starts[0] + length };
  const wanted = Math.max(0, Math.min(1, hint)) * total;
  let best = starts[0];
  let distance = Math.abs(best - wanted);
  for (const start of starts.slice(1)) {
    const gap = Math.abs(start - wanted);
    if (gap < distance) {
      best = start;
      distance = gap;
    }
  }
  return { start: best, end: best + length };
}
function locatePassage(index, passage, options = {}) {
  if (!index || typeof index.text !== "string") return null;
  const needle = collapseWhitespace(passage).trim();
  if (needle.length < 3) return null;
  const hint = Number.isFinite(options.hint) ? options.hint : null;
  const exact = allOccurrences(index.text, needle);
  if (exact.length) {
    return { ...pick(exact, needle.length, index.text.length, hint), exact: true, anchor: null, occurrences: exact.length };
  }
  for (const anchor of anchorsFor(needle)) {
    const found = allOccurrences(index.text, anchor);
    if (found.length) {
      return { ...pick(found, anchor.length, index.text.length, hint), exact: false, anchor, occurrences: found.length };
    }
  }
  return null;
}
function segmentsForRange(index, start, end) {
  const segments = [];
  if (!index || !Array.isArray(index.chunkIndex)) return segments;
  const from = Math.max(0, Math.min(index.chunkIndex.length, Math.trunc(start)));
  const to = Math.max(from, Math.min(index.chunkIndex.length, Math.trunc(end)));
  for (let position = from; position < to; position += 1) {
    const chunk = index.chunkIndex[position];
    const offset = index.offsets[position];
    if (chunk === void 0) continue;
    const last = segments[segments.length - 1];
    if (last && last.chunk === chunk && last.end === offset) {
      last.end = offset + 1;
      continue;
    }
    if (last && last.chunk === chunk && last.end === offset + 1) continue;
    segments.push({ chunk, start: offset, end: offset + 1 });
  }
  return segments;
}

// src/highlight.ts
var BANDS = {
  "signal-likely-human": { wash: "rgba(47,125,84,0.20)", line: "#2f7d54" },
  "signal-unclear": { wash: "rgba(141,145,140,0.22)", line: "#8d918c" },
  "signal-potentially-ai": { wash: "rgba(192,138,23,0.26)", line: "#c08a17" },
  "signal-likely-ai": { wash: "rgba(194,87,28,0.24)", line: "#c2571c" },
  "signal-strongly-ai": { wash: "rgba(165,48,31,0.24)", line: "#a5301f" }
};
var FALLBACK = { wash: "rgba(251,112,10,0.22)", line: "#c25209" };
var rootForReading = () => document.querySelector("article, main, [role='main']") ?? document.body;
var visible = (element) => {
  const style = window.getComputedStyle(element);
  return style.display !== "none" && style.visibility !== "hidden" && style.opacity !== "0";
};
var run = (command) => {
  const cleared = clearHighlight(document.body);
  const passage = typeof command?.passage === "string" ? command.passage : "";
  if (!passage.trim()) return { matched: false, spans: 0, exact: false, cleared, reason: "no-passage" };
  const root = rootForReading();
  const chunks = collectTextChunks(root, { isVisible: visible });
  const index = buildTextIndex(chunks.map((chunk) => chunk.text));
  if (!index.text.trim()) return { matched: false, spans: 0, exact: false, cleared, reason: "no-text" };
  const found = locatePassage(index, passage, { hint: command.hint });
  if (!found) return { matched: false, spans: 0, exact: false, cleared, reason: "not-found" };
  const band = BANDS[command.level] ?? FALLBACK;
  const spans = applyHighlight(document, chunks, segmentsForRange(index, found.start, found.end), {
    style: `background-color:${band.wash};border-radius:2px;color:inherit;`,
    "data-oaci-level": String(command.level ?? "")
  });
  if (spans.length) {
    spans[0].style.borderLeft = `3px solid ${band.line}`;
    spans[spans.length - 1].style.borderRight = `3px solid ${band.line}`;
    spans[0].scrollIntoView({ block: "center", inline: "nearest", behavior: "auto" });
  }
  return { matched: spans.length > 0, spans: spans.length, exact: found.exact, cleared, reason: spans.length ? "matched" : "not-found" };
};
var api = {
  show: run,
  clear: () => clearHighlight(document.body)
};
window.__oaciHighlight = api;
