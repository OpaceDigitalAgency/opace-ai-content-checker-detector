// node_modules/@opace/content-integrity-browser/dist/index.js
var EXCLUDED = /* @__PURE__ */ new Set(["SCRIPT", "STYLE", "TEMPLATE", "NOSCRIPT"]);
var BLOCKS = /* @__PURE__ */ new Set(["ADDRESS", "ARTICLE", "ASIDE", "BLOCKQUOTE", "DIV", "DL", "FIELDSET", "FIGCAPTION", "FIGURE", "FOOTER", "FORM", "H1", "H2", "H3", "H4", "H5", "H6", "HEADER", "HR", "LI", "MAIN", "NAV", "OL", "P", "PRE", "SECTION", "TABLE", "TR", "UL"]);
function projectDomVisibleText(root2) {
  let text = "";
  const runs = [];
  const pathOf = (node) => {
    const path = [];
    let current = node;
    while (current && current !== root2) {
      const p = current.parentNode;
      if (!p) break;
      path.unshift(Array.prototype.indexOf.call(p.childNodes, current));
      current = p;
    }
    return path;
  };
  const append = (value, node, startUtf16, endUtf16) => {
    if (!value) return;
    const start = text.length;
    text += value;
    runs.push({ text: value, node_path: pathOf(node), start_utf16: startUtf16, end_utf16: endUtf16, visible_start_utf16: start, visible_end_utf16: text.length });
  };
  const separator = (node) => {
    if (text && !text.endsWith("\n")) append("\n", node, 0, 0);
  };
  const visit = (node, hidden) => {
    if (node.nodeType === 1) {
      const element = node;
      const excluded = hidden || EXCLUDED.has(element.tagName) || element.hidden || element.getAttribute("aria-hidden") === "true";
      if (excluded) return;
      if (element.tagName === "BR") {
        separator(node);
        return;
      }
      const block = BLOCKS.has(element.tagName);
      if (block) separator(node);
      for (const child of Array.from(node.childNodes)) visit(child, false);
      if (block) separator(node);
      return;
    }
    if (node.nodeType === 3) {
      const value = node.nodeValue ?? "";
      append(value, node, 0, value.length);
      return;
    }
    for (const child of Array.from(node.childNodes)) visit(child, hidden);
  };
  visit(root2, false);
  text = text.replace(/\n+$/g, "");
  while (runs.length && runs.at(-1).visible_start_utf16 >= text.length) runs.pop();
  if (runs.length) runs.at(-1).visible_end_utf16 = Math.min(runs.at(-1).visible_end_utf16, text.length);
  return { text, runs, limitations: ["Visibility uses hidden and aria-hidden markers; computed CSS visibility is host-dependent."] };
}

// src/extract-article.ts
var root = document.querySelector("article, main, [role='main']") ?? document.body;
var projection = projectDomVisibleText(root);
var payload = {
  kind: "article",
  text: projection.text,
  host: location.hostname,
  title: document.title,
  limitations: projection.limitations
};
void chrome.runtime.sendMessage({ type: "CAPTURE_READY", payload });
