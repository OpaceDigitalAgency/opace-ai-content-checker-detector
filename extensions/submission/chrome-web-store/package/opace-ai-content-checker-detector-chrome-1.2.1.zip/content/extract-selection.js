// src/extract-selection.ts
var selection = window.getSelection();
var text = selection?.toString() ?? "";
var payload = {
  kind: "selection",
  text,
  host: location.hostname,
  title: document.title,
  limitations: []
};
void chrome.runtime.sendMessage({ type: "CAPTURE_READY", payload });
