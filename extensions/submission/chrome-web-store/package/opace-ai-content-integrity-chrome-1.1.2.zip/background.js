// ../shared/types.ts
var DEFAULT_SETTINGS = Object.freeze({
  receiptHistory: false,
  highContrast: false
});

// ../shared/eu-allowance.mjs
var EU_ALLOWANCE = Object.freeze({
  perMinute: 3,
  perHour: 20,
  minuteWindowMs: 6e4,
  hourWindowMs: 36e5,
  /** The service's own daily ceiling across every caller, quoted for honesty. */
  serviceDailySegmentInferences: 12e3,
  maxCharacters: 5e4
});
var HOUR_KEEP = EU_ALLOWANCE.hourWindowMs;

// ../shared/storage.ts
var INTERRUPTED_KEY = "unfinished_action";
var markUnfinished = async (phase) => {
  await chrome.storage.session.set({ [INTERRUPTED_KEY]: { phase, at: Date.now() } });
};
var clearUnfinished = async () => {
  await chrome.storage.session.remove(INTERRUPTED_KEY);
};
var loadInterrupted = async () => {
  const stored = await chrome.storage.session.get(INTERRUPTED_KEY);
  const marker = stored[INTERRUPTED_KEY];
  return marker && typeof marker.phase === "string" ? { phase: marker.phase } : null;
};

// src/background.ts
var pendingCapture = null;
var restrictedMessage = "Chrome would not let this extension read that page. Open the side panel and choose This page, and it will offer to ask Chrome for permission, or paste the text instead.";
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: "inspect-selection",
      title: "Check selection with Opace AI Content Integrity",
      contexts: ["selection"]
    });
  });
});
void chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
var runCapture = async (tabId, kind) => {
  pendingCapture = null;
  await markUnfinished(`capturing_${kind}`);
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: [kind === "selection" ? "content/extract-selection.js" : "content/extract-article.js"]
    });
  } catch {
    pendingCapture = { kind, text: "", host: "", title: "Restricted page", limitations: [restrictedMessage] };
    await clearUnfinished();
  }
};
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId !== "inspect-selection" || !tab || typeof tab.id !== "number") return;
  const tabId = tab.id;
  void chrome.sidePanel.open({ tabId }).then(() => runCapture(tabId, "selection"));
});
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "CAPTURE_READY") {
    pendingCapture = message.payload;
    void clearUnfinished();
    sendResponse({ ok: true });
    return false;
  }
  if (message?.type === "CLEAR_PENDING") {
    pendingCapture = null;
    void clearUnfinished();
    sendResponse({ ok: true });
    return false;
  }
  if (message?.type === "START_PASTE") {
    pendingCapture = { kind: "paste", text: "", host: "", title: "Pasted text", limitations: [] };
    void clearUnfinished();
    sendResponse({ ok: true });
    return false;
  }
  if (message?.type === "GET_PENDING") {
    void (async () => {
      const capture = pendingCapture;
      pendingCapture = null;
      const interrupted = capture ? null : await loadInterrupted();
      sendResponse({ capture, interrupted });
    })();
    return true;
  }
  return false;
});
