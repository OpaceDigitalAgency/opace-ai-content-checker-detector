// src/extract-selection.ts
(() => ({
  kind: "selection",
  text: window.getSelection()?.toString() ?? "",
  host: location.hostname,
  title: document.title,
  limitations: []
}))();
