// ../shared/types.ts
var DEFAULT_SETTINGS = Object.freeze({
  receiptHistory: false,
  highContrast: false
});

// ../shared/eu-allowance.mjs
var EU_ALLOWANCE = Object.freeze({
  perMinute: 3,
  perHour: 20,
  minuteWindowMs: 6e4,
  hourWindowMs: 36e5,
  /** The service's own daily ceiling across every caller, quoted for honesty. */
  serviceDailySegmentInferences: 12e3,
  maxCharacters: 5e4
});
var HOUR_KEEP = EU_ALLOWANCE.hourWindowMs;

// ../shared/storage.ts
var INTERRUPTED_KEY = "unfinished_action";
var clearUnfinished = async () => {
  await chrome.storage.session.remove(INTERRUPTED_KEY);
};
var loadInterrupted = async () => {
  const stored = await chrome.storage.session.get(INTERRUPTED_KEY);
  const marker = stored[INTERRUPTED_KEY];
  return marker && typeof marker.phase === "string" ? { phase: marker.phase } : null;
};

// src/background.ts
var pendingCapture = null;
var pendingIntent = null;
var intentSequence = 0;
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: "inspect-selection",
      title: "Check selection with Opace AI Content Checker & Detector",
      contexts: ["selection"]
    });
  });
});
void chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: false }).catch(() => void 0);
var openForCapture = (tabId, mode) => {
  const intent = { id: `${Date.now().toString(36)}-${++intentSequence}`, tabId, mode };
  pendingIntent = intent;
  pendingCapture = null;
  void chrome.sidePanel.open({ tabId }).then(() => {
    if (pendingIntent?.id !== intent.id) return;
    return chrome.runtime.sendMessage({ type: "CAPTURE_INTENT", intent }).catch(() => void 0);
  }).catch(() => void 0);
};
chrome.action.onClicked.addListener((tab) => {
  if (typeof tab.id !== "number") return;
  openForCapture(tab.id, "article");
});
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId !== "inspect-selection" || !tab || typeof tab.id !== "number") return;
  openForCapture(tab.id, "selection");
});
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "CLEAR_CAPTURE_INTENT") {
    if (pendingIntent?.id === message.id) pendingIntent = null;
    sendResponse({ ok: true });
    return false;
  }
  if (message?.type === "CAPTURE_READY") {
    pendingCapture = message.payload;
    void clearUnfinished();
    sendResponse({ ok: true });
    return false;
  }
  if (message?.type === "CLEAR_PENDING") {
    pendingCapture = null;
    void clearUnfinished();
    sendResponse({ ok: true });
    return false;
  }
  if (message?.type === "START_PASTE") {
    pendingIntent = null;
    pendingCapture = { kind: "paste", text: "", host: "", title: "Pasted text", limitations: [] };
    void clearUnfinished();
    sendResponse({ ok: true });
    return false;
  }
  if (message?.type === "GET_PENDING") {
    void (async () => {
      const intent = pendingIntent;
      const capture = pendingCapture;
      pendingCapture = null;
      const interrupted = intent || capture ? null : await loadInterrupted();
      sendResponse({ ...intent ? { intent } : {}, capture, interrupted });
    })();
    return true;
  }
  return false;
});
