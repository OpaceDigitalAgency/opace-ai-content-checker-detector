// node_modules/@opace/content-integrity-browser/dist/index.js
var WORKER_PROTOCOL_VERSION = "1.0";
function createInspectionWorker(options = {}) {
  if (typeof Worker === "undefined") throw new Error("worker_unsupported");
  const worker = new Worker(options.workerUrl ?? new URL("./worker/entry.js", import.meta.url), { type: "module" });
  const pending = /* @__PURE__ */ new Map();
  worker.onmessage = (event) => {
    const m = event.data, p = pending.get(m.id);
    if (!p || m.protocol_version !== WORKER_PROTOCOL_VERSION) return;
    if (m.type === "progress") p.onProgress?.(m.phase);
    else {
      pending.delete(m.id);
      m.type === "result" ? p.resolve(m.result) : p.reject(new Error(m.code));
    }
  };
  return { inspect(request, opts = {}) {
    const id = `inspect_${Date.now()}_${Math.random().toString(36).slice(2)}`;
    return new Promise((resolve, reject) => {
      pending.set(id, { resolve, reject, onProgress: opts.onProgress });
      const abort = () => {
        worker.postMessage({ protocol_version: WORKER_PROTOCOL_VERSION, type: "cancel", id });
        pending.delete(id);
        reject(new DOMException("Inspection cancelled", "AbortError"));
      };
      if (opts.signal?.aborted) return abort();
      opts.signal?.addEventListener("abort", abort, { once: true });
      worker.postMessage({ protocol_version: WORKER_PROTOCOL_VERSION, type: "inspect", id, request });
    });
  }, dispose() {
    for (const p of pending.values()) p.reject(new Error("worker_disposed"));
    pending.clear();
    worker.terminate();
  } };
}

// node_modules/@opace/content-integrity-core/dist/bundle.js
var K = new Uint32Array([
  1116352408,
  1899447441,
  3049323471,
  3921009573,
  961987163,
  1508970993,
  2453635748,
  2870763221,
  3624381080,
  310598401,
  607225278,
  1426881987,
  1925078388,
  2162078206,
  2614888103,
  3248222580,
  3835390401,
  4022224774,
  264347078,
  604807628,
  770255983,
  1249150122,
  1555081692,
  1996064986,
  2554220882,
  2821834349,
  2952996808,
  3210313671,
  3336571891,
  3584528711,
  113926993,
  338241895,
  666307205,
  773529912,
  1294757372,
  1396182291,
  1695183700,
  1986661051,
  2177026350,
  2456956037,
  2730485921,
  2820302411,
  3259730800,
  3345764771,
  3516065817,
  3600352804,
  4094571909,
  275423344,
  430227734,
  506948616,
  659060556,
  883997877,
  958139571,
  1322822218,
  1537002063,
  1747873779,
  1955562222,
  2024104815,
  2227730452,
  2361852424,
  2428436474,
  2756734187,
  3204031479,
  3329325298
]);
var rotr = (x, n) => x >>> n | x << 32 - n;
function utf8Bytes(value) {
  return new TextEncoder().encode(value);
}
function sha256Hex(value) {
  const source = utf8Bytes(value);
  const bitLength = source.length * 8;
  const paddedLength = Math.ceil((source.length + 9) / 64) * 64;
  const bytes = new Uint8Array(paddedLength);
  bytes.set(source);
  bytes[source.length] = 128;
  const view = new DataView(bytes.buffer);
  view.setUint32(paddedLength - 4, bitLength >>> 0, false);
  view.setUint32(paddedLength - 8, Math.floor(bitLength / 4294967296), false);
  const h = new Uint32Array([1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924, 528734635, 1541459225]);
  const w = new Uint32Array(64);
  for (let offset = 0; offset < paddedLength; offset += 64) {
    for (let i = 0; i < 16; i++) w[i] = view.getUint32(offset + i * 4, false);
    for (let i = 16; i < 64; i++) {
      const a2 = w[i - 15], b2 = w[i - 2];
      w[i] = (rotr(a2, 7) ^ rotr(a2, 18) ^ a2 >>> 3) + w[i - 16] + (rotr(b2, 17) ^ rotr(b2, 19) ^ b2 >>> 10) + w[i - 7] >>> 0;
    }
    let [a, b, c, d, e, f, g, hh] = h;
    for (let i = 0; i < 64; i++) {
      const s1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25);
      const ch = e & f ^ ~e & g;
      const t1 = hh + s1 + ch + K[i] + w[i] >>> 0;
      const s0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22);
      const maj = a & b ^ a & c ^ b & c;
      const t2 = s0 + maj >>> 0;
      hh = g;
      g = f;
      f = e;
      e = d + t1 >>> 0;
      d = c;
      c = b;
      b = a;
      a = t1 + t2 >>> 0;
    }
    h[0] = h[0] + a >>> 0;
    h[1] = h[1] + b >>> 0;
    h[2] = h[2] + c >>> 0;
    h[3] = h[3] + d >>> 0;
    h[4] = h[4] + e >>> 0;
    h[5] = h[5] + f >>> 0;
    h[6] = h[6] + g >>> 0;
    h[7] = h[7] + hh >>> 0;
  }
  return Array.from(h, (n) => n.toString(16).padStart(8, "0")).join("");
}
var prefixedSha256 = (value) => `sha256:${sha256Hex(value)}`;
var MSG_INVISIBLE = (what) => `An invisible ${what} is present.`;
var MSG_BIDI = "A bidirectional formatting control is present.";
var BIDI_LIMIT = "Bidirectional controls are required for correct display of mixed right-to-left and left-to-right text.";
var CARRIER_RULES = [
  // Soft hyphen and combining grapheme joiner
  { from: 173, name: "SOFT HYPHEN", severity: "low", fix: "remove", message: "A discretionary soft hyphen is present." },
  { from: 847, name: "COMBINING GRAPHEME JOINER", severity: "medium", fix: "remove", message: MSG_INVISIBLE("combining grapheme joiner"), limitation: "The combining grapheme joiner has rare legitimate uses in collation and diacritic ordering." },
  // Script-specific format characters
  { from: 1564, name: "ARABIC LETTER MARK", severity: "medium", fix: "review", message: MSG_BIDI, limitation: BIDI_LIMIT },
  { from: 1807, name: "SYRIAC ABBREVIATION MARK", severity: "medium", fix: "review", message: "A Syriac abbreviation mark format character is present.", limitation: "This character is legitimate inside Syriac-script text." },
  { from: 2192, to: 2193, name: (cp) => cp === 2192 ? "ARABIC POUND MARK ABOVE" : "ARABIC PIASTRE MARK ABOVE", severity: "medium", fix: "review", message: "An Arabic prepended format mark is present.", limitation: "This character is legitimate inside Arabic-script text." },
  { from: 2274, name: "ARABIC DISPUTED END OF AYAH", severity: "medium", fix: "review", message: "An Arabic prepended format mark is present.", limitation: "This character is legitimate inside Arabic-script text." },
  { from: 6155, to: 6157, name: (cp) => `MONGOLIAN FREE VARIATION SELECTOR-${cp - 6154}`, severity: "medium", fix: "remove", message: MSG_INVISIBLE("Mongolian free variation selector"), context: "variation", limitation: "Free variation selectors are legitimate inside Mongolian-script text." },
  { from: 6158, name: "MONGOLIAN VOWEL SEPARATOR", severity: "medium", fix: "remove", message: MSG_INVISIBLE("Mongolian vowel separator"), limitation: "This character is legitimate inside Mongolian-script text." },
  { from: 6159, name: "MONGOLIAN FREE VARIATION SELECTOR-4", severity: "medium", fix: "remove", message: MSG_INVISIBLE("Mongolian free variation selector"), context: "variation", limitation: "Free variation selectors are legitimate inside Mongolian-script text." },
  // Zero-width and joining controls
  { from: 8203, name: "ZERO WIDTH SPACE", severity: "medium", fix: "remove", message: MSG_INVISIBLE("zero-width space") },
  { from: 8204, name: "ZERO WIDTH NON-JOINER", severity: "medium", fix: "remove", message: MSG_INVISIBLE("zero-width non-joiner"), context: "joiner", limitation: "The zero-width non-joiner is standard orthography in Persian and several Indic languages." },
  { from: 8205, name: "ZERO WIDTH JOINER", severity: "medium", fix: "remove", message: MSG_INVISIBLE("zero-width joiner"), context: "joiner", limitation: "The zero-width joiner is standard in emoji sequences and several complex scripts." },
  // Bidirectional controls
  { from: 8206, name: "LEFT-TO-RIGHT MARK", severity: "medium", fix: "review", message: MSG_BIDI, limitation: BIDI_LIMIT },
  { from: 8207, name: "RIGHT-TO-LEFT MARK", severity: "medium", fix: "review", message: MSG_BIDI, limitation: BIDI_LIMIT },
  { from: 8234, to: 8238, name: (cp) => ["LEFT-TO-RIGHT EMBEDDING", "RIGHT-TO-LEFT EMBEDDING", "POP DIRECTIONAL FORMATTING", "LEFT-TO-RIGHT OVERRIDE", "RIGHT-TO-LEFT OVERRIDE"][cp - 8234], severity: "medium", fix: "review", message: MSG_BIDI, limitation: BIDI_LIMIT },
  { from: 8294, to: 8297, name: (cp) => ["LEFT-TO-RIGHT ISOLATE", "RIGHT-TO-LEFT ISOLATE", "FIRST STRONG ISOLATE", "POP DIRECTIONAL ISOLATE"][cp - 8294], severity: "medium", fix: "review", message: MSG_BIDI, limitation: BIDI_LIMIT },
  // Word joiner, invisible operators and deprecated format characters
  { from: 8288, name: "WORD JOINER", severity: "medium", fix: "remove", message: MSG_INVISIBLE("word joiner") },
  { from: 8289, to: 8292, name: (cp) => ["FUNCTION APPLICATION", "INVISIBLE TIMES", "INVISIBLE SEPARATOR", "INVISIBLE PLUS"][cp - 8289], severity: "medium", fix: "remove", message: MSG_INVISIBLE("mathematical operator character"), limitation: "Invisible operators are legitimate inside machine-generated mathematical notation." },
  { from: 8298, to: 8303, name: (cp) => ["INHIBIT SYMMETRIC SWAPPING", "ACTIVATE SYMMETRIC SWAPPING", "INHIBIT ARABIC FORM SHAPING", "ACTIVATE ARABIC FORM SHAPING", "NATIONAL DIGIT SHAPES", "NOMINAL DIGIT SHAPES"][cp - 8298], severity: "medium", fix: "remove", message: "A deprecated invisible format character is present.", limitation: "These characters are deprecated by Unicode and have no place in modern interchange text." },
  // BOM, interlinear annotation, replacement
  { from: 65279, name: "BYTE ORDER MARK", severity: "low", fix: "remove", message: "A byte-order mark is present." },
  { from: 65529, to: 65531, name: (cp) => ["INTERLINEAR ANNOTATION ANCHOR", "INTERLINEAR ANNOTATION SEPARATOR", "INTERLINEAR ANNOTATION TERMINATOR"][cp - 65529], severity: "medium", fix: "review", message: "An interlinear annotation control is present.", limitation: "Interlinear annotation controls are legitimate in Japanese ruby markup pipelines." },
  { from: 65533, name: "REPLACEMENT CHARACTER", severity: "high", fix: "review", message: "A replacement character may indicate damaged text." },
  // Supplementary-plane format characters
  { from: 69821, name: "KAITHI NUMBER SIGN", severity: "medium", fix: "review", message: "A Kaithi number-sign format character is present.", limitation: "This character is legitimate inside Kaithi-script text." },
  { from: 69837, name: "KAITHI NUMBER SIGN ABOVE", severity: "medium", fix: "review", message: "A Kaithi number-sign format character is present.", limitation: "This character is legitimate inside Kaithi-script text." },
  // Tag characters: the classic covert payload carrier
  { from: 917505, name: "LANGUAGE TAG", severity: "high", fix: "remove", message: "A deprecated invisible language tag is present." },
  { from: 917536, to: 917631, name: (cp) => cp === 917631 ? "CANCEL TAG" : `TAG ${String.fromCodePoint(cp - 917504) === " " ? "SPACE" : `CHARACTER '${String.fromCodePoint(cp - 917504)}'`}`, severity: "high", fix: "remove", message: "An invisible tag character is present; tag runs are a known covert payload carrier.", limitation: "Tag characters have no legitimate use in ordinary interchange text outside emoji flag sequences." },
  // Variation selectors
  { from: 65024, to: 65039, name: (cp) => `VARIATION SELECTOR-${cp - 65024 + 1}`, severity: "medium", fix: "remove", message: MSG_INVISIBLE("variation selector"), context: "variation", limitation: "Variation selectors are legitimate after emoji-capable and CJK base characters." },
  { from: 917760, to: 917999, name: (cp) => `VARIATION SELECTOR-${cp - 917760 + 17}`, severity: "medium", fix: "review", message: MSG_INVISIBLE("supplementary variation selector"), context: "variation_sup", limitation: "Supplementary variation selectors are legitimate after CJK ideographs to select registered glyph variants." },
  // Space separators beyond U+0020
  { from: 160, name: "NO-BREAK SPACE", severity: "note", fix: "space", message: "A non-breaking space is present.", limitation: "Non-breaking spaces are standard French and general typographic practice." },
  { from: 5760, name: "OGHAM SPACE MARK", severity: "low", fix: "space", message: "An unusual space character is present.", limitation: "This character is legitimate inside Ogham-script text." },
  { from: 8192, to: 8200, name: (cp) => ["EN QUAD", "EM QUAD", "EN SPACE", "EM SPACE", "THREE-PER-EM SPACE", "FOUR-PER-EM SPACE", "SIX-PER-EM SPACE", "FIGURE SPACE", "PUNCTUATION SPACE"][cp - 8192], severity: "low", fix: "space", message: "A typographic space that substitutes for an ordinary space is present.", limitation: "Fixed-width spaces are legitimate in carefully typeset material." },
  { from: 8201, name: "THIN SPACE", severity: "note", fix: "space", message: "A thin space is present.", limitation: "Thin spaces are standard French and general typographic practice." },
  { from: 8202, name: "HAIR SPACE", severity: "low", fix: "space", message: "A hair space that substitutes for an ordinary space is present.", limitation: "Hair spaces are legitimate in carefully typeset material." },
  { from: 8239, name: "NARROW NO-BREAK SPACE", severity: "note", fix: "space", message: "A narrow no-break space is present.", limitation: "Narrow no-break spaces are standard French punctuation spacing and appear in Mongolian text." },
  { from: 8287, name: "MEDIUM MATHEMATICAL SPACE", severity: "note", fix: "space", message: "A medium mathematical space is present.", limitation: "This space is legitimate inside typeset mathematical notation." },
  { from: 12288, name: "IDEOGRAPHIC SPACE", severity: "note", fix: "space", message: "An ideographic space is present.", limitation: "Ideographic spaces are standard in Chinese and Japanese text." },
  // Line and paragraph separators
  { from: 8232, name: "LINE SEPARATOR", severity: "low", fix: "review", message: "A Unicode line separator is present instead of a conventional line break." },
  { from: 8233, name: "PARAGRAPH SEPARATOR", severity: "low", fix: "review", message: "A Unicode paragraph separator is present instead of a conventional line break." }
];
var TABLE = /* @__PURE__ */ new Map();
for (const rule of CARRIER_RULES) {
  for (let cp = rule.from; cp <= (rule.to ?? rule.from); cp++) {
    TABLE.set(cp, { name: typeof rule.name === "function" ? rule.name(cp) : rule.name, severity: rule.severity, fix: rule.fix, message: rule.message, context: rule.context, limitation: rule.limitation });
  }
}
var NAME_STOPLIST = new Set("The A An This That These Those It He She They We You I In On At For To From With By Of And But Or Nor If As Is Are Was Were Be Been Not No Yes See Run New Our Your Their His Her Its My Do Does Did Will Would Can Could Should May Might Must Have Has Had So Then There Here What Which Who Whose When Where Why How All Any Each Per Both More Most Some Such Other Also Just Only Now Today Yesterday Tomorrow Please Note".split(" "));
var TIER1 = {
  "delve": "explore, dig into, look at",
  "tapestry": "describe the actual complexity",
  "paradigm": "model, approach, framework",
  "beacon": "rewrite entirely",
  "robust": "strong, reliable, solid",
  "comprehensive": "thorough, complete, full",
  "cutting-edge": "latest, newest, advanced",
  "pivotal": "important, key, critical",
  "meticulous": "careful, detailed, precise",
  "meticulously": "carefully, precisely",
  "seamless": "smooth, easy, without friction",
  "seamlessly": "smoothly, easily",
  "game-changer": "describe what changed",
  "game-changing": "describe what changed",
  "nestled": "is located, sits",
  "vibrant": "describe what makes it active",
  "thriving": "growing, active",
  "bustling": "busy, active",
  "intricate": "complex, detailed",
  "intricacies": "complexities, details",
  "ever-evolving": "changing, growing",
  "enduring": "lasting, long-running",
  "daunting": "hard, difficult",
  "holistic": "complete, full, whole",
  "holistically": "completely, fully",
  "actionable": "practical, useful, concrete",
  "impactful": "effective, significant",
  "learnings": "lessons, findings, takeaways",
  "synergy": "describe the combined effect",
  "synergies": "describe the combined effect",
  "interplay": "relationship, connection",
  "symphony": "describe the coordination",
  "embrace": "adopt, accept, use",
  // 2026.08.3 owner-docs tier A additions (OWNER-DOCS-TELLS.md §8).
  "enigma": "mystery, puzzle",
  "labyrinth": "maze, tangle",
  "top-notch": "excellent, first-rate"
};
var TIER2 = {
  "harness": "use, take advantage of",
  "navigate": "work through, handle",
  "navigating": "working through, handling",
  "foster": "encourage, support, build",
  "elevate": "improve, raise, strengthen",
  "unleash": "release, enable, unlock",
  "streamline": "simplify, speed up",
  "empower": "enable, let, allow",
  "bolster": "support, strengthen",
  "spearhead": "lead, drive, run",
  "resonate": "connect with, appeal to",
  "resonates": "connects with, appeals to",
  "revolutionize": "change, transform",
  "facilitate": "enable, help, allow",
  "facilitates": "enables, helps, allows",
  "underpin": "support, form the basis of",
  "nuanced": "specific, subtle, detailed",
  "crucial": "important, key, necessary",
  "multifaceted": "describe the actual facets",
  "ecosystem": "system, community, network",
  "myriad": "many, numerous",
  "plethora": "many, a lot of",
  "encompass": "include, cover, span",
  "catalyze": "start, trigger, accelerate",
  "reimagine": "rethink, redesign, rebuild",
  "galvanize": "motivate, rally, push",
  "augment": "add to, expand, supplement",
  "cultivate": "build, develop, grow",
  "illuminate": "clarify, explain, show",
  "elucidate": "explain, clarify",
  "juxtapose": "compare, contrast",
  "transformative": "describe what changed",
  "transformation": "describe what changed",
  "cornerstone": "foundation, basis, key part",
  "paramount": "most important, top priority",
  "poised": "ready, set, about to",
  "burgeoning": "growing, emerging",
  "nascent": "new, early-stage",
  "quintessential": "typical, classic, defining",
  "overarching": "main, central, broad",
  "quietly": "cut, or name the concrete contrast",
  "underpinning": "basis, foundation",
  "underpinnings": "basis, foundations",
  "paradigm-shifting": "describe what shifted",
  // 2026.08.3 owner-docs additions (medium FP → cluster-scored tier 2).
  "revolutionary": "describe what changed",
  "ai-powered": "say what the AI part actually does"
};
var TIER3 = [
  "significant",
  "significantly",
  "innovative",
  "innovation",
  "effective",
  "effectively",
  "dynamic",
  "dynamics",
  "scalable",
  "scalability",
  "compelling",
  "unprecedented",
  "exceptional",
  "exceptionally",
  "remarkable",
  "remarkably",
  "sophisticated",
  "instrumental",
  "world-class",
  "state-of-the-art",
  "best-in-class",
  "verbatim"
];
var ISSUE_WEIGHTS = {
  "tier1": 5,
  "tier1-clarity": 3,
  "tier2": 3,
  "tier3": 2,
  "transition": 2,
  "chatbot": 8,
  "sycophantic": 8,
  "filler": 2,
  "generic-conclusion": 3,
  "lets-construction": 2,
  "reasoning-artifact": 6,
  "acknowledgment-loop": 3,
  "significance-inflation": 4,
  "vague-attribution": 5,
  "hollow-intensifier": 2,
  "emotional-flatline": 2,
  "lingering-attention": 3,
  "novelty-inflation": 3,
  "cutoff-disclaimer": 10,
  "template-phrase": 3,
  "false-concession": 2,
  "rhetorical-question": 2,
  "confidence-calibration": 2,
  "em-dash-density": 4,
  "not-just-contrast": 6,
  "uniform-sections": 5,
  "uniform-list-items": 4,
  "sentence-flatline": 5,
  "uniformity": 5,
  "formatting": 3,
  "tier3-phrase": 3,
  "tier3-phrase-cluster": 12,
  "hashtag-stuff": 12,
  "bullet-np-list": 10,
  "hedge-stack": 6,
  "future-narrative": 12,
  "real-actual-inflation": 5,
  "social-cta-closer": 8,
  "formulaic-opener": 8,
  "speculative-opener": 8,
  "title-case-header": 4,
  "parenthetical-hedge": 3,
  "smart-punct-signature": 6,
  "punct-distribution": 6,
  "fnword-trigram-entropy": 5,
  "cross-para-burstiness": 5,
  "normalization-flag": 9,
  "low-ttr": 3,
  "ai-placeholder": 10,
  "ai-citation-markup": 15,
  "ai-utm-source": 12
};
var CATEGORY_META = {
  "tier1": { severity: "high", message: 'A word that turns up a lot in generic machine-written copy, like "delve", "robust" or "seamless".', suggestion: "Swap it for a plainer word." },
  "tier1-clarity": { severity: "medium", message: 'This is a long way of saying something short, like "in order to" for "to", or "due to the fact that" for "because".', suggestion: "Use the shorter form." },
  "tier2": { severity: "medium", message: 'Several buzzwords sit in one paragraph, words like "foster", "facilitate" and "ecosystem". One is fine. A pile of them reads as filler.', suggestion: "Keep one at most, and say the plain thing instead." },
  "tier3": { severity: "low", message: 'A vague filler word such as "significant", "effective" or "dynamic" is used a lot for a piece this long.', suggestion: "Cut some of them, or say what you actually mean." },
  "transition": { severity: "medium", message: 'A joining phrase that could link any two sentences, like "Moreover", "Furthermore" or "In conclusion".', suggestion: "Cut it, or say how the two sentences really connect." },
  "chatbot": { severity: "high", message: 'A line from a chat window is still in the text, like "I hope this helps" or "Certainly!".', suggestion: "Delete it." },
  "sycophantic": { severity: "high", message: `A compliment aimed at the reader's question, the way a chatbot opens a reply: "Great question!".`, suggestion: "Delete it and go straight to the point." },
  "filler": { severity: "medium", message: "A phrase that adds words but no meaning.", suggestion: "Cut it. The sentence almost always still works." },
  "generic-conclusion": { severity: "medium", message: 'A closing line that could end any article, like "only time will tell" or "the future looks bright".', suggestion: "End on something specific instead." },
  "lets-construction": { severity: "medium", message: `A "let's take a look at\u2026" line, the way a tutorial talks to you.`, suggestion: "Just say the thing. Do not announce it first." },
  "reasoning-artifact": { severity: "high", message: 'Step-by-step working is still showing, like "First, let me\u2026" or "Step 1:".', suggestion: "Delete the working and keep the answer." },
  "acknowledgment-loop": { severity: "medium", message: 'The text repeats the question back before answering it: "You asked about X. X is\u2026".', suggestion: "Answer straight away." },
  "significance-inflation": { severity: "high", message: 'A stock line telling the reader how big something was, instead of saying what happened: "marking a pivotal moment".', suggestion: "Say what happened and let the reader judge." },
  "vague-attribution": { severity: "high", message: 'A claim is credited to nobody in particular: "experts say", "studies show".', suggestion: "Name the study or the person, or drop the claim." },
  "hollow-intensifier": { severity: "medium", message: 'An emphasis word that adds no information, like "truly", "incredibly" or "absolutely".', suggestion: "Cut it." },
  "emotional-flatline": { severity: "low", message: 'A ready-made feeling word stands in for a real reaction, like "fascinating" or "surprising".', suggestion: "Say what was actually surprising, or cut it." },
  "lingering-attention": { severity: "medium", message: 'A share-post line about how long an idea stayed with you, which tells the reader nothing about the idea: "this stuck with me for days".', suggestion: "Say why it matters instead." },
  "novelty-inflation": { severity: "medium", message: 'The text announces that it is about to say something rare: "few people realise".', suggestion: "Show the point. Do not advertise it." },
  "cutoff-disclaimer": { severity: "high", message: 'A line where a chatbot describes itself or its training cut-off, like "as of my last update" or "as an AI language model".', suggestion: "Delete it, and check the facts around it yourself." },
  "template-phrase": { severity: "high", message: "A ready-made phrase that turns up in a lot of generated copy.", suggestion: "Replace it with something specific to your subject." },
  "false-concession": { severity: "medium", message: `A formula that pretends to give ground before making the point: "while it's true that\u2026".`, suggestion: "Name the real trade-off, or drop it." },
  "rhetorical-question": { severity: "medium", message: 'A question the writer asks and then answers: "So what does this mean?".', suggestion: "Give the answer without asking first." },
  "confidence-calibration": { severity: "low", message: 'Words like "clearly", "certainly" and "undoubtedly" pile up across the text.', suggestion: "Keep the one or two you have earned and cut the rest." },
  "em-dash-density": { severity: "medium", message: "Em dashes (\u2014), or spaced hyphens used as dashes, turn up a lot for a piece this long. Worth knowing: since OpenAI cut back on em dashes in late 2025, heavy dash use is more common in Claude's writing than in machine writing generally, and plenty of professional human writers use more dashes than this.", suggestion: "Swap some for commas, colons or full stops." },
  "not-just-contrast": { severity: "high", message: `The "it isn't just X, it's Y" shape.`, suggestion: "Say what it is, without the set-up." },
  "uniform-sections": { severity: "medium", message: "Every section is close to the same length. Real writing runs long in places and short in others.", suggestion: "Let each section be as long as its content needs." },
  "uniform-list-items": { severity: "medium", message: "The list items are all close to the same length. Real lists are lumpy.", suggestion: "Let some items run shorter or longer, or merge ones that repeat." },
  "sentence-flatline": { severity: "medium", message: "Sentence lengths barely change across the whole piece. Real writing swings between short and long.", suggestion: "Mix a few short, punchy sentences in with the longer ones." },
  "uniformity": { severity: "medium", message: "The paragraphs are all close to the same size.", suggestion: "Make some paragraphs shorter or longer on purpose." },
  "formatting": { severity: "medium", message: "A lot of bold is used.", suggestion: "Take the bold off most phrases, and put the important thing first." },
  "tier3-phrase": { severity: "medium", message: "The same stock phrase keeps coming back through the text.", suggestion: "Replace at least one of them with something concrete." },
  "tier3-phrase-cluster": { severity: "high", message: "Several different stock phrases are stacked up in one piece.", suggestion: "Rewrite it around one real point." },
  "hashtag-stuff": { severity: "medium", message: "A long block of hashtags.", suggestion: "Cut to two or three that fit, or none." },
  "bullet-np-list": { severity: "high", message: "A long bullet list where every item is a bare noun phrase with no verb.", suggestion: "Turn it into a paragraph, or join the items up." },
  "hedge-stack": { severity: "high", message: 'Two hedges on the same claim, like "may potentially" or "could possibly".', suggestion: "Pick one hedge, or make a claim someone could check." },
  "future-narrative": { severity: "high", message: 'A vague line about the future that nobody could ever check: "is set to reshape the industry".', suggestion: "Say something concrete a reader could test." },
  "real-actual-inflation": { severity: "medium", message: '"Real" or "actual" is doing no work here, as in "real value" or "actual impact".', suggestion: "Cut the word, or say what makes it real." },
  "social-cta-closer": { severity: "high", message: 'A closing line begging for engagement: "What do you think? Let me know below."', suggestion: "Give the reader a reason to care instead of an instruction." },
  "formulaic-opener": { severity: "high", message: `A stock opening line that would fit any article: "In today's fast-paced world\u2026".`, suggestion: "Open on a fact or a specific detail." },
  "speculative-opener": { severity: "high", message: 'The piece opens by asking you to picture a scene: "Imagine a world where\u2026".', suggestion: "Make the point directly." },
  "title-case-header": { severity: "medium", message: "The heading puts a capital on nearly every word, the way a lot of marketing copy does.", suggestion: "Capitalise the first word only, as you would in a sentence." },
  "parenthetical-hedge": { severity: "medium", message: 'An aside in brackets that sounds thoughtful and adds nothing: "(at least in most cases)".', suggestion: "Cut it, or make it a proper sentence." },
  "smart-punct-signature": { severity: "high", message: "Curly quotes, an em dash, an Oxford comma and no typos, all in one piece. That combination is rare in text somebody typed straight out by hand.", suggestion: "Nothing to fix. This is just something we noticed." },
  "punct-distribution": { severity: "medium", message: "Every paragraph uses about the same amount of punctuation.", suggestion: "Let some paragraphs run busier than others." },
  "fnword-trigram-entropy": { severity: "medium", message: "Sentences are built to the same grammar pattern again and again.", suggestion: "Change the way you build some of the sentences." },
  "cross-para-burstiness": { severity: "medium", message: "Every paragraph has the same inner rhythm of long and short sentences.", suggestion: "Let some paragraphs be clipped and others rambling." },
  "normalization-flag": { severity: "high", message: "The text held invisible characters or lookalike letters, the kind used to hide copied text from checkers. We swapped them back before reading it.", suggestion: "Take the hidden characters out and check the text again." },
  "low-ttr": { severity: "low", message: "The same words come round a lot for a piece this long.", suggestion: "Vary the nouns and verbs, unless the subject really does need the repeating." },
  "ai-placeholder": { severity: "high", message: 'A blank somebody forgot to fill in is still here, like "[INSERT NAME]".', suggestion: "Fill it in or delete it before this goes out." },
  "ai-citation-markup": { severity: "high", message: "Chatbot citation code was pasted in along with the text.", suggestion: "Delete it and put a real reference in its place." },
  "ai-utm-source": { severity: "high", message: 'A link carries a tracking tag that AI tools add to the links they hand out, like "utm_source=chatgpt.com".', suggestion: "Strip the tracking part off the link." }
};
var V3_ISSUE_WEIGHTS = {
  // artefact forensics
  "ai-citation-token": 15,
  "reasoning-leak": 12,
  "placeholder-token": 10,
  "pua-character": 14,
  "math-alphanumeric": 12,
  "arrow-decoration": 4,
  "escaped-markup-literal": 3,
  // tier A phrase/structural
  "neg-parallelism": 5,
  "tripled-negation": 5,
  "despite-challenges-arc": 5,
  "metaphor-cluster": 4,
  "participial-tail": 5,
  "focal-density": 5,
  "owner-phrase": 5,
  "power-verb-compound": 6,
  "outcome-tail": 4,
  "conclusion-cta": 6,
  // tier B (low weights; corroboration)
  "liang-cluster": 2,
  "kobak-density": 2,
  "promo-travel": 2,
  "pivotal-role": 2,
  "legacy-framing": 3,
  "notability-canned": 2,
  "buzzword-phrase": 2,
  "faux-insight": 2,
  "rhetorical-qa": 2,
  "didactic-note": 2,
  "narrative-cliche": 3,
  "valuable-insights": 2,
  "copula-avoidance": 3,
  "bold-label-bullets": 3,
  "emoji-decoration": 2,
  "heading-inflation": 3,
  "staccato-fragments": 3,
  "tricolon-density": 2,
  "transition-stacking": 3,
  "quote-inconsistency": 2,
  "token-cutoff": 2,
  "setup-expansion-cadence": 3,
  "passive-ratio": 3,
  "low-specificity": 2,
  "adjacent-lemma-repeat": 3,
  "fiction-claudeism": 3,
  "fiction-promptonym": 3,
  "fiction-slop-phrase": 2,
  "owner-phrase-b": 2,
  "owner-vocab-b": 2,
  "directive-colon-bullets": 3,
  "teach-preach-headings": 2,
  "by-ving-template": 3,
  "invalid-isbn": 3,
  "proximity-cluster": 2,
  // 2026.08.6 furniture rules (low weights; the escalation floors carry the
  // detection, and the weights stay small so furniture cannot fake breadth).
  "markdown-bold": 3,
  "markdown-heading": 3,
  "markdown-furniture": 4
};
var PASTE = "This only shows up when chat formatting survives the paste. If an editor stripped the formatting, the check finds nothing, which says nothing either way.";
var FORMAL = "Formal writing, and writing by people whose first language is not English, can read this way too.";
var V3_CATEGORY_META = {
  "ai-citation-token": { severity: "high", message: "A chatbot's own citation code is sitting in the text. The code itself says which chatbot it came from.", suggestion: "Delete the code and put a real reference in its place." },
  "reasoning-leak": { severity: "high", message: 'Parts of this text talk about the writing job itself, the kind of notes an AI leaves in its answer, like "as requested" or "let me revise".', suggestion: "Delete those notes and keep the finished writing." },
  "placeholder-token": { severity: "high", message: 'A machine placeholder is still in the text, something like "{{name}}" or "<insert>".', suggestion: "Fill it in or delete it before this goes out." },
  "pua-character": { severity: "high", message: "The text holds characters from a private corner of Unicode that has no agreed meaning. ChatGPT wraps its citation codes in these. Icon fonts are the only other common reason for them.", suggestion: "Delete them, and look for chatbot citation codes next to them." },
  "math-alphanumeric": { severity: "high", message: "Fake bold or italic letters built from maths symbols (\u{1D5F9}\u{1D5F6}\u{1D5F8}\u{1D5F2} \u{1D601}\u{1D5F5}\u{1D5F6}\u{1D600}). They come from chatbot copy-paste and social-media text formatters.", suggestion: "Retype them as ordinary letters and use real bold or italic." },
  "arrow-decoration": { severity: "medium", message: 'Arrows stand in for words again and again: "input \u2192 output \u2192 result".', suggestion: "Write the connection out in words." },
  "escaped-markup-literal": { severity: "low", message: 'A stray scrap of code is showing through the text, like "&nbsp;" or "\\n". It usually comes from pasting out of a chat window.', suggestion: "Delete it." },
  "neg-parallelism": { severity: "medium", message: 'The "not only X but Y" shape comes back more than once.', suggestion: "Keep one. Say the rest plainly." },
  "tripled-negation": { severity: "medium", message: 'The "Not X. Not Y. Just Z." shape.', suggestion: "Say what it is, without the three-part build-up." },
  "despite-challenges-arc": { severity: "medium", message: 'The stock "despite challenges, it continues to thrive" story shape.', suggestion: "Name the real problem and what was really done about it." },
  "metaphor-cluster": { severity: "medium", message: 'Several worn-out picture words are stacked together: "tapestry", "interplay", "evolving landscape", "testament to".', suggestion: "Say the plain facts they are standing in for." },
  "participial-tail": { severity: "medium", message: 'Sentences keep ending with a tacked-on "-ing" clause that tells you why it mattered: ", highlighting the need for\u2026", ", underscoring the importance of\u2026". That ending turns up several times more often in machine writing than in human writing.', suggestion: "Stop the sentence at the fact. Cut the tail, or turn it into a claim you can source." },
  "focal-density": { severity: "medium", message: 'A lot of words from the AI-favourite list turn up here: "delve", "showcase", "pivotal", "meticulous". Any one of them is normal English. It is how many there are that stands out.', suggestion: "Swap most of them for plainer verbs and adjectives." },
  "owner-phrase": { severity: "medium", message: "A ready-made phrase from the generic-writing phrasebook.", suggestion: "Replace it with something specific to your subject." },
  "power-verb-compound": { severity: "high", message: 'A big verb glued to a vague adjective: "leverage a robust solution", "ensure seamless delivery". It sounds like value and says nothing.', suggestion: "Name the real action and the thing you can measure." },
  "outcome-tail": { severity: "medium", message: 'The sentence trails off into a vague result: ", leading to increased engagement".', suggestion: "Say the exact result, or cut the tail." },
  "conclusion-cta": { severity: "high", message: 'The stock marketing sign-off: "by following these steps you can boost\u2026".', suggestion: "Close on something specific, not a general promise." },
  "liang-cluster": { severity: "low", message: 'Several judgement words from the AI-overuse lists sit close together, like "crucial", "notable" and "significant".', suggestion: "Keep the judgements you can back up with detail." },
  "kobak-density": { severity: "low", message: "Several words sit here that turned up far more often in machine writing when a large body of text was counted.", suggestion: "Vary the words, or back the claims with detail." },
  "promo-travel": { severity: "low", message: 'Brochure words are bunched together: "nestled", "breathtaking", "hidden gem". They stand out most when the piece is not a travel brochure.', suggestion: "Describe the place or the product with real detail." },
  "pivotal-role": { severity: "low", message: 'The "plays a crucial role in shaping" formula.', suggestion: "Say what it actually does." },
  "legacy-framing": { severity: "low", message: 'Several grand phrases about legacy and importance are stacked up: "enduring legacy", "pivotal moment".', suggestion: "Let the events speak for themselves." },
  "notability-canned": { severity: "low", message: 'A canned line about how well known something is: "profiled in multiple outlets".', suggestion: "Name the outlets, or drop the claim." },
  "buzzword-phrase": { severity: "low", message: 'A stock office phrase: "harness the power of", "at the forefront of".', suggestion: "Say what it can actually do." },
  "faux-insight": { severity: "low", message: `A line promising a secret: "here's what nobody tells you".`, suggestion: "Show the point. Do not announce it." },
  "rhetorical-qa": { severity: "low", message: 'The "The result? X." trick keeps coming back.', suggestion: "Use it once at most." },
  "didactic-note": { severity: "low", message: `A teacherly disclaimer: "it's important to understand", "results may vary".`, suggestion: "Cut it, or make it specific." },
  "narrative-cliche": { severity: "low", message: 'A worn-out story phrase: "faced numerous challenges", "a poignant reminder".', suggestion: "Say what actually happened." },
  "valuable-insights": { severity: "low", message: 'A stock academic filler phrase: "provides valuable insights into".', suggestion: "State the insight itself." },
  "copula-avoidance": { severity: "low", message: 'The text keeps dodging plain "is" and "has" in favour of "serves as", "stands as" and "functions as". ' + FORMAL, suggestion: 'Use "is" and "has" where they fit.' },
  "bold-label-bullets": { severity: "low", message: 'A run of bullets all shaped "**Label:** description". Technical documents use this shape too.', suggestion: "Turn it into sentences, or vary the shape of the items." },
  "emoji-decoration": { severity: "low", message: "Emoji are used on headings or bullets. That is a chat-window habit in a piece of business writing.", suggestion: "Take the decorative emoji out of this kind of writing." },
  "heading-inflation": { severity: "low", message: "There are a lot of headings for the amount of writing under them. SEO advice produces the same shape.", suggestion: "Merge sections whose body is only a sentence or two." },
  "staccato-fragments": { severity: "low", message: "A run of very short, punchy fragments. Ad copy does this on purpose too.", suggestion: "Join some of them into full sentences." },
  "tricolon-density": { severity: "low", message: 'Three-part lists such as "faster, cheaper, simpler" turn up a lot for a piece this long.', suggestion: "Break the pattern: use two items, or four." },
  "transition-stacking": { severity: "low", message: 'Most paragraphs open on a formal joining word: "Furthermore", "Moreover", "Additionally". ' + FORMAL, suggestion: "Let the content do the joining in most paragraphs." },
  "quote-inconsistency": { severity: "low", message: "Curly and straight quotation marks are mixed together. That usually comes from pasting out of a chat window, though word processors do it too.", suggestion: "Make the quotation marks match, either way round." },
  "token-cutoff": { severity: "low", message: "The text stops in the middle of a sentence, the shape of an answer that ran out of room, or a paste that went wrong.", suggestion: "Finish the last sentence, or delete it." },
  "setup-expansion-cadence": { severity: "low", message: "Short sentence, then long one, over and over, or the other way round. " + FORMAL, suggestion: "Keep the pattern only where the short sentence works on its own." },
  "passive-ratio": { severity: "low", message: 'A lot of the sentences hide who did the thing: "mistakes were made". That is high for a blog or a marketing piece. Academic writing does it constantly. ' + FORMAL, suggestion: "Rewrite most sentences so the person or thing doing it comes first." },
  "low-specificity": { severity: "low", message: "Almost no numbers, dates or names for a piece this long. Corporate writers produce empty writing too.", suggestion: "Add facts a reader could go and check." },
  "adjacent-lemma-repeat": { severity: "low", message: "Neighbouring sentences keep reusing the same word. " + FORMAL, suggestion: "Merge the repetitive sentences, or change the wording where it reads naturally." },
  "fiction-claudeism": { severity: "low", message: "Phrases that turn up a lot in Claude's fiction writing. Romance authors use several of them quite normally.", suggestion: "Put the stock phrases into your own words." },
  "fiction-promptonym": { severity: "low", message: 'A character name that AI writing produces far more often than people do. "Elara Voss" is the best-known one.', suggestion: "Pick a less loaded name if you want one." },
  "fiction-slop-phrase": { severity: "low", message: "Several well-worn fiction lines land in the same piece. All of them were human clich\xE9s long before AI.", suggestion: "Cut or rework the stock moments." },
  "owner-phrase-b": { severity: "low", message: "A phrase from the second generic-writing phrasebook.", suggestion: "Replace it with something specific." },
  "owner-vocab-b": { severity: "low", message: 'Several second-string filler words sit close together: "essence", "facet", "pesky", "folks".', suggestion: "Swap them for plainer words where they add nothing." },
  "directive-colon-bullets": { severity: "low", message: 'Several list items open on an order and a colon: "Ensure X:", "Optimise Y:". Real technical checklists look like this too.', suggestion: "Vary the way the items are built." },
  "teach-preach-headings": { severity: "low", message: 'Stock tutorial headings hold the piece together: "Why it matters", "Final thoughts", "Key takeaways".', suggestion: "Name each section after what is actually in it." },
  "by-ving-template": { severity: "low", message: 'The "By doing X, you can Y" shape keeps coming back.', suggestion: "Say the benefit straight out most of the time." },
  "invalid-isbn": { severity: "low", message: "An ISBN in the text does not add up. Made-up references often fail this check, and so do typos.", suggestion: "Check the reference against the real book." },
  "proximity-cluster": { severity: "low", message: "The same flagged buzzword comes back within a sentence or two.", suggestion: "Keep one use at most in each passage." },
  // 2026.08.6 chat-formatting rules. Each one states the paste caveat: the
  // check can only see formatting that survived the paste, so its ABSENCE says
  // nothing about who wrote the text.
  "markdown-bold": { severity: "low", message: "Raw **bold** markdown is showing in the text. None of the 169 human-written documents we checked had it. " + PASTE, suggestion: "Delete the stars, or apply real bold." },
  "markdown-heading": { severity: "low", message: "A raw markdown heading line, the kind that starts with # signs, is showing in the text. None of the 169 human-written documents we checked had one. " + PASTE, suggestion: "Turn it into a real heading, or delete it." },
  "markdown-furniture": { severity: "low", message: "Chat-window formatting shapes this text: runs of bold, heading lines, or a wall of bullets. None of the 169 human-written documents we checked had that combination. " + PASTE, suggestion: "Rebuild the formatting properly for wherever this is going." }
};
var V4_ISSUE_WEIGHTS = {
  "sentence-length-spectral-flatness": 2,
  "conditional-compression": 2,
  "lexical-register-distance": 2,
  "punchline-fragment-density": 2,
  "mic-drop-paragraph": 2,
  "contrast-density": 2,
  "rhetorical-procedural-ratio": 2
};
var V4_CATEGORY_META = {
  "sentence-length-spectral-flatness": {
    severity: "low",
    message: "Sentence lengths follow a pattern that is more regular than most writing this long. We only measure it on fixed-size chunks, so short pieces are skipped. Careful human editing produces the same shape.",
    suggestion: "Nothing to change unless the other checks agree. Varying sentence length is a choice, not a rule."
  },
  "conditional-compression": {
    severity: "low",
    message: "Held up against a sample of varied human writing, this text has less in common with it than most. Copy written to a tight template scores the same way.",
    suggestion: "Nothing to change on its own. If the other checks agree, vary phrasing you have repeated."
  },
  "lexical-register-distance": {
    severity: "low",
    message: "The mix of small joining words, and the length of the words, sits a long way from our sample of everyday human writing. Worth knowing: that sample is general writing, so academic, legal and technical pieces land far away quite fairly.",
    suggestion: "Nothing to change on its own. Plainer wording moves it closer if the other checks agree."
  },
  "punchline-fragment-density": {
    severity: "low",
    message: `Very short, abstract closing lines keep turning up, especially at the end of paragraphs: "That's the point." Good copywriters use punchlines on purpose, which is why we only count how many there are.`,
    suggestion: "Keep the punchlines that earn their place. Turn the rest into full sentences."
  },
  "mic-drop-paragraph": {
    severity: "low",
    message: "Several paragraphs are built the same way: a few medium sentences, then a much shorter line to land on. One paragraph like that is ordinary. It is the repeat that stands out.",
    suggestion: "Let some paragraphs finish on their facts instead of a quotable line."
  },
  "contrast-density": {
    severity: "low",
    message: `Two-sided contrasts keep coming back: "not X, but Y"; "It wasn't A. It was B." One is ordinary writing. It is the rate that stands out.`,
    suggestion: "Keep the strongest contrast and say the rest plainly."
  },
  "rhetorical-procedural-ratio": {
    severity: "low",
    message: "Sentences making broad claims heavily outnumber sentences naming a real action, object or number. We count a sentence as concrete when it holds a number, a name, or a specific action verb. Opinion and vision pieces are broad on purpose.",
    suggestion: "Back more claims with a specific action, name or figure if the other checks agree."
  }
};
var MERGED_WEIGHTS = { ...ISSUE_WEIGHTS, ...V3_ISSUE_WEIGHTS, ...V4_ISSUE_WEIGHTS };
var MERGED_META = { ...CATEGORY_META, ...V3_CATEGORY_META, ...V4_CATEGORY_META };
var byLengthDesc = (a, b) => b.length - a.length || a.localeCompare(b);
var TIER1_WORD_RE = new RegExp("\\b(?:" + Object.keys(TIER1).sort(byLengthDesc).join("|") + ")\\b", "gi");
var TIER2_WORD_RE = new RegExp("\\b(?:" + Object.keys(TIER2).sort(byLengthDesc).join("|") + ")\\b", "gi");
var TIER3_LOOKUP = /* @__PURE__ */ new Map();
for (const word of TIER3) {
  TIER3_LOOKUP.set(word, word);
  const dashless = word.replace(/-/g, "");
  if (dashless !== word) TIER3_LOOKUP.set(dashless, word);
}
var LATIN_LETTER = new RegExp("\\p{Script=Latin}", "u");
function validateProtected(source, candidate2, spans) {
  const failures = [];
  for (const span of spans) {
    const count = candidate2.split(span.text).length - 1;
    if (count === 0) failures.push({ protected_span_id: span.id, expected_hash: span.content_hash, observed: "missing" });
    else if (count > source.split(span.text).length - 1) failures.push({ protected_span_id: span.id, expected_hash: span.content_hash, observed: "duplicated" });
  }
  return { id: "protected_spans.exact", version: "1.0.0", status: failures.length ? "fail" : "pass", hard: true, summary: failures.length ? `${failures.length} protected item(s) changed` : "Protected items remain present", failures, limitations: [] };
}
function validateAdditions(source, candidate2) {
  const pattern = /https?:\/\/[^\s<>)\]]+|```[\s\S]*?```|`[^`\n]+`|\[[0-9]+\]|[“"][^”"\n]+[”"]/g;
  const original = new Set(source.match(pattern) ?? []);
  const added = (candidate2.match(pattern) ?? []).filter((x) => !original.has(x));
  return { id: "unsupported_additions", version: "1.0.0", status: added.length ? "fail" : "pass", hard: true, summary: added.length ? `${added.length} unsupported reference(s) added` : "No unsupported URLs, citations, quotations or code added", failures: added.map((observed) => ({ observed })), limitations: [] };
}
function validateCandidate(source, candidate2, spans, policy = {}) {
  const gates = [validateProtected(source.content, candidate2, spans), validateAdditions(source.content, candidate2)];
  const current = prefixedSha256(source.content), expected = policy.expected_source_hash ?? source.content_hash ?? current;
  gates.push({ id: "source_version", version: "1.0.0", status: current === expected ? "pass" : "fail", hard: true, summary: current === expected ? "Source hash matches" : "Source changed since protection", failures: current === expected ? [] : [{ expected_hash: expected, observed: current }], limitations: [] });
  const executable = /<\s*(?:script|iframe|object|embed|form)\b|\son\w+\s*=|javascript:/i.test(candidate2);
  gates.push({ id: "html_safety", version: "1.0.0", status: executable ? "fail" : "pass", hard: true, summary: executable ? "Executable or unsafe HTML found" : "No executable HTML found", failures: executable ? [{ observed: "executable_markup" }] : [], limitations: ["This deterministic gate is not a complete HTML sanitiser."] });
  const max = policy.max_length_ratio ?? 2;
  const ratio = source.content.length ? candidate2.length / source.content.length : 1;
  gates.push({ id: "language_length", version: "1.0.0", status: ratio > max ? "fail" : "pass", hard: true, summary: ratio > max ? "Candidate exceeds the configured length bound" : "Candidate is within the configured length bound", failures: ratio > max ? [{ observed_ratio: ratio, max_ratio: max }] : [], limitations: ["CORE-10 does not infer language; it preserves the requested language as a host-reviewed constraint."] });
  const leakage = /\b(?:protected_span_id|system prompt|<\|(?:system|assistant|user)\|>)\b/i.test(candidate2);
  gates.push({ id: "output_safety", version: "1.0.0", status: leakage ? "fail" : "pass", hard: true, summary: leakage ? "Prompt or protected-ID leakage found" : "No prompt/control-token leakage found", failures: leakage ? [{ observed: "control_or_prompt_marker" }] : [], limitations: [] });
  gates.push({ id: "semantic_entailment", version: "unconfigured/1", status: "not_configured", hard: true, summary: "Semantic entailment is not configured in the deterministic core", failures: [], limitations: ["Strict policy must treat this required semantic gate as blocking when generation depends on semantic fidelity."] });
  return gates;
}
var tokens = (s) => s.match(/\s+|[^\s]+/g) ?? [];
function diff(source, candidate2) {
  if (source.length + candidate2.length > 8e4) return lineDiff(source, candidate2);
  const a = tokens(source), b = tokens(candidate2);
  if (a.length * b.length > 2e6) return lineDiff(source, candidate2);
  const matches = hirschberg(a, b);
  let i = 0, j = 0, sp = 0, cp = 0, mi = 0;
  const out = [];
  const push = (type, text, ss, se, cs, ce) => {
    const last = out.at(-1);
    if (last?.type === type && last.source_end === ss && last.candidate_end === cs) {
      last.text += text;
      last.source_end = se;
      last.candidate_end = ce;
    } else out.push({ type, text, source_start: ss, source_end: se, candidate_start: cs, candidate_end: ce });
  };
  while (i < a.length || j < b.length) {
    const match = matches[mi];
    if (match && i === match[0] && j === match[1]) {
      const t = a[i];
      push("equal", t, sp, sp + t.length, cp, cp + t.length);
      sp += t.length;
      cp += t.length;
      i++;
      j++;
      mi++;
    } else if (j < b.length && (!match || j < match[1])) {
      const t = b[j];
      push("insert", t, sp, sp, cp, cp + t.length);
      cp += t.length;
      j++;
    } else {
      const t = a[i];
      push("delete", t, sp, sp + t.length, cp, cp);
      sp += t.length;
      i++;
    }
  }
  return { version: "lcs-token/1.0.0", source_hash: prefixedSha256(source), candidate_hash: prefixedSha256(candidate2), change_count: out.filter((x) => x.type !== "equal").length, segments: out, fallback: false };
}
function rowScores(a, a0, a1, b, b0, b1, reverse = false) {
  const width = b1 - b0;
  let previous = new Uint32Array(width + 1), current = new Uint32Array(width + 1);
  for (let ai = 0; ai < a1 - a0; ai++) {
    const av = a[reverse ? a1 - 1 - ai : a0 + ai];
    for (let bj = 0; bj < width; bj++) {
      const bv = b[reverse ? b1 - 1 - bj : b0 + bj];
      current[bj + 1] = av === bv ? previous[bj] + 1 : Math.max(previous[bj + 1], current[bj]);
    }
    const swap = previous;
    previous = current;
    current = swap;
    current.fill(0);
  }
  return previous;
}
function hirschberg(a, b) {
  const out = [];
  const walk = (a0, a1, b0, b1) => {
    if (a0 >= a1 || b0 >= b1) return;
    if (a1 - a0 === 1) {
      for (let j = b0; j < b1; j++) if (a[a0] === b[j]) {
        out.push([a0, j]);
        break;
      }
      return;
    }
    const mid = a0 + a1 >> 1;
    let left = rowScores(a, a0, mid, b, b0, b1), right = rowScores(a, mid, a1, b, b0, b1, true);
    let split = 0, best = -1;
    for (let j = 0; j <= b1 - b0; j++) {
      const score = left[j] + right[b1 - b0 - j];
      if (score > best) {
        best = score;
        split = j;
      }
    }
    left = void 0;
    right = void 0;
    walk(a0, mid, b0, b0 + split);
    walk(mid, a1, b0 + split, b1);
  };
  walk(0, a.length, 0, b.length);
  return out;
}
function lineDiff(source, candidate2) {
  const segments = source === candidate2 ? source ? [{ type: "equal", text: source, source_start: 0, source_end: source.length, candidate_start: 0, candidate_end: candidate2.length }] : [] : [];
  if (source !== candidate2) {
    if (source) segments.push({ type: "delete", text: source, source_start: 0, source_end: source.length, candidate_start: 0, candidate_end: 0 });
    if (candidate2) segments.push({ type: "insert", text: candidate2, source_start: source.length, source_end: source.length, candidate_start: 0, candidate_end: candidate2.length });
  }
  return { version: "lcs-token/1.0.0", source_hash: prefixedSha256(source), candidate_hash: prefixedSha256(candidate2), change_count: segments.filter((item2) => item2.type !== "equal").length, segments, fallback: true };
}
var MAGIC = [67, 50, 80, 65, 84, 88, 84, 0];
var HEADER_BYTES = 13;
var SENTINEL = 65279;
var variationSelectorToByte = (codePoint) => codePoint >= 65024 && codePoint <= 65039 ? codePoint - 65024 : codePoint >= 917760 && codePoint <= 917999 ? codePoint - 917760 + 16 : null;
function detectC2paTextCredentials(text) {
  const found = [];
  for (let i = 0; i < text.length; ) {
    const codePoint = text.codePointAt(i);
    const width = codePoint > 65535 ? 2 : 1;
    if (codePoint !== SENTINEL) {
      i += width;
      continue;
    }
    const bytes = [];
    let cursor = i + width;
    while (cursor < text.length) {
      const next = text.codePointAt(cursor);
      const byte = variationSelectorToByte(next);
      if (byte === null) break;
      bytes.push(byte);
      cursor += next > 65535 ? 2 : 1;
    }
    if (bytes.length < HEADER_BYTES || !MAGIC.every((value, index) => bytes[index] === value)) {
      i += width;
      continue;
    }
    const manifestLength = (bytes[9] << 24 | bytes[10] << 16 | bytes[11] << 8 | bytes[12]) >>> 0;
    found.push({
      start_utf16: i,
      end_utf16: cursor,
      version: bytes[8],
      manifest_length: manifestLength,
      status: bytes.length >= HEADER_BYTES + manifestLength ? "ok" : "truncated"
    });
    i = cursor;
  }
  return found;
}
var withinCredential = (credentials, span) => credentials.some(
  (credential) => span.start_utf16 < credential.end_utf16 && span.end_utf16 > credential.start_utf16
);
function previewSafeFixes(source, findings, selectedFindingIds, protectedSpans = [], options = {}) {
  const credentials = options.allow_c2pa_credential_removal ? [] : detectC2paTextCredentials(source);
  const selected = new Set(selectedFindingIds), edits = [], skipped = [];
  for (const f of findings) {
    if (!selected.has(f.id)) continue;
    const raw = source.slice(f.span.start_utf16, f.span.end_utf16);
    if (!f.id.startsWith("unicode_") || f.span.end_utf16 <= f.span.start_utf16 || f.matched_text_hash !== prefixedSha256(raw)) {
      skipped.push({ id: f.id, reason: "invalid_finding_provenance" });
      continue;
    }
    if (f.code_point === "U+FEFF" && f.span.start_utf16 !== 0) {
      skipped.push({ id: f.id, reason: "invalid_bom_position" });
      continue;
    }
    if (f.fix === "review") {
      skipped.push({ id: f.id, reason: "user_review" });
      continue;
    }
    if (withinCredential(credentials, f.span)) {
      skipped.push({ id: f.id, reason: "c2pa_text_credential" });
      continue;
    }
    if (protectedSpans.some((p) => f.span.start_utf16 < p.end_utf16 && f.span.end_utf16 > p.start_utf16)) {
      skipped.push({ id: f.id, reason: "protected_span" });
      continue;
    }
    if (edits.some((e) => f.span.start_utf16 < e.end && f.span.end_utf16 > e.start)) {
      skipped.push({ id: f.id, reason: "overlapping_edit" });
      continue;
    }
    edits.push({ start: f.span.start_utf16, end: f.span.end_utf16, value: f.fix === "space" ? " " : "", id: f.id });
  }
  edits.sort((a, b) => b.start - a.start);
  let candidate2 = source;
  for (const e of edits) candidate2 = candidate2.slice(0, e.start) + e.value + candidate2.slice(e.end);
  return deepFreeze2({ source_hash: prefixedSha256(source), candidate_hash: prefixedSha256(candidate2), candidate: candidate2, applied_finding_ids: edits.map((e) => e.id).reverse(), skipped, diff: diff(source, candidate2) });
}
function deepFreeze2(value) {
  if (value && typeof value === "object" && !Object.isFrozen(value)) {
    Object.freeze(value);
    for (const child of Object.values(value)) deepFreeze2(child);
  }
  return value;
}
function hasLoneSurrogate(value) {
  for (let i = 0; i < value.length; i++) {
    const code = value.charCodeAt(i);
    if (code >= 55296 && code <= 56319) {
      if (i === value.length - 1) {
        return true;
      }
      const next = value.charCodeAt(i + 1);
      if (!(next >= 56320 && next <= 57343)) {
        return true;
      }
      i++;
    } else if (code >= 56320 && code <= 57343) {
      return true;
    }
  }
  return false;
}
function canonicalize(object, seen = /* @__PURE__ */ new Set()) {
  if (typeof object === "number" && isNaN(object)) {
    throw new Error("NaN is not allowed");
  }
  if (typeof object === "number" && !isFinite(object)) {
    throw new Error("Infinity is not allowed");
  }
  if (typeof object === "string" && hasLoneSurrogate(object)) {
    throw new Error("Lone surrogate is not allowed");
  }
  if (object === null || typeof object !== "object") {
    return JSON.stringify(object);
  }
  if (typeof object.toJSON === "function") {
    if (seen.has(object)) {
      throw new Error("Circular reference detected");
    }
    seen.add(object);
    const result22 = canonicalize(object.toJSON(), seen);
    seen.delete(object);
    return result22;
  }
  if (seen.has(object)) {
    throw new Error("Circular reference detected");
  }
  seen.add(object);
  let result2;
  if (Array.isArray(object)) {
    const values = object.map((cv) => {
      const value = cv === void 0 || typeof cv === "symbol" ? null : cv;
      return canonicalize(value, seen);
    });
    result2 = `[${values.join(",")}]`;
  } else {
    const parts = [];
    for (const key of Object.keys(object).sort()) {
      if (object[key] === void 0 || typeof object[key] === "symbol") {
        continue;
      }
      parts.push(`${canonicalize(key)}:${canonicalize(object[key], seen)}`);
    }
    result2 = `{${parts.join(",")}}`;
  }
  seen.delete(object);
  return result2;
}
var payloadForHash = (receipt2) => {
  const clone = structuredClone(receipt2);
  delete clone.integrity?.payload_hash;
  delete clone.integrity?.signature;
  return clone;
};
var canonical = (value) => {
  const output = canonicalize(value);
  if (output === void 0) throw new Error("receipt_canonicalisation_failed");
  return output;
};
async function buildReceipt(input) {
  if (input.contains_content !== input.policy.retain_content) throw new Error("receipt_content_consent_mismatch");
  if (input.contains_content && input.rewrite && !input.rewrite.candidate_content) throw new Error("receipt_candidate_content_required");
  const sourceHash = prefixedSha256(input.source.content), normalisedHash = prefixedSha256(input.source.normalised_text ?? input.source.content);
  const source = { content_hash: sourceHash, normalised_hash: normalisedHash, content_type: input.source.content_type, language: input.source.language, word_count: (input.source.content.trim().match(/\S+/g) ?? []).length };
  if (input.contains_content) source.content = input.source.content;
  const rewrite = input.rewrite ? (() => {
    const { candidate_content, source_content: _callerSourceContent, ...metadata } = input.rewrite;
    return { ...metadata, ...input.contains_content ? { source_content: input.source.content, candidate_content } : {} };
  })() : null;
  const receipt2 = { schema_version: "1.0", contract_version: "1.0.0", product_version: input.product_version, receipt_id: input.receipt_id, created_at: input.created_at, source, policy: input.policy, methods: input.methods, rewrite, approval: input.approval, limitations: input.limitations, contains_content: input.contains_content, integrity: { canonicalisation: "RFC8785", payload_hash: "sha256:" + "0".repeat(64) } };
  receipt2.integrity.payload_hash = prefixedSha256(canonical(payloadForHash(receipt2)));
  return deepFreeze3(receipt2);
}
function deepFreeze3(value) {
  if (value && typeof value === "object" && !Object.isFrozen(value)) {
    Object.freeze(value);
    for (const child of Object.values(value)) deepFreeze3(child);
  }
  return value;
}
var METHODS = Object.freeze([
  Object.freeze({ id: "unicode.invisible", category: "unicode", version: "unicode:2026.08.1", state: "available", privacy_routes: ["browser"], limitations: ["Controls can be legitimate in multilingual text."] }),
  Object.freeze({ id: "unicode.homoglyph", category: "unicode", version: "unicode:2026.08.1", state: "available", privacy_routes: ["browser"], limitations: ["Mixed scripts require contextual human review."] }),
  Object.freeze({ id: "style.patterns", category: "pattern", version: "en-gb:2026.08.1", state: "available", privacy_routes: ["browser"], limitations: ["Editorial pattern findings are not authorship evidence."] }),
  Object.freeze({ id: "watermark.anthropic", category: "watermark", version: "adapter-placeholder/1", state: "unsupported", privacy_routes: ["browser"], limitations: ["No official detector interface is available."] })
]);

// ../shared/types.ts
var MAX_TEXT_LENGTH = 5e4;
var DEFAULT_SETTINGS = Object.freeze({
  receiptHistory: false,
  highContrast: false
});
var sourceLabel = (capture2) => {
  if (capture2.kind === "paste") return "Pasted text";
  const noun = capture2.kind === "selection" ? "Selected text" : "Visible article text";
  return `${noun} from ${capture2.host || "this page"}`;
};
var validateCapture = (capture2) => {
  if (!capture2.text.trim()) return capture2.kind === "selection" ? "Select at least one sentence, or choose Check this article." : "Paste or capture some text before inspection.";
  if (capture2.text.length > MAX_TEXT_LENGTH) {
    return `This text is ${capture2.text.length.toLocaleString("en-GB")} characters. The local browser limit is ${MAX_TEXT_LENGTH.toLocaleString("en-GB")}; choose or paste a smaller scope. Nothing was truncated.`;
  }
  for (let index = 0; index < capture2.text.length; index += 1) {
    const current = capture2.text.charCodeAt(index);
    if (current >= 55296 && current <= 56319) {
      const next = capture2.text.charCodeAt(index + 1);
      if (!(next >= 56320 && next <= 57343)) return "The text contains an unpaired Unicode surrogate and cannot be inspected safely.";
      index += 1;
    } else if (current >= 56320 && current <= 57343) {
      return "The text contains an unpaired Unicode surrogate and cannot be inspected safely.";
    }
  }
  return null;
};

// ../shared/storage.ts
var SETTINGS_KEY = "settings";
var loadSettings = async () => {
  const stored = await chrome.storage.local.get(SETTINGS_KEY);
  const candidate2 = stored[SETTINGS_KEY];
  return {
    receiptHistory: false,
    highContrast: candidate2?.highContrast === true
  };
};
var saveSettings = async (settings) => {
  await chrome.storage.local.set({ [SETTINGS_KEY]: { ...settings, receiptHistory: false } });
};
var clearAllExtensionData = async () => {
  const [local, session] = await Promise.all([
    chrome.storage.local.get(null),
    chrome.storage.session.get(null)
  ]);
  await Promise.all([chrome.storage.local.clear(), chrome.storage.session.clear()]);
  return { local: Object.keys(local).length, session: Object.keys(session).length };
};

// src/panel.ts
var app = document.querySelector("#app");
var live = document.querySelector("#live");
var steps = ["Capture", "Inspect", "Protect", "Improve", "Compare", "Export"];
var capture = null;
var result = null;
var candidate = "";
var receipt = null;
var abortController = null;
var escapeHtml = (value) => value.replace(/[&<>'"]/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" })[char]);
var announce = (message) => {
  live.textContent = "";
  requestAnimationFrame(() => {
    live.textContent = message;
  });
};
var stepNav = (active) => `<nav aria-label="Inspection workflow"><ol class="steps">${steps.map((step, index) => `<li ${index === active ? 'aria-current="step"' : ""}>${index + 1}<span>${step}</span></li>`).join("")}</ol></nav>`;
var shell = (active, body) => {
  app.innerHTML = `${stepNav(active)}<main tabindex="-1">${body}</main>`;
  app.querySelector("main")?.focus({ preventScroll: true });
};
var preview = (text) => escapeHtml(text.slice(0, 1200)) + (text.length > 1200 ? "\u2026" : "");
var renderCapture = (message = "") => {
  const isPaste = capture?.kind === "paste";
  const text = capture?.text ?? "";
  const editable = isPaste || !capture;
  const displayText = !editable && text.length > MAX_TEXT_LENGTH ? text.slice(0, MAX_TEXT_LENGTH) : text;
  const limitation = capture?.limitations[0] ?? message;
  shell(0, `<section class="sheet"><p class="eyebrow">Local evidence desk</p><h1>Capture text</h1>
    <p class="lede">Review the exact scope before anything runs. Nothing has left this browser.</p>
    ${limitation ? `<div class="notice attention" role="status"><strong>Paste fallback</strong><p>${escapeHtml(limitation)}</p></div>` : ""}
    <label for="source">${isPaste || !capture ? "Paste text" : escapeHtml(sourceLabel(capture))}</label>
    <textarea id="source" ${editable ? "" : "readonly"} maxlength="250001" aria-describedby="count privacy">${escapeHtml(displayText)}</textarea>
    <div class="meta"><span id="count">${text.length.toLocaleString("en-GB")} / ${MAX_TEXT_LENGTH.toLocaleString("en-GB")} characters${displayText.length < text.length ? ` \xB7 preview shows the first ${MAX_TEXT_LENGTH.toLocaleString("en-GB")}` : ""}</span><span id="privacy">Text is held in memory only.</span></div>
    <div id="capture-error" class="notice error" role="alert" tabindex="-1" hidden></div>
    <div class="actions"><button class="primary" id="inspect">Inspect text</button><button id="clear-capture">Clear</button></div>
  </section>`);
  const input = app.querySelector("#source");
  const count = app.querySelector("#count");
  const errorBox = app.querySelector("#capture-error");
  const clearValidationError = () => {
    input.removeAttribute("aria-invalid");
    input.setAttribute("aria-describedby", "count privacy");
    errorBox.hidden = true;
    errorBox.textContent = "";
  };
  input.addEventListener("input", () => {
    count.textContent = `${input.value.length.toLocaleString("en-GB")} / ${MAX_TEXT_LENGTH.toLocaleString("en-GB")} characters`;
    clearValidationError();
  });
  app.querySelector("#clear-capture")?.addEventListener("click", () => {
    capture = { kind: "paste", text: "", host: "", title: "Pasted text", limitations: [] };
    renderCapture();
  });
  app.querySelector("#inspect")?.addEventListener("click", () => {
    capture = { ...capture ?? { kind: "paste", host: "", title: "Pasted text", limitations: [] }, text: input.readOnly ? text : input.value };
    const error = validateCapture(capture);
    if (error) {
      input.setAttribute("aria-invalid", "true");
      input.setAttribute("aria-describedby", "count privacy capture-error");
      errorBox.hidden = false;
      errorBox.textContent = error;
      errorBox.focus();
      return;
    }
    clearValidationError();
    void inspectCapture();
  });
};
var inspectCapture = async () => {
  if (!capture) return;
  abortController?.abort();
  abortController = new AbortController();
  shell(1, `<section class="sheet"><p class="eyebrow">Browser route \xB7 no network</p><h1>Inspecting text</h1><div class="progress" aria-hidden="true"><span></span></div><p id="phase">Validating source\u2026</p><button id="cancel">Cancel inspection</button></section>`);
  app.querySelector("#cancel")?.addEventListener("click", () => abortController?.abort());
  const worker = createInspectionWorker({ workerUrl: new URL("./worker.js", import.meta.url) });
  try {
    result = await worker.inspect({
      schema_version: "1.0",
      contract_version: "1.0.0",
      request_id: `ext_${Date.now()}`,
      created_at: (/* @__PURE__ */ new Date()).toISOString(),
      source: { content: capture.text, content_type: "plain_text", language: "en-GB" },
      checks: ["unicode.invisible", "style.patterns", "watermark.anthropic", "detector.local"],
      privacy: { allowed_routes: ["browser"], save_receipt: false, retain_content: false },
      context: { caller: "chrome-extension", correlation_id: "private-session" }
    }, {
      signal: abortController.signal,
      onProgress: (phase) => {
        const target = app.querySelector("#phase");
        if (target) target.textContent = phase.replaceAll("_", " ");
      }
    });
    renderResults();
    announce("Inspection complete. Results are ready.");
  } catch (error) {
    if (error.name === "AbortError") {
      shell(1, `<section class="sheet"><p class="eyebrow">Interrupted</p><h1>Inspection cancelled</h1><p>No result or source was retained.</p><button id="return">Return to capture</button></section>`);
      app.querySelector("#return")?.addEventListener("click", () => renderCapture());
      announce("Inspection cancelled.");
    } else {
      renderCapture(`Inspection stopped safely: ${error.message}`);
    }
  } finally {
    worker.dispose();
    abortController = null;
  }
};
var statusLabel = (status) => status.replaceAll("_", " ");
var renderResults = () => {
  if (!result || !capture) return;
  const rows = result.methods.map((method) => {
    const label = method.id === "watermark.anthropic" ? "Official verifier unavailable" : method.provider_or_method;
    return `<li class="method ${method.status}"><div><strong>${escapeHtml(label)}</strong><span>${escapeHtml(method.id)}</span></div><b>${escapeHtml(statusLabel(method.status))}</b><p>${escapeHtml(method.limitations[0])}</p></li>`;
  }).join("");
  shell(1, `<section class="sheet"><p class="eyebrow">Evidence, not guarantees</p><h1>Inspection results</h1>
    <div class="summary"><div><b>${result.summary.attention}</b><span>Attention</span></div><div><b>${result.protected_spans.length}</b><span>Protected</span></div><div><b>${result.summary.unsupported}</b><span>Unavailable</span></div></div>
    <details open><summary>Named checks</summary><ul class="methods">${rows}</ul></details>
    <div class="notice neutral"><strong>Local signals</strong><p>Not configured. Browser inspection remains available without a model or provider.</p></div>
    <div class="actions"><button class="primary" id="protect">Protect facts</button><button id="back">Change source</button></div>
  </section>`);
  app.querySelector("#back")?.addEventListener("click", () => renderCapture());
  app.querySelector("#protect")?.addEventListener("click", renderProtect);
};
var renderProtect = () => {
  if (!result) return;
  const spans = result.protected_spans;
  shell(2, `<section class="sheet"><p class="eyebrow">Immutable evidence rail</p><h1>Protected content</h1><p>${spans.length} names, figures, dates, links, quotations, citations or code spans are locked before comparison.</p>
    <ul class="protected-list">${spans.slice(0, 12).map((span) => `<li><strong>${escapeHtml(span.kind)}</strong><span>${span.start_utf16}\u2013${span.end_utf16}</span></li>`).join("") || "<li>No protected spans were found.</li>"}</ul>
    <div class="actions"><button class="primary" id="improve">Prepare local candidate</button><button id="results">Back to results</button></div></section>`);
  app.querySelector("#results")?.addEventListener("click", renderResults);
  app.querySelector("#improve")?.addEventListener("click", renderImprove);
};
var renderImprove = () => {
  if (!result || !capture) return;
  const unicodeEvidence = result.methods.flatMap((method) => method.evidence).filter((item) => item?.type === "unicode_finding");
  const selected = unicodeEvidence.filter((item) => item.fix !== "review").map((item) => item.id);
  const fix = previewSafeFixes(capture.text, unicodeEvidence, selected, result.protected_spans);
  candidate = fix.candidate;
  const changed = fix.applied_finding_ids.length > 0;
  shell(3, `<section class="sheet"><p class="eyebrow">Copy-only candidate</p><h1>${changed ? "Safe character treatment prepared" : "No automatic change proposed"}</h1>
    <p>${changed ? `${fix.applied_finding_ids.length} explainable character treatment(s) were applied outside protected spans.` : "Browser-only checks found no safe automatic edit. The original remains the copyable fallback."}</p>
    <div class="notice neutral"><strong>Local engine unavailable</strong><p>The frozen local API has no pairing-code exchange operation. Connection and rewrite controls are disabled rather than simulated.</p></div>
    <div class="actions"><button class="primary" id="compare">Compare candidate</button><button id="protect-back">Back</button></div></section>`);
  app.querySelector("#protect-back")?.addEventListener("click", renderProtect);
  app.querySelector("#compare")?.addEventListener("click", renderCompare);
};
var renderCompare = () => {
  if (!result || !capture) return;
  const gates = validateCandidate({ content: capture.text, content_hash: result.source.content_hash, content_type: "plain_text", language: "en-GB" }, candidate, result.protected_spans, { expected_source_hash: result.source.content_hash });
  const blocking = gates.filter((gate) => gate.hard && gate.status !== "pass" && gate.id !== "semantic_entailment");
  shell(4, `<section class="sheet"><p class="eyebrow">Two-rail comparison</p><h1>Compare before copying</h1>
    <div class="rails"><section><h2>Original</h2><pre>${preview(capture.text)}</pre></section><section><h2>Candidate</h2><pre>${preview(candidate)}</pre></section></div>
    <p class="gate ${blocking.length ? "fail" : "pass"}"><strong>${blocking.length ? "Blocked" : "Deterministic gates passed"}</strong> \xB7 ${gates.length} gates checked; semantic entailment remains not configured.</p>
    <div id="copy-fallback" hidden><label for="fallback">Clipboard unavailable. Select all and copy:</label><textarea id="fallback" readonly>${escapeHtml(candidate)}</textarea></div>
    <div class="actions"><button class="primary" id="copy" ${blocking.length ? "disabled" : ""}>Copy selected candidate</button><button id="export">Export receipt</button><button id="improve-back">Back</button></div></section>`);
  app.querySelector("#improve-back")?.addEventListener("click", renderImprove);
  app.querySelector("#copy")?.addEventListener("click", async () => {
    try {
      await navigator.clipboard.writeText(candidate);
      announce("Candidate copied. The page was not changed.");
    } catch {
      const fallback = app.querySelector("#copy-fallback");
      fallback.hidden = false;
      app.querySelector("#fallback")?.focus();
      announce("Clipboard unavailable. A read-only copy field is ready.");
    }
  });
  app.querySelector("#export")?.addEventListener("click", () => void renderExport(gates));
};
var renderExport = async (gates) => {
  if (!result || !capture) return;
  receipt = await buildReceipt({
    receipt_id: `ext_receipt_${Date.now()}`,
    product_version: "1.0.0",
    created_at: (/* @__PURE__ */ new Date()).toISOString(),
    source: { content: capture.text, content_type: "plain_text", language: "en-GB", normalised_text: capture.text.normalize("NFC") },
    policy: { id: "extension-browser", version: "1.0.0", requested_checks: result.methods.map((method) => method.id), allowed_routes: ["browser"], retain_content: false },
    methods: result.methods,
    rewrite: candidate === capture.text ? null : { source_hash: result.source.content_hash, candidate_hash: prefixedSha256(candidate), generator: { route: "browser", provider: "Opace deterministic core", model: "none", prompt_template: "safe-unicode-preview" }, gates, selected_candidate: "candidate_1", candidate_content: candidate },
    approval: { scope: "none" },
    limitations: ["This hash-only receipt contains no source URL or text and does not prove human authorship."],
    contains_content: false
  });
  shell(5, `<section class="sheet"><p class="eyebrow">Hash-only evidence</p><h1>Receipt ready</h1><p>The JSON contains hashes, method states and limitations. It contains no source URL, source text or candidate text.</p>
    <dl><div><dt>Methods</dt><dd>${receipt.methods.length}</dd></div><div><dt>Content retained</dt><dd>No</dd></div><div><dt>History</dt><dd>Off</dd></div></dl>
    <div class="actions"><button class="primary" id="download">Download JSON receipt</button><button id="clear-data">Clear extension data</button><button id="compare-back">Back</button></div><p id="clear-result" role="status"></p></section>`);
  app.querySelector("#compare-back")?.addEventListener("click", renderCompare);
  app.querySelector("#download")?.addEventListener("click", () => {
    const blob = new Blob([`${JSON.stringify(receipt, null, 2)}
`], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `${receipt.receipt_id}.json`;
    anchor.click();
    URL.revokeObjectURL(url);
    announce("Hash-only receipt download started.");
  });
  app.querySelector("#clear-data")?.addEventListener("click", async () => {
    const counts = await clearAllExtensionData();
    const target = app.querySelector("#clear-result");
    target.textContent = `Cleared ${counts.local} local setting group(s) and ${counts.session} session marker(s). No text history existed.`;
  });
};
var initialise = async () => {
  const settings = await loadSettings();
  document.documentElement.dataset.contrast = settings.highContrast ? "high" : "normal";
  await saveSettings(settings);
  const pending = await chrome.runtime.sendMessage({ type: "GET_PENDING" });
  if (pending?.capture) {
    capture = pending.capture;
    renderCapture();
    return;
  }
  if (pending?.interrupted) {
    capture = { kind: "paste", text: "", host: "", title: "Interrupted", limitations: [] };
    renderCapture("The browser interrupted an unfinished capture. No source or result was retained; paste or capture again.");
    return;
  }
  capture = { kind: "paste", text: "", host: "", title: "Pasted text", limitations: [] };
  renderCapture();
};
void initialise();
