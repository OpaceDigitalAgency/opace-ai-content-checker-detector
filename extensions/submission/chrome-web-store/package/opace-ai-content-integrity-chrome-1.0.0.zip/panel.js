// node_modules/@opace/content-integrity-browser/dist/index.js
var WORKER_PROTOCOL_VERSION = "1.0";
function createInspectionWorker(options = {}) {
  if (typeof Worker === "undefined") throw new Error("worker_unsupported");
  const worker = new Worker(options.workerUrl ?? new URL("./worker/entry.js", import.meta.url), { type: "module" });
  const pending = /* @__PURE__ */ new Map();
  worker.onmessage = (event) => {
    const m = event.data, p = pending.get(m.id);
    if (!p || m.protocol_version !== WORKER_PROTOCOL_VERSION) return;
    if (m.type === "progress") p.onProgress?.(m.phase);
    else {
      pending.delete(m.id);
      m.type === "result" ? p.resolve(m.result) : p.reject(new Error(m.code));
    }
  };
  return { inspect(request, opts = {}) {
    const id = `inspect_${Date.now()}_${Math.random().toString(36).slice(2)}`;
    return new Promise((resolve, reject) => {
      pending.set(id, { resolve, reject, onProgress: opts.onProgress });
      const abort = () => {
        worker.postMessage({ protocol_version: WORKER_PROTOCOL_VERSION, type: "cancel", id });
        pending.delete(id);
        reject(new DOMException("Inspection cancelled", "AbortError"));
      };
      if (opts.signal?.aborted) return abort();
      opts.signal?.addEventListener("abort", abort, { once: true });
      worker.postMessage({ protocol_version: WORKER_PROTOCOL_VERSION, type: "inspect", id, request });
    });
  }, dispose() {
    for (const p of pending.values()) p.reject(new Error("worker_disposed"));
    pending.clear();
    worker.terminate();
  } };
}

// node_modules/@opace/content-integrity-core/dist/bundle.js
var K = new Uint32Array([
  1116352408,
  1899447441,
  3049323471,
  3921009573,
  961987163,
  1508970993,
  2453635748,
  2870763221,
  3624381080,
  310598401,
  607225278,
  1426881987,
  1925078388,
  2162078206,
  2614888103,
  3248222580,
  3835390401,
  4022224774,
  264347078,
  604807628,
  770255983,
  1249150122,
  1555081692,
  1996064986,
  2554220882,
  2821834349,
  2952996808,
  3210313671,
  3336571891,
  3584528711,
  113926993,
  338241895,
  666307205,
  773529912,
  1294757372,
  1396182291,
  1695183700,
  1986661051,
  2177026350,
  2456956037,
  2730485921,
  2820302411,
  3259730800,
  3345764771,
  3516065817,
  3600352804,
  4094571909,
  275423344,
  430227734,
  506948616,
  659060556,
  883997877,
  958139571,
  1322822218,
  1537002063,
  1747873779,
  1955562222,
  2024104815,
  2227730452,
  2361852424,
  2428436474,
  2756734187,
  3204031479,
  3329325298
]);
var rotr = (x, n) => x >>> n | x << 32 - n;
function utf8Bytes(value) {
  return new TextEncoder().encode(value);
}
function sha256Hex(value) {
  const source = utf8Bytes(value);
  const bitLength = source.length * 8;
  const paddedLength = Math.ceil((source.length + 9) / 64) * 64;
  const bytes = new Uint8Array(paddedLength);
  bytes.set(source);
  bytes[source.length] = 128;
  const view = new DataView(bytes.buffer);
  view.setUint32(paddedLength - 4, bitLength >>> 0, false);
  view.setUint32(paddedLength - 8, Math.floor(bitLength / 4294967296), false);
  const h = new Uint32Array([1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924, 528734635, 1541459225]);
  const w = new Uint32Array(64);
  for (let offset = 0; offset < paddedLength; offset += 64) {
    for (let i = 0; i < 16; i++) w[i] = view.getUint32(offset + i * 4, false);
    for (let i = 16; i < 64; i++) {
      const a2 = w[i - 15], b2 = w[i - 2];
      w[i] = (rotr(a2, 7) ^ rotr(a2, 18) ^ a2 >>> 3) + w[i - 16] + (rotr(b2, 17) ^ rotr(b2, 19) ^ b2 >>> 10) + w[i - 7] >>> 0;
    }
    let [a, b, c, d, e, f, g, hh] = h;
    for (let i = 0; i < 64; i++) {
      const s1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25);
      const ch = e & f ^ ~e & g;
      const t1 = hh + s1 + ch + K[i] + w[i] >>> 0;
      const s0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22);
      const maj = a & b ^ a & c ^ b & c;
      const t2 = s0 + maj >>> 0;
      hh = g;
      g = f;
      f = e;
      e = d + t1 >>> 0;
      d = c;
      c = b;
      b = a;
      a = t1 + t2 >>> 0;
    }
    h[0] = h[0] + a >>> 0;
    h[1] = h[1] + b >>> 0;
    h[2] = h[2] + c >>> 0;
    h[3] = h[3] + d >>> 0;
    h[4] = h[4] + e >>> 0;
    h[5] = h[5] + f >>> 0;
    h[6] = h[6] + g >>> 0;
    h[7] = h[7] + hh >>> 0;
  }
  return Array.from(h, (n) => n.toString(16).padStart(8, "0")).join("");
}
var prefixedSha256 = (value) => `sha256:${sha256Hex(value)}`;
function validateProtected(source, candidate2, spans) {
  const failures = [];
  for (const span of spans) {
    const count = candidate2.split(span.text).length - 1;
    if (count === 0) failures.push({ protected_span_id: span.id, expected_hash: span.content_hash, observed: "missing" });
    else if (count > source.split(span.text).length - 1) failures.push({ protected_span_id: span.id, expected_hash: span.content_hash, observed: "duplicated" });
  }
  return { id: "protected_spans.exact", version: "1.0.0", status: failures.length ? "fail" : "pass", hard: true, summary: failures.length ? `${failures.length} protected item(s) changed` : "Protected items remain present", failures, limitations: [] };
}
function validateAdditions(source, candidate2) {
  const pattern = /https?:\/\/[^\s<>)\]]+|```[\s\S]*?```|`[^`\n]+`|\[[0-9]+\]|[“"][^”"\n]+[”"]/g;
  const original = new Set(source.match(pattern) ?? []);
  const added = (candidate2.match(pattern) ?? []).filter((x) => !original.has(x));
  return { id: "unsupported_additions", version: "1.0.0", status: added.length ? "fail" : "pass", hard: true, summary: added.length ? `${added.length} unsupported reference(s) added` : "No unsupported URLs, citations, quotations or code added", failures: added.map((observed) => ({ observed })), limitations: [] };
}
function validateCandidate(source, candidate2, spans, policy = {}) {
  const gates = [validateProtected(source.content, candidate2, spans), validateAdditions(source.content, candidate2)];
  const current = prefixedSha256(source.content), expected = policy.expected_source_hash ?? source.content_hash ?? current;
  gates.push({ id: "source_version", version: "1.0.0", status: current === expected ? "pass" : "fail", hard: true, summary: current === expected ? "Source hash matches" : "Source changed since protection", failures: current === expected ? [] : [{ expected_hash: expected, observed: current }], limitations: [] });
  const executable = /<\s*(?:script|iframe|object|embed|form)\b|\son\w+\s*=|javascript:/i.test(candidate2);
  gates.push({ id: "html_safety", version: "1.0.0", status: executable ? "fail" : "pass", hard: true, summary: executable ? "Executable or unsafe HTML found" : "No executable HTML found", failures: executable ? [{ observed: "executable_markup" }] : [], limitations: ["This deterministic gate is not a complete HTML sanitiser."] });
  const max = policy.max_length_ratio ?? 2;
  const ratio = source.content.length ? candidate2.length / source.content.length : 1;
  gates.push({ id: "language_length", version: "1.0.0", status: ratio > max ? "fail" : "pass", hard: true, summary: ratio > max ? "Candidate exceeds the configured length bound" : "Candidate is within the configured length bound", failures: ratio > max ? [{ observed_ratio: ratio, max_ratio: max }] : [], limitations: ["CORE-10 does not infer language; it preserves the requested language as a host-reviewed constraint."] });
  const leakage = /\b(?:protected_span_id|system prompt|<\|(?:system|assistant|user)\|>)\b/i.test(candidate2);
  gates.push({ id: "output_safety", version: "1.0.0", status: leakage ? "fail" : "pass", hard: true, summary: leakage ? "Prompt or protected-ID leakage found" : "No prompt/control-token leakage found", failures: leakage ? [{ observed: "control_or_prompt_marker" }] : [], limitations: [] });
  gates.push({ id: "semantic_entailment", version: "unconfigured/1", status: "not_configured", hard: true, summary: "Semantic entailment is not configured in the deterministic core", failures: [], limitations: ["Strict policy must treat this required semantic gate as blocking when generation depends on semantic fidelity."] });
  return gates;
}
var tokens = (s) => s.match(/\s+|[^\s]+/g) ?? [];
function diff(source, candidate2) {
  if (source.length + candidate2.length > 8e4) return lineDiff(source, candidate2);
  const a = tokens(source), b = tokens(candidate2);
  if (a.length * b.length > 2e6) return lineDiff(source, candidate2);
  const matches = hirschberg(a, b);
  let i = 0, j = 0, sp = 0, cp = 0, mi = 0;
  const out = [];
  const push = (type, text, ss, se, cs, ce) => {
    const last = out.at(-1);
    if (last?.type === type && last.source_end === ss && last.candidate_end === cs) {
      last.text += text;
      last.source_end = se;
      last.candidate_end = ce;
    } else out.push({ type, text, source_start: ss, source_end: se, candidate_start: cs, candidate_end: ce });
  };
  while (i < a.length || j < b.length) {
    const match = matches[mi];
    if (match && i === match[0] && j === match[1]) {
      const t = a[i];
      push("equal", t, sp, sp + t.length, cp, cp + t.length);
      sp += t.length;
      cp += t.length;
      i++;
      j++;
      mi++;
    } else if (j < b.length && (!match || j < match[1])) {
      const t = b[j];
      push("insert", t, sp, sp, cp, cp + t.length);
      cp += t.length;
      j++;
    } else {
      const t = a[i];
      push("delete", t, sp, sp + t.length, cp, cp);
      sp += t.length;
      i++;
    }
  }
  return { version: "lcs-token/1.0.0", source_hash: prefixedSha256(source), candidate_hash: prefixedSha256(candidate2), change_count: out.filter((x) => x.type !== "equal").length, segments: out, fallback: false };
}
function rowScores(a, a0, a1, b, b0, b1, reverse = false) {
  const width = b1 - b0;
  let previous = new Uint32Array(width + 1), current = new Uint32Array(width + 1);
  for (let ai = 0; ai < a1 - a0; ai++) {
    const av = a[reverse ? a1 - 1 - ai : a0 + ai];
    for (let bj = 0; bj < width; bj++) {
      const bv = b[reverse ? b1 - 1 - bj : b0 + bj];
      current[bj + 1] = av === bv ? previous[bj] + 1 : Math.max(previous[bj + 1], current[bj]);
    }
    const swap = previous;
    previous = current;
    current = swap;
    current.fill(0);
  }
  return previous;
}
function hirschberg(a, b) {
  const out = [];
  const walk = (a0, a1, b0, b1) => {
    if (a0 >= a1 || b0 >= b1) return;
    if (a1 - a0 === 1) {
      for (let j = b0; j < b1; j++) if (a[a0] === b[j]) {
        out.push([a0, j]);
        break;
      }
      return;
    }
    const mid = a0 + a1 >> 1;
    let left = rowScores(a, a0, mid, b, b0, b1), right = rowScores(a, mid, a1, b, b0, b1, true);
    let split = 0, best = -1;
    for (let j = 0; j <= b1 - b0; j++) {
      const score = left[j] + right[b1 - b0 - j];
      if (score > best) {
        best = score;
        split = j;
      }
    }
    left = void 0;
    right = void 0;
    walk(a0, mid, b0, b0 + split);
    walk(mid, a1, b0 + split, b1);
  };
  walk(0, a.length, 0, b.length);
  return out;
}
function lineDiff(source, candidate2) {
  const segments = source === candidate2 ? source ? [{ type: "equal", text: source, source_start: 0, source_end: source.length, candidate_start: 0, candidate_end: candidate2.length }] : [] : [];
  if (source !== candidate2) {
    if (source) segments.push({ type: "delete", text: source, source_start: 0, source_end: source.length, candidate_start: 0, candidate_end: 0 });
    if (candidate2) segments.push({ type: "insert", text: candidate2, source_start: source.length, source_end: source.length, candidate_start: 0, candidate_end: candidate2.length });
  }
  return { version: "lcs-token/1.0.0", source_hash: prefixedSha256(source), candidate_hash: prefixedSha256(candidate2), change_count: segments.filter((item) => item.type !== "equal").length, segments, fallback: true };
}
function previewSafeFixes(source, findings, selectedFindingIds, protectedSpans = []) {
  const selected = new Set(selectedFindingIds), edits = [], skipped = [];
  for (const f of findings) {
    if (!selected.has(f.id)) continue;
    const raw = source.slice(f.span.start_utf16, f.span.end_utf16);
    if (!f.id.startsWith("unicode_") || f.span.end_utf16 <= f.span.start_utf16 || f.matched_text_hash !== prefixedSha256(raw)) {
      skipped.push({ id: f.id, reason: "invalid_finding_provenance" });
      continue;
    }
    if (f.code_point === "U+FEFF" && f.span.start_utf16 !== 0) {
      skipped.push({ id: f.id, reason: "invalid_bom_position" });
      continue;
    }
    if (f.fix === "review") {
      skipped.push({ id: f.id, reason: "user_review" });
      continue;
    }
    if (protectedSpans.some((p) => f.span.start_utf16 < p.end_utf16 && f.span.end_utf16 > p.start_utf16)) {
      skipped.push({ id: f.id, reason: "protected_span" });
      continue;
    }
    if (edits.some((e) => f.span.start_utf16 < e.end && f.span.end_utf16 > e.start)) {
      skipped.push({ id: f.id, reason: "overlapping_edit" });
      continue;
    }
    edits.push({ start: f.span.start_utf16, end: f.span.end_utf16, value: f.fix === "space" ? " " : "", id: f.id });
  }
  edits.sort((a, b) => b.start - a.start);
  let candidate2 = source;
  for (const e of edits) candidate2 = candidate2.slice(0, e.start) + e.value + candidate2.slice(e.end);
  return deepFreeze2({ source_hash: prefixedSha256(source), candidate_hash: prefixedSha256(candidate2), candidate: candidate2, applied_finding_ids: edits.map((e) => e.id).reverse(), skipped, diff: diff(source, candidate2) });
}
function deepFreeze2(value) {
  if (value && typeof value === "object" && !Object.isFrozen(value)) {
    Object.freeze(value);
    for (const child of Object.values(value)) deepFreeze2(child);
  }
  return value;
}
function hasLoneSurrogate(value) {
  for (let i = 0; i < value.length; i++) {
    const code = value.charCodeAt(i);
    if (code >= 55296 && code <= 56319) {
      if (i === value.length - 1) {
        return true;
      }
      const next = value.charCodeAt(i + 1);
      if (!(next >= 56320 && next <= 57343)) {
        return true;
      }
      i++;
    } else if (code >= 56320 && code <= 57343) {
      return true;
    }
  }
  return false;
}
function canonicalize(object, seen = /* @__PURE__ */ new Set()) {
  if (typeof object === "number" && isNaN(object)) {
    throw new Error("NaN is not allowed");
  }
  if (typeof object === "number" && !isFinite(object)) {
    throw new Error("Infinity is not allowed");
  }
  if (typeof object === "string" && hasLoneSurrogate(object)) {
    throw new Error("Lone surrogate is not allowed");
  }
  if (object === null || typeof object !== "object") {
    return JSON.stringify(object);
  }
  if (typeof object.toJSON === "function") {
    if (seen.has(object)) {
      throw new Error("Circular reference detected");
    }
    seen.add(object);
    const result22 = canonicalize(object.toJSON(), seen);
    seen.delete(object);
    return result22;
  }
  if (seen.has(object)) {
    throw new Error("Circular reference detected");
  }
  seen.add(object);
  let result2;
  if (Array.isArray(object)) {
    const values = object.map((cv) => {
      const value = cv === void 0 || typeof cv === "symbol" ? null : cv;
      return canonicalize(value, seen);
    });
    result2 = `[${values.join(",")}]`;
  } else {
    const parts = [];
    for (const key of Object.keys(object).sort()) {
      if (object[key] === void 0 || typeof object[key] === "symbol") {
        continue;
      }
      parts.push(`${canonicalize(key)}:${canonicalize(object[key], seen)}`);
    }
    result2 = `{${parts.join(",")}}`;
  }
  seen.delete(object);
  return result2;
}
var payloadForHash = (receipt2) => {
  const clone = structuredClone(receipt2);
  delete clone.integrity?.payload_hash;
  delete clone.integrity?.signature;
  return clone;
};
var canonical = (value) => {
  const output = canonicalize(value);
  if (output === void 0) throw new Error("receipt_canonicalisation_failed");
  return output;
};
async function buildReceipt(input) {
  if (input.contains_content !== input.policy.retain_content) throw new Error("receipt_content_consent_mismatch");
  if (input.contains_content && input.rewrite && !input.rewrite.candidate_content) throw new Error("receipt_candidate_content_required");
  const sourceHash = prefixedSha256(input.source.content), normalisedHash = prefixedSha256(input.source.normalised_text ?? input.source.content);
  const source = { content_hash: sourceHash, normalised_hash: normalisedHash, content_type: input.source.content_type, language: input.source.language, word_count: (input.source.content.trim().match(/\S+/g) ?? []).length };
  if (input.contains_content) source.content = input.source.content;
  const rewrite = input.rewrite ? (() => {
    const { candidate_content, source_content: _callerSourceContent, ...metadata } = input.rewrite;
    return { ...metadata, ...input.contains_content ? { source_content: input.source.content, candidate_content } : {} };
  })() : null;
  const receipt2 = { schema_version: "1.0", contract_version: "1.0.0", product_version: input.product_version, receipt_id: input.receipt_id, created_at: input.created_at, source, policy: input.policy, methods: input.methods, rewrite, approval: input.approval, limitations: input.limitations, contains_content: input.contains_content, integrity: { canonicalisation: "RFC8785", payload_hash: "sha256:" + "0".repeat(64) } };
  receipt2.integrity.payload_hash = prefixedSha256(canonical(payloadForHash(receipt2)));
  return deepFreeze3(receipt2);
}
function deepFreeze3(value) {
  if (value && typeof value === "object" && !Object.isFrozen(value)) {
    Object.freeze(value);
    for (const child of Object.values(value)) deepFreeze3(child);
  }
  return value;
}
var METHODS = Object.freeze([
  Object.freeze({ id: "unicode.invisible", category: "unicode", version: "unicode:2026.08.1", state: "available", privacy_routes: ["browser"], limitations: ["Controls can be legitimate in multilingual text."] }),
  Object.freeze({ id: "unicode.homoglyph", category: "unicode", version: "unicode:2026.08.1", state: "available", privacy_routes: ["browser"], limitations: ["Mixed scripts require contextual human review."] }),
  Object.freeze({ id: "style.patterns", category: "pattern", version: "en-gb:2026.08.1", state: "available", privacy_routes: ["browser"], limitations: ["Editorial pattern findings are not authorship evidence."] }),
  Object.freeze({ id: "watermark.anthropic", category: "watermark", version: "adapter-placeholder/1", state: "unsupported", privacy_routes: ["browser"], limitations: ["No official detector interface is available."] })
]);

// ../shared/types.ts
var MAX_TEXT_LENGTH = 5e4;
var DEFAULT_SETTINGS = Object.freeze({
  receiptHistory: false,
  highContrast: false
});
var sourceLabel = (capture2) => {
  if (capture2.kind === "paste") return "Pasted text";
  const noun = capture2.kind === "selection" ? "Selected text" : "Visible article text";
  return `${noun} from ${capture2.host || "this page"}`;
};
var validateCapture = (capture2) => {
  if (!capture2.text.trim()) return capture2.kind === "selection" ? "Select at least one sentence, or choose Check this article." : "Paste or capture some text before inspection.";
  if (capture2.text.length > MAX_TEXT_LENGTH) {
    return `This text is ${capture2.text.length.toLocaleString("en-GB")} characters. The local browser limit is ${MAX_TEXT_LENGTH.toLocaleString("en-GB")}; choose or paste a smaller scope. Nothing was truncated.`;
  }
  for (let index = 0; index < capture2.text.length; index += 1) {
    const current = capture2.text.charCodeAt(index);
    if (current >= 55296 && current <= 56319) {
      const next = capture2.text.charCodeAt(index + 1);
      if (!(next >= 56320 && next <= 57343)) return "The text contains an unpaired Unicode surrogate and cannot be inspected safely.";
      index += 1;
    } else if (current >= 56320 && current <= 57343) {
      return "The text contains an unpaired Unicode surrogate and cannot be inspected safely.";
    }
  }
  return null;
};

// ../shared/storage.ts
var SETTINGS_KEY = "settings";
var loadSettings = async () => {
  const stored = await chrome.storage.local.get(SETTINGS_KEY);
  const candidate2 = stored[SETTINGS_KEY];
  return {
    receiptHistory: false,
    highContrast: candidate2?.highContrast === true
  };
};
var saveSettings = async (settings) => {
  await chrome.storage.local.set({ [SETTINGS_KEY]: { ...settings, receiptHistory: false } });
};
var clearAllExtensionData = async () => {
  const [local, session] = await Promise.all([
    chrome.storage.local.get(null),
    chrome.storage.session.get(null)
  ]);
  await Promise.all([chrome.storage.local.clear(), chrome.storage.session.clear()]);
  return { local: Object.keys(local).length, session: Object.keys(session).length };
};

// src/panel.ts
var app = document.querySelector("#app");
var live = document.querySelector("#live");
var steps = ["Capture", "Inspect", "Protect", "Improve", "Compare", "Export"];
var capture = null;
var result = null;
var candidate = "";
var receipt = null;
var abortController = null;
var escapeHtml = (value) => value.replace(/[&<>'"]/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" })[char]);
var announce = (message) => {
  live.textContent = "";
  requestAnimationFrame(() => {
    live.textContent = message;
  });
};
var stepNav = (active) => `<nav aria-label="Inspection workflow"><ol class="steps">${steps.map((step, index) => `<li ${index === active ? 'aria-current="step"' : ""}>${index + 1}<span>${step}</span></li>`).join("")}</ol></nav>`;
var shell = (active, body) => {
  app.innerHTML = `${stepNav(active)}<main tabindex="-1">${body}</main>`;
  app.querySelector("main")?.focus({ preventScroll: true });
};
var preview = (text) => escapeHtml(text.slice(0, 1200)) + (text.length > 1200 ? "\u2026" : "");
var renderCapture = (message = "") => {
  const isPaste = capture?.kind === "paste";
  const text = capture?.text ?? "";
  const editable = isPaste || !capture;
  const displayText = !editable && text.length > MAX_TEXT_LENGTH ? text.slice(0, MAX_TEXT_LENGTH) : text;
  const limitation = capture?.limitations[0] ?? message;
  shell(0, `<section class="sheet"><p class="eyebrow">Local evidence desk</p><h1>Capture text</h1>
    <p class="lede">Review the exact scope before anything runs. Nothing has left this browser.</p>
    ${limitation ? `<div class="notice attention" role="status"><strong>Paste fallback</strong><p>${escapeHtml(limitation)}</p></div>` : ""}
    <label for="source">${isPaste || !capture ? "Paste text" : escapeHtml(sourceLabel(capture))}</label>
    <textarea id="source" ${editable ? "" : "readonly"} maxlength="250001" aria-describedby="count privacy">${escapeHtml(displayText)}</textarea>
    <div class="meta"><span id="count">${text.length.toLocaleString("en-GB")} / ${MAX_TEXT_LENGTH.toLocaleString("en-GB")} characters${displayText.length < text.length ? ` \xB7 preview shows the first ${MAX_TEXT_LENGTH.toLocaleString("en-GB")}` : ""}</span><span id="privacy">Text is held in memory only.</span></div>
    <div id="capture-error" class="notice error" role="alert" tabindex="-1" hidden></div>
    <div class="actions"><button class="primary" id="inspect">Inspect text</button><button id="clear-capture">Clear</button></div>
  </section>`);
  const input = app.querySelector("#source");
  const count = app.querySelector("#count");
  const errorBox = app.querySelector("#capture-error");
  const clearValidationError = () => {
    input.removeAttribute("aria-invalid");
    input.setAttribute("aria-describedby", "count privacy");
    errorBox.hidden = true;
    errorBox.textContent = "";
  };
  input.addEventListener("input", () => {
    count.textContent = `${input.value.length.toLocaleString("en-GB")} / ${MAX_TEXT_LENGTH.toLocaleString("en-GB")} characters`;
    clearValidationError();
  });
  app.querySelector("#clear-capture")?.addEventListener("click", () => {
    capture = { kind: "paste", text: "", host: "", title: "Pasted text", limitations: [] };
    renderCapture();
  });
  app.querySelector("#inspect")?.addEventListener("click", () => {
    capture = { ...capture ?? { kind: "paste", host: "", title: "Pasted text", limitations: [] }, text: input.readOnly ? text : input.value };
    const error = validateCapture(capture);
    if (error) {
      input.setAttribute("aria-invalid", "true");
      input.setAttribute("aria-describedby", "count privacy capture-error");
      errorBox.hidden = false;
      errorBox.textContent = error;
      errorBox.focus();
      return;
    }
    clearValidationError();
    void inspectCapture();
  });
};
var inspectCapture = async () => {
  if (!capture) return;
  abortController?.abort();
  abortController = new AbortController();
  shell(1, `<section class="sheet"><p class="eyebrow">Browser route \xB7 no network</p><h1>Inspecting text</h1><div class="progress" aria-hidden="true"><span></span></div><p id="phase">Validating source\u2026</p><button id="cancel">Cancel inspection</button></section>`);
  app.querySelector("#cancel")?.addEventListener("click", () => abortController?.abort());
  const worker = createInspectionWorker({ workerUrl: new URL("./worker.js", import.meta.url) });
  try {
    result = await worker.inspect({
      schema_version: "1.0",
      contract_version: "1.0.0",
      request_id: `ext_${Date.now()}`,
      created_at: (/* @__PURE__ */ new Date()).toISOString(),
      source: { content: capture.text, content_type: "plain_text", language: "en-GB" },
      checks: ["unicode.invisible", "style.patterns", "watermark.anthropic", "detector.local"],
      privacy: { allowed_routes: ["browser"], save_receipt: false, retain_content: false },
      context: { caller: "chrome-extension", correlation_id: "private-session" }
    }, {
      signal: abortController.signal,
      onProgress: (phase) => {
        const target = app.querySelector("#phase");
        if (target) target.textContent = phase.replaceAll("_", " ");
      }
    });
    renderResults();
    announce("Inspection complete. Results are ready.");
  } catch (error) {
    if (error.name === "AbortError") {
      shell(1, `<section class="sheet"><p class="eyebrow">Interrupted</p><h1>Inspection cancelled</h1><p>No result or source was retained.</p><button id="return">Return to capture</button></section>`);
      app.querySelector("#return")?.addEventListener("click", () => renderCapture());
      announce("Inspection cancelled.");
    } else {
      renderCapture(`Inspection stopped safely: ${error.message}`);
    }
  } finally {
    worker.dispose();
    abortController = null;
  }
};
var statusLabel = (status) => status.replaceAll("_", " ");
var renderResults = () => {
  if (!result || !capture) return;
  const rows = result.methods.map((method) => {
    const label = method.id === "watermark.anthropic" ? "Official verifier unavailable" : method.provider_or_method;
    return `<li class="method ${method.status}"><div><strong>${escapeHtml(label)}</strong><span>${escapeHtml(method.id)}</span></div><b>${escapeHtml(statusLabel(method.status))}</b><p>${escapeHtml(method.limitations[0])}</p></li>`;
  }).join("");
  shell(1, `<section class="sheet"><p class="eyebrow">Evidence, not guarantees</p><h1>Inspection results</h1>
    <div class="summary"><div><b>${result.summary.attention}</b><span>Attention</span></div><div><b>${result.protected_spans.length}</b><span>Protected</span></div><div><b>${result.summary.unsupported}</b><span>Unavailable</span></div></div>
    <details open><summary>Named checks</summary><ul class="methods">${rows}</ul></details>
    <div class="notice neutral"><strong>Local signals</strong><p>Not configured. Browser inspection remains available without a model or provider.</p></div>
    <div class="actions"><button class="primary" id="protect">Protect facts</button><button id="back">Change source</button></div>
  </section>`);
  app.querySelector("#back")?.addEventListener("click", () => renderCapture());
  app.querySelector("#protect")?.addEventListener("click", renderProtect);
};
var renderProtect = () => {
  if (!result) return;
  const spans = result.protected_spans;
  shell(2, `<section class="sheet"><p class="eyebrow">Immutable evidence rail</p><h1>Protected content</h1><p>${spans.length} names, figures, dates, links, quotations, citations or code spans are locked before comparison.</p>
    <ul class="protected-list">${spans.slice(0, 12).map((span) => `<li><strong>${escapeHtml(span.kind)}</strong><span>${span.start_utf16}\u2013${span.end_utf16}</span></li>`).join("") || "<li>No protected spans were found.</li>"}</ul>
    <div class="actions"><button class="primary" id="improve">Prepare local candidate</button><button id="results">Back to results</button></div></section>`);
  app.querySelector("#results")?.addEventListener("click", renderResults);
  app.querySelector("#improve")?.addEventListener("click", renderImprove);
};
var renderImprove = () => {
  if (!result || !capture) return;
  const unicodeEvidence = result.methods.flatMap((method) => method.evidence).filter((item) => item?.type === "unicode_finding");
  const selected = unicodeEvidence.filter((item) => item.fix !== "review").map((item) => item.id);
  const fix = previewSafeFixes(capture.text, unicodeEvidence, selected, result.protected_spans);
  candidate = fix.candidate;
  const changed = fix.applied_finding_ids.length > 0;
  shell(3, `<section class="sheet"><p class="eyebrow">Copy-only candidate</p><h1>${changed ? "Safe character treatment prepared" : "No automatic change proposed"}</h1>
    <p>${changed ? `${fix.applied_finding_ids.length} explainable character treatment(s) were applied outside protected spans.` : "Browser-only checks found no safe automatic edit. The original remains the copyable fallback."}</p>
    <div class="notice neutral"><strong>Local engine unavailable</strong><p>The frozen local API has no pairing-code exchange operation. Connection and rewrite controls are disabled rather than simulated.</p></div>
    <div class="actions"><button class="primary" id="compare">Compare candidate</button><button id="protect-back">Back</button></div></section>`);
  app.querySelector("#protect-back")?.addEventListener("click", renderProtect);
  app.querySelector("#compare")?.addEventListener("click", renderCompare);
};
var renderCompare = () => {
  if (!result || !capture) return;
  const gates = validateCandidate({ content: capture.text, content_hash: result.source.content_hash, content_type: "plain_text", language: "en-GB" }, candidate, result.protected_spans, { expected_source_hash: result.source.content_hash });
  const blocking = gates.filter((gate) => gate.hard && gate.status !== "pass" && gate.id !== "semantic_entailment");
  shell(4, `<section class="sheet"><p class="eyebrow">Two-rail comparison</p><h1>Compare before copying</h1>
    <div class="rails"><section><h2>Original</h2><pre>${preview(capture.text)}</pre></section><section><h2>Candidate</h2><pre>${preview(candidate)}</pre></section></div>
    <p class="gate ${blocking.length ? "fail" : "pass"}"><strong>${blocking.length ? "Blocked" : "Deterministic gates passed"}</strong> \xB7 ${gates.length} gates checked; semantic entailment remains not configured.</p>
    <div id="copy-fallback" hidden><label for="fallback">Clipboard unavailable. Select all and copy:</label><textarea id="fallback" readonly>${escapeHtml(candidate)}</textarea></div>
    <div class="actions"><button class="primary" id="copy" ${blocking.length ? "disabled" : ""}>Copy selected candidate</button><button id="export">Export receipt</button><button id="improve-back">Back</button></div></section>`);
  app.querySelector("#improve-back")?.addEventListener("click", renderImprove);
  app.querySelector("#copy")?.addEventListener("click", async () => {
    try {
      await navigator.clipboard.writeText(candidate);
      announce("Candidate copied. The page was not changed.");
    } catch {
      const fallback = app.querySelector("#copy-fallback");
      fallback.hidden = false;
      app.querySelector("#fallback")?.focus();
      announce("Clipboard unavailable. A read-only copy field is ready.");
    }
  });
  app.querySelector("#export")?.addEventListener("click", () => void renderExport(gates));
};
var renderExport = async (gates) => {
  if (!result || !capture) return;
  receipt = await buildReceipt({
    receipt_id: `ext_receipt_${Date.now()}`,
    product_version: "1.0.0",
    created_at: (/* @__PURE__ */ new Date()).toISOString(),
    source: { content: capture.text, content_type: "plain_text", language: "en-GB", normalised_text: capture.text.normalize("NFC") },
    policy: { id: "extension-browser", version: "1.0.0", requested_checks: result.methods.map((method) => method.id), allowed_routes: ["browser"], retain_content: false },
    methods: result.methods,
    rewrite: candidate === capture.text ? null : { source_hash: result.source.content_hash, candidate_hash: prefixedSha256(candidate), generator: { route: "browser", provider: "Opace deterministic core", model: "none", prompt_template: "safe-unicode-preview" }, gates, selected_candidate: "candidate_1", candidate_content: candidate },
    approval: { scope: "none" },
    limitations: ["This hash-only receipt contains no source URL or text and does not prove human authorship."],
    contains_content: false
  });
  shell(5, `<section class="sheet"><p class="eyebrow">Hash-only evidence</p><h1>Receipt ready</h1><p>The JSON contains hashes, method states and limitations. It contains no source URL, source text or candidate text.</p>
    <dl><div><dt>Methods</dt><dd>${receipt.methods.length}</dd></div><div><dt>Content retained</dt><dd>No</dd></div><div><dt>History</dt><dd>Off</dd></div></dl>
    <div class="actions"><button class="primary" id="download">Download JSON receipt</button><button id="clear-data">Clear extension data</button><button id="compare-back">Back</button></div><p id="clear-result" role="status"></p></section>`);
  app.querySelector("#compare-back")?.addEventListener("click", renderCompare);
  app.querySelector("#download")?.addEventListener("click", () => {
    const blob = new Blob([`${JSON.stringify(receipt, null, 2)}
`], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `${receipt.receipt_id}.json`;
    anchor.click();
    URL.revokeObjectURL(url);
    announce("Hash-only receipt download started.");
  });
  app.querySelector("#clear-data")?.addEventListener("click", async () => {
    const counts = await clearAllExtensionData();
    const target = app.querySelector("#clear-result");
    target.textContent = `Cleared ${counts.local} local setting group(s) and ${counts.session} session marker(s). No text history existed.`;
  });
};
var initialise = async () => {
  const settings = await loadSettings();
  document.documentElement.dataset.contrast = settings.highContrast ? "high" : "normal";
  await saveSettings(settings);
  const pending = await chrome.runtime.sendMessage({ type: "GET_PENDING" });
  if (pending?.capture) {
    capture = pending.capture;
    renderCapture();
    return;
  }
  if (pending?.interrupted) {
    capture = { kind: "paste", text: "", host: "", title: "Interrupted", limitations: [] };
    renderCapture("The browser interrupted an unfinished capture. No source or result was retained; paste or capture again.");
    return;
  }
  capture = { kind: "paste", text: "", host: "", title: "Pasted text", limitations: [] };
  renderCapture();
};
void initialise();
