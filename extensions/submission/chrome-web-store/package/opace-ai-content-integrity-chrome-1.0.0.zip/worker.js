// node_modules/@opace/content-integrity-browser/dist/worker/entry.js
var ENTITIES = { amp: "&", lt: "<", gt: ">", quot: '"', apos: "'", nbsp: "\xA0" };
var decodeEntity = (raw) => {
  if (raw[1] !== "#") return ENTITIES[raw.slice(1, -1)] ?? raw;
  const value = raw[2]?.toLowerCase() === "x" ? Number.parseInt(raw.slice(3, -1), 16) : Number.parseInt(raw.slice(2, -1), 10);
  return Number.isInteger(value) && value >= 0 && value <= 1114111 && !(value >= 55296 && value <= 57343) ? String.fromCodePoint(value) : raw;
};
function projectVisibleText(source, contentType) {
  if (contentType === "plain_text") return { text: source, runs: source ? [{ visible_start_utf16: 0, visible_end_utf16: source.length, source_start_utf16: 0, source_end_utf16: source.length }] : [], limitations: [] };
  if (contentType === "markdown") {
    const text2 = source.replace(/```[\s\S]*?```/g, (m) => m).replace(/!?(\[([^\]]*)\])\(([^)]+)\)/g, (_m, _a, label) => label).replace(/(^|\s)[*_]{1,3}([^*_]+)[*_]{1,3}/g, "$1$2");
    return { text: text2, runs: text2 ? [{ visible_start_utf16: 0, visible_end_utf16: text2.length, source_start_utf16: 0, source_end_utf16: source.length }] : [], limitations: ["Markdown mapping is projection-level; protected extractors retain exact source ranges."] };
  }
  let text = "", cursor = 0;
  const runs = [];
  const excluded = /<(script|style|template|noscript)\b[^>]*>[\s\S]*?<\/\1\s*>|<!--[\s\S]*?-->/gi;
  const safe = source.replace(excluded, (m) => " ".repeat(m.length));
  const token = /<[^>]*>|&(?:#x?[0-9a-f]+|[a-z]+);/gi;
  let match;
  const append = (value, start, end) => {
    if (!value) return;
    const v = text.length;
    text += value;
    runs.push({ visible_start_utf16: v, visible_end_utf16: text.length, source_start_utf16: start, source_end_utf16: end });
  };
  while (match = token.exec(safe)) {
    append(safe.slice(cursor, match.index), cursor, match.index);
    const raw = match[0];
    if (/^<(br|\/?(?:p|div|section|article|li|h[1-6]|blockquote|tr))\b/i.test(raw)) append("\n", match.index, token.lastIndex);
    else if (raw[0] === "&") append(decodeEntity(raw), match.index, token.lastIndex);
    cursor = token.lastIndex;
  }
  append(safe.slice(cursor), cursor, safe.length);
  return { text, runs, limitations: ["HTML projection is deterministic text extraction, not sanitisation."] };
}
var K = new Uint32Array([
  1116352408,
  1899447441,
  3049323471,
  3921009573,
  961987163,
  1508970993,
  2453635748,
  2870763221,
  3624381080,
  310598401,
  607225278,
  1426881987,
  1925078388,
  2162078206,
  2614888103,
  3248222580,
  3835390401,
  4022224774,
  264347078,
  604807628,
  770255983,
  1249150122,
  1555081692,
  1996064986,
  2554220882,
  2821834349,
  2952996808,
  3210313671,
  3336571891,
  3584528711,
  113926993,
  338241895,
  666307205,
  773529912,
  1294757372,
  1396182291,
  1695183700,
  1986661051,
  2177026350,
  2456956037,
  2730485921,
  2820302411,
  3259730800,
  3345764771,
  3516065817,
  3600352804,
  4094571909,
  275423344,
  430227734,
  506948616,
  659060556,
  883997877,
  958139571,
  1322822218,
  1537002063,
  1747873779,
  1955562222,
  2024104815,
  2227730452,
  2361852424,
  2428436474,
  2756734187,
  3204031479,
  3329325298
]);
var rotr = (x, n) => x >>> n | x << 32 - n;
function utf8Bytes(value) {
  return new TextEncoder().encode(value);
}
function sha256Hex(value) {
  const source = utf8Bytes(value);
  const bitLength = source.length * 8;
  const paddedLength = Math.ceil((source.length + 9) / 64) * 64;
  const bytes = new Uint8Array(paddedLength);
  bytes.set(source);
  bytes[source.length] = 128;
  const view = new DataView(bytes.buffer);
  view.setUint32(paddedLength - 4, bitLength >>> 0, false);
  view.setUint32(paddedLength - 8, Math.floor(bitLength / 4294967296), false);
  const h = new Uint32Array([1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924, 528734635, 1541459225]);
  const w = new Uint32Array(64);
  for (let offset = 0; offset < paddedLength; offset += 64) {
    for (let i = 0; i < 16; i++) w[i] = view.getUint32(offset + i * 4, false);
    for (let i = 16; i < 64; i++) {
      const a2 = w[i - 15], b2 = w[i - 2];
      w[i] = (rotr(a2, 7) ^ rotr(a2, 18) ^ a2 >>> 3) + w[i - 16] + (rotr(b2, 17) ^ rotr(b2, 19) ^ b2 >>> 10) + w[i - 7] >>> 0;
    }
    let [a, b, c, d, e, f, g, hh] = h;
    for (let i = 0; i < 64; i++) {
      const s1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25);
      const ch = e & f ^ ~e & g;
      const t1 = hh + s1 + ch + K[i] + w[i] >>> 0;
      const s0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22);
      const maj = a & b ^ a & c ^ b & c;
      const t2 = s0 + maj >>> 0;
      hh = g;
      g = f;
      f = e;
      e = d + t1 >>> 0;
      d = c;
      c = b;
      b = a;
      a = t1 + t2 >>> 0;
    }
    h[0] = h[0] + a >>> 0;
    h[1] = h[1] + b >>> 0;
    h[2] = h[2] + c >>> 0;
    h[3] = h[3] + d >>> 0;
    h[4] = h[4] + e >>> 0;
    h[5] = h[5] + f >>> 0;
    h[6] = h[6] + g >>> 0;
    h[7] = h[7] + hh >>> 0;
  }
  return Array.from(h, (n) => n.toString(16).padStart(8, "0")).join("");
}
var prefixedSha256 = (value) => `sha256:${sha256Hex(value)}`;
function utf16ToCodePointOffset(text, offset) {
  if (!Number.isInteger(offset) || offset < 0 || offset > text.length) throw new RangeError("invalid_utf16_offset");
  if (offset > 0 && offset < text.length && /[\uD800-\uDBFF]/.test(text[offset - 1]) && /[\uDC00-\uDFFF]/.test(text[offset])) throw new RangeError("split_surrogate");
  return Array.from(text.slice(0, offset)).length;
}
function rangeFromUtf16(text, start, end) {
  if (end <= start) throw new RangeError("empty_or_reversed_range");
  return { start_utf16: start, end_utf16: end, start_codepoint: utf16ToCodePointOffset(text, start), end_codepoint: utf16ToCodePointOffset(text, end) };
}
var RULES = /* @__PURE__ */ new Map([
  [65279, { name: "BYTE ORDER MARK", severity: "low", fix: "remove", message: "A byte-order mark is present." }],
  [8203, { name: "ZERO WIDTH SPACE", severity: "medium", fix: "remove", message: "An invisible zero-width space is present." }],
  [8288, { name: "WORD JOINER", severity: "medium", fix: "remove", message: "An invisible word joiner is present." }],
  [173, { name: "SOFT HYPHEN", severity: "low", fix: "remove", message: "A discretionary soft hyphen is present." }],
  [160, { name: "NO-BREAK SPACE", severity: "note", fix: "space", message: "A non-breaking space is present." }],
  [8201, { name: "THIN SPACE", severity: "note", fix: "space", message: "A thin space is present." }],
  [65533, { name: "REPLACEMENT CHARACTER", severity: "high", fix: "review", message: "A replacement character may indicate damaged text." }]
]);
var BIDI = /* @__PURE__ */ new Set([8234, 8235, 8236, 8237, 8238, 8294, 8295, 8296, 8297]);
function inspectUnicode(text) {
  const findings = [];
  for (let i = 0; i < text.length; ) {
    const cp = text.codePointAt(i);
    const width = cp > 65535 ? 2 : 1;
    const rule = RULES.get(cp) ?? (BIDI.has(cp) ? { name: "BIDIRECTIONAL CONTROL", severity: "medium", fix: "review", message: "A bidirectional formatting control is present." } : void 0);
    if (rule) {
      const raw = text.slice(i, i + width);
      findings.push({ id: `unicode_${i}_${cp.toString(16)}`, code_point: `U+${cp.toString(16).toUpperCase().padStart(4, "0")}`, name: rule.name, severity: rule.severity, message: rule.message, suggestion: rule.fix === "review" ? "Review the surrounding script and direction before editing." : "Preview the deterministic change before approval.", span: rangeFromUtf16(text, i, i + width), matched_text_hash: prefixedSha256(raw), fix: rule.fix, limitations: ["Unicode controls can be legitimate in multilingual text; this finding is not evidence of authorship."] });
    }
    if (cp >= 55296 && cp <= 57343) {
      findings.push({ id: `unicode_${i}_surrogate`, code_point: `U+${cp.toString(16).toUpperCase()}`, name: "UNPAIRED SURROGATE", severity: "high", message: "An unpaired UTF-16 surrogate cannot be encoded as valid UTF-8.", suggestion: "Replace or remove it after checking the source encoding.", span: { start_utf16: i, end_utf16: i + 1, start_codepoint: Array.from(text.slice(0, i)).length, end_codepoint: Array.from(text.slice(0, i)).length + 1 }, matched_text_hash: prefixedSha256("\uFFFD"), fix: "review", limitations: ["The displayed replacement may differ from the original invalid code unit."] });
    }
    i += width;
  }
  const tokens2 = [...text.matchAll(/[\p{L}\p{N}_-]+/gu)];
  const confusable = /* @__PURE__ */ new Map([[1072, "CYRILLIC SMALL LETTER A"], [1077, "CYRILLIC SMALL LETTER IE"], [1086, "CYRILLIC SMALL LETTER O"], [1088, "CYRILLIC SMALL LETTER ER"], [1089, "CYRILLIC SMALL LETTER ES"], [1093, "CYRILLIC SMALL LETTER HA"], [1091, "CYRILLIC SMALL LETTER U"]]);
  for (const token of tokens2) {
    const value = token[0];
    if (!new RegExp("\\p{Script=Latin}", "u").test(value) || !new RegExp("\\p{Script=Cyrillic}|\\p{Script=Greek}", "u").test(value)) continue;
    let local = 0;
    for (const char of value) {
      const cp = char.codePointAt(0), name = confusable.get(cp);
      if (name) {
        const start = token.index + local;
        findings.push({ id: `unicode_${start}_homoglyph_${cp.toString(16)}`, code_point: `U+${cp.toString(16).toUpperCase().padStart(4, "0")}`, name, severity: "medium", message: "A mixed-script token contains a character visually confusable with Latin text.", suggestion: "Verify the intended spelling; homoglyphs are never replaced automatically.", span: rangeFromUtf16(text, start, start + char.length), matched_text_hash: prefixedSha256(char), fix: "review", limitations: ["Mixed scripts can be legitimate in names and multilingual text; this is contextual evidence only."] });
      }
      local += char.length;
    }
  }
  return findings;
}
var RULES2 = [
  ["code", /```[\s\S]*?```|`[^`\n]+`/g],
  ["url", /https?:\/\/[^\s<>)\]]+/g],
  ["email", /\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/gi],
  ["citation", /\[[0-9]+\]|\([A-Z][A-Za-z-]+,?\s+\d{4}[a-z]?\)/g],
  ["quote", /[“"][^”"\n]+[”"]/g],
  ["currency", /(?:£|\$|€)\s?\d[\d,]*(?:\.\d+)?/g],
  ["date", /\b(?:\d{1,2}\s+[A-Z][a-z]+\s+\d{4}|\d{4}-\d{2}-\d{2})\b/g],
  ["time", /\b\d{1,2}:\d{2}(?:\s?[ap]m)?\b/gi],
  ["unit", /\b\d+(?:\.\d+)?\s?(?:kg|g|km|m|cm|mm|GB|MB|%|°C)\b/g],
  ["number", /\b\d[\d,]*(?:\.\d+)?%?\b/g]
];
function extractProtectedSpans(source, policy = {}) {
  const hash = source.content_hash ?? prefixedSha256(source.content);
  const spans = [];
  const add = (text, start, kind, origin, protection = "exact") => {
    const r = rangeFromUtf16(source.content, start, start + text.length);
    spans.push({ id: `ps_${kind}_${start}_${prefixedSha256(text).slice(7, 15)}`, kind, text, ...r, normalised_value: text, policy: protection, source: origin, confidence: null, content_hash: hash });
  };
  for (const [kind, regex] of RULES2) {
    regex.lastIndex = 0;
    for (const m of source.content.matchAll(regex)) add(m[0], m.index, kind, "deterministic", kind === "date" || kind === "number" ? "equivalent_format" : "exact");
  }
  for (const term of policy.configured_terms ?? []) {
    let at = 0;
    while ((at = source.content.indexOf(term.text, at)) >= 0) {
      add(term.text, at, term.kind ?? "name", "user");
      at += term.text.length;
    }
  }
  for (const selected of policy.user_spans ?? []) add(source.content.slice(selected.start_utf16, selected.end_utf16), selected.start_utf16, "user_selected", "user");
  const unique = /* @__PURE__ */ new Map();
  for (const span of spans) unique.set(`${span.start_utf16}:${span.end_utf16}:${span.kind}:${span.policy}`, span);
  return [...unique.values()].sort((a, b) => a.start_utf16 - b.start_utf16 || b.end_utf16 - b.start_utf16 - (a.end_utf16 - a.start_utf16) || a.id.localeCompare(b.id));
}
var EN_GB_PATTERN_VERSION = "en-gb:2026.08.1";
var PHRASES = ["in today's rapidly evolving landscape", "game-changer", "in conclusion", "it is important to note", "delve into"];
var finding = (text, start, rule, severity, message, suggestion, evidence) => ({ rule_id: rule, rule_version: EN_GB_PATTERN_VERSION, severity, message, suggestion, span: rangeFromUtf16(text, start, start + String(evidence.matched ?? text.slice(start, start + 1)).length), matched_text_hash: prefixedSha256(String(evidence.matched ?? "")), evidence });
function inspectPatterns(text) {
  const findings = [];
  const lower = text.toLocaleLowerCase("en-GB");
  for (const phrase of PHRASES) {
    let at = 0, count = 0;
    while ((at = lower.indexOf(phrase, at)) >= 0) {
      count++;
      at += phrase.length;
    }
    if (count >= 1) {
      const start = lower.indexOf(phrase);
      findings.push(finding(text, start, "style.overused_phrase", count > 1 ? "medium" : "low", "A stock phrase may make the passage feel generic.", "Review whether a more specific statement would be clearer.", { matched: text.slice(start, start + phrase.length), count, threshold: 1 }));
    }
  }
  const sentences = text.split(/(?<=[.!?])\s+/).filter(Boolean);
  const openings = /* @__PURE__ */ new Map();
  let cursor = 0;
  for (const sentence of sentences) {
    const start = text.indexOf(sentence, cursor);
    cursor = start + sentence.length;
    const opening = sentence.trim().split(/\s+/).slice(0, 3).join(" ").toLocaleLowerCase("en-GB");
    if (opening.split(" ").length >= 2) (openings.get(opening) ?? (openings.set(opening, []), openings.get(opening))).push(start);
  }
  for (const [opening, starts] of openings) if (starts.length >= 3) findings.push(finding(text, starts[0], "style.repeated_opening", "medium", "Several sentences begin the same way.", "Vary only the openings that genuinely benefit from it.", { matched: text.slice(starts[0], starts[0] + opening.length), count: starts.length, threshold: 3 }));
  const transitions = (lower.match(/\b(?:moreover|furthermore|additionally|consequently|therefore|however)\b/g) ?? []).length;
  const wordCount = text.trim() ? text.trim().split(/\s+/).length : 0;
  if (wordCount >= 40 && transitions / wordCount > 0.04) {
    const m = /\b(?:moreover|furthermore|additionally|consequently|therefore|however)\b/i.exec(text);
    findings.push(finding(text, m.index, "style.transition_density", "low", "Transition words are unusually dense.", "Remove transitions that do not clarify the relationship between sentences.", { matched: m[0], count: transitions, word_count: wordCount, threshold_ratio: 0.04 }));
  }
  return findings.sort((a, b) => a.span.start_utf16 - b.span.start_utf16 || a.rule_id.localeCompare(b.rule_id));
}
var packs = /* @__PURE__ */ new Map();
var runRegisteredPacks = (text) => [...packs.values()].flatMap((pack) => pack.inspect(text));
var limits = (message) => [message, "Authorship cannot be proved from this check."];
async function inspect(request, options = {}) {
  const now = options.now ?? (() => (/* @__PURE__ */ new Date()).toISOString()), started = now();
  const progress = (p) => {
    if (options.signal?.aborted) throw new DOMException("Inspection cancelled", "AbortError");
    options.onProgress?.(p);
  };
  progress("validating");
  if (request.schema_version !== "1.0" || !request.contract_version.startsWith("1.")) throw new Error("contract_incompatible");
  if (request.source.content.length > 25e4) throw new Error("request_too_large");
  if (hasUnpairedSurrogate(request.source.content)) throw new Error("invalid_unicode_unpaired_surrogate");
  const sourceHash = prefixedSha256(request.source.content);
  progress("mapping_text");
  const projection = projectVisibleText(request.source.content, request.source.content_type);
  progress("unicode_checks");
  const unicode = inspectUnicode(request.source.content);
  progress("protected_spans");
  const protectedSpans = extractProtectedSpans({ ...request.source, content_hash: sourceHash });
  progress("writing_patterns");
  const patternFindings = [...inspectPatterns(projection.text), ...runRegisteredPacks(projection.text)];
  const methods = [];
  for (const id of request.checks) {
    const methodStarted = now();
    if (id.startsWith("unicode.")) {
      methods.push(method(id, "unicode", "Opace deterministic Unicode inspection", "unicode:2026.08.1", unicode.length ? "attention" : "pass", unicode.map((x) => ({ type: "unicode_finding", ...x })), limits("Unicode controls can be legitimate in multilingual text."), methodStarted, now(), "browser"));
    } else if (id === "style.patterns") {
      methods.push(method(id, "pattern", "Opace writing-pattern rules", "en-gb:2026.08.1", patternFindings.length ? "attention" : "pass", patternFindings.map((x) => ({ type: "pattern_finding", rule_id: x.rule_id, span: x.span })), limits("Writing patterns are editorial prompts, not detector or watermark evidence."), methodStarted, now(), "browser"));
    } else if (id === "watermark.anthropic") {
      methods.push({ ...method(id, "watermark", "Anthropic official text-watermark detector", "unavailable-2026-08-26", "unsupported", [], ["No official detector call was available. Local style or public SynthID tests are not substitutes."], methodStarted, now(), "browser"), availability: "not_available", native_outcome: "not_available" });
    } else methods.push(method(id, "detector", id, "unsupported/1", "unsupported", [], ["This requested method is not implemented in the deterministic browser core."], methodStarted, now(), "browser"));
  }
  const summary = { pass: 0, attention: 0, fail: 0, inconclusive: 0, unsupported: 0, not_configured: 0, not_run: 0, error: 0 };
  for (const item of methods) summary[item.status]++;
  progress("complete");
  const result = { schema_version: "1.0", contract_version: "1.0.0", request_id: request.request_id, analysis_id: options.analysisId?.() ?? `analysis_${sourceHash.slice(7, 23)}`, source: { content_hash: sourceHash, normalised_hash: prefixedSha256(projection.text.normalize("NFC")), content_type: request.source.content_type, language: request.source.language, word_count: (projection.text.trim().match(/\S+/g) ?? []).length }, protected_spans: protectedSpans, pattern_findings: patternFindings, methods, summary, limitations: ["Authorship cannot be proved from these checks.", ...projection.limitations], started_at: started, completed_at: now() };
  return deepFreeze(result);
}
function method(id, category, provider, version, status, evidence, limitations, started_at, completed_at, privacy_route) {
  if (!limitations.length) throw new Error("method_limitations_required");
  return { id, category, provider_or_method: provider, version, status, score: null, threshold: null, segments: [], evidence, limitations, started_at, completed_at, privacy_route };
}
function deepFreeze(value) {
  if (value && typeof value === "object" && !Object.isFrozen(value)) {
    Object.freeze(value);
    for (const child of Object.values(value)) deepFreeze(child);
  }
  return value;
}
function hasUnpairedSurrogate(value) {
  for (let i = 0; i < value.length; i++) {
    const code = value.charCodeAt(i);
    if (code >= 55296 && code <= 56319) {
      const next = value.charCodeAt(i + 1);
      if (!(next >= 56320 && next <= 57343)) return true;
      i++;
    } else if (code >= 56320 && code <= 57343) return true;
  }
  return false;
}
var METHODS = Object.freeze([
  Object.freeze({ id: "unicode.invisible", category: "unicode", version: "unicode:2026.08.1", state: "available", privacy_routes: ["browser"], limitations: ["Controls can be legitimate in multilingual text."] }),
  Object.freeze({ id: "unicode.homoglyph", category: "unicode", version: "unicode:2026.08.1", state: "available", privacy_routes: ["browser"], limitations: ["Mixed scripts require contextual human review."] }),
  Object.freeze({ id: "style.patterns", category: "pattern", version: "en-gb:2026.08.1", state: "available", privacy_routes: ["browser"], limitations: ["Editorial pattern findings are not authorship evidence."] }),
  Object.freeze({ id: "watermark.anthropic", category: "watermark", version: "adapter-placeholder/1", state: "unsupported", privacy_routes: ["browser"], limitations: ["No official detector interface is available."] })
]);
var WORKER_PROTOCOL_VERSION = "1.0";
var controllers = /* @__PURE__ */ new Map();
self.onmessage = async (event) => {
  const m = event.data;
  if (m.protocol_version !== WORKER_PROTOCOL_VERSION) return;
  if (m.type === "cancel") {
    controllers.get(m.id)?.abort();
    return;
  }
  const controller = new AbortController();
  controllers.set(m.id, controller);
  try {
    const result = await inspect(m.request, { signal: controller.signal, onProgress: (phase) => self.postMessage({ protocol_version: WORKER_PROTOCOL_VERSION, type: "progress", id: m.id, phase }) });
    self.postMessage({ protocol_version: WORKER_PROTOCOL_VERSION, type: "result", id: m.id, result });
  } catch (error) {
    self.postMessage({ protocol_version: WORKER_PROTOCOL_VERSION, type: "error", id: m.id, code: error instanceof DOMException && error.name === "AbortError" ? "job_cancelled" : "internal_error", message: "Inspection did not complete." });
  } finally {
    controllers.delete(m.id);
  }
};
