// src/popup.ts
var statusMessage = document.querySelector("#status");
var openPanel = async (kind) => {
  statusMessage.textContent = "Opening private inspection\u2026";
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (typeof tab?.id !== "number" || typeof tab.windowId !== "number") {
    statusMessage.textContent = "No active page is available. Paste text in the side panel instead.";
    return;
  }
  await chrome.sidePanel.open({ tabId: tab.id });
  await chrome.runtime.sendMessage(kind === "paste" ? { type: "START_PASTE" } : { type: "START_CAPTURE", tabId: tab.id, kind });
  window.close();
};
document.querySelector("#selection")?.addEventListener("click", () => void openPanel("selection"));
document.querySelector("#article")?.addEventListener("click", () => void openPanel("article"));
document.querySelector("#paste")?.addEventListener("click", () => void openPanel("paste"));
