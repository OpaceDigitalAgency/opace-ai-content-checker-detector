var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
  get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
}) : x)(function(x) {
  if (typeof require !== "undefined") return require.apply(this, arguments);
  throw Error('Dynamic require of "' + x + '" is not supported');
});
var __esm = (fn2, res, err) => function __init() {
  if (err) throw err[0];
  try {
    return fn2 && (res = (0, fn2[__getOwnPropNames(fn2)[0]])(fn2 = 0)), res;
  } catch (e) {
    throw err = [e], e;
  }
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// ../../packages/cycle5-browser/node_modules/onnxruntime-web/dist/ort.wasm.bundle.min.mjs
var ort_wasm_bundle_min_exports = {};
__export(ort_wasm_bundle_min_exports, {
  InferenceSession: () => ts,
  TRACE: () => xr,
  TRACE_EVENT_BEGIN: () => Pe,
  TRACE_EVENT_END: () => Ue,
  TRACE_FUNC_BEGIN: () => _e,
  TRACE_FUNC_END: () => De,
  Tensor: () => de,
  default: () => au,
  env: () => Y,
  registerBackend: () => qe
});
async function Vr(n = {}) {
  var t = n, a = !!globalThis.window, u = !!globalThis.WorkerGlobalScope, o = u && self.name?.startsWith("em-pthread");
  t.mountExternalData = (e, r) => {
    e.startsWith("./") && (e = e.substring(2)), (t.Rb || (t.Rb = /* @__PURE__ */ new Map())).set(e, r);
  }, t.unmountExternalData = () => {
    delete t.Rb, delete t.kc, delete t.jc, delete t.lc;
  }, globalThis.SharedArrayBuffer ?? new WebAssembly.Memory({ initial: 0, maximum: 0, shared: true }).buffer.constructor;
  var d, c, l = (e, r) => {
    throw r;
  }, m = import.meta.url, h = "";
  if (a || u) {
    try {
      h = new URL(".", m).href;
    } catch {
    }
    u && (c = (e) => {
      var r = new XMLHttpRequest();
      return r.open("GET", e, false), r.responseType = "arraybuffer", r.send(null), new Uint8Array(r.response);
    }), d = async (e) => {
      if (k(e)) return new Promise((i, s) => {
        var f = new XMLHttpRequest();
        f.open("GET", e, true), f.responseType = "arraybuffer", f.onload = () => {
          f.status == 200 || f.status == 0 && f.response ? i(f.response) : s(f.status);
        }, f.onerror = s, f.send(null);
      });
      var r = await fetch(e, { credentials: "same-origin" });
      if (r.ok) return r.arrayBuffer();
      throw Error(r.status + " : " + r.url);
    };
  }
  var g, b, y, T, I, _, $ = console.log.bind(console), v = console.error.bind(console), O = $, N = v, D = false, k = (e) => e.startsWith("file://");
  function w() {
    ge.buffer != H.buffer && ee();
  }
  if (o) {
    let e = function(r) {
      try {
        var i = r.data, s = i.Pb;
        if (s === "load") {
          let f = [];
          self.onmessage = (p) => f.push(p), _ = () => {
            postMessage({ Pb: "loaded" });
            for (let p of f) e(p);
            self.onmessage = e;
          };
          for (let p of i.Zb) t[p] && !t[p].proxy || (t[p] = (...E) => {
            postMessage({ Pb: "callHandler", Yb: p, args: E });
          }, p == "print" && (O = t[p]), p == "printErr" && (N = t[p]));
          ge = i.dc, ee(), b = i.ec, Ut(), it();
        } else if (s === "run") {
          (function(f) {
            var p = (w(), W)[f + 52 >>> 2 >>> 0];
            f = (w(), W)[f + 56 >>> 2 >>> 0], sr(p, p - f), P(p);
          })(i.Ob), zt(i.Ob, 0, 0, 1, 0, 0), wn(), Nt(i.Ob), Z ||= true;
          try {
            Ao(i.bc, i.Tb);
          } catch (f) {
            if (f != "unwind") throw f;
          }
        } else i.target !== "setimmediate" && (s === "checkMailbox" ? Z && rt() : s && (N(`worker: received unknown command ${s}`), N(i)));
      } catch (f) {
        throw tr(), f;
      }
    };
    var Ss = e, Z = false;
    self.onunhandledrejection = (r) => {
      throw r.reason || r;
    }, self.onmessage = e;
  }
  var H, ne, pe, B, W, re, me, A, K3, je = false;
  function ee() {
    var e = ge.buffer;
    t.HEAP8 = H = new Int8Array(e), pe = new Int16Array(e), t.HEAPU8 = ne = new Uint8Array(e), new Uint16Array(e), t.HEAP32 = B = new Int32Array(e), t.HEAPU32 = W = new Uint32Array(e), re = new Float32Array(e), me = new Float64Array(e), A = new BigInt64Array(e), new BigUint64Array(e);
  }
  function he() {
    je = true, o ? _() : Ee.Ta();
  }
  function j(e) {
    throw N(e = "Aborted(" + e + ")"), D = true, e = new WebAssembly.RuntimeError(e + ". Build with -sASSERTIONS for more info."), I?.(e), e;
  }
  function q() {
    return { a: { T: fa, f: Io, w: Bo, e: Lo, k: _o, h: Do, L: Po, b: Uo, G: xo, ta: vn, j: Co, M: In, Ja: Bn, pa: Ln, ra: _n, Ka: Dn, Ha: Pn, Aa: Un, Ga: xn, Z: Cn, qa: Mn, na: Rn, Ia: Nn, oa: Fn, Pa: Mo, Da: Ro, la: Fo, ua: ko, ia: Wo, U: Go, Ca: Nt, Ma: $o, xa: zo, ya: Ho, za: jo, va: $n, wa: zn, ja: Hn, Ra: Yo, Oa: Xo, W: Qo, V: Zo, Na: Jo, F: Ko, La: ea, ma: ta, u: Vo, H: na, R: at, ka: oa, ba: ra, Sa: aa, Ea: Yn, Fa: Jn, sa: ye, I: qn, Y: Xn, Ba: Qn, X: Zn, $: ja, N: Wa, aa: Ha, O: ka, v: _a, d: pa, m: la, n: ca, r: va, ca: Ra, E: Ma, o: wa, P: Na, C: Ga, J: Ca, da: xa, ea: Ua, z: Oa, Q: Pa, fa: Da, y: Ba, D: Fa, c: da, q: ha, i: ma, _: Va, l: ya, p: ga, s: ba, t: Ea, x: Aa, S: La, A: $a, K: Ia, B: za, ga: Sa, ha: Ta, g: ia, a: ge, Qa: V } };
  }
  async function Ut() {
    function e(s, f) {
      return Ee = s.exports, Ee = (function() {
        var p = Ee, E = (x) => () => x() >>> 0, S = (x) => (R) => x(R) >>> 0;
        return (p = Object.assign({}, p)).sb = E(p.sb), p.ub = S(p.ub), p.Ib = S(p.Ib), p.Jb = E(p.Jb), p.Nb = S(p.Nb), p;
      })(), mn.push(Ee.vb), s = Ee, t._OrtInit = s.Ua, t._OrtGetLastError = s.Va, t._OrtCreateSessionOptions = s.Wa, t._OrtAppendExecutionProvider = s.Xa, t._OrtAddFreeDimensionOverride = s.Ya, t._OrtAddSessionConfigEntry = s.Za, t._OrtReleaseSessionOptions = s._a, t._OrtCreateSession = s.$a, t._OrtReleaseSession = s.ab, t._OrtGetInputOutputCount = s.bb, t._OrtGetInputOutputMetadata = s.cb, t._OrtFree = s.db, t._OrtCreateTensor = s.eb, t._OrtGetTensorData = s.fb, t._OrtReleaseTensor = s.gb, t._OrtCreateRunOptions = s.hb, t._OrtAddRunConfigEntry = s.ib, t._OrtReleaseRunOptions = s.jb, t._OrtCreateBinding = s.kb, t._OrtBindInput = s.lb, t._OrtBindOutput = s.mb, t._OrtClearBoundOutputs = s.nb, t._OrtReleaseBinding = s.ob, t._OrtRunWithBinding = s.pb, t._OrtRun = s.qb, t._OrtEndProfiling = s.rb, st = s.sb, Kn = t._free = s.tb, er = t._malloc = s.ub, zt = s.xb, tr = s.yb, nr = s.zb, rr = s.Ab, Ht = s.Bb, or = s.Cb, ar = s.Db, C = s.Eb, Je = s.Fb, sr = s.Gb, P = s.Hb, jt = s.Ib, U = s.Jb, ir = s.Kb, Vt = s.Lb, ur = s.Mb, fr = s.Nb, cr = s.wb, b = f, Ee;
    }
    var r, i = q();
    return t.instantiateWasm ? new Promise((s) => {
      t.instantiateWasm(i, (f, p) => {
        s(e(f, p));
      });
    }) : o ? e(new WebAssembly.Instance(b, q()), b) : (K3 ??= t.locateFile ? t.locateFile ? t.locateFile("ort-wasm-simd-threaded.wasm", h) : h + "ort-wasm-simd-threaded.wasm" : new URL("ort-wasm-simd-threaded.wasm", import.meta.url).href, r = await (async function(s) {
      var f = K3;
      if (!g && !k(f)) try {
        var p = fetch(f, { credentials: "same-origin" });
        return await WebAssembly.instantiateStreaming(p, s);
      } catch (E) {
        N(`wasm streaming compile failed: ${E}`), N("falling back to ArrayBuffer instantiation");
      }
      return (async function(E, S) {
        try {
          var x = await (async function(R) {
            if (!g) try {
              var X = await d(R);
              return new Uint8Array(X);
            } catch {
            }
            if (R == K3 && g) R = new Uint8Array(g);
            else {
              if (!c) throw "both async and sync fetching of the wasm failed";
              R = c(R);
            }
            return R;
          })(E);
          return await WebAssembly.instantiate(x, S);
        } catch (R) {
          N(`failed to asynchronously prepare wasm: ${R}`), j(R);
        }
      })(f, s);
    })(i), e(r.instance, r.module));
  }
  class Se {
    name = "ExitStatus";
    constructor(r) {
      this.message = `Program terminated with exit(${r})`, this.status = r;
    }
  }
  var ve = (e) => {
    e.terminate(), e.onmessage = () => {
    };
  }, Ve = [], Re = 0, te = null, ue = (e) => {
    ce.length == 0 && (yn(), bn(ce[0]));
    var r = ce.pop();
    if (!r) return 6;
    Ne.push(r), Oe[e.Ob] = r, r.Ob = e.Ob;
    var i = { Pb: "run", bc: e.ac, Tb: e.Tb, Ob: e.Ob };
    return r.postMessage(i, e.Xb), 0;
  }, se = 0, L = (e, r, ...i) => {
    var s, f = 16 * i.length, p = U(), E = jt(f), S = E >>> 3;
    for (s of i) typeof s == "bigint" ? ((w(), A)[S++ >>> 0] = 1n, (w(), A)[S++ >>> 0] = s) : ((w(), A)[S++ >>> 0] = 0n, (w(), me)[S++ >>> 0] = s);
    return e = nr(e, 0, f, E, r), P(p), e;
  };
  function V(e) {
    if (o) return L(0, 1, e);
    if (y = e, !(0 < se)) {
      for (var r of Ne) ve(r);
      for (r of ce) ve(r);
      ce = [], Ne = [], Oe = {}, D = true;
    }
    l(0, new Se(e));
  }
  function fe(e) {
    if (o) return L(1, 0, e);
    ye(e);
  }
  var ye = (e) => {
    if (y = e, o) throw fe(e), "unwind";
    V(e);
  }, ce = [], Ne = [], mn = [], Oe = {}, hn = (e) => {
    var r = e.Ob;
    delete Oe[r], ce.push(e), Ne.splice(Ne.indexOf(e), 1), e.Ob = 0, rr(r);
  };
  function wn() {
    mn.forEach((e) => e());
  }
  var bn = (e) => new Promise((r) => {
    e.onmessage = (f) => {
      var p = f.data;
      if (f = p.Pb, p.Sb && p.Sb != st()) {
        var E = Oe[p.Sb];
        E ? E.postMessage(p, p.Xb) : N(`Internal error! Worker sent a message "${f}" to target pthread ${p.Sb}, but that thread no longer exists!`);
      } else f === "checkMailbox" ? rt() : f === "spawnThread" ? ue(p) : f === "cleanupThread" ? Rt(() => {
        hn(Oe[p.cc]);
      }) : f === "loaded" ? (e.loaded = true, r(e)) : p.target === "setimmediate" ? e.postMessage(p) : f === "uncaughtException" ? e.onerror(p.error) : f === "callHandler" ? t[p.Yb](...p.args) : f && N(`worker sent an unknown command ${f}`);
    }, e.onerror = (f) => {
      throw N(`worker sent an error! ${f.filename}:${f.lineno}: ${f.message}`), f;
    };
    var i, s = [];
    for (i of []) t.propertyIsEnumerable(i) && s.push(i);
    e.postMessage({ Pb: "load", Zb: s, dc: ge, ec: b });
  });
  function yn() {
    var e = new Worker((() => {
      let r = URL;
      return import.meta.url > "file:" && import.meta.url < "file;" ? new r("ort.wasm.bundle.min.mjs", import.meta.url) : new URL(import.meta.url);
    })(), { type: "module", workerData: "em-pthread", name: "em-pthread" });
    ce.push(e);
  }
  var ge, gn = [], M = (e) => {
    var r = gn[e];
    return r || (gn[e] = r = cr.get(e)), r;
  }, Ao = (e, r) => {
    se = 0, e = M(e)(r), 0 < se ? y = e : Ht(e);
  }, tt = [], nt = 0;
  function Io(e) {
    var r = new xt(e >>>= 0);
    return (w(), H)[r.Qb + 12 >>> 0] == 0 && (En(r, true), nt--), Tn(r, false), tt.push(r), fr(e);
  }
  var Fe = 0, Bo = () => {
    C(0, 0);
    var e = tt.pop();
    ir(e.Ub), Fe = 0;
  };
  function En(e, r) {
    r = r ? 1 : 0, (w(), H)[e.Qb + 12 >>> 0] = r;
  }
  function Tn(e, r) {
    r = r ? 1 : 0, (w(), H)[e.Qb + 13 >>> 0] = r;
  }
  class xt {
    constructor(r) {
      this.Ub = r, this.Qb = r - 24;
    }
  }
  var Ct = (e) => {
    var r = Fe;
    if (!r) return Je(0), 0;
    var i = new xt(r);
    (w(), W)[i.Qb + 16 >>> 2 >>> 0] = r;
    var s = (w(), W)[i.Qb + 4 >>> 2 >>> 0];
    if (!s) return Je(0), r;
    for (var f of e) {
      if (f === 0 || f === s) break;
      if (ur(f, s, i.Qb + 16)) return Je(f), r;
    }
    return Je(s), r;
  };
  function Lo() {
    return Ct([]);
  }
  function _o(e) {
    return Ct([e >>> 0]);
  }
  function Do(e, r, i, s) {
    return Ct([e >>> 0, r >>> 0, i >>> 0, s >>> 0]);
  }
  var Po = () => {
    var e = tt.pop();
    e || j("no exception to throw");
    var r = e.Ub;
    throw (w(), H)[e.Qb + 13 >>> 0] == 0 && (tt.push(e), Tn(e, true), En(e, false), nt++), Vt(r), Fe = r;
  };
  function Uo(e, r, i) {
    var s = new xt(e >>>= 0);
    throw r >>>= 0, i >>>= 0, (w(), W)[s.Qb + 16 >>> 2 >>> 0] = 0, (w(), W)[s.Qb + 4 >>> 2 >>> 0] = r, (w(), W)[s.Qb + 8 >>> 2 >>> 0] = i, Vt(e), nt++, Fe = e;
  }
  var xo = () => nt;
  function Sn(e, r, i, s) {
    return o ? L(2, 1, e, r, i, s) : vn(e, r, i, s);
  }
  function vn(e, r, i, s) {
    if (e >>>= 0, r >>>= 0, i >>>= 0, s >>>= 0, !globalThis.SharedArrayBuffer) return 6;
    var f = [];
    return o && f.length === 0 ? Sn(e, r, i, s) : (e = { ac: i, Ob: e, Tb: s, Xb: f }, o ? (e.Pb = "spawnThread", postMessage(e, f), 0) : ue(e));
  }
  function Co(e) {
    throw Fe ||= e >>> 0, Fe;
  }
  var On = globalThis.TextDecoder && new TextDecoder(), An = (e, r = 0, i, s) => {
    var f = r >>>= 0;
    if (i = f + i, s) s = i;
    else {
      for (; e[f] && !(f >= i); ) ++f;
      s = f;
    }
    if (16 < s - r && e.buffer && On) return On.decode(e.buffer instanceof ArrayBuffer ? e.subarray(r, s) : e.slice(r, s));
    for (f = ""; r < s; ) if (128 & (i = e[r++])) {
      var p = 63 & e[r++];
      if ((224 & i) == 192) f += String.fromCharCode((31 & i) << 6 | p);
      else {
        var E = 63 & e[r++];
        65536 > (i = (240 & i) == 224 ? (15 & i) << 12 | p << 6 | E : (7 & i) << 18 | p << 12 | E << 6 | 63 & e[r++]) ? f += String.fromCharCode(i) : (i -= 65536, f += String.fromCharCode(55296 | i >> 10, 56320 | 1023 & i));
      }
    } else f += String.fromCharCode(i);
    return f;
  }, Mt = (e, r, i) => (e >>>= 0) ? An((w(), ne), e, r, i) : "";
  function In(e, r, i) {
    return o ? L(3, 1, e, r, i) : 0;
  }
  function Bn(e, r) {
    if (o) return L(4, 1, e, r);
  }
  function Ln(e, r) {
    if (o) return L(5, 1, e, r);
  }
  function _n(e, r, i) {
    if (o) return L(6, 1, e, r, i);
  }
  function Dn(e, r, i) {
    return o ? L(7, 1, e, r, i) : 0;
  }
  function Pn(e, r) {
    if (o) return L(8, 1, e, r);
  }
  function Un(e, r, i) {
    if (o) return L(9, 1, e, r, i);
  }
  function xn(e, r, i, s) {
    if (o) return L(10, 1, e, r, i, s);
  }
  function Cn(e, r, i, s) {
    if (o) return L(11, 1, e, r, i, s);
  }
  function Mn(e, r, i, s) {
    if (o) return L(12, 1, e, r, i, s);
  }
  function Rn(e) {
    if (o) return L(13, 1, e);
  }
  function Nn(e, r) {
    if (o) return L(14, 1, e, r);
  }
  function Fn(e, r, i) {
    if (o) return L(15, 1, e, r, i);
  }
  var Mo = () => j("");
  function Ro(e) {
    zt(e >>> 0, !u, 1, !a, 131072, false), wn();
  }
  var Rt = (e) => {
    if (!D) try {
      if (e(), !(0 < se)) try {
        o ? st() && Ht(y) : ye(y);
      } catch (r) {
        r instanceof Se || r == "unwind" || l(0, r);
      }
    } catch (r) {
      r instanceof Se || r == "unwind" || l(0, r);
    }
  }, No = !Atomics.waitAsync || globalThis.navigator?.userAgent && 91 > Number((navigator.userAgent.match(/Chrom(e|ium)\/([0-9]+)\./) || [])[2]);
  function Nt(e) {
    e >>>= 0, No || (Atomics.waitAsync((w(), B), e >>> 2, e).value.then(rt), e += 128, Atomics.store((w(), B), e >>> 2, 1));
  }
  var rt = () => Rt(() => {
    var e = st();
    e && (Nt(e), ar());
  });
  function Fo(e, r) {
    (e >>>= 0) == r >>> 0 ? setTimeout(rt) : o ? postMessage({ Sb: e, Pb: "checkMailbox" }) : (e = Oe[e]) && e.postMessage({ Pb: "checkMailbox" });
  }
  var Ft = [];
  function ko(e, r, i, s, f) {
    for (r >>>= 0, f >>>= 0, Ft.length = 0, i = f >>> 3, s = f + s >>> 3; i < s; ) {
      var p;
      p = (w(), A)[i++ >>> 0] ? (w(), A)[i++ >>> 0] : (w(), me)[i++ >>> 0], Ft.push(p);
    }
    return (r ? lr[r] : ua[e])(...Ft);
  }
  var Wo = () => {
    se = 0;
  };
  function Go(e) {
    e >>>= 0, o ? postMessage({ Pb: "cleanupThread", cc: e }) : hn(Oe[e]);
  }
  function $o(e) {
  }
  function zo(e, r) {
    e = -9007199254740992 > e || 9007199254740992 < e ? NaN : Number(e), r >>>= 0, e = new Date(1e3 * e), (w(), B)[r >>> 2 >>> 0] = e.getUTCSeconds(), (w(), B)[r + 4 >>> 2 >>> 0] = e.getUTCMinutes(), (w(), B)[r + 8 >>> 2 >>> 0] = e.getUTCHours(), (w(), B)[r + 12 >>> 2 >>> 0] = e.getUTCDate(), (w(), B)[r + 16 >>> 2 >>> 0] = e.getUTCMonth(), (w(), B)[r + 20 >>> 2 >>> 0] = e.getUTCFullYear() - 1900, (w(), B)[r + 24 >>> 2 >>> 0] = e.getUTCDay(), e = (e.getTime() - Date.UTC(e.getUTCFullYear(), 0, 1, 0, 0, 0, 0)) / 864e5 | 0, (w(), B)[r + 28 >>> 2 >>> 0] = e;
  }
  var kn = (e) => e % 4 == 0 && (e % 100 != 0 || e % 400 == 0), Wn = [0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335], Gn = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
  function Ho(e, r) {
    e = -9007199254740992 > e || 9007199254740992 < e ? NaN : Number(e), r >>>= 0, e = new Date(1e3 * e), (w(), B)[r >>> 2 >>> 0] = e.getSeconds(), (w(), B)[r + 4 >>> 2 >>> 0] = e.getMinutes(), (w(), B)[r + 8 >>> 2 >>> 0] = e.getHours(), (w(), B)[r + 12 >>> 2 >>> 0] = e.getDate(), (w(), B)[r + 16 >>> 2 >>> 0] = e.getMonth(), (w(), B)[r + 20 >>> 2 >>> 0] = e.getFullYear() - 1900, (w(), B)[r + 24 >>> 2 >>> 0] = e.getDay();
    var i = (kn(e.getFullYear()) ? Wn : Gn)[e.getMonth()] + e.getDate() - 1 | 0;
    (w(), B)[r + 28 >>> 2 >>> 0] = i, (w(), B)[r + 36 >>> 2 >>> 0] = -60 * e.getTimezoneOffset(), i = new Date(e.getFullYear(), 6, 1).getTimezoneOffset();
    var s = new Date(e.getFullYear(), 0, 1).getTimezoneOffset();
    e = 0 | (i != s && e.getTimezoneOffset() == Math.min(s, i)), (w(), B)[r + 32 >>> 2 >>> 0] = e;
  }
  function jo(e) {
    e >>>= 0;
    var r = new Date((w(), B)[e + 20 >>> 2 >>> 0] + 1900, (w(), B)[e + 16 >>> 2 >>> 0], (w(), B)[e + 12 >>> 2 >>> 0], (w(), B)[e + 8 >>> 2 >>> 0], (w(), B)[e + 4 >>> 2 >>> 0], (w(), B)[e >>> 2 >>> 0], 0), i = (w(), B)[e + 32 >>> 2 >>> 0], s = r.getTimezoneOffset(), f = new Date(r.getFullYear(), 6, 1).getTimezoneOffset(), p = new Date(r.getFullYear(), 0, 1).getTimezoneOffset(), E = Math.min(p, f);
    return 0 > i ? (w(), B)[e + 32 >>> 2 >>> 0] = +(f != p && E == s) : 0 < i != (E == s) && (f = Math.max(p, f), r.setTime(r.getTime() + 6e4 * ((0 < i ? E : f) - s))), (w(), B)[e + 24 >>> 2 >>> 0] = r.getDay(), i = (kn(r.getFullYear()) ? Wn : Gn)[r.getMonth()] + r.getDate() - 1 | 0, (w(), B)[e + 28 >>> 2 >>> 0] = i, (w(), B)[e >>> 2 >>> 0] = r.getSeconds(), (w(), B)[e + 4 >>> 2 >>> 0] = r.getMinutes(), (w(), B)[e + 8 >>> 2 >>> 0] = r.getHours(), (w(), B)[e + 12 >>> 2 >>> 0] = r.getDate(), (w(), B)[e + 16 >>> 2 >>> 0] = r.getMonth(), (w(), B)[e + 20 >>> 2 >>> 0] = r.getYear(), e = r.getTime(), BigInt(isNaN(e) ? -1 : e / 1e3);
  }
  function $n(e, r, i, s, f, p, E) {
    return o ? L(16, 1, e, r, i, s, f, p, E) : -52;
  }
  function zn(e, r, i, s, f, p) {
    if (o) return L(17, 1, e, r, i, s, f, p);
  }
  var Ye = {}, Vo = () => performance.timeOrigin + performance.now();
  function Hn(e, r) {
    if (o) return L(18, 1, e, r);
    if (Ye[e] && (clearTimeout(Ye[e].id), delete Ye[e]), !r) return 0;
    var i = setTimeout(() => {
      delete Ye[e], Rt(() => or(e, performance.timeOrigin + performance.now()));
    }, r);
    return Ye[e] = { id: i, mc: r }, 0;
  }
  var Ae = (e, r, i) => {
    var s = (w(), ne);
    if (r >>>= 0, 0 < i) {
      var f = r;
      i = r + i - 1;
      for (var p = 0; p < e.length; ++p) {
        var E = e.codePointAt(p);
        if (127 >= E) {
          if (r >= i) break;
          s[r++ >>> 0] = E;
        } else if (2047 >= E) {
          if (r + 1 >= i) break;
          s[r++ >>> 0] = 192 | E >> 6, s[r++ >>> 0] = 128 | 63 & E;
        } else if (65535 >= E) {
          if (r + 2 >= i) break;
          s[r++ >>> 0] = 224 | E >> 12, s[r++ >>> 0] = 128 | E >> 6 & 63, s[r++ >>> 0] = 128 | 63 & E;
        } else {
          if (r + 3 >= i) break;
          s[r++ >>> 0] = 240 | E >> 18, s[r++ >>> 0] = 128 | E >> 12 & 63, s[r++ >>> 0] = 128 | E >> 6 & 63, s[r++ >>> 0] = 128 | 63 & E, p++;
        }
      }
      s[r >>> 0] = 0, e = r - f;
    } else e = 0;
    return e;
  };
  function Yo(e, r, i, s) {
    e >>>= 0, r >>>= 0, i >>>= 0, s >>>= 0;
    var f = (/* @__PURE__ */ new Date()).getFullYear(), p = new Date(f, 0, 1).getTimezoneOffset();
    f = new Date(f, 6, 1).getTimezoneOffset();
    var E = Math.max(p, f);
    (w(), W)[e >>> 2 >>> 0] = 60 * E, (w(), B)[r >>> 2 >>> 0] = +(p != f), e = (r = (S) => {
      var x = Math.abs(S);
      return `UTC${0 <= S ? "-" : "+"}${String(Math.floor(x / 60)).padStart(2, "0")}${String(x % 60).padStart(2, "0")}`;
    })(p), r = r(f), f < p ? (Ae(e, i, 17), Ae(r, s, 17)) : (Ae(e, s, 17), Ae(r, i, 17));
  }
  var Jo = () => Date.now(), qo = 1;
  function Xo(e, r, i) {
    if (i >>>= 0, !(0 <= e && 3 >= e)) return 28;
    if (e === 0) e = Date.now();
    else {
      if (!qo) return 52;
      e = performance.timeOrigin + performance.now();
    }
    return e = Math.round(1e6 * e), (w(), A)[i >>> 3 >>> 0] = BigInt(e), 0;
  }
  var kt = [];
  function Qo(e, r, i) {
    e >>>= 0, r >>>= 0, i >>>= 0, kt.length = 0;
    for (var s; s = (w(), ne)[r++ >>> 0]; ) {
      var f = s != 105;
      i += (f &= s != 112) && i % 8 ? 4 : 0, kt.push(s == 112 ? (w(), W)[i >>> 2 >>> 0] : s == 106 ? (w(), A)[i >>> 3 >>> 0] : s == 105 ? (w(), B)[i >>> 2 >>> 0] : (w(), me)[i >>> 3 >>> 0]), i += f ? 8 : 4;
    }
    return lr[e](...kt);
  }
  var Zo = () => {
  };
  function Ko(e, r) {
    return N(Mt(e >>> 0, r >>> 0));
  }
  var ea = () => {
    throw se += 1, "unwind";
  };
  function ta() {
    return 4294901760;
  }
  var na = () => navigator.hardwareConcurrency, Ie = {}, Wt = (e) => {
    for (var r = 0, i = 0; i < e.length; ++i) {
      var s = e.charCodeAt(i);
      127 >= s ? r++ : 2047 >= s ? r += 2 : 55296 <= s && 57343 >= s ? (r += 4, ++i) : r += 3;
    }
    return r;
  }, ot = (e) => {
    var r;
    return (r = /\bwasm-function\[\d+\]:(0x[0-9a-f]+)/.exec(e)) ? +r[1] : (r = /:(\d+):\d+(?:\)|$)/.exec(e)) ? 2147483648 | +r[1] : 0;
  }, jn = (e) => {
    for (var r of e) (e = ot(r)) && (Ie[e] = r);
  };
  function ra() {
    var e = Error().stack.toString().split(`
`);
    return e[0] == "Error" && e.shift(), jn(e), Ie.Vb = ot(e[3]), Ie.$b = e, Ie.Vb;
  }
  function at(e) {
    if (!(e = Ie[e >>> 0])) return 0;
    var r;
    if (r = /^\s+at .*\.wasm\.(.*) \(.*\)$/.exec(e)) e = r[1];
    else if (r = /^\s+at (.*) \(.*\)$/.exec(e)) e = r[1];
    else {
      if (!(r = /^(.+?)@/.exec(e))) return 0;
      e = r[1];
    }
    Kn(at.Wb ?? 0), r = Wt(e) + 1;
    var i = er(r);
    return i && Ae(e, i, r), at.Wb = i, at.Wb;
  }
  function oa(e) {
    e >>>= 0;
    var r = (w(), ne).length;
    if (e <= r || 4294901760 < e) return false;
    for (var i = 1; 4 >= i; i *= 2) {
      var s = r * (1 + 0.2 / i);
      s = Math.min(s, e + 100663296);
      e: {
        s = (Math.min(4294901760, 65536 * Math.ceil(Math.max(e, s) / 65536)) - ge.buffer.byteLength + 65535) / 65536 | 0;
        try {
          ge.grow(s), ee();
          var f = 1;
          break e;
        } catch {
        }
        f = void 0;
      }
      if (f) return true;
    }
    return false;
  }
  function aa(e, r, i) {
    if (e >>>= 0, r >>>= 0, Ie.Vb == e) var s = Ie.$b;
    else (s = Error().stack.toString().split(`
`))[0] == "Error" && s.shift(), jn(s);
    for (var f = 3; s[f] && ot(s[f]) != e; ) ++f;
    for (e = 0; e < i && s[e + f]; ++e) (w(), B)[r + 4 * e >>> 2 >>> 0] = ot(s[e + f]);
    return e;
  }
  var Gt, $t = {}, Vn = () => {
    if (!Gt) {
      var e, r = { USER: "web_user", LOGNAME: "web_user", PATH: "/", PWD: "/", HOME: "/home/web_user", LANG: (globalThis.navigator?.language ?? "C").replace("-", "_") + ".UTF-8", _: "./this.program" };
      for (e in $t) $t[e] === void 0 ? delete r[e] : r[e] = $t[e];
      var i = [];
      for (e in r) i.push(`${e}=${r[e]}`);
      Gt = i;
    }
    return Gt;
  };
  function Yn(e, r) {
    if (o) return L(19, 1, e, r);
    e >>>= 0, r >>>= 0;
    var i, s = 0, f = 0;
    for (i of Vn()) {
      var p = r + s;
      (w(), W)[e + f >>> 2 >>> 0] = p, s += Ae(i, p, 1 / 0) + 1, f += 4;
    }
    return 0;
  }
  function Jn(e, r) {
    if (o) return L(20, 1, e, r);
    e >>>= 0, r >>>= 0;
    var i = Vn();
    for (var s of ((w(), W)[e >>> 2 >>> 0] = i.length, e = 0, i)) e += Wt(s) + 1;
    return (w(), W)[r >>> 2 >>> 0] = e, 0;
  }
  function qn(e) {
    return o ? L(21, 1, e) : 52;
  }
  function Xn(e, r, i, s) {
    return o ? L(22, 1, e, r, i, s) : 52;
  }
  function Qn(e, r, i, s) {
    return o ? L(23, 1, e, r, i, s) : 70;
  }
  var sa = [null, [], []];
  function Zn(e, r, i, s) {
    if (o) return L(24, 1, e, r, i, s);
    r >>>= 0, i >>>= 0, s >>>= 0;
    for (var f = 0, p = 0; p < i; p++) {
      var E = (w(), W)[r >>> 2 >>> 0], S = (w(), W)[r + 4 >>> 2 >>> 0];
      r += 8;
      for (var x = 0; x < S; x++) {
        var R = e, X = (w(), ne)[E + x >>> 0], le = sa[R];
        X === 0 || X === 10 ? ((R === 1 ? O : N)(An(le)), le.length = 0) : le.push(X);
      }
      f += S;
    }
    return (w(), W)[s >>> 2 >>> 0] = f, 0;
  }
  function ia(e) {
    return e >>> 0;
  }
  o || (function() {
    for (var e = t.numThreads - 1; e--; ) yn();
    Ve.push(async () => {
      var r = (async function() {
        if (!o) return Promise.all(ce.map(bn));
      })();
      Re++, await r, --Re == 0 && te && (r = te, te = null, r());
    });
  })(), o || (ge = new WebAssembly.Memory({ initial: 256, maximum: 65536, shared: true }), ee()), t.wasmBinary && (g = t.wasmBinary), t.stackSave = () => U(), t.stackRestore = (e) => P(e), t.stackAlloc = (e) => jt(e), t.setValue = function(e, r, i = "i8") {
    switch (i.endsWith("*") && (i = "*"), i) {
      case "i1":
      case "i8":
        (w(), H)[e >>> 0] = r;
        break;
      case "i16":
        (w(), pe)[e >>> 1 >>> 0] = r;
        break;
      case "i32":
        (w(), B)[e >>> 2 >>> 0] = r;
        break;
      case "i64":
        (w(), A)[e >>> 3 >>> 0] = BigInt(r);
        break;
      case "float":
        (w(), re)[e >>> 2 >>> 0] = r;
        break;
      case "double":
        (w(), me)[e >>> 3 >>> 0] = r;
        break;
      case "*":
        (w(), W)[e >>> 2 >>> 0] = r;
        break;
      default:
        j(`invalid type for setValue: ${i}`);
    }
  }, t.getValue = function(e, r = "i8") {
    switch (r.endsWith("*") && (r = "*"), r) {
      case "i1":
      case "i8":
        return (w(), H)[e >>> 0];
      case "i16":
        return (w(), pe)[e >>> 1 >>> 0];
      case "i32":
        return (w(), B)[e >>> 2 >>> 0];
      case "i64":
        return (w(), A)[e >>> 3 >>> 0];
      case "float":
        return (w(), re)[e >>> 2 >>> 0];
      case "double":
        return (w(), me)[e >>> 3 >>> 0];
      case "*":
        return (w(), W)[e >>> 2 >>> 0];
      default:
        j(`invalid type for getValue: ${r}`);
    }
  }, t.UTF8ToString = Mt, t.stringToUTF8 = Ae, t.lengthBytesUTF8 = Wt;
  var st, Kn, er, zt, tr, nr, rr, Ht, or, ar, C, Je, sr, P, jt, U, ir, Vt, ur, fr, cr, Ee, ua = [V, fe, Sn, In, Bn, Ln, _n, Dn, Pn, Un, xn, Cn, Mn, Rn, Nn, Fn, $n, zn, Hn, Yn, Jn, qn, Xn, Qn, Zn], lr = { 1011284: (e, r, i, s, f) => {
    if (t === void 0 || !t.Rb) return 1;
    if ((e = Mt(Number(e >>> 0))).startsWith("./") && (e = e.substring(2)), !(e = t.Rb.get(e))) return 2;
    if (r = Number(r >>> 0), i = Number(i >>> 0), s = Number(s >>> 0), r + i > e.byteLength) return 3;
    try {
      let p = e.subarray(r, r + i);
      switch (f) {
        case 0:
          (w(), ne).set(p, s >>> 0);
          break;
        case 1:
          t.fc ? t.fc(s, p) : t.ic(s, p);
          break;
        default:
          return 4;
      }
      return 0;
    } catch {
      return 4;
    }
  }, 1012108: () => typeof wasmOffsetConverter < "u" };
  function fa() {
    return typeof wasmOffsetConverter < "u";
  }
  function ca(e, r, i, s) {
    var f = U();
    try {
      return M(e)(r, i, s);
    } catch (p) {
      if (P(f), p !== p + 0) throw p;
      C(1, 0);
    }
  }
  function la(e, r, i) {
    var s = U();
    try {
      return M(e)(r, i);
    } catch (f) {
      if (P(s), f !== f + 0) throw f;
      C(1, 0);
    }
  }
  function da(e) {
    var r = U();
    try {
      M(e)();
    } catch (i) {
      if (P(r), i !== i + 0) throw i;
      C(1, 0);
    }
  }
  function pa(e, r) {
    var i = U();
    try {
      return M(e)(r);
    } catch (s) {
      if (P(i), s !== s + 0) throw s;
      C(1, 0);
    }
  }
  function ma(e, r, i) {
    var s = U();
    try {
      M(e)(r, i);
    } catch (f) {
      if (P(s), f !== f + 0) throw f;
      C(1, 0);
    }
  }
  function ha(e, r) {
    var i = U();
    try {
      M(e)(r);
    } catch (s) {
      if (P(i), s !== s + 0) throw s;
      C(1, 0);
    }
  }
  function wa(e, r, i, s, f, p, E) {
    var S = U();
    try {
      return M(e)(r, i, s, f, p, E);
    } catch (x) {
      if (P(S), x !== x + 0) throw x;
      C(1, 0);
    }
  }
  function ba(e, r, i, s, f, p) {
    var E = U();
    try {
      M(e)(r, i, s, f, p);
    } catch (S) {
      if (P(E), S !== S + 0) throw S;
      C(1, 0);
    }
  }
  function ya(e, r, i, s) {
    var f = U();
    try {
      M(e)(r, i, s);
    } catch (p) {
      if (P(f), p !== p + 0) throw p;
      C(1, 0);
    }
  }
  function ga(e, r, i, s, f) {
    var p = U();
    try {
      M(e)(r, i, s, f);
    } catch (E) {
      if (P(p), E !== E + 0) throw E;
      C(1, 0);
    }
  }
  function Ea(e, r, i, s, f, p, E) {
    var S = U();
    try {
      M(e)(r, i, s, f, p, E);
    } catch (x) {
      if (P(S), x !== x + 0) throw x;
      C(1, 0);
    }
  }
  function Ta(e, r, i, s, f, p, E) {
    var S = U();
    try {
      M(e)(r, i, s, f, p, E);
    } catch (x) {
      if (P(S), x !== x + 0) throw x;
      C(1, 0);
    }
  }
  function Sa(e, r, i, s, f, p, E, S) {
    var x = U();
    try {
      M(e)(r, i, s, f, p, E, S);
    } catch (R) {
      if (P(x), R !== R + 0) throw R;
      C(1, 0);
    }
  }
  function va(e, r, i, s, f) {
    var p = U();
    try {
      return M(e)(r, i, s, f);
    } catch (E) {
      if (P(p), E !== E + 0) throw E;
      C(1, 0);
    }
  }
  function Oa(e, r, i) {
    var s = U();
    try {
      return M(e)(r, i);
    } catch (f) {
      if (P(s), f !== f + 0) throw f;
      C(1, 0);
    }
  }
  function Aa(e, r, i, s, f, p, E, S) {
    var x = U();
    try {
      M(e)(r, i, s, f, p, E, S);
    } catch (R) {
      if (P(x), R !== R + 0) throw R;
      C(1, 0);
    }
  }
  function Ia(e, r, i, s, f, p, E, S, x, R, X, le) {
    var we = U();
    try {
      M(e)(r, i, s, f, p, E, S, x, R, X, le);
    } catch (be) {
      if (P(we), be !== be + 0) throw be;
      C(1, 0);
    }
  }
  function Ba(e, r, i) {
    var s = U();
    try {
      return M(e)(r, i);
    } catch (f) {
      if (P(s), f !== f + 0) throw f;
      return C(1, 0), 0n;
    }
  }
  function La(e, r, i, s, f, p, E, S, x) {
    var R = U();
    try {
      M(e)(r, i, s, f, p, E, S, x);
    } catch (X) {
      if (P(R), X !== X + 0) throw X;
      C(1, 0);
    }
  }
  function _a(e) {
    var r = U();
    try {
      return M(e)();
    } catch (i) {
      if (P(r), i !== i + 0) throw i;
      C(1, 0);
    }
  }
  function Da(e, r) {
    var i = U();
    try {
      return M(e)(r);
    } catch (s) {
      if (P(i), s !== s + 0) throw s;
      return C(1, 0), 0n;
    }
  }
  function Pa(e) {
    var r = U();
    try {
      return M(e)();
    } catch (i) {
      if (P(r), i !== i + 0) throw i;
      return C(1, 0), 0n;
    }
  }
  function Ua(e, r, i, s) {
    var f = U();
    try {
      return M(e)(r, i, s);
    } catch (p) {
      if (P(f), p !== p + 0) throw p;
      C(1, 0);
    }
  }
  function xa(e, r, i, s, f) {
    var p = U();
    try {
      return M(e)(r, i, s, f);
    } catch (E) {
      if (P(p), E !== E + 0) throw E;
      C(1, 0);
    }
  }
  function Ca(e, r, i, s, f, p) {
    var E = U();
    try {
      return M(e)(r, i, s, f, p);
    } catch (S) {
      if (P(E), S !== S + 0) throw S;
      C(1, 0);
    }
  }
  function Ma(e, r, i, s, f, p) {
    var E = U();
    try {
      return M(e)(r, i, s, f, p);
    } catch (S) {
      if (P(E), S !== S + 0) throw S;
      C(1, 0);
    }
  }
  function Ra(e, r, i, s, f, p) {
    var E = U();
    try {
      return M(e)(r, i, s, f, p);
    } catch (S) {
      if (P(E), S !== S + 0) throw S;
      C(1, 0);
    }
  }
  function Na(e, r, i, s, f, p, E, S) {
    var x = U();
    try {
      return M(e)(r, i, s, f, p, E, S);
    } catch (R) {
      if (P(x), R !== R + 0) throw R;
      C(1, 0);
    }
  }
  function Fa(e, r, i, s, f) {
    var p = U();
    try {
      return M(e)(r, i, s, f);
    } catch (E) {
      if (P(p), E !== E + 0) throw E;
      return C(1, 0), 0n;
    }
  }
  function ka(e, r, i, s) {
    var f = U();
    try {
      return M(e)(r, i, s);
    } catch (p) {
      if (P(f), p !== p + 0) throw p;
      C(1, 0);
    }
  }
  function Wa(e, r, i, s) {
    var f = U();
    try {
      return M(e)(r, i, s);
    } catch (p) {
      if (P(f), p !== p + 0) throw p;
      C(1, 0);
    }
  }
  function Ga(e, r, i, s, f, p, E, S, x, R, X, le) {
    var we = U();
    try {
      return M(e)(r, i, s, f, p, E, S, x, R, X, le);
    } catch (be) {
      if (P(we), be !== be + 0) throw be;
      C(1, 0);
    }
  }
  function $a(e, r, i, s, f, p, E, S, x, R, X) {
    var le = U();
    try {
      M(e)(r, i, s, f, p, E, S, x, R, X);
    } catch (we) {
      if (P(le), we !== we + 0) throw we;
      C(1, 0);
    }
  }
  function za(e, r, i, s, f, p, E, S, x, R, X, le, we, be, Ya, Ja) {
    var qa = U();
    try {
      M(e)(r, i, s, f, p, E, S, x, R, X, le, we, be, Ya, Ja);
    } catch (Yt) {
      if (P(qa), Yt !== Yt + 0) throw Yt;
      C(1, 0);
    }
  }
  function Ha(e, r, i) {
    var s = U();
    try {
      return M(e)(r, i);
    } catch (f) {
      if (P(s), f !== f + 0) throw f;
      C(1, 0);
    }
  }
  function ja(e, r, i) {
    var s = U();
    try {
      return M(e)(r, i);
    } catch (f) {
      if (P(s), f !== f + 0) throw f;
      C(1, 0);
    }
  }
  function Va(e, r, i, s) {
    var f = U();
    try {
      M(e)(r, i, s);
    } catch (p) {
      if (P(f), p !== p + 0) throw p;
      C(1, 0);
    }
  }
  function it() {
    if (0 < Re) te = it;
    else if (o) T?.(t), he();
    else {
      for (var e = Ve; 0 < e.length; ) e.shift()(t);
      0 < Re ? te = it : (t.calledRun = true, D || (he(), T?.(t)));
    }
  }
  return o || (Ee = await Ut(), it()), t.PTR_SIZE = 4, je ? t : new Promise((e, r) => {
    T = e, I = r;
  });
}
var Jt, Xa, Qa, Za, qt, F, ut, Ka, Xt, ft, Be, qe, es, dr, Qt, pr, mr, hr, wr, J, Zt, Y, br, yr, gr, Er, Kt, Tr, Sr, vr, Or, Ar, Ir, Le, Xe, Br, Lr, _r, Dr, Pr, Ur, Q, ct, de, en, xr, Cr, _e, De, Pe, Ue, tn, lt, Mr, ts, Rr, Nr, Fr, kr, Wr, nn, Te, dt, Hr, $r, zr, ns, jr, Yr, rs, os, Jr, Qr, an, as, oe, Zr, on, ss, is, Kr, us, qr, eo, Xr, to, pt, sn, un, St, no, fs, cs, ls, mt, z, xe, ae, Ze, G, vt, ro, oo, ds, ps, ms, ke, hs, ao, so, We, Ot, Ge, io, uo, At, It, fo, fn, Ke, cn, ws, ht, wt, $e, bs, co, Qe, bt, yt, lo, gt, Et, Tt, rn, Me, ie, et, Lt, _t, Bt, ln, dn, ze, He, gs, po, mo, ho, wo, bo, yo, go, pn, Eo, Es, Dt, To, vo, So, Pt, Ts, Oo, Gr, au;
var init_ort_wasm_bundle_min = __esm({
  "../../packages/cycle5-browser/node_modules/onnxruntime-web/dist/ort.wasm.bundle.min.mjs"() {
    Jt = Object.defineProperty;
    Xa = Object.getOwnPropertyDescriptor;
    Qa = Object.getOwnPropertyNames;
    Za = Object.prototype.hasOwnProperty;
    qt = ((n) => typeof __require < "u" ? __require : typeof Proxy < "u" ? new Proxy(n, { get: (t, a) => (typeof __require < "u" ? __require : t)[a] }) : n)(function(n) {
      if (typeof __require < "u") return __require.apply(this, arguments);
      throw Error('Dynamic require of "' + n + '" is not supported');
    });
    F = (n, t, a) => () => {
      if (a) throw a[0];
      try {
        return n && (t = n(n = 0)), t;
      } catch (u) {
        throw a = [u], u;
      }
    };
    ut = (n, t) => {
      for (var a in t) Jt(n, a, { get: t[a], enumerable: true });
    };
    Ka = (n, t, a, u) => {
      if (t && typeof t == "object" || typeof t == "function") for (let o of Qa(t)) !Za.call(n, o) && o !== a && Jt(n, o, { get: () => t[o], enumerable: !(u = Xa(t, o)) || u.enumerable });
      return n;
    };
    Xt = (n) => Ka(Jt({}, "__esModule", { value: true }), n);
    Qt = F(() => {
      "use strict";
      ft = /* @__PURE__ */ new Map(), Be = [], qe = (n, t, a) => {
        if (t && typeof t.init == "function" && typeof t.createInferenceSessionHandler == "function") {
          let u = ft.get(n);
          if (u === void 0) ft.set(n, { backend: t, priority: a });
          else {
            if (u.priority > a) return;
            if (u.priority === a && u.backend !== t) throw new Error(`cannot register backend "${n}" using priority ${a}`);
          }
          if (a >= 0) {
            let o = Be.indexOf(n);
            o !== -1 && Be.splice(o, 1);
            for (let d = 0; d < Be.length; d++) if (ft.get(Be[d]).priority <= a) {
              Be.splice(d, 0, n);
              return;
            }
            Be.push(n);
          }
          return;
        }
        throw new TypeError("not a valid backend");
      }, es = async (n) => {
        let t = ft.get(n);
        if (!t) return "backend not found.";
        if (t.initialized) return t.backend;
        if (t.aborted) return t.error;
        {
          let a = !!t.initPromise;
          try {
            return a || (t.initPromise = t.backend.init(n)), await t.initPromise, t.initialized = true, t.backend;
          } catch (u) {
            return a || (t.error = `${u}`, t.aborted = true), t.error;
          } finally {
            delete t.initPromise;
          }
        }
      }, dr = async (n) => {
        let t = n.executionProviders || [], a = t.map((m) => typeof m == "string" ? m : m.name), u = a.length === 0 ? Be : a, o, d = [], c = /* @__PURE__ */ new Set();
        for (let m of u) {
          let h = await es(m);
          typeof h == "string" ? d.push({ name: m, err: h }) : (o || (o = h), o === h && c.add(m));
        }
        if (!o) throw new Error(`no available backend found. ERR: ${d.map((m) => `[${m.name}] ${m.err}`).join(", ")}`);
        for (let { name: m, err: h } of d) a.includes(m) && console.warn(`removing requested execution provider "${m}" from session options because it is not available: ${h}`);
        let l = t.filter((m) => c.has(typeof m == "string" ? m : m.name));
        return [o, new Proxy(n, { get: (m, h) => h === "executionProviders" ? l : Reflect.get(m, h) })];
      };
    });
    pr = F(() => {
      "use strict";
      Qt();
    });
    hr = F(() => {
      "use strict";
      mr = "1.29.0";
    });
    Zt = F(() => {
      "use strict";
      hr();
      wr = "warning", J = { wasm: {}, webgl: {}, webgpu: {}, versions: { common: mr }, set logLevel(n) {
        if (n !== void 0) {
          if (typeof n != "string" || ["verbose", "info", "warning", "error", "fatal"].indexOf(n) === -1) throw new Error(`Unsupported logging level: ${n}`);
          wr = n;
        }
      }, get logLevel() {
        return wr;
      } };
      Object.defineProperty(J, "logLevel", { enumerable: true });
    });
    br = F(() => {
      "use strict";
      Zt();
      Y = J;
    });
    Er = F(() => {
      "use strict";
      yr = (n, t) => {
        let a = typeof document < "u" ? document.createElement("canvas") : new OffscreenCanvas(1, 1);
        a.width = n.dims[3], a.height = n.dims[2];
        let u = a.getContext("2d");
        if (u != null) {
          let o, d;
          t?.tensorLayout !== void 0 && t.tensorLayout === "NHWC" ? (o = n.dims[2], d = n.dims[3]) : (o = n.dims[3], d = n.dims[2]);
          let c = t?.format !== void 0 ? t.format : "RGB", l = t?.norm, m, h;
          l === void 0 || l.mean === void 0 ? m = [255, 255, 255, 255] : typeof l.mean == "number" ? m = [l.mean, l.mean, l.mean, l.mean] : (m = [l.mean[0], l.mean[1], l.mean[2], 0], l.mean[3] !== void 0 && (m[3] = l.mean[3])), l === void 0 || l.bias === void 0 ? h = [0, 0, 0, 0] : typeof l.bias == "number" ? h = [l.bias, l.bias, l.bias, l.bias] : (h = [l.bias[0], l.bias[1], l.bias[2], 0], l.bias[3] !== void 0 && (h[3] = l.bias[3]));
          let g = d * o, b = 0, y = g, T = g * 2, I = -1;
          c === "RGBA" ? (b = 0, y = g, T = g * 2, I = g * 3) : c === "RGB" ? (b = 0, y = g, T = g * 2) : c === "RBG" && (b = 0, T = g, y = g * 2);
          for (let _ = 0; _ < d; _++) for (let $ = 0; $ < o; $++) {
            let v = (n.data[b++] - h[0]) * m[0], O = (n.data[y++] - h[1]) * m[1], N = (n.data[T++] - h[2]) * m[2], D = I === -1 ? 255 : (n.data[I++] - h[3]) * m[3];
            u.fillStyle = "rgba(" + v + "," + O + "," + N + "," + D + ")", u.fillRect($, _, 1, 1);
          }
          if ("toDataURL" in a) return a.toDataURL();
          throw new Error("toDataURL is not supported");
        } else throw new Error("Can not access image data");
      }, gr = (n, t) => {
        let a = typeof document < "u" ? document.createElement("canvas").getContext("2d") : new OffscreenCanvas(1, 1).getContext("2d"), u;
        if (a != null) {
          let o, d, c;
          t?.tensorLayout !== void 0 && t.tensorLayout === "NHWC" ? (o = n.dims[2], d = n.dims[1], c = n.dims[3]) : (o = n.dims[3], d = n.dims[2], c = n.dims[1]);
          let l = t !== void 0 && t.format !== void 0 ? t.format : "RGB", m = t?.norm, h, g;
          m === void 0 || m.mean === void 0 ? h = [255, 255, 255, 255] : typeof m.mean == "number" ? h = [m.mean, m.mean, m.mean, m.mean] : (h = [m.mean[0], m.mean[1], m.mean[2], 255], m.mean[3] !== void 0 && (h[3] = m.mean[3])), m === void 0 || m.bias === void 0 ? g = [0, 0, 0, 0] : typeof m.bias == "number" ? g = [m.bias, m.bias, m.bias, m.bias] : (g = [m.bias[0], m.bias[1], m.bias[2], 0], m.bias[3] !== void 0 && (g[3] = m.bias[3]));
          let b = d * o;
          if (t !== void 0 && (t.format !== void 0 && c === 4 && t.format !== "RGBA" || c === 3 && t.format !== "RGB" && t.format !== "BGR")) throw new Error("Tensor format doesn't match input tensor dims");
          let y = 4, T = 0, I = 1, _ = 2, $ = 3, v = 0, O = b, N = b * 2, D = -1;
          l === "RGBA" ? (v = 0, O = b, N = b * 2, D = b * 3) : l === "RGB" ? (v = 0, O = b, N = b * 2) : l === "RBG" && (v = 0, N = b, O = b * 2), u = a.createImageData(o, d);
          for (let k = 0; k < d * o; T += y, I += y, _ += y, $ += y, k++) u.data[T] = (n.data[v++] - g[0]) * h[0], u.data[I] = (n.data[O++] - g[1]) * h[1], u.data[_] = (n.data[N++] - g[2]) * h[2], u.data[$] = D === -1 ? 255 : (n.data[D++] - g[3]) * h[3];
        } else throw new Error("Can not access image data");
        return u;
      };
    });
    Ir = F(() => {
      "use strict";
      ct();
      Kt = (n, t) => {
        if (n === void 0) throw new Error("Image buffer must be defined");
        if (t.height === void 0 || t.width === void 0) throw new Error("Image height and width must be defined");
        if (t.tensorLayout === "NHWC") throw new Error("NHWC Tensor layout is not supported yet");
        let { height: a, width: u } = t, o = t.norm ?? { mean: 255, bias: 0 }, d, c;
        typeof o.mean == "number" ? d = [o.mean, o.mean, o.mean, o.mean] : d = [o.mean[0], o.mean[1], o.mean[2], o.mean[3] ?? 255], typeof o.bias == "number" ? c = [o.bias, o.bias, o.bias, o.bias] : c = [o.bias[0], o.bias[1], o.bias[2], o.bias[3] ?? 0];
        let l = t.format !== void 0 ? t.format : "RGBA", m = t.tensorFormat !== void 0 && t.tensorFormat !== void 0 ? t.tensorFormat : "RGB", h = a * u, g = m === "RGBA" ? new Float32Array(h * 4) : new Float32Array(h * 3), b = 4, y = 0, T = 1, I = 2, _ = 3, $ = 0, v = h, O = h * 2, N = -1;
        l === "RGB" && (b = 3, y = 0, T = 1, I = 2, _ = -1), m === "RGBA" ? N = h * 3 : m === "RBG" ? ($ = 0, O = h, v = h * 2) : m === "BGR" && (O = 0, v = h, $ = h * 2);
        for (let k = 0; k < h; k++, y += b, I += b, T += b, _ += b) g[$++] = (n[y] + c[0]) / d[0], g[v++] = (n[T] + c[1]) / d[1], g[O++] = (n[I] + c[2]) / d[2], N !== -1 && _ !== -1 && (g[N++] = (n[_] + c[3]) / d[3]);
        return m === "RGBA" ? new Q("float32", g, [1, 4, a, u]) : new Q("float32", g, [1, 3, a, u]);
      }, Tr = async (n, t) => {
        let a = typeof HTMLImageElement < "u" && n instanceof HTMLImageElement, u = typeof ImageData < "u" && n instanceof ImageData, o = typeof ImageBitmap < "u" && n instanceof ImageBitmap, d = typeof n == "string", c, l = t ?? {}, m = () => {
          if (typeof document < "u") return document.createElement("canvas");
          if (typeof OffscreenCanvas < "u") return new OffscreenCanvas(1, 1);
          throw new Error("Canvas is not supported");
        }, h = (g) => typeof HTMLCanvasElement < "u" && g instanceof HTMLCanvasElement || g instanceof OffscreenCanvas ? g.getContext("2d") : null;
        if (a) {
          let g = m();
          g.width = n.width, g.height = n.height;
          let b = h(g);
          if (b != null) {
            let y = n.height, T = n.width;
            if (t !== void 0 && t.resizedHeight !== void 0 && t.resizedWidth !== void 0 && (y = t.resizedHeight, T = t.resizedWidth), t !== void 0) {
              if (l = t, t.tensorFormat !== void 0) throw new Error("Image input config format must be RGBA for HTMLImageElement");
              l.tensorFormat = "RGBA", l.height = y, l.width = T;
            } else l.tensorFormat = "RGBA", l.height = y, l.width = T;
            b.drawImage(n, 0, 0), c = b.getImageData(0, 0, T, y).data;
          } else throw new Error("Can not access image data");
        } else if (u) {
          let g, b;
          if (t !== void 0 && t.resizedWidth !== void 0 && t.resizedHeight !== void 0 ? (g = t.resizedHeight, b = t.resizedWidth) : (g = n.height, b = n.width), t !== void 0 && (l = t), l.format = "RGBA", l.height = g, l.width = b, t !== void 0) {
            let y = m();
            y.width = b, y.height = g;
            let T = h(y);
            if (T != null) T.putImageData(n, 0, 0), c = T.getImageData(0, 0, b, g).data;
            else throw new Error("Can not access image data");
          } else c = n.data;
        } else if (o) {
          if (t === void 0) throw new Error("Please provide image config with format for Imagebitmap");
          let g = m();
          g.width = n.width, g.height = n.height;
          let b = h(g);
          if (b != null) {
            let y = n.height, T = n.width;
            return b.drawImage(n, 0, 0, T, y), c = b.getImageData(0, 0, T, y).data, l.height = y, l.width = T, Kt(c, l);
          } else throw new Error("Can not access image data");
        } else {
          if (d) return new Promise((g, b) => {
            let y = m(), T = h(y);
            if (!n || !T) return b();
            let I = new Image();
            I.crossOrigin = "Anonymous", I.src = n, I.onload = () => {
              y.width = I.width, y.height = I.height, T.drawImage(I, 0, 0, y.width, y.height);
              let _ = T.getImageData(0, 0, y.width, y.height);
              l.height = y.height, l.width = y.width, g(Kt(_.data, l));
            };
          });
          throw new Error("Input data provided is not supported - aborted tensor creation");
        }
        if (c !== void 0) return Kt(c, l);
        throw new Error("Input data provided is not supported - aborted tensor creation");
      }, Sr = (n, t) => {
        let { width: a, height: u, download: o, dispose: d } = t, c = [1, u, a, 4];
        return new Q({ location: "texture", type: "float32", texture: n, dims: c, download: o, dispose: d });
      }, vr = (n, t) => {
        let { dataType: a, dims: u, download: o, dispose: d } = t;
        return new Q({ location: "gpu-buffer", type: a ?? "float32", gpuBuffer: n, dims: u, download: o, dispose: d });
      }, Or = (n, t) => {
        let { dataType: a, dims: u, download: o, dispose: d } = t;
        return new Q({ location: "ml-tensor", type: a ?? "float32", mlTensor: n, dims: u, download: o, dispose: d });
      }, Ar = (n, t, a) => new Q({ location: "cpu-pinned", type: n, data: t, dims: a ?? [t.length] });
    });
    _r = F(() => {
      "use strict";
      Le = /* @__PURE__ */ new Map([["float32", Float32Array], ["uint8", Uint8Array], ["int8", Int8Array], ["uint16", Uint16Array], ["int16", Int16Array], ["int32", Int32Array], ["bool", Uint8Array], ["float64", Float64Array], ["uint32", Uint32Array], ["int4", Uint8Array], ["uint4", Uint8Array]]), Xe = /* @__PURE__ */ new Map([[Float32Array, "float32"], [Uint8Array, "uint8"], [Int8Array, "int8"], [Uint16Array, "uint16"], [Int16Array, "int16"], [Int32Array, "int32"], [Float64Array, "float64"], [Uint32Array, "uint32"]]), Br = false, Lr = () => {
        if (!Br) {
          Br = true;
          let n = typeof BigInt64Array < "u" && BigInt64Array.from, t = typeof BigUint64Array < "u" && BigUint64Array.from, a = globalThis.Float16Array, u = typeof a < "u" && a.from;
          n && (Le.set("int64", BigInt64Array), Xe.set(BigInt64Array, "int64")), t && (Le.set("uint64", BigUint64Array), Xe.set(BigUint64Array, "uint64")), u ? (Le.set("float16", a), Xe.set(a, "float16")) : Le.set("float16", Uint16Array);
        }
      };
    });
    Ur = F(() => {
      "use strict";
      ct();
      Dr = (n) => {
        let t = 1;
        for (let a = 0; a < n.length; a++) {
          let u = n[a];
          if (typeof u != "number" || !Number.isSafeInteger(u)) throw new TypeError(`dims[${a}] must be an integer, got: ${u}`);
          if (u < 0) throw new RangeError(`dims[${a}] must be a non-negative integer, got: ${u}`);
          t *= u;
        }
        return t;
      }, Pr = (n, t) => {
        switch (n.location) {
          case "cpu":
            return new Q(n.type, n.data, t);
          case "cpu-pinned":
            return new Q({ location: "cpu-pinned", data: n.data, type: n.type, dims: t });
          case "texture":
            return new Q({ location: "texture", texture: n.texture, type: n.type, dims: t });
          case "gpu-buffer":
            return new Q({ location: "gpu-buffer", gpuBuffer: n.gpuBuffer, type: n.type, dims: t });
          case "ml-tensor":
            return new Q({ location: "ml-tensor", mlTensor: n.mlTensor, type: n.type, dims: t });
          default:
            throw new Error(`tensorReshape: tensor location ${n.location} is not supported`);
        }
      };
    });
    ct = F(() => {
      "use strict";
      Er();
      Ir();
      _r();
      Ur();
      Q = class {
        constructor(t, a, u) {
          Lr();
          let o, d;
          if (typeof t == "object" && "location" in t) switch (this.dataLocation = t.location, o = t.type, d = t.dims, t.location) {
            case "cpu-pinned": {
              let l = Le.get(o);
              if (!l) throw new TypeError(`unsupported type "${o}" to create tensor from pinned buffer`);
              if (!(t.data instanceof l)) throw new TypeError(`buffer should be of type ${l.name}`);
              this.cpuData = t.data;
              break;
            }
            case "texture": {
              if (o !== "float32") throw new TypeError(`unsupported type "${o}" to create tensor from texture`);
              this.gpuTextureData = t.texture, this.downloader = t.download, this.disposer = t.dispose;
              break;
            }
            case "gpu-buffer": {
              if (o !== "float32" && o !== "float16" && o !== "int32" && o !== "int64" && o !== "uint32" && o !== "uint8" && o !== "bool" && o !== "uint4" && o !== "int4") throw new TypeError(`unsupported type "${o}" to create tensor from gpu buffer`);
              this.gpuBufferData = t.gpuBuffer, this.downloader = t.download, this.disposer = t.dispose;
              break;
            }
            case "ml-tensor": {
              if (o !== "float32" && o !== "float16" && o !== "int32" && o !== "int64" && o !== "uint32" && o !== "uint64" && o !== "int8" && o !== "uint8" && o !== "bool" && o !== "uint4" && o !== "int4") throw new TypeError(`unsupported type "${o}" to create tensor from MLTensor`);
              this.mlTensorData = t.mlTensor, this.downloader = t.download, this.disposer = t.dispose;
              break;
            }
            default:
              throw new Error(`Tensor constructor: unsupported location '${this.dataLocation}'`);
          }
          else {
            let l, m;
            if (typeof t == "string") if (o = t, m = u, t === "string") {
              if (!Array.isArray(a)) throw new TypeError("A string tensor's data must be a string array.");
              l = a;
            } else {
              let h = Le.get(t);
              if (h === void 0) throw new TypeError(`Unsupported tensor type: ${t}.`);
              if (Array.isArray(a)) {
                if (t === "float16" && h === Uint16Array || t === "uint4" || t === "int4") throw new TypeError(`Creating a ${t} tensor from number array is not supported. Please use ${h.name} as data.`);
                t === "uint64" || t === "int64" ? l = h.from(a, BigInt) : l = h.from(a);
              } else if (a instanceof h) l = a;
              else if (a instanceof Uint8ClampedArray) if (t === "uint8") l = Uint8Array.from(a);
              else throw new TypeError("A Uint8ClampedArray tensor's data must be type of uint8");
              else if (t === "float16" && a instanceof Uint16Array && h !== Uint16Array) l = new globalThis.Float16Array(a.buffer, a.byteOffset, a.length);
              else throw new TypeError(`A ${o} tensor's data must be type of ${h}`);
            }
            else if (m = a, Array.isArray(t)) {
              if (t.length === 0) throw new TypeError("Tensor type cannot be inferred from an empty array.");
              let h = typeof t[0];
              if (h === "string") o = "string", l = t;
              else if (h === "boolean") o = "bool", l = Uint8Array.from(t);
              else throw new TypeError(`Invalid element type of data array: ${h}.`);
            } else if (t instanceof Uint8ClampedArray) o = "uint8", l = Uint8Array.from(t);
            else {
              let h = Xe.get(t.constructor);
              if (h === void 0) throw new TypeError(`Unsupported type for tensor data: ${t.constructor}.`);
              o = h, l = t;
            }
            if (m === void 0) m = [l.length];
            else if (!Array.isArray(m)) throw new TypeError("A tensor's dims must be a number array");
            d = m, this.cpuData = l, this.dataLocation = "cpu";
          }
          let c = Dr(d);
          if (this.cpuData && c !== this.cpuData.length && !((o === "uint4" || o === "int4") && Math.ceil(c / 2) === this.cpuData.length)) throw new Error(`Tensor's size(${c}) does not match data length(${this.cpuData.length}).`);
          this.type = o, this.dims = d, this.size = c;
        }
        static async fromImage(t, a) {
          return Tr(t, a);
        }
        static fromTexture(t, a) {
          return Sr(t, a);
        }
        static fromGpuBuffer(t, a) {
          return vr(t, a);
        }
        static fromMLTensor(t, a) {
          return Or(t, a);
        }
        static fromPinnedBuffer(t, a, u) {
          return Ar(t, a, u);
        }
        toDataURL(t) {
          return yr(this, t);
        }
        toImageData(t) {
          return gr(this, t);
        }
        get data() {
          if (this.ensureValid(), !this.cpuData) throw new Error("The data is not on CPU. Use `getData()` to download GPU data to CPU, or use `texture` or `gpuBuffer` property to access the GPU data directly.");
          return this.cpuData;
        }
        get location() {
          return this.dataLocation;
        }
        get texture() {
          if (this.ensureValid(), !this.gpuTextureData) throw new Error("The data is not stored as a WebGL texture.");
          return this.gpuTextureData;
        }
        get gpuBuffer() {
          if (this.ensureValid(), !this.gpuBufferData) throw new Error("The data is not stored as a WebGPU buffer.");
          return this.gpuBufferData;
        }
        get mlTensor() {
          if (this.ensureValid(), !this.mlTensorData) throw new Error("The data is not stored as a WebNN MLTensor.");
          return this.mlTensorData;
        }
        async getData(t) {
          switch (this.ensureValid(), this.dataLocation) {
            case "cpu":
            case "cpu-pinned":
              return this.data;
            case "texture":
            case "gpu-buffer":
            case "ml-tensor": {
              if (!this.downloader) throw new Error("The current tensor is not created with a specified data downloader.");
              if (this.isDownloading) throw new Error("The current tensor is being downloaded.");
              try {
                this.isDownloading = true;
                let a = await this.downloader();
                return this.downloader = void 0, this.dataLocation = "cpu", this.cpuData = a, t && this.disposer && (this.disposer(), this.disposer = void 0), a;
              } finally {
                this.isDownloading = false;
              }
            }
            default:
              throw new Error(`cannot get data from location: ${this.dataLocation}`);
          }
        }
        dispose() {
          if (this.isDownloading) throw new Error("The current tensor is being downloaded.");
          this.disposer && (this.disposer(), this.disposer = void 0), this.cpuData = void 0, this.gpuTextureData = void 0, this.gpuBufferData = void 0, this.mlTensorData = void 0, this.downloader = void 0, this.isDownloading = void 0, this.dataLocation = "none";
        }
        ensureValid() {
          if (this.dataLocation === "none") throw new Error("The tensor is disposed.");
        }
        reshape(t) {
          if (this.ensureValid(), this.downloader || this.disposer) throw new Error("Cannot reshape a tensor that owns GPU resource.");
          return Pr(this, t);
        }
      };
    });
    en = F(() => {
      "use strict";
      ct();
      de = Q;
    });
    tn = F(() => {
      "use strict";
      Zt();
      xr = (n, t) => {
        (typeof J.trace > "u" ? !J.wasm.trace : !J.trace) || console.timeStamp(`${n}::ORT::${t}`);
      }, Cr = (n, t) => {
        let a = new Error().stack?.split(/\r\n|\r|\n/g) || [], u = false;
        for (let o = 0; o < a.length; o++) {
          if (u && !a[o].includes("TRACE_FUNC")) {
            let d = `FUNC_${n}::${a[o].trim().split(" ")[1]}`;
            t && (d += `::${t}`), xr("CPU", d);
            return;
          }
          a[o].includes("TRACE_FUNC") && (u = true);
        }
      }, _e = (n) => {
        (typeof J.trace > "u" ? !J.wasm.trace : !J.trace) || Cr("BEGIN", n);
      }, De = (n) => {
        (typeof J.trace > "u" ? !J.wasm.trace : !J.trace) || Cr("END", n);
      }, Pe = (n) => {
        (typeof J.trace > "u" ? !J.wasm.trace : !J.trace) || console.time(`ORT::${n}`);
      }, Ue = (n) => {
        (typeof J.trace > "u" ? !J.wasm.trace : !J.trace) || console.timeEnd(`ORT::${n}`);
      };
    });
    Mr = F(() => {
      "use strict";
      Qt();
      en();
      tn();
      lt = class n {
        constructor(t) {
          this.handler = t;
        }
        async run(t, a, u) {
          _e(), Pe("InferenceSession.run");
          let o = {}, d = {};
          if (typeof t != "object" || t === null || t instanceof de || Array.isArray(t)) throw new TypeError("'feeds' must be an object that use input names as keys and OnnxValue as corresponding values.");
          let c = true;
          if (typeof a == "object") {
            if (a === null) throw new TypeError("Unexpected argument[1]: cannot be null.");
            if (a instanceof de) throw new TypeError("'fetches' cannot be a Tensor");
            if (Array.isArray(a)) {
              if (a.length === 0) throw new TypeError("'fetches' cannot be an empty array.");
              c = false;
              for (let h of a) {
                if (typeof h != "string") throw new TypeError("'fetches' must be a string array or an object.");
                if (this.outputNames.indexOf(h) === -1) throw new RangeError(`'fetches' contains invalid output name: ${h}.`);
                o[h] = null;
              }
              if (typeof u == "object" && u !== null) d = u;
              else if (typeof u < "u") throw new TypeError("'options' must be an object.");
            } else {
              let h = false, g = Object.getOwnPropertyNames(a);
              for (let b of this.outputNames) if (g.indexOf(b) !== -1) {
                let y = a[b];
                (y === null || y instanceof de) && (h = true, c = false, o[b] = y);
              }
              if (h) {
                if (typeof u == "object" && u !== null) d = u;
                else if (typeof u < "u") throw new TypeError("'options' must be an object.");
              } else d = a;
            }
          } else if (typeof a < "u") throw new TypeError("Unexpected argument[1]: must be 'fetches' or 'options'.");
          for (let h of this.inputNames) if (typeof t[h] > "u") throw new Error(`input '${h}' is missing in 'feeds'.`);
          if (c) for (let h of this.outputNames) o[h] = null;
          let l = await this.handler.run(t, o, d), m = {};
          for (let h in l) if (Object.hasOwnProperty.call(l, h)) {
            let g = l[h];
            g instanceof de ? m[h] = g : m[h] = new de(g.type, g.data, g.dims);
          }
          return Ue("InferenceSession.run"), De(), m;
        }
        async release() {
          return this.handler.dispose();
        }
        static async create(t, a, u, o) {
          _e(), Pe("InferenceSession.create");
          let d, c = {};
          if (typeof t == "string") {
            if (d = t, typeof a == "object" && a !== null) c = a;
            else if (typeof a < "u") throw new TypeError("'options' must be an object.");
          } else if (t instanceof Uint8Array) {
            if (d = t, typeof a == "object" && a !== null) c = a;
            else if (typeof a < "u") throw new TypeError("'options' must be an object.");
          } else if (t instanceof ArrayBuffer || typeof SharedArrayBuffer < "u" && t instanceof SharedArrayBuffer) {
            let g = t, b = 0, y = t.byteLength;
            if (typeof a == "object" && a !== null) c = a;
            else if (typeof a == "number") {
              if (b = a, !Number.isSafeInteger(b)) throw new RangeError("'byteOffset' must be an integer.");
              if (b < 0 || b >= g.byteLength) throw new RangeError(`'byteOffset' is out of range [0, ${g.byteLength}).`);
              if (y = t.byteLength - b, typeof u == "number") {
                if (y = u, !Number.isSafeInteger(y)) throw new RangeError("'byteLength' must be an integer.");
                if (y <= 0 || b + y > g.byteLength) throw new RangeError(`'byteLength' is out of range (0, ${g.byteLength - b}].`);
                if (typeof o == "object" && o !== null) c = o;
                else if (typeof o < "u") throw new TypeError("'options' must be an object.");
              } else if (typeof u < "u") throw new TypeError("'byteLength' must be a number.");
            } else if (typeof a < "u") throw new TypeError("'options' must be an object.");
            d = new Uint8Array(g, b, y);
          } else throw new TypeError("Unexpected argument[0]: must be 'path' or 'buffer'.");
          let [l, m] = await dr(c), h = await l.createInferenceSessionHandler(d, m);
          return Ue("InferenceSession.create"), De(), new n(h);
        }
        startProfiling() {
          this.handler.startProfiling();
        }
        endProfiling() {
          this.handler.endProfiling();
        }
        get inputNames() {
          return this.handler.inputNames;
        }
        get outputNames() {
          return this.handler.outputNames;
        }
        get inputMetadata() {
          return this.handler.inputMetadata;
        }
        get outputMetadata() {
          return this.handler.outputMetadata;
        }
      };
    });
    Rr = F(() => {
      "use strict";
      Mr();
      ts = lt;
    });
    Nr = F(() => {
      "use strict";
    });
    Fr = F(() => {
      "use strict";
    });
    kr = F(() => {
      "use strict";
    });
    Wr = F(() => {
      "use strict";
    });
    nn = {};
    ut(nn, { InferenceSession: () => ts, TRACE: () => xr, TRACE_EVENT_BEGIN: () => Pe, TRACE_EVENT_END: () => Ue, TRACE_FUNC_BEGIN: () => _e, TRACE_FUNC_END: () => De, Tensor: () => de, env: () => Y, registerBackend: () => qe });
    Te = F(() => {
      "use strict";
      pr();
      br();
      Rr();
      en();
      Nr();
      Fr();
      tn();
      kr();
      Wr();
    });
    dt = F(() => {
      "use strict";
    });
    Hr = {};
    ut(Hr, { default: () => ns });
    jr = F(() => {
      "use strict";
      rn();
      xe();
      pt();
      $r = "ort-wasm-proxy-worker", zr = globalThis.self?.name === $r;
      zr && (self.onmessage = (n) => {
        let { type: t, in: a } = n.data;
        try {
          switch (t) {
            case "init-wasm":
              mt(a.wasm).then(() => {
                ht(a).then(() => {
                  postMessage({ type: t });
                }, (u) => {
                  postMessage({ type: t, err: u });
                });
              }, (u) => {
                postMessage({ type: t, err: u });
              });
              break;
            case "init-ep": {
              let { epName: u, env: o } = a;
              wt(o, u).then(() => {
                postMessage({ type: t });
              }, (d) => {
                postMessage({ type: t, err: d });
              });
              break;
            }
            case "copy-from": {
              let { buffer: u } = a, o = Qe(u);
              postMessage({ type: t, out: o });
              break;
            }
            case "create": {
              let { model: u, options: o } = a;
              bt(u, o).then((d) => {
                postMessage({ type: t, out: d });
              }, (d) => {
                postMessage({ type: t, err: d });
              });
              break;
            }
            case "release":
              yt(a), postMessage({ type: t });
              break;
            case "run": {
              let { sessionId: u, inputIndices: o, inputs: d, outputIndices: c, options: l } = a;
              gt(u, o, d, c, new Array(c.length).fill(null), l).then((m) => {
                m.some((h) => h[3] !== "cpu") ? postMessage({ type: t, err: "Proxy does not support non-cpu tensor location." }) : postMessage({ type: t, out: m }, Tt([...d, ...m]));
              }, (m) => {
                postMessage({ type: t, err: m });
              });
              break;
            }
            case "end-profiling":
              Et(a), postMessage({ type: t });
              break;
            default:
          }
        } catch (u) {
          postMessage({ type: t, err: u });
        }
      });
      ns = zr ? null : (n) => new Worker(n ?? oe, { type: "module", name: $r });
    });
    Yr = {};
    ut(Yr, { default: () => rs });
    Jr = F(() => {
      "use strict";
      rs = Vr, os = globalThis.self?.name?.startsWith("em-pthread");
      os && Vr();
    });
    pt = F(() => {
      "use strict";
      dt();
      Qr = typeof location > "u" ? void 0 : location.origin, an = import.meta.url > "file:" && import.meta.url < "file;", as = () => {
        if (true) {
          if (an) {
            let n = URL;
            return new URL(new n("ort.wasm.bundle.min.mjs", import.meta.url).href, Qr).href;
          }
          return import.meta.url;
        }
      }, oe = as(), Zr = () => {
        if (oe && !oe.startsWith("blob:")) return oe.substring(0, oe.lastIndexOf("/") + 1);
      }, on = (n, t) => {
        try {
          let a = t ?? oe;
          return (a ? new URL(n, a) : new URL(n)).origin === Qr;
        } catch {
          return false;
        }
      }, ss = (n, t) => {
        let a = t ?? oe;
        try {
          return (a ? new URL(n, a) : new URL(n)).href;
        } catch {
          return;
        }
      }, is = (n, t) => `${t ?? "./"}${n}`, Kr = async (n) => {
        let a = await (await fetch(n, { credentials: "same-origin" })).blob();
        return URL.createObjectURL(a);
      }, us = async (n) => (await import(
        /*webpackIgnore:true*/
        /*@vite-ignore*/
        n
      )).default, qr = (jr(), Xt(Hr)).default, eo = async () => {
        if (!oe) throw new Error("Failed to load proxy worker: cannot determine the script source URL.");
        if (on(oe)) return [void 0, qr()];
        let n = await Kr(oe);
        return [n, qr(n)];
      }, Xr = (Jr(), Xt(Yr)).default, to = async (n, t, a, u) => {
        let o = Xr && !(n || t);
        if (o) if (oe) o = on(oe) || u && !a;
        else if (u && !a) o = true;
        else throw new Error("cannot determine the script source URL.");
        if (o) return [void 0, Xr];
        {
          let d = "ort-wasm-simd-threaded.mjs", c = n ?? ss(d, t), l = a && c && !on(c, t), m = l ? await Kr(c) : c ?? is(d, t);
          return [l ? m : void 0, await us(m)];
        }
      };
    });
    xe = F(() => {
      "use strict";
      pt();
      un = false, St = false, no = false, fs = () => {
        if (typeof SharedArrayBuffer > "u") return false;
        try {
          return typeof MessageChannel < "u" && new MessageChannel().port1.postMessage(new SharedArrayBuffer(1)), WebAssembly.validate(new Uint8Array([0, 97, 115, 109, 1, 0, 0, 0, 1, 4, 1, 96, 0, 0, 3, 2, 1, 0, 5, 4, 1, 3, 1, 1, 10, 11, 1, 9, 0, 65, 0, 254, 16, 2, 0, 26, 11]));
        } catch {
          return false;
        }
      }, cs = () => {
        try {
          return WebAssembly.validate(new Uint8Array([0, 97, 115, 109, 1, 0, 0, 0, 1, 4, 1, 96, 0, 0, 3, 2, 1, 0, 10, 30, 1, 28, 0, 65, 0, 253, 15, 253, 12, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 253, 186, 1, 26, 11]));
        } catch {
          return false;
        }
      }, ls = () => {
        try {
          return WebAssembly.validate(new Uint8Array([0, 97, 115, 109, 1, 0, 0, 0, 1, 5, 1, 96, 0, 1, 123, 3, 2, 1, 0, 10, 19, 1, 17, 0, 65, 1, 253, 15, 65, 2, 253, 15, 65, 3, 253, 15, 253, 147, 2, 11]));
        } catch {
          return false;
        }
      }, mt = async (n) => {
        if (un) return Promise.resolve();
        if (St) throw new Error("multiple calls to 'initializeWebAssembly()' detected.");
        if (no) throw new Error("previous call to 'initializeWebAssembly()' failed.");
        St = true;
        let t = n.initTimeout, a = n.numThreads;
        if (n.simd !== false) {
          if (n.simd === "relaxed") {
            if (!ls()) throw new Error("Relaxed WebAssembly SIMD is not supported in the current environment.");
          } else if (!cs()) throw new Error("WebAssembly SIMD is not supported in the current environment.");
        }
        let u = fs();
        a > 1 && !u && (typeof self < "u" && !self.crossOriginIsolated && console.warn("env.wasm.numThreads is set to " + a + ", but this will not work unless you enable crossOriginIsolated mode. See https://web.dev/cross-origin-isolation-guide/ for more info."), console.warn("WebAssembly multi-threading is not supported in the current environment. Falling back to single-threading."), n.numThreads = a = 1);
        let o = n.wasmPaths, d = typeof o == "string" ? o : void 0, c = o?.mjs, l = c?.href ?? c, m = o?.wasm, h = m?.href ?? m, g = n.wasmBinary, [b, y] = await to(l, d, a > 1, !!g || !!h), T = false, I = [];
        if (t > 0 && I.push(new Promise((_) => {
          setTimeout(() => {
            T = true, _();
          }, t);
        })), I.push(new Promise((_, $) => {
          let v = { numThreads: a };
          if (g) v.wasmBinary = g, v.locateFile = (O) => O;
          else if (h || d) v.locateFile = (O) => h ?? d + O;
          else if (l && l.indexOf("blob:") !== 0) v.locateFile = (O) => new URL(O, l).href;
          else if (b) {
            let O = Zr();
            O && (v.locateFile = (N) => O + N);
          }
          y(v).then((O) => {
            St = false, un = true, sn = O, _(), b && URL.revokeObjectURL(b);
          }, (O) => {
            St = false, no = true, $(O);
          });
        })), await Promise.race(I), T) throw new Error(`WebAssembly backend initializing failed due to timeout: ${t}ms`);
      }, z = () => {
        if (un && sn) return sn;
        throw new Error("WebAssembly is not initialized yet.");
      };
    });
    vt = F(() => {
      "use strict";
      xe();
      ae = (n, t) => {
        let a = z(), u = a.lengthBytesUTF8(n) + 1, o = a._malloc(u);
        return a.stringToUTF8(n, o, u), t.push(o), o;
      }, Ze = (n, t, a, u) => {
        if (typeof n == "object" && n !== null) {
          if (a.has(n)) throw new Error("Circular reference in options");
          a.add(n);
        }
        Object.entries(n).forEach(([o, d]) => {
          let c = t ? t + o : o;
          if (typeof d == "object") Ze(d, c + ".", a, u);
          else if (typeof d == "string" || typeof d == "number") u(c, d.toString());
          else if (typeof d == "boolean") u(c, d ? "1" : "0");
          else throw new Error(`Can't handle extra config type: ${typeof d}`);
        });
      }, G = (n) => {
        let t = z(), a = t.stackSave();
        try {
          let u = t.PTR_SIZE, o = t.stackAlloc(2 * u);
          t._OrtGetLastError(o, o + u);
          let d = Number(t.getValue(o, u === 4 ? "i32" : "i64")), c = t.getValue(o + u, "*"), l = c ? t.UTF8ToString(c) : "";
          throw new Error(`${n} ERROR_CODE: ${d}, ERROR_MESSAGE: ${l}`);
        } finally {
          t.stackRestore(a);
        }
      };
    });
    oo = F(() => {
      "use strict";
      xe();
      vt();
      ro = (n) => {
        let t = z(), a = 0, u = [], o = n || {};
        try {
          if (n?.logSeverityLevel === void 0) o.logSeverityLevel = 2;
          else if (typeof n.logSeverityLevel != "number" || !Number.isInteger(n.logSeverityLevel) || n.logSeverityLevel < 0 || n.logSeverityLevel > 4) throw new Error(`log severity level is not valid: ${n.logSeverityLevel}`);
          if (n?.logVerbosityLevel === void 0) o.logVerbosityLevel = 0;
          else if (typeof n.logVerbosityLevel != "number" || !Number.isInteger(n.logVerbosityLevel)) throw new Error(`log verbosity level is not valid: ${n.logVerbosityLevel}`);
          n?.terminate === void 0 && (o.terminate = false);
          let d = 0;
          return n?.tag !== void 0 && (d = ae(n.tag, u)), a = t._OrtCreateRunOptions(o.logSeverityLevel, o.logVerbosityLevel, !!o.terminate, d), a === 0 && G("Can't create run options."), n?.extra !== void 0 && Ze(n.extra, "", /* @__PURE__ */ new WeakSet(), (c, l) => {
            let m = ae(c, u), h = ae(l, u);
            t._OrtAddRunConfigEntry(a, m, h) !== 0 && G(`Can't set a run config entry: ${c} - ${l}.`);
          }), [a, u];
        } catch (d) {
          throw a !== 0 && t._OrtReleaseRunOptions(a), u.forEach((c) => t._free(c)), d;
        }
      };
    });
    so = F(() => {
      "use strict";
      xe();
      vt();
      ds = (n) => {
        switch (n) {
          case "disabled":
            return 0;
          case "basic":
            return 1;
          case "extended":
            return 2;
          case "layout":
            return 3;
          case "all":
            return 99;
          default:
            throw new Error(`unsupported graph optimization level: ${n}`);
        }
      }, ps = (n) => {
        switch (n) {
          case "sequential":
            return 0;
          case "parallel":
            return 1;
          default:
            throw new Error(`unsupported execution mode: ${n}`);
        }
      }, ms = (n) => {
        n.extra || (n.extra = {}), n.extra.session || (n.extra.session = {});
        let t = n.extra.session;
        t.use_ort_model_bytes_directly || (t.use_ort_model_bytes_directly = "1"), n.executionProviders && n.executionProviders.some((a) => (typeof a == "string" ? a : a.name) === "webgpu") && (n.enableMemPattern = false);
      }, ke = (n, t, a, u) => {
        let o = ae(t, u), d = ae(a, u);
        z()._OrtAddSessionConfigEntry(n, o, d) !== 0 && G(`Can't set a session config entry: ${t} - ${a}.`);
      }, hs = async (n, t, a) => {
        let u = t.executionProviders;
        for (let o of u) {
          let d = typeof o == "string" ? o : o.name, c = [];
          switch (d) {
            case "webnn":
              if (d = "WEBNN", ke(n, "session.disable_quant_qdq", "1", a), ke(n, "session.disable_qdq_constant_folding", "1", a), typeof o != "string") {
                let y = o?.deviceType;
                y && ke(n, "deviceType", y, a);
              }
              break;
            case "webgpu":
              if (d = "JS", typeof o != "string") {
                let b = o;
                if (b?.preferredLayout) {
                  if (b.preferredLayout !== "NCHW" && b.preferredLayout !== "NHWC") throw new Error(`preferredLayout must be either 'NCHW' or 'NHWC': ${b.preferredLayout}`);
                  ke(n, "preferredLayout", b.preferredLayout, a);
                }
              }
              break;
            case "wasm":
            case "cpu":
              continue;
            default:
              throw new Error(`not supported execution provider: ${d}`);
          }
          let l = ae(d, a), m = c.length, h = 0, g = 0;
          if (m > 0) {
            h = z()._malloc(m * z().PTR_SIZE), a.push(h), g = z()._malloc(m * z().PTR_SIZE), a.push(g);
            for (let b = 0; b < m; b++) z().setValue(h + b * z().PTR_SIZE, c[b][0], "*"), z().setValue(g + b * z().PTR_SIZE, c[b][1], "*");
          }
          await z()._OrtAppendExecutionProvider(n, l, h, g, m) !== 0 && G(`Can't append execution provider: ${d}.`);
        }
      }, ao = async (n) => {
        let t = z(), a = 0, u = [], o = n || {};
        ms(o);
        try {
          let d = ds(o.graphOptimizationLevel ?? "all"), c = ps(o.executionMode ?? "sequential"), l = typeof o.logId == "string" ? ae(o.logId, u) : 0, m = o.logSeverityLevel ?? 2;
          if (!Number.isInteger(m) || m < 0 || m > 4) throw new Error(`log severity level is not valid: ${m}`);
          let h = o.logVerbosityLevel ?? 0;
          if (!Number.isInteger(h) || h < 0 || h > 4) throw new Error(`log verbosity level is not valid: ${h}`);
          let g = typeof o.optimizedModelFilePath == "string" ? ae(o.optimizedModelFilePath, u) : 0;
          if (a = t._OrtCreateSessionOptions(d, !!o.enableCpuMemArena, !!o.enableMemPattern, c, !!o.enableProfiling, 0, l, m, h, g), a === 0 && G("Can't create session options."), o.executionProviders && await hs(a, o, u), o.enableGraphCapture !== void 0) {
            if (typeof o.enableGraphCapture != "boolean") throw new Error(`enableGraphCapture must be a boolean value: ${o.enableGraphCapture}`);
            ke(a, "enableGraphCapture", o.enableGraphCapture.toString(), u);
          }
          if (o.freeDimensionOverrides) for (let [b, y] of Object.entries(o.freeDimensionOverrides)) {
            if (typeof b != "string") throw new Error(`free dimension override name must be a string: ${b}`);
            if (typeof y != "number" || !Number.isInteger(y) || y < 0) throw new Error(`free dimension override value must be a non-negative integer: ${y}`);
            let T = ae(b, u);
            t._OrtAddFreeDimensionOverride(a, T, y) !== 0 && G(`Can't set a free dimension override: ${b} - ${y}.`);
          }
          return o.extra !== void 0 && Ze(o.extra, "", /* @__PURE__ */ new WeakSet(), (b, y) => {
            ke(a, b, y, u);
          }), [a, u];
        } catch (d) {
          throw a !== 0 && t._OrtReleaseSessionOptions(a) !== 0 && G("Can't release session options."), u.forEach((c) => t._free(c)), d;
        }
      };
    });
    fn = F(() => {
      "use strict";
      We = (n) => {
        switch (n) {
          case "int8":
            return 3;
          case "uint8":
            return 2;
          case "bool":
            return 9;
          case "int16":
            return 5;
          case "uint16":
            return 4;
          case "int32":
            return 6;
          case "uint32":
            return 12;
          case "float16":
            return 10;
          case "float32":
            return 1;
          case "float64":
            return 11;
          case "string":
            return 8;
          case "int64":
            return 7;
          case "uint64":
            return 13;
          case "int4":
            return 22;
          case "uint4":
            return 21;
          default:
            throw new Error(`unsupported data type: ${n}`);
        }
      }, Ot = (n) => {
        switch (n) {
          case 3:
            return "int8";
          case 2:
            return "uint8";
          case 9:
            return "bool";
          case 5:
            return "int16";
          case 4:
            return "uint16";
          case 6:
            return "int32";
          case 12:
            return "uint32";
          case 10:
            return "float16";
          case 1:
            return "float32";
          case 11:
            return "float64";
          case 8:
            return "string";
          case 7:
            return "int64";
          case 13:
            return "uint64";
          case 22:
            return "int4";
          case 21:
            return "uint4";
          default:
            throw new Error(`unsupported data type: ${n}`);
        }
      }, Ge = (n, t) => {
        let a = [-1, 4, 1, 1, 2, 2, 4, 8, -1, 1, 2, 8, 4, 8, -1, -1, -1, -1, -1, -1, -1, 0.5, 0.5][n], u = typeof t == "number" ? t : t.reduce((o, d) => o * d, 1);
        return a > 0 ? Math.ceil(u * a) : void 0;
      }, io = (n) => {
        switch (n) {
          case "float16":
            return typeof Float16Array < "u" ? Float16Array : Uint16Array;
          case "float32":
            return Float32Array;
          case "uint8":
            return Uint8Array;
          case "int8":
            return Int8Array;
          case "uint16":
            return Uint16Array;
          case "int16":
            return Int16Array;
          case "int32":
            return Int32Array;
          case "bool":
            return Uint8Array;
          case "float64":
            return Float64Array;
          case "uint32":
            return Uint32Array;
          case "int64":
            return BigInt64Array;
          case "uint64":
            return BigUint64Array;
          default:
            throw new Error(`unsupported type: ${n}`);
        }
      }, uo = (n) => {
        switch (n) {
          case "verbose":
            return 0;
          case "info":
            return 1;
          case "warning":
            return 2;
          case "error":
            return 3;
          case "fatal":
            return 4;
          default:
            throw new Error(`unsupported logging level: ${n}`);
        }
      }, At = (n) => n === "float32" || n === "float16" || n === "int32" || n === "int64" || n === "uint32" || n === "uint8" || n === "bool" || n === "uint4" || n === "int4", It = (n) => n === "float32" || n === "float16" || n === "int32" || n === "int64" || n === "uint32" || n === "uint64" || n === "int8" || n === "uint8" || n === "bool" || n === "uint4" || n === "int4", fo = (n) => {
        switch (n) {
          case "none":
            return 0;
          case "cpu":
            return 1;
          case "cpu-pinned":
            return 2;
          case "texture":
            return 3;
          case "gpu-buffer":
            return 4;
          case "ml-tensor":
            return 5;
          default:
            throw new Error(`unsupported data location: ${n}`);
        }
      };
    });
    cn = F(() => {
      "use strict";
      dt();
      Ke = async (n) => {
        if (typeof n == "string") if (false) try {
          let { readFile: t } = qt("node:fs/promises");
          return new Uint8Array(await t(n));
        } catch (t) {
          if (t.code === "ERR_FS_FILE_TOO_LARGE") {
            let { createReadStream: a } = qt("node:fs"), u = a(n), o = [];
            for await (let d of u) o.push(d);
            return new Uint8Array(Buffer.concat(o));
          }
          throw t;
        }
        else {
          let t = await fetch(n);
          if (!t.ok) throw new Error(`failed to load external data file: ${n}`);
          let a = t.headers.get("Content-Length"), u = a ? parseInt(a, 10) : 0;
          if (u < 1073741824) return new Uint8Array(await t.arrayBuffer());
          {
            if (!t.body) throw new Error(`failed to load external data file: ${n}, no response body.`);
            let o = t.body.getReader(), d;
            try {
              d = new ArrayBuffer(u);
            } catch (l) {
              if (l instanceof RangeError) {
                let m = Math.ceil(u / 65536);
                d = new WebAssembly.Memory({ initial: m, maximum: m }).buffer;
              } else throw l;
            }
            let c = 0;
            for (; ; ) {
              let { done: l, value: m } = await o.read();
              if (l) break;
              let h = m.byteLength;
              new Uint8Array(d, c, h).set(m), c += h;
            }
            return new Uint8Array(d, 0, u);
          }
        }
        else return n instanceof Blob ? new Uint8Array(await n.arrayBuffer()) : n instanceof Uint8Array ? n : new Uint8Array(n);
      };
    });
    rn = F(() => {
      "use strict";
      Te();
      oo();
      so();
      fn();
      xe();
      vt();
      cn();
      ws = (n, t) => {
        z()._OrtInit(n, t) !== 0 && G("Can't initialize onnxruntime.");
      }, ht = async (n) => {
        ws(n.wasm.numThreads, uo(n.logLevel));
      }, wt = async (n, t) => {
        z().asyncInit?.();
        let a = n.webgpu.adapter;
        if (t === "webgpu") {
          if (typeof navigator > "u" || !navigator.gpu) throw new Error("WebGPU is not supported in current environment");
          if (a) {
            if (typeof a.limits != "object" || typeof a.features != "object" || typeof a.requestDevice != "function") throw new Error("Invalid GPU adapter set in `env.webgpu.adapter`. It must be a GPUAdapter object.");
          } else {
            let u = n.webgpu.powerPreference;
            if (u !== void 0 && u !== "low-power" && u !== "high-performance") throw new Error(`Invalid powerPreference setting: "${u}"`);
            let o = n.webgpu.forceFallbackAdapter;
            if (o !== void 0 && typeof o != "boolean") throw new Error(`Invalid forceFallbackAdapter setting: "${o}"`);
            if (a = await navigator.gpu.requestAdapter({ powerPreference: u, forceFallbackAdapter: o }), !a) throw new Error('Failed to get GPU adapter. You may need to enable flag "--enable-unsafe-webgpu" if you are using Chrome.');
          }
        }
        if (t === "webnn" && (typeof navigator > "u" || !navigator.ml)) throw new Error("WebNN is not supported in current environment");
      }, $e = /* @__PURE__ */ new Map(), bs = (n) => {
        let t = z(), a = t.stackSave();
        try {
          let u = t.PTR_SIZE, o = t.stackAlloc(2 * u);
          t._OrtGetInputOutputCount(n, o, o + u) !== 0 && G("Can't get session input/output count.");
          let c = u === 4 ? "i32" : "i64";
          return [Number(t.getValue(o, c)), Number(t.getValue(o + u, c))];
        } finally {
          t.stackRestore(a);
        }
      }, co = (n, t) => {
        let a = z(), u = a.stackSave(), o = 0;
        try {
          let d = a.PTR_SIZE, c = a.stackAlloc(2 * d);
          a._OrtGetInputOutputMetadata(n, t, c, c + d) !== 0 && G("Can't get session input/output metadata.");
          let m = Number(a.getValue(c, "*"));
          o = Number(a.getValue(c + d, "*"));
          let h = a.HEAP32[o / 4];
          if (h === 0) return [m, 0];
          let g = a.HEAPU32[o / 4 + 1], b = [];
          for (let y = 0; y < g; y++) {
            let T = Number(a.getValue(o + 8 + y * d, "*"));
            b.push(T !== 0 ? a.UTF8ToString(T) : Number(a.getValue(o + 8 + (y + g) * d, "*")));
          }
          return [m, h, b];
        } finally {
          a.stackRestore(u), o !== 0 && a._OrtFree(o);
        }
      }, Qe = (n) => {
        let t = z(), a = t._malloc(n.byteLength);
        if (a === 0) throw new Error(`Can't create a session. failed to allocate a buffer of size ${n.byteLength}.`);
        return t.HEAPU8.set(n, a), [a, n.byteLength];
      }, bt = async (n, t) => {
        let a, u, o = z();
        Array.isArray(n) ? [a, u] = n : n.buffer === o.HEAPU8.buffer ? [a, u] = [n.byteOffset, n.byteLength] : [a, u] = Qe(n);
        let d = 0, c = 0, l = 0, m = [], h = [], g = [];
        try {
          if ([c, m] = await ao(t), t?.externalData && o.mountExternalData) {
            let D = [];
            for (let k of t.externalData) {
              let w = typeof k == "string" ? k : k.path, Z = typeof k == "string" ? k : k.data;
              D.push(Ke(Z).then((H) => {
                o.mountExternalData(w, H);
              }));
            }
            await Promise.all(D);
          }
          for (let D of t?.executionProviders ?? []) if ((typeof D == "string" ? D : D.name) === "webnn") {
            if (o.shouldTransferToMLTensor = false, typeof D != "string") {
              let w = D, Z = w?.context, H = w?.gpuDevice, ne = w?.deviceType, pe = w?.powerPreference;
              Z ? o.currentContext = Z : H ? o.currentContext = await o.webnnCreateMLContext(H) : o.currentContext = await o.webnnCreateMLContext({ deviceType: ne, powerPreference: pe });
            } else o.currentContext = await o.webnnCreateMLContext();
            break;
          }
          d = await o._OrtCreateSession(a, u, c), o.webgpuOnCreateSession?.(d), d === 0 && G("Can't create a session."), o.jsepOnCreateSession?.(), o.currentContext && (o.webnnRegisterMLContext(d, o.currentContext), o.currentContext = void 0, o.shouldTransferToMLTensor = true);
          let [b, y] = bs(d), T = !!t?.enableGraphCapture, I = [], _ = [], $ = [], v = [], O = [];
          for (let D = 0; D < b; D++) {
            let [k, w, Z] = co(d, D);
            k === 0 && G("Can't get an input name."), h.push(k);
            let H = o.UTF8ToString(k);
            I.push(H), $.push(w === 0 ? { name: H, isTensor: false } : { name: H, isTensor: true, type: Ot(w), shape: Z });
          }
          for (let D = 0; D < y; D++) {
            let [k, w, Z] = co(d, D + b);
            k === 0 && G("Can't get an output name."), g.push(k);
            let H = o.UTF8ToString(k);
            _.push(H), v.push(w === 0 ? { name: H, isTensor: false } : { name: H, isTensor: true, type: Ot(w), shape: Z });
          }
          return $e.set(d, [d, h, g, null, T, false]), [d, I, _, $, v];
        } catch (b) {
          throw h.forEach((y) => o._OrtFree(y)), g.forEach((y) => o._OrtFree(y)), l !== 0 && o._OrtReleaseBinding(l) !== 0 && G("Can't release IO binding."), d !== 0 && o._OrtReleaseSession(d) !== 0 && G("Can't release session."), b;
        } finally {
          o._free(a), c !== 0 && o._OrtReleaseSessionOptions(c) !== 0 && G("Can't release session options."), m.forEach((b) => o._free(b)), o.unmountExternalData?.();
        }
      }, yt = (n) => {
        let t = z(), a = $e.get(n);
        if (!a) throw new Error(`cannot release session. invalid session id: ${n}`);
        let [u, o, d, c, l] = a;
        c && (l && t._OrtClearBoundOutputs(c.handle) !== 0 && G("Can't clear bound outputs."), t._OrtReleaseBinding(c.handle) !== 0 && G("Can't release IO binding.")), t.jsepOnReleaseSession?.(n), t.webnnOnReleaseSession?.(n), t.webgpuOnReleaseSession?.(n), o.forEach((m) => t._OrtFree(m)), d.forEach((m) => t._OrtFree(m)), t._OrtReleaseSession(u) !== 0 && G("Can't release session."), $e.delete(n);
      }, lo = async (n, t, a, u, o, d, c = false) => {
        if (!n) {
          t.push(0);
          return;
        }
        let l = z(), m = l.PTR_SIZE, h = n[0], g = n[1], b = n[3], y = b, T, I;
        if (h === "string" && (b === "gpu-buffer" || b === "ml-tensor")) throw new Error("String tensor is not supported on GPU.");
        if (c && b !== "gpu-buffer") throw new Error(`External buffer must be provided for input/output index ${d} when enableGraphCapture is true.`);
        if (b === "gpu-buffer") {
          let v = n[2].gpuBuffer;
          I = Ge(We(h), g);
          {
            let O = l.jsepRegisterBuffer;
            if (!O) throw new Error('Tensor location "gpu-buffer" is not supported without using WebGPU.');
            T = O(u, d, v, I);
          }
        } else if (b === "ml-tensor") {
          let v = n[2].mlTensor;
          I = Ge(We(h), g);
          let O = l.webnnRegisterMLTensor;
          if (!O) throw new Error('Tensor location "ml-tensor" is not supported without using WebNN.');
          T = O(u, v, We(h), g);
        } else {
          let v = n[2];
          if (Array.isArray(v)) {
            I = m * v.length, T = l._malloc(I), a.push(T);
            for (let O = 0; O < v.length; O++) {
              if (typeof v[O] != "string") throw new TypeError(`tensor data at index ${O} is not a string`);
              l.setValue(T + O * m, ae(v[O], a), "*");
            }
          } else {
            let O = l.webnnIsGraphInput, N = l.webnnIsGraphOutput;
            if (h !== "string" && O && N) {
              let D = l.UTF8ToString(o);
              if (O(u, D) || N(u, D)) {
                let k = We(h);
                I = Ge(k, g), y = "ml-tensor";
                let w = l.webnnCreateTemporaryTensor, Z = l.webnnUploadTensor;
                if (!w || !Z) throw new Error('Tensor location "ml-tensor" is not supported without using WebNN.');
                let H = await w(u, k, g);
                Z(H, new Uint8Array(v.buffer, v.byteOffset, v.byteLength)), T = H;
              } else I = v.byteLength, T = l._malloc(I), a.push(T), l.HEAPU8.set(new Uint8Array(v.buffer, v.byteOffset, I), T);
            } else I = v.byteLength, T = l._malloc(I), a.push(T), l.HEAPU8.set(new Uint8Array(v.buffer, v.byteOffset, I), T);
          }
        }
        let _ = l.stackSave(), $ = l.stackAlloc(4 * g.length);
        try {
          g.forEach((O, N) => l.setValue($ + N * m, O, m === 4 ? "i32" : "i64"));
          let v = l._OrtCreateTensor(We(h), T, I, $, g.length, fo(y));
          v === 0 && G(`Can't create tensor for input/output. session=${u}, index=${d}.`), t.push(v);
        } finally {
          l.stackRestore(_);
        }
      }, gt = async (n, t, a, u, o, d) => {
        let c = z(), l = c.PTR_SIZE, m = $e.get(n);
        if (!m) throw new Error(`cannot run inference. invalid session id: ${n}`);
        let h = m[0], g = m[1], b = m[2], y = m[3], T = m[4], I = m[5], _ = t.length, $ = u.length, v = 0, O = [], N = [], D = [], k = [], w = [], Z = c.stackSave(), H = c.stackAlloc(_ * l), ne = c.stackAlloc(_ * l), pe = c.stackAlloc($ * l), B = c.stackAlloc($ * l);
        try {
          [v, O] = ro(d), Pe("wasm prepareInputOutputTensor");
          for (let A = 0; A < _; A++) await lo(a[A], N, k, n, g[t[A]], t[A], T);
          for (let A = 0; A < $; A++) await lo(o[A], D, k, n, b[u[A]], _ + u[A], T);
          Ue("wasm prepareInputOutputTensor");
          for (let A = 0; A < _; A++) c.setValue(H + A * l, N[A], "*"), c.setValue(ne + A * l, g[t[A]], "*");
          for (let A = 0; A < $; A++) c.setValue(pe + A * l, D[A], "*"), c.setValue(B + A * l, b[u[A]], "*");
          c.jsepOnRunStart?.(h), c.webnnOnRunStart?.(h);
          let W;
          W = await c._OrtRun(h, ne, H, _, B, $, pe, v), W !== 0 && G("failed to call OrtRun().");
          let re = [], me = [];
          Pe("wasm ProcessOutputTensor");
          for (let A = 0; A < $; A++) {
            let K3 = Number(c.getValue(pe + A * l, "*"));
            if (K3 === D[A] || w.includes(D[A])) {
              re.push(o[A]), K3 !== D[A] && c._OrtReleaseTensor(K3) !== 0 && G("Can't release tensor.");
              continue;
            }
            let je = c.stackSave(), ee = c.stackAlloc(4 * l), he = false, j, q = 0;
            try {
              c._OrtGetTensorData(K3, ee, ee + l, ee + 2 * l, ee + 3 * l) !== 0 && G(`Can't access output tensor data on index ${A}.`);
              let Se = l === 4 ? "i32" : "i64", ve = Number(c.getValue(ee, Se));
              q = c.getValue(ee + l, "*");
              let Ve = c.getValue(ee + l * 2, "*"), Re = Number(c.getValue(ee + l * 3, Se)), te = [];
              for (let L = 0; L < Re; L++) te.push(Number(c.getValue(Ve + L * l, Se)));
              c._OrtFree(Ve) !== 0 && G("Can't free memory for tensor dims.");
              let ue = te.reduce((L, V) => L * V, 1);
              j = Ot(ve);
              let se = y?.outputPreferredLocations[u[A]];
              if (j === "string") {
                if (se === "gpu-buffer" || se === "ml-tensor") throw new Error("String tensor is not supported on GPU.");
                let L = [];
                for (let V = 0; V < ue; V++) {
                  let fe = c.getValue(q + V * l, "*"), ye = c.getValue(q + (V + 1) * l, "*"), ce = V === ue - 1 ? void 0 : ye - fe;
                  L.push(c.UTF8ToString(fe, ce));
                }
                re.push([j, te, L, "cpu"]);
              } else if (se === "gpu-buffer" && ue > 0) {
                let L = c.jsepGetBuffer;
                if (!L) throw new Error('preferredLocation "gpu-buffer" is not supported without using WebGPU.');
                let V = L(q), fe = Ge(ve, ue);
                if (fe === void 0 || !At(j)) throw new Error(`Unsupported data type: ${j}`);
                he = true, re.push([j, te, { gpuBuffer: V, download: c.jsepCreateDownloader(V, fe, j), dispose: () => {
                  c._OrtReleaseTensor(K3) !== 0 && G("Can't release tensor.");
                } }, "gpu-buffer"]);
              } else if (se === "ml-tensor" && ue > 0) {
                let L = c.webnnEnsureTensor, V = c.webnnIsGraphInputOutputTypeSupported;
                if (!L || !V) throw new Error('preferredLocation "ml-tensor" is not supported without using WebNN.');
                if (Ge(ve, ue) === void 0 || !It(j)) throw new Error(`Unsupported data type: ${j}`);
                if (!V(n, j, false)) throw new Error(`preferredLocation "ml-tensor" for ${j} output is not supported by current WebNN Context.`);
                let ye = await L(n, q, ve, te, false);
                he = true, re.push([j, te, { mlTensor: ye, download: c.webnnCreateMLTensorDownloader(q, j), dispose: () => {
                  c.webnnReleaseTensorId(q), c._OrtReleaseTensor(K3);
                } }, "ml-tensor"]);
              } else if (se === "ml-tensor-cpu-output" && ue > 0) {
                let L = c.webnnCreateMLTensorDownloader(q, j)(), V = re.length;
                he = true, me.push((async () => {
                  let fe = [V, await L];
                  return c.webnnReleaseTensorId(q), c._OrtReleaseTensor(K3), fe;
                })()), re.push([j, te, [], "cpu"]);
              } else {
                let L = io(j), V = new L(ue);
                new Uint8Array(V.buffer, V.byteOffset, V.byteLength).set(c.HEAPU8.subarray(q, q + V.byteLength)), re.push([j, te, V, "cpu"]);
              }
            } finally {
              c.stackRestore(je), j === "string" && q && c._free(q), he || c._OrtReleaseTensor(K3);
            }
          }
          y && !T && (c._OrtClearBoundOutputs(y.handle) !== 0 && G("Can't clear bound outputs."), $e.set(n, [h, g, b, y, T, false]));
          for (let [A, K3] of await Promise.all(me)) re[A][2] = K3;
          return Ue("wasm ProcessOutputTensor"), re;
        } finally {
          c.webnnOnRunEnd?.(h), c.stackRestore(Z), N.forEach((W) => c._OrtReleaseTensor(W)), D.forEach((W) => c._OrtReleaseTensor(W)), k.forEach((W) => c._free(W)), v !== 0 && c._OrtReleaseRunOptions(v), O.forEach((W) => c._free(W));
        }
      }, Et = (n) => {
        let t = z(), a = $e.get(n);
        if (!a) throw new Error("invalid session id");
        let u = a[0], o = t._OrtEndProfiling(u);
        o === 0 && G("Can't get an profile file name."), t._OrtFree(o);
      }, Tt = (n) => {
        let t = [];
        for (let a of n) {
          let u = a[2];
          !Array.isArray(u) && "buffer" in u && t.push(u.buffer);
        }
        return t;
      };
    });
    pn = F(() => {
      "use strict";
      Te();
      rn();
      xe();
      pt();
      Me = () => !!Y.wasm.proxy && typeof document < "u", et = false, Lt = false, _t = false, dn = /* @__PURE__ */ new Map(), ze = (n, t) => {
        let a = dn.get(n);
        a ? a.push(t) : dn.set(n, [t]);
      }, He = () => {
        if (et || !Lt || _t || !ie) throw new Error("worker not ready");
      }, gs = (n) => {
        switch (n.data.type) {
          case "init-wasm":
            et = false, n.data.err ? (_t = true, ln[1](n.data.err)) : (Lt = true, ln[0]()), Bt && (URL.revokeObjectURL(Bt), Bt = void 0);
            break;
          case "init-ep":
          case "copy-from":
          case "create":
          case "release":
          case "run":
          case "end-profiling": {
            let t = dn.get(n.data.type);
            n.data.err ? t.shift()[1](n.data.err) : t.shift()[0](n.data.out);
            break;
          }
          default:
        }
      }, po = async () => {
        if (!Lt) {
          if (et) throw new Error("multiple calls to 'initWasm()' detected.");
          if (_t) throw new Error("previous call to 'initWasm()' failed.");
          if (et = true, Me()) return new Promise((n, t) => {
            ie?.terminate(), eo().then(([a, u]) => {
              try {
                ie = u, ie.onerror = (d) => t(d), ie.onmessage = gs, ln = [n, t];
                let o = { type: "init-wasm", in: Y };
                !o.in.wasm.wasmPaths && (a || an) && (o.in.wasm.wasmPaths = { wasm: new URL("ort-wasm-simd-threaded.wasm", import.meta.url).href }), ie.postMessage(o), Bt = a;
              } catch (o) {
                t(o);
              }
            }, t);
          });
          try {
            await mt(Y.wasm), await ht(Y), Lt = true;
          } catch (n) {
            throw _t = true, n;
          } finally {
            et = false;
          }
        }
      }, mo = async (n) => {
        if (Me()) return He(), new Promise((t, a) => {
          ze("init-ep", [t, a]);
          let u = { type: "init-ep", in: { epName: n, env: Y } };
          ie.postMessage(u);
        });
        await wt(Y, n);
      }, ho = async (n) => Me() ? (He(), new Promise((t, a) => {
        ze("copy-from", [t, a]);
        let u = { type: "copy-from", in: { buffer: n } };
        ie.postMessage(u, [n.buffer]);
      })) : Qe(n), wo = async (n, t) => {
        if (Me()) {
          if (t?.preferredOutputLocation) throw new Error('session option "preferredOutputLocation" is not supported for proxy.');
          return He(), new Promise((a, u) => {
            ze("create", [a, u]);
            let o = { type: "create", in: { model: n, options: { ...t } } }, d = [];
            n instanceof Uint8Array && d.push(n.buffer), ie.postMessage(o, d);
          });
        } else return bt(n, t);
      }, bo = async (n) => {
        if (Me()) return He(), new Promise((t, a) => {
          ze("release", [t, a]);
          let u = { type: "release", in: n };
          ie.postMessage(u);
        });
        yt(n);
      }, yo = async (n, t, a, u, o, d) => {
        if (Me()) {
          if (a.some((c) => c[3] !== "cpu")) throw new Error("input tensor on GPU is not supported for proxy.");
          if (o.some((c) => c)) throw new Error("pre-allocated output tensor is not supported for proxy.");
          return He(), new Promise((c, l) => {
            ze("run", [c, l]);
            let m = a, h = { type: "run", in: { sessionId: n, inputIndices: t, inputs: m, outputIndices: u, options: d } };
            ie.postMessage(h, Tt(m));
          });
        } else return gt(n, t, a, u, o, d);
      }, go = async (n) => {
        if (Me()) return He(), new Promise((t, a) => {
          ze("end-profiling", [t, a]);
          let u = { type: "end-profiling", in: n };
          ie.postMessage(u);
        });
        Et(n);
      };
    });
    To = F(() => {
      "use strict";
      Te();
      pn();
      fn();
      dt();
      cn();
      Eo = (n, t) => {
        switch (n.location) {
          case "cpu":
            return [n.type, n.dims, n.data, "cpu"];
          case "gpu-buffer":
            return [n.type, n.dims, { gpuBuffer: n.gpuBuffer }, "gpu-buffer"];
          case "ml-tensor":
            return [n.type, n.dims, { mlTensor: n.mlTensor }, "ml-tensor"];
          default:
            throw new Error(`invalid data location: ${n.location} for ${t()}`);
        }
      }, Es = (n) => {
        switch (n[3]) {
          case "cpu":
            return new de(n[0], n[2], n[1]);
          case "gpu-buffer": {
            let t = n[0];
            if (!At(t)) throw new Error(`not supported data type: ${t} for deserializing GPU tensor`);
            let { gpuBuffer: a, download: u, dispose: o } = n[2];
            return de.fromGpuBuffer(a, { dataType: t, dims: n[1], download: u, dispose: o });
          }
          case "ml-tensor": {
            let t = n[0];
            if (!It(t)) throw new Error(`not supported data type: ${t} for deserializing MLTensor tensor`);
            let { mlTensor: a, download: u, dispose: o } = n[2];
            return de.fromMLTensor(a, { dataType: t, dims: n[1], download: u, dispose: o });
          }
          default:
            throw new Error(`invalid data location: ${n[3]}`);
        }
      }, Dt = class {
        async fetchModelAndCopyToWasmMemory(t) {
          return ho(await Ke(t));
        }
        async loadModel(t, a) {
          _e();
          let u;
          typeof t == "string" ? u = await this.fetchModelAndCopyToWasmMemory(t) : u = t, [this.sessionId, this.inputNames, this.outputNames, this.inputMetadata, this.outputMetadata] = await wo(u, a), De();
        }
        async dispose() {
          return bo(this.sessionId);
        }
        async run(t, a, u) {
          _e();
          let o = [], d = [];
          Object.entries(t).forEach((y) => {
            let T = y[0], I = y[1], _ = this.inputNames.indexOf(T);
            if (_ === -1) throw new Error(`invalid input '${T}'`);
            o.push(I), d.push(_);
          });
          let c = [], l = [];
          Object.entries(a).forEach((y) => {
            let T = y[0], I = y[1], _ = this.outputNames.indexOf(T);
            if (_ === -1) throw new Error(`invalid output '${T}'`);
            c.push(I), l.push(_);
          });
          let m = o.map((y, T) => Eo(y, () => `input "${this.inputNames[d[T]]}"`)), h = c.map((y, T) => y ? Eo(y, () => `output "${this.outputNames[l[T]]}"`) : null), g = await yo(this.sessionId, d, m, l, h, u), b = {};
          for (let y = 0; y < g.length; y++) b[this.outputNames[l[y]]] = c[y] ?? Es(g[y]);
          return De(), b;
        }
        startProfiling() {
        }
        endProfiling() {
          go(this.sessionId);
        }
      };
    });
    vo = {};
    ut(vo, { OnnxruntimeWebAssemblyBackend: () => Pt, initializeFlags: () => So, wasmBackend: () => Ts });
    Oo = F(() => {
      "use strict";
      Te();
      pn();
      To();
      So = () => {
        (typeof Y.wasm.initTimeout != "number" || Y.wasm.initTimeout < 0) && (Y.wasm.initTimeout = 0);
        let n = Y.wasm.simd;
        if (typeof n != "boolean" && n !== void 0 && n !== "fixed" && n !== "relaxed" && (console.warn(`Property "env.wasm.simd" is set to unknown value "${n}". Reset it to \`false\` and ignore SIMD feature checking.`), Y.wasm.simd = false), typeof Y.wasm.proxy != "boolean" && (Y.wasm.proxy = false), typeof Y.wasm.trace != "boolean" && (Y.wasm.trace = false), typeof Y.wasm.numThreads != "number" || !Number.isInteger(Y.wasm.numThreads) || Y.wasm.numThreads <= 0) if (typeof self < "u" && !self.crossOriginIsolated) Y.wasm.numThreads = 1;
        else {
          let t = typeof navigator > "u" ? qt("node:os").cpus().length : navigator.hardwareConcurrency;
          Y.wasm.numThreads = Math.min(4, Math.ceil((t || 1) / 2));
        }
      }, Pt = class {
        async init(t) {
          So(), await po(), await mo(t);
        }
        async createInferenceSessionHandler(t, a) {
          let u = new Dt();
          return await u.loadModel(t, a), u;
        }
      }, Ts = new Pt();
    });
    Te();
    Te();
    Te();
    Gr = "1.29.0";
    au = nn;
    {
      let n = (Oo(), Xt(vo)).wasmBackend;
      qe("cpu", n, 10), qe("wasm", n, 10);
    }
    Object.defineProperty(Y.versions, "web", { value: Gr, enumerable: true });
  }
});

// node_modules/@opace/content-integrity-browser/dist/index.js
var WORKER_PROTOCOL_VERSION = "1.0";
function createInspectionWorker(options = {}) {
  if (typeof Worker === "undefined") throw new Error("worker_unsupported");
  const worker = new Worker(options.workerUrl ?? new URL("./worker/entry.js", import.meta.url), { type: "module" });
  const pending = /* @__PURE__ */ new Map();
  worker.onmessage = (event) => {
    const m = event.data, p = pending.get(m.id);
    if (!p || m.protocol_version !== WORKER_PROTOCOL_VERSION) return;
    if (m.type === "progress") p.onProgress?.(m.phase);
    else {
      pending.delete(m.id);
      m.type === "result" ? p.resolve(m.result) : p.reject(new Error(m.code));
    }
  };
  return { inspect(request, opts = {}) {
    const id = `inspect_${Date.now()}_${Math.random().toString(36).slice(2)}`;
    return new Promise((resolve, reject) => {
      pending.set(id, { resolve, reject, onProgress: opts.onProgress });
      const abort = () => {
        worker.postMessage({ protocol_version: WORKER_PROTOCOL_VERSION, type: "cancel", id });
        pending.delete(id);
        reject(new DOMException("Inspection cancelled", "AbortError"));
      };
      if (opts.signal?.aborted) return abort();
      opts.signal?.addEventListener("abort", abort, { once: true });
      worker.postMessage({ protocol_version: WORKER_PROTOCOL_VERSION, type: "inspect", id, request });
    });
  }, dispose() {
    for (const p of pending.values()) p.reject(new Error("worker_disposed"));
    pending.clear();
    worker.terminate();
  } };
}

// ../../packages/cycle5-browser/dist/index.js
var CYCLE5_MODEL_BASE = "https://opace.agency/models/local-signals-v1/";
var CYCLE5_CACHE_NAME = "opace-content-integrity-cycle5-browser-2026-09-1";
var CYCLE5_SUPERSEDED_CACHES = [
  "opace-local-signals-v1",
  "opace-local-signals-cycle2",
  "opace-local-signals-cycle5"
];
var CYCLE5_MODEL_FILE = "tier3-cycle5-full-e5small-int8-perchannel.onnx";
var CYCLE5_VOCAB_FILE = "vocab.txt";
var CYCLE5_WASM_FILE = "ort/ort-wasm-simd-threaded.wasm";
var CYCLE5_MANIFEST_FILE = "manifest.json";
var CYCLE5_MODEL_BYTES = 34301767;
var CYCLE5_MODEL_SHA256 = "9f57d6a8fe48a329170c5272f4f09a08ed383f9f461e7900fecd70f9fb15ef1b";
var CYCLE5_VOCAB_BYTES = 231508;
var CYCLE5_VOCAB_SHA256 = "07eced375cec144d27c900241f3e339478dec958f92fddbc551f295c992038a3";
var CYCLE5_WASM_BYTES = 13961845;
var CYCLE5_WASM_SHA256 = "ec8580a9d7b9476ceee52e10a7f94124e4dc71a019d666ed6d4726697c109a4d";
var CYCLE5_DOWNLOAD_BYTES = CYCLE5_MODEL_BYTES + CYCLE5_VOCAB_BYTES;
var CYCLE5_MODEL_DOWNLOAD_LABEL = "34.5 MB";
var CYCLE5_DEFAULT_MAX_CHARACTERS = 5e4;
var CYCLE5_MAX_CHARACTERS = 1e5;
var CYCLE5_MAX_LEN = 512;
var CYCLE5_MIN_SCORED_TOKENS = 50;
var CYCLE5_TEMPERATURE = 1.0479;
var CYCLE5_PRIMARY_MARGIN = 3.570935;
var CYCLE5_SECONDARY_GAP = 0.34;
var CYCLE5_PRIMARY_DISPLAY_THRESHOLD = 0.9679444972866822;
var CYCLE5_SECONDARY_DISPLAY_THRESHOLD = 0.9561964051006938;
var CYCLE5_BANDS = [
  { id: "very_likely_ai", min: CYCLE5_PRIMARY_DISPLAY_THRESHOLD },
  { id: "uncertain", min: 0.95 },
  { id: "likely_human", min: 0.5 },
  { id: "very_likely_human", min: 0 }
];
var CYCLE5_ASSETS = Object.freeze({
  [CYCLE5_MODEL_FILE]: { bytes: CYCLE5_MODEL_BYTES, sha256: CYCLE5_MODEL_SHA256, mediaType: "application/octet-stream" },
  [CYCLE5_VOCAB_FILE]: { bytes: CYCLE5_VOCAB_BYTES, sha256: CYCLE5_VOCAB_SHA256, mediaType: "text/plain" },
  [CYCLE5_WASM_FILE]: { bytes: CYCLE5_WASM_BYTES, sha256: CYCLE5_WASM_SHA256, mediaType: "application/wasm" }
});
var Cycle5BrowserError = class extends Error {
  code;
  constructor(code, message, options) {
    super(message, options);
    this.name = "Cycle5BrowserError";
    this.code = code;
  }
};
function normaliseAllowedModelBase(candidate2, allowed) {
  let parsed;
  try {
    parsed = new URL(candidate2);
  } catch (cause) {
    throw new Cycle5BrowserError("invalid_model_base", "The model base is not a valid URL.", { cause });
  }
  if (parsed.protocol !== "https:" || parsed.username || parsed.password || parsed.search || parsed.hash) {
    throw new Cycle5BrowserError("invalid_model_base", "The model base must be an exact credential-free HTTPS directory URL.");
  }
  if (!parsed.pathname.endsWith("/")) parsed.pathname += "/";
  const normalised = parsed.href;
  const allowlist = allowed.map((entry) => {
    const url = new URL(entry);
    if (!url.pathname.endsWith("/")) url.pathname += "/";
    return url.href;
  });
  if (!allowlist.includes(normalised)) throw new Cycle5BrowserError("invalid_model_base", "The model base is not in this host's fixed allowlist.");
  return normalised;
}
function throwIfAborted(signal, message = "The on-device model preparation was cancelled.") {
  if (signal?.aborted) throw new Cycle5BrowserError("cancelled", message);
}
async function sha256(bytes, signal) {
  throwIfAborted(signal);
  const digest2 = await crypto.subtle.digest("SHA-256", bytes.slice().buffer);
  throwIfAborted(signal);
  return [...new Uint8Array(digest2)].map((byte) => byte.toString(16).padStart(2, "0")).join("");
}
function abortReason(signal) {
  if (signal?.aborted) throw new Cycle5BrowserError("cancelled", "The on-device model preparation was cancelled.");
  throw new Cycle5BrowserError("engine_error", "The model asset stream ended unexpectedly.");
}
async function boundedFetch(fetcher, url, maxBytes, signal, onProgress) {
  let response;
  try {
    response = await fetcher(url, { method: "GET", credentials: "omit", redirect: "error", cache: "no-store", signal });
  } catch (cause) {
    if (signal?.aborted) throw new Cycle5BrowserError("cancelled", "The on-device model download was cancelled.", { cause });
    throw new Cycle5BrowserError("offline", `The on-device asset could not be fetched: ${url}`, { cause });
  }
  if (!response.ok) throw new Cycle5BrowserError("offline", `The on-device asset returned HTTP ${response.status}: ${url}`);
  const reader = response.body?.getReader();
  if (!reader) {
    const bytes2 = new Uint8Array(await response.arrayBuffer());
    throwIfAborted(signal, "The on-device model download was cancelled.");
    if (bytes2.byteLength > maxBytes) throw new Cycle5BrowserError("integrity_error", `The on-device asset exceeded its byte bound: ${url}`);
    onProgress?.(bytes2.byteLength);
    return bytes2;
  }
  const chunks = [];
  let total = 0;
  for (; ; ) {
    if (signal?.aborted) {
      await reader.cancel().catch(() => void 0);
      abortReason(signal);
    }
    const { done, value } = await reader.read();
    if (done) break;
    if (!value) continue;
    total += value.byteLength;
    if (total > maxBytes) {
      await reader.cancel().catch(() => void 0);
      throw new Cycle5BrowserError("integrity_error", `The on-device asset exceeded its byte bound: ${url}`);
    }
    chunks.push(value);
    onProgress?.(total);
  }
  const bytes = new Uint8Array(total);
  let offset = 0;
  for (const chunk of chunks) {
    bytes.set(chunk, offset);
    offset += chunk.byteLength;
  }
  return bytes;
}
function validateManifest(manifest) {
  if (manifest.version !== "tier3-cycle5-v1" || !manifest.files || typeof manifest.files !== "object") {
    throw new Cycle5BrowserError("integrity_error", "The model manifest does not identify tier3-cycle5-v1.");
  }
  for (const [file, expected] of Object.entries(CYCLE5_ASSETS)) {
    const entry = manifest.files[file];
    if (!entry || entry.bytes !== expected.bytes || entry.sha256 !== expected.sha256) {
      throw new Cycle5BrowserError("integrity_error", `The model manifest does not match the pinned ${file} identity.`);
    }
  }
}
async function validateAsset(file, bytes, signal) {
  const expected = CYCLE5_ASSETS[file];
  throwIfAborted(signal);
  if (bytes.byteLength !== expected.bytes || await sha256(bytes, signal) !== expected.sha256) {
    throw new Cycle5BrowserError("integrity_error", `Integrity check failed for ${file}.`);
  }
  throwIfAborted(signal);
}
var availableCaches = (provided) => provided ?? (typeof caches === "undefined" ? void 0 : caches);
async function pruneSuperseded(storage, signal) {
  const cacheStorage = availableCaches(storage);
  if (!cacheStorage) return;
  throwIfAborted(signal);
  const names = await cacheStorage.keys().catch(() => []);
  throwIfAborted(signal);
  await Promise.all(names.filter((name) => CYCLE5_SUPERSEDED_CACHES.includes(name)).map((name) => cacheStorage.delete(name)));
  throwIfAborted(signal);
}
function assetUrl(baseUrl, wasmUrl, file) {
  if (file === CYCLE5_WASM_FILE && wasmUrl) return new URL(wasmUrl, globalThis.location?.href ?? baseUrl).href;
  return new URL(file, baseUrl).href;
}
async function loadVerifiedCachedAssets(baseUrl, wasmUrl, storage, signal) {
  const cacheStorage = availableCaches(storage);
  if (!cacheStorage) return void 0;
  throwIfAborted(signal);
  await pruneSuperseded(cacheStorage, signal);
  let cache;
  try {
    cache = await cacheStorage.open(CYCLE5_CACHE_NAME);
    throwIfAborted(signal);
  } catch (cause) {
    if (cause instanceof Cycle5BrowserError && cause.code === "cancelled") throw cause;
    return void 0;
  }
  const loaded = {};
  try {
    for (const file of Object.keys(CYCLE5_ASSETS)) {
      throwIfAborted(signal);
      const response = await cache.match(assetUrl(baseUrl, wasmUrl, file));
      throwIfAborted(signal);
      if (!response) return void 0;
      const bytes = new Uint8Array(await response.arrayBuffer());
      throwIfAborted(signal);
      await validateAsset(file, bytes, signal);
      loaded[file] = bytes;
    }
  } catch (cause) {
    if (cause instanceof Cycle5BrowserError && cause.code === "cancelled") throw cause;
    await cacheStorage.delete(CYCLE5_CACHE_NAME).catch(() => false);
    return void 0;
  }
  throwIfAborted(signal);
  return { model: loaded[CYCLE5_MODEL_FILE], vocab: loaded[CYCLE5_VOCAB_FILE], wasm: loaded[CYCLE5_WASM_FILE] };
}
async function downloadVerifiedAssets(options) {
  const { baseUrl, wasmUrl, fetcher, cacheStorage, signal, onProgress } = options;
  await pruneSuperseded(cacheStorage, signal);
  const manifestBytes = await boundedFetch(fetcher, new URL(CYCLE5_MANIFEST_FILE, baseUrl).href, 65536, signal);
  let manifest;
  try {
    manifest = JSON.parse(new TextDecoder().decode(manifestBytes));
  } catch (cause) {
    throw new Cycle5BrowserError("integrity_error", "The model manifest is not valid JSON.", { cause });
  }
  validateManifest(manifest);
  const files = Object.keys(CYCLE5_ASSETS);
  const loaded = {};
  for (const [index, file] of files.entries()) {
    const expected = CYCLE5_ASSETS[file];
    const url = assetUrl(baseUrl, wasmUrl, file);
    const bytes = await boundedFetch(fetcher, url, expected.bytes, signal, (receivedBytes) => onProgress?.({
      file,
      fileIndex: index + 1,
      fileCount: files.length,
      receivedBytes,
      totalBytes: expected.bytes
    }));
    await validateAsset(file, bytes, signal);
    loaded[file] = bytes;
  }
  const storage = availableCaches(cacheStorage);
  if (storage) {
    try {
      const cache = await storage.open(CYCLE5_CACHE_NAME);
      throwIfAborted(signal);
      for (const file of files) {
        throwIfAborted(signal);
        const expected = CYCLE5_ASSETS[file];
        await cache.put(assetUrl(baseUrl, wasmUrl, file), new Response(loaded[file].slice().buffer, { headers: { "content-type": expected.mediaType, "content-length": String(expected.bytes) } }));
        throwIfAborted(signal);
      }
    } catch (cause) {
      if (signal?.aborted) throw new Cycle5BrowserError("cancelled", "The on-device model preparation was cancelled.", { cause });
    }
  }
  return { model: loaded[CYCLE5_MODEL_FILE], vocab: loaded[CYCLE5_VOCAB_FILE], wasm: loaded[CYCLE5_WASM_FILE] };
}
async function clearCycle5Cache(storage) {
  const cacheStorage = availableCaches(storage);
  return cacheStorage ? cacheStorage.delete(CYCLE5_CACHE_NAME) : false;
}
var IMPERATIVE_VERBS = /* @__PURE__ */ new Set([
  "write",
  "separate",
  "check",
  "decide",
  "ask",
  "compare",
  "choose",
  "use",
  "avoid",
  "consider",
  "start",
  "keep",
  "make",
  "ensure",
  "focus",
  "set",
  "review",
  "plan",
  "list",
  "add",
  "remove",
  "treat",
  "look",
  "note",
  "take",
  "put",
  "get",
  "define",
  "identify",
  "measure",
  "test",
  "build",
  "map",
  "record",
  "confirm",
  "agree",
  "include",
  "prioritise",
  "prioritize",
  "read",
  "think",
  "remember",
  "imagine",
  "consult",
  "contact",
  "call",
  "visit",
  "try",
  "begin",
  "stop",
  "watch",
  "find",
  "give",
  "send",
  "bring",
  "leave",
  "let",
  "pick",
  "select",
  "apply",
  "assess",
  "evaluate",
  "explain",
  "describe",
  "state",
  "name",
  "show",
  "tell",
  "expect",
  "allow",
  "aim",
  "work",
  "run",
  "draft",
  "publish",
  "share",
  "track",
  "monitor",
  "verify",
  "document",
  "budget",
  "quote",
  "price",
  "specify",
  "request",
  "require",
  "reduce",
  "improve",
  "increase",
  "protect",
  "secure",
  "update",
  "replace",
  "revisit",
  "weigh",
  "balance",
  "match",
  "align",
  "clarify",
  "capture"
]);
var UTILITY_VERBS = /* @__PURE__ */ new Set([
  "affects",
  "affect",
  "changes",
  "change",
  "reduces",
  "reduce",
  "improves",
  "improve",
  "helps",
  "help",
  "ensures",
  "ensure",
  "determines",
  "determine",
  "drives",
  "drive",
  "covers",
  "cover",
  "includes",
  "include",
  "requires",
  "require",
  "depends",
  "depend",
  "means",
  "mean",
  "matters",
  "matter",
  "supports",
  "support",
  "enables",
  "enable",
  "prevents",
  "prevent",
  "increases",
  "increase",
  "lowers",
  "lower",
  "shapes",
  "shape",
  "delivers",
  "deliver",
  "provides",
  "provide",
  "creates",
  "create",
  "allows",
  "allow",
  "offers",
  "offer",
  "adds",
  "add",
  "brings",
  "bring",
  "makes",
  "make",
  "gives",
  "give",
  "saves",
  "save",
  "costs",
  "cost",
  "takes",
  "take",
  "needs",
  "need",
  "sets",
  "set",
  "builds",
  "build",
  "leads",
  "lead",
  "informs",
  "inform",
  "guides",
  "guide",
  "reflects",
  "reflect",
  "signals",
  "signal",
  "indicates",
  "indicate",
  "boosts",
  "boost",
  "strengthens",
  "strengthen",
  "limits",
  "limit",
  "avoids",
  "avoid",
  "protects",
  "protect",
  "streamlines",
  "streamline",
  "influences",
  "influence",
  "reveals",
  "reveal",
  "explains",
  "explain",
  "shows",
  "show",
  "raises",
  "raise",
  "cuts",
  "cut",
  "speeds",
  "speed",
  "clarifies",
  "clarify",
  "removes",
  "remove"
]);
var AUX_VERBS = /* @__PURE__ */ new Set([
  "is",
  "are",
  "was",
  "were",
  "be",
  "been",
  "being",
  "am",
  "has",
  "have",
  "had",
  "do",
  "does",
  "did",
  "can",
  "could",
  "will",
  "would",
  "shall",
  "should",
  "may",
  "might",
  "must"
]);
var CONSEQUENCE_OPENERS = [
  "otherwise",
  "so ",
  "as a result",
  "that means",
  "this means",
  "the result is",
  "therefore",
  "then ",
  "consequently",
  "in short",
  "the effect is",
  "which is why",
  "that is why"
];
var EXAMPLE_MARKERS = [
  "for example",
  "for instance",
  "such as",
  "e.g.",
  "including ",
  "say, ",
  "like a ",
  "take the ",
  "consider the "
];
var CONTRAST_MARKERS = [
  " but ",
  " however",
  " though",
  " although",
  " yet ",
  " whereas ",
  " while ",
  " rather than ",
  " not always",
  " does not always",
  " is not a ",
  " is not the ",
  " instead of ",
  " unlike ",
  " despite ",
  " even so",
  " on the other hand"
];
var HEDGES = [
  "perhaps",
  "maybe",
  "sort of",
  "kind of",
  "arguably",
  "obviously",
  "of course",
  "i think",
  "we think",
  "in my experience",
  "honestly",
  "frankly",
  "actually",
  "pretty much",
  "more or less",
  "admittedly",
  "oddly",
  "curiously",
  "strangely",
  "funnily",
  "i suspect",
  "i'd say",
  "to be fair",
  "if anything",
  "not entirely",
  "i suppose",
  "somewhat",
  "roughly",
  "broadly",
  "loosely",
  "in a sense"
];
var FIRST_SECOND_PERSON = /* @__PURE__ */ new Set([
  "i",
  "me",
  "my",
  "mine",
  "we",
  "us",
  "our",
  "ours",
  "you",
  "your",
  "yours",
  "i'm",
  "i've",
  "i'd",
  "i'll",
  "we're",
  "we've",
  "you're",
  "you've"
]);
var ABSTRACT_SUFFIXES = [
  "tion",
  "sion",
  "ment",
  "ity",
  "ance",
  "ence",
  "ness",
  "ship",
  "ology",
  "ism",
  "age",
  "ure",
  "cy",
  "ing"
];
var ABSTRACT_NOUNS = /* @__PURE__ */ new Set([
  "cost",
  "costs",
  "count",
  "effort",
  "work",
  "price",
  "prices",
  "quality",
  "scope",
  "budget",
  "process",
  "model",
  "platform",
  "approach",
  "strategy",
  "structure",
  "content",
  "design",
  "page",
  "pages",
  "site",
  "sites",
  "data",
  "research",
  "evidence",
  "team",
  "business",
  "value",
  "risk",
  "time",
  "result",
  "results",
  "outcome",
  "outcomes",
  "choice",
  "decision",
  "factor",
  "feature",
  "features",
  "detail",
  "details",
  "brief",
  "spec",
  "policy",
  "practice",
  "method",
  "system",
  "tool",
  "tools",
  "rate",
  "rates",
  "level",
  "levels",
  "scale",
  "range",
  "share",
  "growth",
  "demand",
  "supply",
  "market",
  "sector",
  "product",
  "service",
  "services",
  "support",
  "success",
  "failure",
  "impact",
  "effect",
  "change",
  "role",
  "aim",
  "goal",
  "target"
]);
var CLAUSE_MARKERS = [
  " because ",
  " which ",
  " that ",
  " when ",
  " if ",
  " where ",
  " after ",
  " before ",
  " since ",
  " unless ",
  " until ",
  " so that ",
  " whether ",
  " while ",
  " although ",
  " though ",
  " whereas ",
  " as "
];
var SENT_SPLIT = /(?<=[.!?])["')\]]*\s+/;
var ABBREV = /\b(?:e\.g|i\.e|etc|vs|Dr|Mr|Mrs|Ms|Prof|Fig|No|St|Jr|Sr|approx|cf|al)\.$/i;
var WORD_RE = /[A-Za-z][A-Za-z'’-]*/g;
var cadenceWords = (s) => s.match(WORD_RE) ?? [];
var splitCadenceSentences = (text2) => {
  const out = [];
  for (const raw of text2.trim().split(SENT_SPLIT)) {
    const piece = raw.trim();
    if (!piece) continue;
    if (out.length && ABBREV.test(out[out.length - 1])) out[out.length - 1] += ` ${piece}`;
    else out.push(piece);
  }
  return out.filter((s) => cadenceWords(s).length > 0);
};
var isHeading = (block) => {
  const ws2 = cadenceWords(block);
  const last = block.replace(/\s+$/, "").slice(-1);
  return ws2.length > 0 && ws2.length <= 12 && !`.!?:;"')]`.includes(last);
};
var splitCadenceParagraphs = (text2) => {
  let blocks = text2.split(/\n\s*\n/).map((b) => b.trim()).filter(Boolean);
  if (blocks.length <= 1) blocks = text2.split("\n").map((b) => b.trim()).filter(Boolean);
  const kept = [];
  for (const block of blocks) {
    const lines = block.split("\n").map((line) => line.trim()).filter(Boolean).filter((line) => !isHeading(line));
    if (lines.length) kept.push(lines.join(" "));
  }
  return kept.length ? kept : blocks;
};
var startsImperative = (ws2) => {
  if (!ws2.length) return false;
  const first = ws2[0].toLowerCase();
  if (["do", "don't", "never", "always"].includes(first) && ws2.length > 1) {
    const second = ws2[1].toLowerCase().replace(/^['t]+|['t]+$/g, "");
    return IMPERATIVE_VERBS.has(second) || first === "never" || first === "always";
  }
  if (IMPERATIVE_VERBS.has(first)) {
    if (ws2.length > 1 && AUX_VERBS.has(ws2[1].toLowerCase())) return false;
    return true;
  }
  return false;
};
var firstFiniteIndex = (ws2) => {
  for (let i = 0; i < ws2.length; i++) {
    const lw = ws2[i].toLowerCase();
    if (AUX_VERBS.has(lw) || UTILITY_VERBS.has(lw)) return i;
  }
  return -1;
};
var isAbstractSubject = (sub) => {
  if (!sub.length || sub.length > 5) return false;
  if (sub.some((w) => FIRST_SECOND_PERSON.has(w.toLowerCase()))) return false;
  if (sub.slice(1).some((w) => /[A-Z]/.test(w[0]))) return false;
  const head = sub[sub.length - 1].toLowerCase();
  return ABSTRACT_NOUNS.has(head) || ABSTRACT_SUFFIXES.some((suffix) => head.endsWith(suffix));
};
var countEnumeration = (s) => /\w+\s*,\s*[^,;.]{2,40},\s*[^,;.]{2,40}\s+(?:and|or)\s+/.test(s);
var isBalancedImpl = (s) => {
  const parts = s.split(/;|\s+while\s+|\s+whereas\s+/);
  if (parts.length < 2) return false;
  const heads = [];
  for (const part of parts) {
    const ws2 = cadenceWords(part);
    if (ws2.length < 4) return false;
    const idx = firstFiniteIndex(ws2);
    heads.push(idx >= 0 ? ws2[idx].toLowerCase() : null);
  }
  const real = heads.filter((h) => h !== null);
  return real.length >= 2 && new Set(real).size === 1;
};
var countOccurrences = (haystack, needle) => {
  let count = 0, index = haystack.indexOf(needle);
  while (index !== -1) {
    count += 1;
    index = haystack.indexOf(needle, index + 1);
  }
  return count;
};
var analyseCadenceSentence = (s) => {
  const ws2 = cadenceWords(s);
  const low = ` ${s.toLowerCase()} `;
  const sent = {
    text: s,
    role: "C",
    nWords: ws2.length,
    imperative: false,
    utility: false,
    messy: false,
    enumeration: countEnumeration(s),
    balanced: isBalancedImpl(s)
  };
  sent.messy = s.includes("(") || s.includes("\u2014") || s.includes("\u2013") || s.includes(" - ") || s.includes("...") || s.includes("\u2026") || s.includes("!") || ws2.some((w) => FIRST_SECOND_PERSON.has(w.toLowerCase())) || HEDGES.some((h) => low.includes(h)) || ws2.length > 0 && ["and", "but", "so", "or", "still", "anyway"].includes(ws2[0].toLowerCase());
  const idx = firstFiniteIndex(ws2);
  if (idx > 0) {
    sent.utility = UTILITY_VERBS.has(ws2[idx].toLowerCase()) && isAbstractSubject(ws2.slice(0, idx));
  }
  sent.imperative = startsImperative(ws2);
  if (s.replace(/\s+$/, "").endsWith("?")) sent.role = "Q";
  else if (sent.imperative) sent.role = "I";
  else if (CONSEQUENCE_OPENERS.some((o) => low.startsWith(` ${o}`))) sent.role = "S";
  else if ([" should ", " must ", " need to ", " ought to "].some((m) => low.includes(m))) sent.role = "R";
  else if (EXAMPLE_MARKERS.some((m) => low.includes(m))) sent.role = "E";
  else if (CONTRAST_MARKERS.some((m) => low.includes(m))) sent.role = "X";
  else if (sent.messy) sent.role = "A";
  else sent.role = "C";
  void countOccurrences;
  void CLAUSE_MARKERS;
  return sent;
};
var CADENCE_GATE = 4;
var cadenceFrom = (ss2) => {
  if (!ss2.length) return 0;
  const total = ss2.reduce((sum, s) => sum + s.nWords, 0);
  const roles = ss2.map((s) => s.role);
  let score = 0;
  if (ss2.length >= 3 && total <= 55) score += 3;
  if (["I", "R", "S"].includes(roles[roles.length - 1])) score += 2;
  if (ss2.length >= 3 && ["C", "X"].includes(roles[0]) && ["I", "R", "S"].includes(roles[roles.length - 1])) score += 2;
  if (ss2.some((s) => s.balanced)) score += 2;
  score += Math.min(2, ss2.filter((s) => s.utility).length);
  if (ss2.some((s) => s.enumeration)) score += 1;
  score -= 2 * ss2.filter((s) => s.messy).length;
  return Math.max(0, score);
};
var hasParagraphMarkup = (text2) => splitCadenceParagraphs(text2).length >= 3;
var paragraphCadenceRate = (text2) => {
  const paragraphs2 = splitCadenceParagraphs(text2).map((p) => splitCadenceSentences(p).map(analyseCadenceSentence)).filter((ss2) => ss2.length > 0);
  const sentences = paragraphs2.flat();
  const nWords = sentences.reduce((sum, s) => sum + s.nWords, 0);
  const nSents = sentences.length;
  if (nWords < 50 || nSents < 4) return void 0;
  if (!hasParagraphMarkup(text2)) return void 0;
  const perK = 1e3 / nWords;
  const multi = paragraphs2.filter((ss2) => ss2.length >= 2);
  const scores = multi.map((ss2) => cadenceFrom(ss2));
  return scores.filter((v) => v >= CADENCE_GATE).length * perK;
};
var phrase = (text2, aiPer1000, humanPer1000, aiDocs, humanDocs, ratio, confirmingRatio) => ({
  phrase: text2,
  aiPer1000,
  humanPer1000,
  aiDocs,
  humanDocs,
  ratio,
  confirmingRatio,
  smallSample: aiDocs < 10 || humanDocs < 10
});
var CURATED_PHRASE_TELLS = [
  phrase("robust", 60.26, 16.17, 242, 67, 3.7, 3.7),
  phrase("whether you're", 43.82, 8.69, 176, 36, 5, 3.1),
  phrase("seamless", 22.41, 5.79, 90, 24, 3.8, 3.6),
  phrase("seamlessly", 11.21, 5.07, 45, 21, 2.2, 2.2),
  phrase("streamline", 10.21, 4.34, 41, 18, 2.3, 4.4),
  phrase("underscores", 5.48, 2.41, 22, 10, 2.2, 3.5),
  phrase("in an era", 4.48, 1.21, 18, 5, 3.5, 3.3),
  phrase("at its core", 3.24, 1.45, 13, 6, 2.1, 2.8),
  phrase("game-changer", 4.23, 1.69, 17, 7, 2.4, 3.4),
  phrase("streamlining", 4.23, 1.93, 17, 8, 2.1, 4),
  phrase("is not just about", 3.49, 1.21, 14, 5, 2.7, 2.5),
  phrase("a testament to", 3.24, 1.21, 13, 5, 2.5, 13.9),
  phrase("elevate your", 2.99, 0.72, 12, 3, 3.7, 2.8),
  phrase("here's the thing", 2.24, 0.24, 9, 1, 6.5, 5.8),
  phrase("key takeaways", 1.99, 0.72, 8, 3, 2.5, 2.2),
  phrase("paving the way", 1.74, 0.24, 7, 1, 5.2, 5.8),
  phrase("plays a crucial role", 1.25, 0.48, 5, 2, 2.3, 2.6),
  phrase("tapestry", 0.75, 0, 3, 0, 7.2, 13.4),
  phrase("in today's digital", 0.75, 0, 3, 0, 7.2, 2.5),
  phrase("final thoughts", 0.75, 0.24, 3, 1, 2.4, 2.3),
  phrase("a beacon of", 0.25, 0, 1, 0, 3.1, 6.2)
];
var BULLET_RE = /^\s*([-*+•]|\d+[.)])\s+/;
var headingLike = (line) => {
  const s = line.trim();
  if (!s || s.length > 90) return false;
  if (BULLET_RE.test(s)) return false;
  if (/[.!?,;]$/.test(s)) return false;
  const words = s.split(/\s+/);
  if (words.length > 12) return false;
  return /[A-Za-z]/.test(s);
};
var sentenceCount = (paragraph) => paragraph.split(/(?<=[.!?])\s+/).filter((part) => part.trim().split(/\s+/).length >= 2).length;
var populationCv = (values) => {
  if (values.length < 2) return void 0;
  const mean = values.reduce((sum, value) => sum + value, 0) / values.length;
  if (mean === 0) return void 0;
  const variance = values.reduce((sum, value) => sum + (value - mean) ** 2, 0) / values.length;
  return Math.sqrt(variance) / mean;
};
var COHESION_STOPWORDS = new Set(`a about above after again against all am an and any are aren't as at be because been
before being below between both but by can cannot could couldn't did didn't do does doesn't doing don't
down during each few for from further had hadn't has hasn't have haven't having he her here hers herself
him himself his how i if in into is isn't it its itself let's me more most mustn't my myself no nor not
of off on once only or other ought our ours ourselves out over own same shan't she should shouldn't so
some such than that the their theirs them themselves then there these they this those through to too
under until up very was wasn't we were weren't what when where which while who whom why with won't would
wouldn't you your yours yourself yourselves`.split(/\s+/));
var COHESION_WORD_RE = /[A-Za-zÀ-ɏ']+/g;
var COHESION_SENT_SPLIT = /(?<!\bMr)(?<!\bMrs)(?<!\bDr)(?<!\bSt)(?<!\bvs)(?<!\betc)(?<!\be\.g)(?<!\bi\.e)(?<!\bFig)(?<!\bNo)(?<=[.!?])["'”’)\]]*\s+(?=["'“‘(\[]*[A-Z0-9])/;
var cohesionSentences = (draft) => {
  const out = [];
  for (const line of draft.split("\n")) {
    const trimmedLine = line.trim();
    if (!trimmedLine) continue;
    for (const sentence of trimmedLine.split(COHESION_SENT_SPLIT)) {
      const trimmed = sentence.trim();
      if (trimmed) out.push(trimmed);
    }
  }
  return out;
};
var adjacentCohesionRaw = (draft) => {
  const sentenceSets = cohesionSentences(draft).map((sentence) => {
    const words = sentence.match(COHESION_WORD_RE) ?? [];
    return new Set(words.map((word) => word.toLowerCase()).filter((word) => !COHESION_STOPWORDS.has(word)));
  });
  let total = 0, pairs = 0;
  for (let i = 0; i < sentenceSets.length - 1; i++) {
    const a = sentenceSets[i], b = sentenceSets[i + 1];
    if (!a.size || !b.size) continue;
    let shared = 0;
    for (const word of a) if (b.has(word)) shared += 1;
    total += shared / (a.size + b.size - shared);
    pairs += 1;
  }
  if (!pairs) return void 0;
  return { value: total / pairs, pairs };
};
var BOLD_ONLY_RE = /^\*\*(.+)\*\*:?\s*$/;
var stripMdInline = (s) => s.replace(/\*\*(.+?)\*\*/g, "$1").replace(/\*(.+?)\*/g, "$1").replace(/`(.+?)`/g, "$1").replace(/\[(.+?)\]\([^)]*\)/g, "$1").trim();
var classifyBlocks = (text2) => {
  const out = [];
  for (const raw of text2.split(/\n\s*\n/)) {
    let lines = raw.split("\n").filter((line) => line.trim());
    if (!lines.length) continue;
    for (; ; ) {
      const first = lines[0]?.trim() ?? "";
      const md = first.match(/^#{1,6}\s+(.*)$/);
      const bold = first.match(BOLD_ONLY_RE);
      if (md) {
        out.push({ kind: "heading", content: stripMdInline(md[1]) });
        lines = lines.slice(1);
        continue;
      }
      if (bold && headingLike(stripMdInline(bold[1]))) {
        out.push({ kind: "heading", content: stripMdInline(bold[1]) });
        lines = lines.slice(1);
        continue;
      }
      break;
    }
    if (!lines.length) continue;
    const bulletLines = lines.filter((line) => BULLET_RE.test(line)).length;
    const body = lines.join("\n");
    if (bulletLines >= 2 && bulletLines >= 0.5 * lines.length) {
      out.push({ kind: "bullets", content: body });
    } else if (lines.length === 1 && headingLike(stripMdInline(lines[0])) && !BULLET_RE.test(lines[0])) {
      out.push({ kind: "heading", content: stripMdInline(lines[0]) });
    } else {
      out.push({ kind: "para", content: lines.length === 1 ? stripMdInline(body) : body });
    }
  }
  return out;
};
var scaffoldFeaturesRaw = (text2) => {
  const blocks = classifyBlocks(text2);
  const sections = [];
  let current = [];
  for (const block of blocks) {
    if (block.kind === "heading") {
      sections.push(current);
      current = [];
    } else current.push(block);
  }
  sections.push(current);
  const nonEmpty = sections.length > 1 ? sections.slice(1).filter((section) => section.length) : [];
  const out = {};
  if (nonEmpty.length >= 3) {
    const body = nonEmpty.length >= 5 ? nonEmpty.slice(1, -1) : nonEmpty;
    const signatures = body.map((section) => ({
      paragraphs: section.filter((block) => block.kind === "para").length,
      bullets: section.filter((block) => block.kind === "bullets").length
    }));
    const counts = /* @__PURE__ */ new Map();
    for (const signature of signatures) {
      const key = `${signature.paragraphs}|${signature.bullets}`;
      counts.set(key, (counts.get(key) ?? 0) + 1);
    }
    const modeCount = [...counts.values()].sort((a, b) => b - a)[0];
    out.bodyModeShare = modeCount / signatures.length;
  }
  const paras = blocks.filter((block) => block.kind === "para");
  const spp = paras.map((block) => sentenceCount(block.content)).filter((count) => count > 0);
  if (spp.length >= 5) out.sppCv = populationCv(spp);
  return out;
};
var wordCountWhitespace = (s) => {
  const trimmed = s.trim();
  return trimmed ? trimmed.split(/\s+/).length : 0;
};
var median = (values) => {
  const sorted = [...values].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
};
var populationVariance = (values) => {
  const mean = values.reduce((sum, value) => sum + value, 0) / values.length;
  return values.reduce((sum, value) => sum + (value - mean) ** 2, 0) / values.length;
};
var wordMetrics = (text2) => {
  const blocks = classifyBlocks(text2);
  const sections = [];
  let current = [];
  for (const block of blocks) {
    if (block.kind === "heading") {
      sections.push(current);
      current = [];
    } else current.push(block);
  }
  sections.push(current);
  const nonempty = sections.length > 1 ? sections.slice(1).filter((section) => section.length) : [];
  const out = {};
  if (nonempty.length >= 4) out.ppsVar = populationVariance(nonempty.map((section) => section.length));
  const wps = nonempty.map((section) => section.reduce((sum, block) => sum + wordCountWhitespace(block.content), 0));
  if (wps.length >= 3) {
    out.wpsCv = populationCv(wps);
    const body = wps.length >= 5 ? wps.slice(1, -1) : wps;
    if (body.length >= 4 || wps.length >= 4 && body.length >= 2) {
      const med = median(body);
      if (med > 0 && wps.length >= 4) {
        out.secWithin15 = body.filter((w) => Math.abs(w - med) <= 0.15 * med).length / body.length;
      }
    }
  }
  const paras = blocks.filter((block) => block.kind === "para");
  const wpp = paras.map((block) => wordCountWhitespace(block.content)).filter((n) => n > 0);
  if (wpp.length >= 5) out.wppCv = populationCv(wpp);
  return out;
};
var hasStructure = (text2) => {
  const blocks = classifyBlocks(text2);
  const nHead = blocks.filter((block) => block.kind === "heading").length;
  const nPara = blocks.filter((block) => block.kind === "para").length;
  return nHead >= 1 || nPara >= 3 ? 1 : 0;
};
var FEATURE_NORM = {
  mean: [
    0.4083594134418581,
    0.3858695169470864,
    3.972885878050851,
    0.47256837589441686,
    0.3761888885414563,
    0.04671324010389126,
    0.43453264073828046,
    0.4892945080826464
  ],
  sd: [
    0.21248020231631692,
    0.26923918696432436,
    41.53045781679202,
    0.20330337201399315,
    0.16477298430411097,
    0.04122616971543623,
    1.3061158641315476,
    0.49988537930490373
  ],
  clip: 4
};
var rawFeatures = (text2) => {
  const wm = wordMetrics(text2);
  const scaffold = scaffoldFeaturesRaw(text2);
  const cohesion = adjacentCohesionRaw(text2);
  const cadenceRate = paragraphCadenceRate(text2);
  return [
    wm.wppCv,
    wm.secWithin15,
    wm.ppsVar,
    scaffold.bodyModeShare,
    scaffold.sppCv,
    cohesion?.value,
    cadenceRate,
    hasStructure(text2)
  ];
};
var normaliseFeatures = (raw) => raw.map((value, i) => {
  if (value === void 0 || !Number.isFinite(value)) return 0;
  const z2 = (value - FEATURE_NORM.mean[i]) / FEATURE_NORM.sd[i];
  const clipped2 = Math.min(FEATURE_NORM.clip, Math.max(-FEATURE_NORM.clip, z2));
  return Number.isFinite(clipped2) ? clipped2 : 0;
});
var featuresV1 = (text2) => normaliseFeatures(rawFeatures(text2));
var MODEL_MAX_TOKENS = 512;
var SPECIAL_TOKENS = 2;
var SEGMENT_TOKEN_BUDGET = MODEL_MAX_TOKENS - SPECIAL_TOKENS;
var WORD = /\S+/gu;
var atomsOf = (text2, countTokens) => {
  const words = [];
  WORD.lastIndex = 0;
  for (let match = WORD.exec(text2); match; match = WORD.exec(text2)) words.push({ start: match.index, end: match.index + match[0].length });
  const counts = countTokens(words.map((word) => text2.slice(word.start, word.end)));
  const spans = [];
  const tokens2 = [];
  const isWordStart = [];
  const forced = [];
  const oversized = [];
  for (let index = 0; index < words.length; index++) {
    const word = words[index];
    if (counts[index] <= SEGMENT_TOKEN_BUDGET) {
      spans.push(word);
      tokens2.push(counts[index]);
      isWordStart.push(true);
      forced.push(false);
      continue;
    }
    let at = word.start, first = true;
    while (at < word.end) {
      const stop = Math.min(at + SEGMENT_TOKEN_BUDGET, word.end);
      spans.push({ start: at, end: stop });
      oversized.push(spans.length - 1);
      tokens2.push(0);
      isWordStart.push(first);
      forced.push(true);
      first = false;
      at = stop;
    }
  }
  if (oversized.length) {
    const measured = countTokens(oversized.map((index) => text2.slice(spans[index].start, spans[index].end)));
    oversized.forEach((index, position) => {
      tokens2[index] = measured[position];
    });
  }
  return { spans, tokens: tokens2, isWordStart, forced };
};
var cutsFor = (cum, total, parts, forcedCuts, atomCount) => {
  const cuts = [];
  let previous = 0;
  for (let j = 1; j < parts; j++) {
    const target = j * total;
    let at = previous + 1;
    while (at < atomCount && cum[at] * parts < target) at++;
    const ceiling = atomCount - (parts - j);
    if (at > ceiling) at = ceiling;
    cuts.push(at);
    previous = at;
  }
  const merged = [.../* @__PURE__ */ new Set([...cuts, ...forcedCuts])].sort((a, b) => a - b);
  return merged.filter((cut) => cut > 0 && cut < atomCount);
};
var segmentText = (text2, countTokens) => {
  const { spans, tokens: tokens2, isWordStart, forced } = atomsOf(text2, countTokens);
  const atomCount = spans.length;
  const cum = [0];
  for (const count of tokens2) cum.push(cum[cum.length - 1] + count);
  const total = cum[atomCount];
  const anyForced = forced.some(Boolean);
  if (total + SPECIAL_TOKENS <= MODEL_MAX_TOKENS && !anyForced) {
    const words = isWordStart.filter(Boolean).length;
    return [{ index: 0, start: 0, end: text2.length, words, text: text2, tokens: total + SPECIAL_TOKENS }];
  }
  const forcedCuts = [];
  for (let index = 0; index < atomCount; index++) if (forced[index]) {
    forcedCuts.push(index);
    forcedCuts.push(index + 1);
  }
  let parts = Math.max(1, Math.ceil(total / SEGMENT_TOKEN_BUDGET));
  let cuts = [], starts = [], ends = [], pieces = [], measured = [];
  for (; ; ) {
    cuts = cutsFor(cum, total, parts, forcedCuts, atomCount);
    starts = [0, ...cuts.map((cut) => spans[cut - 1].end)];
    ends = [...cuts.map((cut) => spans[cut - 1].end), text2.length];
    pieces = starts.map((start, index) => text2.slice(start, ends[index]));
    measured = countTokens(pieces).map((count) => count + SPECIAL_TOKENS);
    if (measured.every((count) => count <= MODEL_MAX_TOKENS) || parts >= atomCount) break;
    parts++;
  }
  const edges = [...cuts, atomCount];
  const segments = [];
  let firstAtom = 0;
  for (let index = 0; index < edges.length; index++) {
    let words = 0;
    for (let atom = firstAtom; atom < edges[index]; atom++) if (isWordStart[atom]) words++;
    segments.push({ index, start: starts[index], end: ends[index], words, text: pieces[index], tokens: measured[index] });
    firstAtom = edges[index];
  }
  return segments;
};
var scoringOrder = (count) => {
  if (count <= 1) return count === 1 ? [0] : [];
  const first = [Math.floor((count - 1) / 2), count - 1, 0];
  const order = [];
  const seen = /* @__PURE__ */ new Set();
  for (const index of first) if (index >= 0 && index < count && !seen.has(index)) {
    seen.add(index);
    order.push(index);
  }
  for (let index = 0; index < count; index++) if (!seen.has(index)) {
    seen.add(index);
    order.push(index);
  }
  return order;
};
var MAX_WORD_CHARS = 100;
var PUNCT_ASCII = (code) => code >= 33 && code <= 47 || code >= 58 && code <= 64 || code >= 91 && code <= 96 || code >= 123 && code <= 126;
var PUNCT_UNICODE = new RegExp("\\p{P}", "u");
var CONTROL = /[\p{Cc}\p{Cf}\p{Co}\p{Cn}]/u;
var WHITESPACE = new RegExp("\\p{White_Space}", "u");
var isPunctuation = (ch) => PUNCT_ASCII(ch.codePointAt(0)) || PUNCT_UNICODE.test(ch);
var isControl = (ch) => !WHITESPACE.test(ch) && CONTROL.test(ch);
var isCjk = (code) => code >= 19968 && code <= 40959 || code >= 13312 && code <= 19903 || code >= 131072 && code <= 173791 || code >= 173824 && code <= 177983 || code >= 177984 && code <= 178207 || code >= 178208 && code <= 183983 || code >= 63744 && code <= 64255 || code >= 194560 && code <= 195103;
var WordPieceTokenizer = class {
  vocab;
  clsId;
  sepId;
  unkId;
  constructor(vocabText) {
    this.vocab = /* @__PURE__ */ new Map();
    const lines = vocabText.split("\n");
    let index = 0;
    for (const line of lines) {
      const token = line.replace(/\r$/, "");
      if (token === "" && index === lines.length - 1) break;
      this.vocab.set(token, index);
      index++;
    }
    this.clsId = this.vocab.get("[CLS]");
    this.sepId = this.vocab.get("[SEP]");
    this.unkId = this.vocab.get("[UNK]");
  }
  cleanText(text2) {
    let out = "";
    for (const ch of text2) {
      const code = ch.codePointAt(0);
      if (code === 0 || code === 65533 || isControl(ch)) continue;
      out += WHITESPACE.test(ch) ? " " : ch;
    }
    return out;
  }
  spaceCjk(text2) {
    let out = "";
    for (const ch of text2) out += isCjk(ch.codePointAt(0)) ? ` ${ch} ` : ch;
    return out;
  }
  basicTokenize(text2) {
    const words = this.spaceCjk(this.cleanText(text2)).split(/ +/u).filter(Boolean);
    const tokens2 = [];
    for (let word of words) {
      word = [...word].map((character) => character.toLowerCase()).join("").normalize("NFD").replace(new RegExp("\\p{Mn}", "gu"), "");
      let current = "";
      for (const ch of word) {
        if (isPunctuation(ch)) {
          if (current) {
            tokens2.push(current);
            current = "";
          }
          tokens2.push(ch);
        } else current += ch;
      }
      if (current) tokens2.push(current);
    }
    return tokens2;
  }
  wordPiece(word) {
    if ([...word].length > MAX_WORD_CHARS) return [this.unkId];
    const ids = [];
    let start = 0;
    while (start < word.length) {
      let end = word.length, id;
      while (start < end) {
        const piece = (start > 0 ? "##" : "") + word.slice(start, end);
        const found = this.vocab.get(piece);
        if (found !== void 0) {
          id = found;
          break;
        }
        end--;
      }
      if (id === void 0) return [this.unkId];
      ids.push(id);
      start = end;
    }
    return ids;
  }
  /**
   * WordPiece token counts for each string, with no [CLS]/[SEP] and no
   * truncation. This is what segments.ts bounds a segment by: the word-count
   * proxy it used before was measured to leave 5.78% of segments over the
   * 512-token window on the fresh long-form corpus, silently dropping their
   * ends. Counting is the same code path encode() uses, so the two can never
   * disagree about how long a passage is.
   */
  countTokens(strings) {
    return strings.map((text2) => {
      let total = 0;
      for (const token of this.basicTokenize(text2)) total += this.wordPiece(token).length;
      return total;
    });
  }
  /** [CLS] + pieces + [SEP], right-truncated so the total length is at most maxLen. */
  encode(text2, maxLen) {
    const ids = [];
    for (const token of this.basicTokenize(text2)) {
      for (const id of this.wordPiece(token)) {
        ids.push(id);
        if (ids.length >= maxLen - 2) break;
      }
      if (ids.length >= maxLen - 2) break;
    }
    const truncated = ids.length >= maxLen - 2;
    return { inputIds: [this.clsId, ...ids, this.sepId], truncated };
  }
};
var probabilityFromMargin = (margin) => 1 / (1 + Math.exp(-margin / CYCLE5_TEMPERATURE));
var bandFor = (score) => CYCLE5_BANDS.find((band) => score >= band.min).id;
async function defaultSessionFactory(assets, signal) {
  if (signal?.aborted) throw new Cycle5BrowserError("cancelled", "The on-device model load was cancelled.");
  const ort = await Promise.resolve().then(() => (init_ort_wasm_bundle_min(), ort_wasm_bundle_min_exports));
  const wasmUrl = URL.createObjectURL(new Blob([assets.wasm.slice().buffer], { type: "application/wasm" }));
  try {
    ort.env.wasm.numThreads = 1;
    ort.env.wasm.proxy = false;
    ort.env.wasm.wasmPaths = { wasm: wasmUrl };
    const session = await ort.InferenceSession.create(assets.model.slice(), { executionProviders: ["wasm"], graphOptimizationLevel: "basic" });
    if (signal?.aborted) {
      await session.release();
      throw new Cycle5BrowserError("cancelled", "The on-device model load was cancelled.");
    }
    return {
      async run(feeds, shape) {
        const output = await session.run({
          input_ids: new ort.Tensor("int64", feeds.input_ids, shape),
          attention_mask: new ort.Tensor("int64", feeds.attention_mask, shape),
          feats: new ort.Tensor("float32", feeds.feats, [1, 8])
        });
        const logits = await output.logits?.getData();
        if (!logits || logits.length !== 2) throw new Cycle5BrowserError("engine_error", "The Cycle-5 model returned an invalid logits tensor.");
        return { logits: Float32Array.from(logits) };
      },
      release: () => session.release()
    };
  } finally {
    URL.revokeObjectURL(wasmUrl);
  }
}
var Cycle5BrowserRuntime = class {
  modelBaseUrl;
  maxCharacters;
  wasmUrl;
  fetcher;
  cacheStorage;
  sessionFactory;
  session;
  tokenizer;
  preparation;
  snapshot = { state: "not_ready", message: "The on-device model has not been prepared.", cacheVersion: CYCLE5_CACHE_NAME };
  constructor(config) {
    this.modelBaseUrl = normaliseAllowedModelBase(config.modelBaseUrl, config.allowedModelBaseUrls);
    this.wasmUrl = config.wasmUrl;
    this.maxCharacters = config.maxCharacters ?? CYCLE5_DEFAULT_MAX_CHARACTERS;
    if (!Number.isInteger(this.maxCharacters) || this.maxCharacters < 1 || this.maxCharacters > CYCLE5_MAX_CHARACTERS) {
      throw new RangeError(`maxCharacters must be an integer from 1 to ${CYCLE5_MAX_CHARACTERS}.`);
    }
    this.fetcher = config.fetch ?? globalThis.fetch.bind(globalThis);
    this.cacheStorage = config.cacheStorage;
    this.sessionFactory = config.createSession ?? defaultSessionFactory;
  }
  state() {
    return Object.freeze({ ...this.snapshot });
  }
  setState(state, message) {
    this.snapshot = { state, message, cacheVersion: CYCLE5_CACHE_NAME };
  }
  async prepareFromCache(signal) {
    if (this.session) return true;
    if (this.preparation) {
      await this.preparation;
      return Boolean(this.session);
    }
    this.setState("checking_cache", "Checking for a previously consented Cycle-5 model.");
    let assets;
    try {
      assets = await loadVerifiedCachedAssets(this.modelBaseUrl, this.wasmUrl, this.cacheStorage, signal);
    } catch (cause) {
      if (cause instanceof Cycle5BrowserError && cause.code === "cancelled") this.setState("not_ready", cause.message);
      throw cause;
    }
    if (!assets) {
      this.setState("not_ready", "The Cycle-5 model is not cached. An explicit download choice is required.");
      return false;
    }
    this.preparation = this.loadAssets(assets, signal);
    try {
      await this.preparation;
      return true;
    } finally {
      this.preparation = void 0;
    }
  }
  async prepareWithConsent(options) {
    if (!options.consent) throw new Cycle5BrowserError("consent_required", "Explicit consent is required before the model download starts.");
    if (this.session) return;
    if (this.preparation) return this.preparation;
    this.setState("downloading", this.wasmUrl ? "Downloading the pinned model and vocabulary after explicit consent, then verifying the packaged browser runtime." : "Downloading the pinned model, vocabulary and browser runtime after explicit consent.");
    this.preparation = (async () => {
      try {
        const cached = await loadVerifiedCachedAssets(this.modelBaseUrl, this.wasmUrl, this.cacheStorage, options.signal);
        const assets = cached ?? await downloadVerifiedAssets({
          baseUrl: this.modelBaseUrl,
          wasmUrl: this.wasmUrl,
          fetcher: this.fetcher,
          cacheStorage: this.cacheStorage,
          signal: options.signal,
          onProgress: options.onProgress
        });
        await this.loadAssets(assets, options.signal);
      } catch (cause) {
        const error = cause instanceof Cycle5BrowserError ? cause : new Cycle5BrowserError("engine_error", "The on-device model could not be prepared.", { cause });
        const state = error.code === "offline" ? "offline" : error.code === "integrity_error" ? "integrity_error" : error.code === "cancelled" ? "not_ready" : "error";
        this.setState(state, error.message);
        throw error;
      }
    })();
    try {
      await this.preparation;
    } finally {
      this.preparation = void 0;
    }
  }
  async loadAssets(assets, signal) {
    if (signal?.aborted) throw new Cycle5BrowserError("cancelled", "The on-device model load was cancelled.");
    this.setState("loading", "Loading the verified Cycle-5 model on this device.");
    const tokenizer = new WordPieceTokenizer(new TextDecoder().decode(assets.vocab));
    if (signal?.aborted) throw new Cycle5BrowserError("cancelled", "The on-device model load was cancelled.");
    const session = await this.sessionFactory({ model: assets.model, wasm: assets.wasm }, signal);
    if (signal?.aborted) {
      await session.release?.();
      throw new Cycle5BrowserError("cancelled", "The on-device model load was cancelled.");
    }
    this.tokenizer = tokenizer;
    this.session = session;
    this.setState("ready", "The verified Cycle-5 model is ready on this device.");
  }
  async score(text2, options = {}) {
    if (!this.session || !this.tokenizer) return { status: "not_scored", code: "not_ready", reason: this.snapshot.message };
    if (text2.length > this.maxCharacters) return { status: "not_scored", code: "too_long", reason: `The draft is ${text2.length} characters; this route refuses more than ${this.maxCharacters} rather than truncating it.` };
    if (options.signal?.aborted) return { status: "not_scored", code: "cancelled", reason: "The on-device model run was cancelled." };
    const pieces = segmentText(text2, (values) => this.tokenizer.countTokens(values));
    const sections = [];
    let done = 0;
    for (const position of scoringOrder(pieces.length)) {
      if (options.signal?.aborted) return { status: "not_scored", code: "cancelled", reason: "The on-device model run was cancelled." };
      const piece = pieces[position];
      const encoded = this.tokenizer.encode(piece.text, CYCLE5_MAX_LEN);
      const scoredTokens = encoded.inputIds.length - 2;
      if (scoredTokens < CYCLE5_MIN_SCORED_TOKENS) continue;
      if (encoded.truncated || piece.tokens > CYCLE5_MAX_LEN) throw new Cycle5BrowserError("integrity_error", "segments-v3 failed to fit a complete section in the model window.");
      const inputIds = new BigInt64Array(encoded.inputIds.map((id) => BigInt(id)));
      const output = await this.session.run({
        input_ids: inputIds,
        attention_mask: new BigInt64Array(inputIds.length).fill(1n),
        feats: Float32Array.from(featuresV1(piece.text))
      }, [1, inputIds.length]);
      const rawMargin = output.logits[1] - output.logits[0];
      const rawScore = probabilityFromMargin(rawMargin);
      sections.push({
        index: piece.index,
        startUtf16: piece.start,
        endUtf16: piece.end,
        wordCount: piece.words,
        tokenCount: scoredTokens,
        rawScore,
        rawMargin,
        bandId: bandFor(rawScore),
        passage: piece.text
      });
      done += 1;
      options.onSection?.(done, pieces.length);
    }
    if (!sections.length) return { status: "not_scored", code: "too_short", reason: `At least ${CYCLE5_MIN_SCORED_TOKENS} scored tokens are required for an AI-pattern reading.` };
    sections.sort((a, b) => a.index - b.index);
    sections.forEach((section, index) => {
      section.index = index;
    });
    const strongest = sections.reduce((best, section) => section.rawScore > best.rawScore ? section : best, sections[0]);
    const margins = sections.map((section) => section.rawMargin).sort((a, b) => b - a);
    const primary = margins[0] >= CYCLE5_PRIMARY_MARGIN;
    const secondary = margins.length > 1 && margins[1] + CYCLE5_SECONDARY_GAP >= CYCLE5_PRIMARY_MARGIN;
    return {
      status: "scored",
      provider: "onnxruntime-web-wasm",
      modelVersion: "tier3-cycle5-v1",
      rawScore: strongest.rawScore,
      rawMargin: strongest.rawMargin,
      flagged: primary || secondary,
      flagReason: primary ? "primary" : secondary ? "secondary" : null,
      sections
    };
  }
  async clearCache() {
    return clearCycle5Cache(this.cacheStorage);
  }
  async dispose() {
    await this.session?.release?.();
    this.session = void 0;
    this.tokenizer = void 0;
    this.setState("not_ready", "The on-device session was released. Cached verified assets were not deleted.");
  }
};
function createCycle5BrowserRuntime(config) {
  return new Cycle5BrowserRuntime(config);
}
var K = new Uint32Array([
  1116352408,
  1899447441,
  3049323471,
  3921009573,
  961987163,
  1508970993,
  2453635748,
  2870763221,
  3624381080,
  310598401,
  607225278,
  1426881987,
  1925078388,
  2162078206,
  2614888103,
  3248222580,
  3835390401,
  4022224774,
  264347078,
  604807628,
  770255983,
  1249150122,
  1555081692,
  1996064986,
  2554220882,
  2821834349,
  2952996808,
  3210313671,
  3336571891,
  3584528711,
  113926993,
  338241895,
  666307205,
  773529912,
  1294757372,
  1396182291,
  1695183700,
  1986661051,
  2177026350,
  2456956037,
  2730485921,
  2820302411,
  3259730800,
  3345764771,
  3516065817,
  3600352804,
  4094571909,
  275423344,
  430227734,
  506948616,
  659060556,
  883997877,
  958139571,
  1322822218,
  1537002063,
  1747873779,
  1955562222,
  2024104815,
  2227730452,
  2361852424,
  2428436474,
  2756734187,
  3204031479,
  3329325298
]);
var rotr = (x, n) => x >>> n | x << 32 - n;
function utf8Bytes(value) {
  return new TextEncoder().encode(value);
}
function sha256Hex(value) {
  const source = utf8Bytes(value);
  const bitLength = source.length * 8;
  const paddedLength = Math.ceil((source.length + 9) / 64) * 64;
  const bytes = new Uint8Array(paddedLength);
  bytes.set(source);
  bytes[source.length] = 128;
  const view = new DataView(bytes.buffer);
  view.setUint32(paddedLength - 4, bitLength >>> 0, false);
  view.setUint32(paddedLength - 8, Math.floor(bitLength / 4294967296), false);
  const h = new Uint32Array([1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924, 528734635, 1541459225]);
  const w = new Uint32Array(64);
  for (let offset = 0; offset < paddedLength; offset += 64) {
    for (let i = 0; i < 16; i++) w[i] = view.getUint32(offset + i * 4, false);
    for (let i = 16; i < 64; i++) {
      const a2 = w[i - 15], b2 = w[i - 2];
      w[i] = (rotr(a2, 7) ^ rotr(a2, 18) ^ a2 >>> 3) + w[i - 16] + (rotr(b2, 17) ^ rotr(b2, 19) ^ b2 >>> 10) + w[i - 7] >>> 0;
    }
    let [a, b, c, d, e, f, g, hh] = h;
    for (let i = 0; i < 64; i++) {
      const s1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25);
      const ch = e & f ^ ~e & g;
      const t1 = hh + s1 + ch + K[i] + w[i] >>> 0;
      const s0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22);
      const maj = a & b ^ a & c ^ b & c;
      const t2 = s0 + maj >>> 0;
      hh = g;
      g = f;
      f = e;
      e = d + t1 >>> 0;
      d = c;
      c = b;
      b = a;
      a = t1 + t2 >>> 0;
    }
    h[0] = h[0] + a >>> 0;
    h[1] = h[1] + b >>> 0;
    h[2] = h[2] + c >>> 0;
    h[3] = h[3] + d >>> 0;
    h[4] = h[4] + e >>> 0;
    h[5] = h[5] + f >>> 0;
    h[6] = h[6] + g >>> 0;
    h[7] = h[7] + hh >>> 0;
  }
  return Array.from(h, (n) => n.toString(16).padStart(8, "0")).join("");
}
var prefixedSha256 = (value) => `sha256:${sha256Hex(value)}`;
var MSG_INVISIBLE = (what) => `An invisible ${what} is present.`;
var MSG_BIDI = "A bidirectional formatting control is present.";
var BIDI_LIMIT = "Bidirectional controls are required for correct display of mixed right-to-left and left-to-right text.";
var CARRIER_RULES = [
  // Soft hyphen and combining grapheme joiner
  { from: 173, name: "SOFT HYPHEN", severity: "low", fix: "remove", message: "A discretionary soft hyphen is present." },
  { from: 847, name: "COMBINING GRAPHEME JOINER", severity: "medium", fix: "remove", message: MSG_INVISIBLE("combining grapheme joiner"), limitation: "The combining grapheme joiner has rare legitimate uses in collation and diacritic ordering." },
  // Script-specific format characters
  { from: 1564, name: "ARABIC LETTER MARK", severity: "medium", fix: "review", message: MSG_BIDI, limitation: BIDI_LIMIT },
  { from: 1807, name: "SYRIAC ABBREVIATION MARK", severity: "medium", fix: "review", message: "A Syriac abbreviation mark format character is present.", limitation: "This character is legitimate inside Syriac-script text." },
  { from: 2192, to: 2193, name: (cp) => cp === 2192 ? "ARABIC POUND MARK ABOVE" : "ARABIC PIASTRE MARK ABOVE", severity: "medium", fix: "review", message: "An Arabic prepended format mark is present.", limitation: "This character is legitimate inside Arabic-script text." },
  { from: 2274, name: "ARABIC DISPUTED END OF AYAH", severity: "medium", fix: "review", message: "An Arabic prepended format mark is present.", limitation: "This character is legitimate inside Arabic-script text." },
  { from: 6155, to: 6157, name: (cp) => `MONGOLIAN FREE VARIATION SELECTOR-${cp - 6154}`, severity: "medium", fix: "remove", message: MSG_INVISIBLE("Mongolian free variation selector"), context: "variation", limitation: "Free variation selectors are legitimate inside Mongolian-script text." },
  { from: 6158, name: "MONGOLIAN VOWEL SEPARATOR", severity: "medium", fix: "remove", message: MSG_INVISIBLE("Mongolian vowel separator"), limitation: "This character is legitimate inside Mongolian-script text." },
  { from: 6159, name: "MONGOLIAN FREE VARIATION SELECTOR-4", severity: "medium", fix: "remove", message: MSG_INVISIBLE("Mongolian free variation selector"), context: "variation", limitation: "Free variation selectors are legitimate inside Mongolian-script text." },
  // Zero-width and joining controls
  { from: 8203, name: "ZERO WIDTH SPACE", severity: "medium", fix: "remove", message: MSG_INVISIBLE("zero-width space") },
  { from: 8204, name: "ZERO WIDTH NON-JOINER", severity: "medium", fix: "remove", message: MSG_INVISIBLE("zero-width non-joiner"), context: "joiner", limitation: "The zero-width non-joiner is standard orthography in Persian and several Indic languages." },
  { from: 8205, name: "ZERO WIDTH JOINER", severity: "medium", fix: "remove", message: MSG_INVISIBLE("zero-width joiner"), context: "joiner", limitation: "The zero-width joiner is standard in emoji sequences and several complex scripts." },
  // Bidirectional controls
  { from: 8206, name: "LEFT-TO-RIGHT MARK", severity: "medium", fix: "review", message: MSG_BIDI, limitation: BIDI_LIMIT },
  { from: 8207, name: "RIGHT-TO-LEFT MARK", severity: "medium", fix: "review", message: MSG_BIDI, limitation: BIDI_LIMIT },
  { from: 8234, to: 8238, name: (cp) => ["LEFT-TO-RIGHT EMBEDDING", "RIGHT-TO-LEFT EMBEDDING", "POP DIRECTIONAL FORMATTING", "LEFT-TO-RIGHT OVERRIDE", "RIGHT-TO-LEFT OVERRIDE"][cp - 8234], severity: "medium", fix: "review", message: MSG_BIDI, limitation: BIDI_LIMIT },
  { from: 8294, to: 8297, name: (cp) => ["LEFT-TO-RIGHT ISOLATE", "RIGHT-TO-LEFT ISOLATE", "FIRST STRONG ISOLATE", "POP DIRECTIONAL ISOLATE"][cp - 8294], severity: "medium", fix: "review", message: MSG_BIDI, limitation: BIDI_LIMIT },
  // Word joiner, invisible operators and deprecated format characters
  { from: 8288, name: "WORD JOINER", severity: "medium", fix: "remove", message: MSG_INVISIBLE("word joiner") },
  { from: 8289, to: 8292, name: (cp) => ["FUNCTION APPLICATION", "INVISIBLE TIMES", "INVISIBLE SEPARATOR", "INVISIBLE PLUS"][cp - 8289], severity: "medium", fix: "remove", message: MSG_INVISIBLE("mathematical operator character"), limitation: "Invisible operators are legitimate inside machine-generated mathematical notation." },
  { from: 8298, to: 8303, name: (cp) => ["INHIBIT SYMMETRIC SWAPPING", "ACTIVATE SYMMETRIC SWAPPING", "INHIBIT ARABIC FORM SHAPING", "ACTIVATE ARABIC FORM SHAPING", "NATIONAL DIGIT SHAPES", "NOMINAL DIGIT SHAPES"][cp - 8298], severity: "medium", fix: "remove", message: "A deprecated invisible format character is present.", limitation: "These characters are deprecated by Unicode and have no place in modern interchange text." },
  // BOM, interlinear annotation, replacement
  { from: 65279, name: "BYTE ORDER MARK", severity: "low", fix: "remove", message: "A byte-order mark is present." },
  { from: 65529, to: 65531, name: (cp) => ["INTERLINEAR ANNOTATION ANCHOR", "INTERLINEAR ANNOTATION SEPARATOR", "INTERLINEAR ANNOTATION TERMINATOR"][cp - 65529], severity: "medium", fix: "review", message: "An interlinear annotation control is present.", limitation: "Interlinear annotation controls are legitimate in Japanese ruby markup pipelines." },
  { from: 65533, name: "REPLACEMENT CHARACTER", severity: "high", fix: "review", message: "A replacement character may indicate damaged text." },
  // Supplementary-plane format characters
  { from: 69821, name: "KAITHI NUMBER SIGN", severity: "medium", fix: "review", message: "A Kaithi number-sign format character is present.", limitation: "This character is legitimate inside Kaithi-script text." },
  { from: 69837, name: "KAITHI NUMBER SIGN ABOVE", severity: "medium", fix: "review", message: "A Kaithi number-sign format character is present.", limitation: "This character is legitimate inside Kaithi-script text." },
  // Tag characters: the classic covert payload carrier
  { from: 917505, name: "LANGUAGE TAG", severity: "high", fix: "remove", message: "A deprecated invisible language tag is present." },
  { from: 917536, to: 917631, name: (cp) => cp === 917631 ? "CANCEL TAG" : `TAG ${String.fromCodePoint(cp - 917504) === " " ? "SPACE" : `CHARACTER '${String.fromCodePoint(cp - 917504)}'`}`, severity: "high", fix: "remove", message: "An invisible tag character is present; tag runs are a known covert payload carrier.", limitation: "Tag characters have no legitimate use in ordinary interchange text outside emoji flag sequences." },
  // Variation selectors
  { from: 65024, to: 65039, name: (cp) => `VARIATION SELECTOR-${cp - 65024 + 1}`, severity: "medium", fix: "remove", message: MSG_INVISIBLE("variation selector"), context: "variation", limitation: "Variation selectors are legitimate after emoji-capable and CJK base characters." },
  { from: 917760, to: 917999, name: (cp) => `VARIATION SELECTOR-${cp - 917760 + 17}`, severity: "medium", fix: "review", message: MSG_INVISIBLE("supplementary variation selector"), context: "variation_sup", limitation: "Supplementary variation selectors are legitimate after CJK ideographs to select registered glyph variants." },
  // Space separators beyond U+0020
  { from: 160, name: "NO-BREAK SPACE", severity: "note", fix: "space", message: "A non-breaking space is present.", limitation: "Non-breaking spaces are standard French and general typographic practice." },
  { from: 5760, name: "OGHAM SPACE MARK", severity: "low", fix: "space", message: "An unusual space character is present.", limitation: "This character is legitimate inside Ogham-script text." },
  { from: 8192, to: 8200, name: (cp) => ["EN QUAD", "EM QUAD", "EN SPACE", "EM SPACE", "THREE-PER-EM SPACE", "FOUR-PER-EM SPACE", "SIX-PER-EM SPACE", "FIGURE SPACE", "PUNCTUATION SPACE"][cp - 8192], severity: "low", fix: "space", message: "A typographic space that substitutes for an ordinary space is present.", limitation: "Fixed-width spaces are legitimate in carefully typeset material." },
  { from: 8201, name: "THIN SPACE", severity: "note", fix: "space", message: "A thin space is present.", limitation: "Thin spaces are standard French and general typographic practice." },
  { from: 8202, name: "HAIR SPACE", severity: "low", fix: "space", message: "A hair space that substitutes for an ordinary space is present.", limitation: "Hair spaces are legitimate in carefully typeset material." },
  { from: 8239, name: "NARROW NO-BREAK SPACE", severity: "note", fix: "space", message: "A narrow no-break space is present.", limitation: "Narrow no-break spaces are standard French punctuation spacing and appear in Mongolian text." },
  { from: 8287, name: "MEDIUM MATHEMATICAL SPACE", severity: "note", fix: "space", message: "A medium mathematical space is present.", limitation: "This space is legitimate inside typeset mathematical notation." },
  { from: 12288, name: "IDEOGRAPHIC SPACE", severity: "note", fix: "space", message: "An ideographic space is present.", limitation: "Ideographic spaces are standard in Chinese and Japanese text." },
  // Line and paragraph separators
  { from: 8232, name: "LINE SEPARATOR", severity: "low", fix: "review", message: "A Unicode line separator is present instead of a conventional line break." },
  { from: 8233, name: "PARAGRAPH SEPARATOR", severity: "low", fix: "review", message: "A Unicode paragraph separator is present instead of a conventional line break." }
];
var TABLE = /* @__PURE__ */ new Map();
for (const rule of CARRIER_RULES) {
  for (let cp = rule.from; cp <= (rule.to ?? rule.from); cp++) {
    TABLE.set(cp, { name: typeof rule.name === "function" ? rule.name(cp) : rule.name, severity: rule.severity, fix: rule.fix, message: rule.message, context: rule.context, limitation: rule.limitation });
  }
}
var NAME_STOPLIST = new Set("The A An This That These Those It He She They We You I In On At For To From With By Of And But Or Nor If As Is Are Was Were Be Been Not No Yes See Run New Our Your Their His Her Its My Do Does Did Will Would Can Could Should May Might Must Have Has Had So Then There Here What Which Who Whose When Where Why How All Any Each Per Both More Most Some Such Other Also Just Only Now Today Yesterday Tomorrow Please Note".split(" "));
var TIER1 = {
  "delve": "explore, dig into, look at",
  "tapestry": "describe the actual complexity",
  "paradigm": "model, approach, framework",
  "beacon": "rewrite entirely",
  "robust": "strong, reliable, solid",
  "comprehensive": "thorough, complete, full",
  "cutting-edge": "latest, newest, advanced",
  "pivotal": "important, key, critical",
  "meticulous": "careful, detailed, precise",
  "meticulously": "carefully, precisely",
  "seamless": "smooth, easy, without friction",
  "seamlessly": "smoothly, easily",
  "game-changer": "describe what changed",
  "game-changing": "describe what changed",
  "nestled": "is located, sits",
  "vibrant": "describe what makes it active",
  "thriving": "growing, active",
  "bustling": "busy, active",
  "intricate": "complex, detailed",
  "intricacies": "complexities, details",
  "ever-evolving": "changing, growing",
  "enduring": "lasting, long-running",
  "daunting": "hard, difficult",
  "holistic": "complete, full, whole",
  "holistically": "completely, fully",
  "actionable": "practical, useful, concrete",
  "impactful": "effective, significant",
  "learnings": "lessons, findings, takeaways",
  "synergy": "describe the combined effect",
  "synergies": "describe the combined effect",
  "interplay": "relationship, connection",
  "symphony": "describe the coordination",
  "embrace": "adopt, accept, use",
  // 2026.08.3 owner-docs tier A additions (OWNER-DOCS-TELLS.md §8).
  "enigma": "mystery, puzzle",
  "labyrinth": "maze, tangle",
  "top-notch": "excellent, first-rate"
};
var TIER2 = {
  "harness": "use, take advantage of",
  "navigate": "work through, handle",
  "navigating": "working through, handling",
  "foster": "encourage, support, build",
  "elevate": "improve, raise, strengthen",
  "unleash": "release, enable, unlock",
  "streamline": "simplify, speed up",
  "empower": "enable, let, allow",
  "bolster": "support, strengthen",
  "spearhead": "lead, drive, run",
  "resonate": "connect with, appeal to",
  "resonates": "connects with, appeals to",
  "revolutionize": "change, transform",
  "facilitate": "enable, help, allow",
  "facilitates": "enables, helps, allows",
  "underpin": "support, form the basis of",
  "nuanced": "specific, subtle, detailed",
  "crucial": "important, key, necessary",
  "multifaceted": "describe the actual facets",
  "ecosystem": "system, community, network",
  "myriad": "many, numerous",
  "plethora": "many, a lot of",
  "encompass": "include, cover, span",
  "catalyze": "start, trigger, accelerate",
  "reimagine": "rethink, redesign, rebuild",
  "galvanize": "motivate, rally, push",
  "augment": "add to, expand, supplement",
  "cultivate": "build, develop, grow",
  "illuminate": "clarify, explain, show",
  "elucidate": "explain, clarify",
  "juxtapose": "compare, contrast",
  "transformative": "describe what changed",
  "transformation": "describe what changed",
  "cornerstone": "foundation, basis, key part",
  "paramount": "most important, top priority",
  "poised": "ready, set, about to",
  "burgeoning": "growing, emerging",
  "nascent": "new, early-stage",
  "quintessential": "typical, classic, defining",
  "overarching": "main, central, broad",
  "quietly": "cut, or name the concrete contrast",
  "underpinning": "basis, foundation",
  "underpinnings": "basis, foundations",
  "paradigm-shifting": "describe what shifted",
  // 2026.08.3 owner-docs additions (medium FP → cluster-scored tier 2).
  "revolutionary": "describe what changed",
  "ai-powered": "say what the AI part actually does"
};
var TIER3 = [
  "significant",
  "significantly",
  "innovative",
  "innovation",
  "effective",
  "effectively",
  "dynamic",
  "dynamics",
  "scalable",
  "scalability",
  "compelling",
  "unprecedented",
  "exceptional",
  "exceptionally",
  "remarkable",
  "remarkably",
  "sophisticated",
  "instrumental",
  "world-class",
  "state-of-the-art",
  "best-in-class",
  "verbatim"
];
var ISSUE_WEIGHTS = {
  "tier1": 5,
  "tier1-clarity": 3,
  "tier2": 3,
  "tier3": 2,
  "transition": 2,
  "chatbot": 8,
  "sycophantic": 8,
  "filler": 2,
  "generic-conclusion": 3,
  "lets-construction": 2,
  "reasoning-artifact": 6,
  "acknowledgment-loop": 3,
  "significance-inflation": 4,
  "vague-attribution": 5,
  "hollow-intensifier": 2,
  "emotional-flatline": 2,
  "lingering-attention": 3,
  "novelty-inflation": 3,
  "cutoff-disclaimer": 10,
  "template-phrase": 3,
  "false-concession": 2,
  "rhetorical-question": 2,
  "confidence-calibration": 2,
  "em-dash-density": 4,
  "not-just-contrast": 6,
  "uniform-sections": 5,
  "uniform-list-items": 4,
  "sentence-flatline": 5,
  "uniformity": 5,
  "formatting": 3,
  "tier3-phrase": 3,
  "tier3-phrase-cluster": 12,
  "hashtag-stuff": 12,
  "bullet-np-list": 10,
  "hedge-stack": 6,
  "future-narrative": 12,
  "real-actual-inflation": 5,
  "social-cta-closer": 8,
  "formulaic-opener": 8,
  "speculative-opener": 8,
  "title-case-header": 4,
  "parenthetical-hedge": 3,
  "smart-punct-signature": 6,
  "punct-distribution": 6,
  "fnword-trigram-entropy": 5,
  "cross-para-burstiness": 5,
  "normalization-flag": 9,
  "low-ttr": 3,
  "ai-placeholder": 10,
  "ai-citation-markup": 15,
  "ai-utm-source": 12
};
var CATEGORY_META = {
  "tier1": { severity: "high", message: 'A word that turns up a lot in generic machine-written copy, like "delve", "robust" or "seamless".', suggestion: "Swap it for a plainer word." },
  "tier1-clarity": { severity: "medium", message: 'This is a long way of saying something short, like "in order to" for "to", or "due to the fact that" for "because".', suggestion: "Use the shorter form." },
  "tier2": { severity: "medium", message: 'Several buzzwords sit in one paragraph, words like "foster", "facilitate" and "ecosystem". One is fine. A pile of them reads as filler.', suggestion: "Keep one at most, and say the plain thing instead." },
  "tier3": { severity: "low", message: 'A vague filler word such as "significant", "effective" or "dynamic" is used a lot for a piece this long.', suggestion: "Cut some of them, or say what you actually mean." },
  "transition": { severity: "medium", message: 'A joining phrase that could link any two sentences, like "Moreover", "Furthermore" or "In conclusion".', suggestion: "Cut it, or say how the two sentences really connect." },
  "chatbot": { severity: "high", message: 'A line from a chat window is still in the text, like "I hope this helps" or "Certainly!".', suggestion: "Delete it." },
  "sycophantic": { severity: "high", message: `A compliment aimed at the reader's question, the way a chatbot opens a reply: "Great question!".`, suggestion: "Delete it and go straight to the point." },
  "filler": { severity: "medium", message: "A phrase that adds words but no meaning.", suggestion: "Cut it. The sentence almost always still works." },
  "generic-conclusion": { severity: "medium", message: 'A closing line that could end any article, like "only time will tell" or "the future looks bright".', suggestion: "End on something specific instead." },
  "lets-construction": { severity: "medium", message: `A "let's take a look at\u2026" line, the way a tutorial talks to you.`, suggestion: "Just say the thing. Do not announce it first." },
  "reasoning-artifact": { severity: "high", message: 'Step-by-step working is still showing, like "First, let me\u2026" or "Step 1:".', suggestion: "Delete the working and keep the answer." },
  "acknowledgment-loop": { severity: "medium", message: 'The text repeats the question back before answering it: "You asked about X. X is\u2026".', suggestion: "Answer straight away." },
  "significance-inflation": { severity: "high", message: 'A stock line telling the reader how big something was, instead of saying what happened: "marking a pivotal moment".', suggestion: "Say what happened and let the reader judge." },
  "vague-attribution": { severity: "high", message: 'A claim is credited to nobody in particular: "experts say", "studies show".', suggestion: "Name the study or the person, or drop the claim." },
  "hollow-intensifier": { severity: "medium", message: 'An emphasis word that adds no information, like "truly", "incredibly" or "absolutely".', suggestion: "Cut it." },
  "emotional-flatline": { severity: "low", message: 'A ready-made feeling word stands in for a real reaction, like "fascinating" or "surprising".', suggestion: "Say what was actually surprising, or cut it." },
  "lingering-attention": { severity: "medium", message: 'A share-post line about how long an idea stayed with you, which tells the reader nothing about the idea: "this stuck with me for days".', suggestion: "Say why it matters instead." },
  "novelty-inflation": { severity: "medium", message: 'The text announces that it is about to say something rare: "few people realise".', suggestion: "Show the point. Do not advertise it." },
  "cutoff-disclaimer": { severity: "high", message: 'A line where a chatbot describes itself or its training cut-off, like "as of my last update" or "as an AI language model".', suggestion: "Delete it, and check the facts around it yourself." },
  "template-phrase": { severity: "high", message: "A ready-made phrase that turns up in a lot of generated copy.", suggestion: "Replace it with something specific to your subject." },
  "false-concession": { severity: "medium", message: `A formula that pretends to give ground before making the point: "while it's true that\u2026".`, suggestion: "Name the real trade-off, or drop it." },
  "rhetorical-question": { severity: "medium", message: 'A question the writer asks and then answers: "So what does this mean?".', suggestion: "Give the answer without asking first." },
  "confidence-calibration": { severity: "low", message: 'Words like "clearly", "certainly" and "undoubtedly" pile up across the text.', suggestion: "Keep the one or two you have earned and cut the rest." },
  "em-dash-density": { severity: "medium", message: "Em dashes (\u2014), or spaced hyphens used as dashes, turn up a lot for a piece this long. Worth knowing: since OpenAI cut back on em dashes in late 2025, heavy dash use is more common in Claude's writing than in machine writing generally, and plenty of professional human writers use more dashes than this.", suggestion: "Swap some for commas, colons or full stops." },
  "not-just-contrast": { severity: "high", message: `The "it isn't just X, it's Y" shape.`, suggestion: "Say what it is, without the set-up." },
  "uniform-sections": { severity: "medium", message: "Every section is close to the same length. Real writing runs long in places and short in others.", suggestion: "Let each section be as long as its content needs." },
  "uniform-list-items": { severity: "medium", message: "The list items are all close to the same length. Real lists are lumpy.", suggestion: "Let some items run shorter or longer, or merge ones that repeat." },
  "sentence-flatline": { severity: "medium", message: "Sentence lengths barely change across the whole piece. Real writing swings between short and long.", suggestion: "Mix a few short, punchy sentences in with the longer ones." },
  "uniformity": { severity: "medium", message: "The paragraphs are all close to the same size.", suggestion: "Make some paragraphs shorter or longer on purpose." },
  "formatting": { severity: "medium", message: "A lot of bold is used.", suggestion: "Take the bold off most phrases, and put the important thing first." },
  "tier3-phrase": { severity: "medium", message: "The same stock phrase keeps coming back through the text.", suggestion: "Replace at least one of them with something concrete." },
  "tier3-phrase-cluster": { severity: "high", message: "Several different stock phrases are stacked up in one piece.", suggestion: "Rewrite it around one real point." },
  "hashtag-stuff": { severity: "medium", message: "A long block of hashtags.", suggestion: "Cut to two or three that fit, or none." },
  "bullet-np-list": { severity: "high", message: "A long bullet list where every item is a bare noun phrase with no verb.", suggestion: "Turn it into a paragraph, or join the items up." },
  "hedge-stack": { severity: "high", message: 'Two hedges on the same claim, like "may potentially" or "could possibly".', suggestion: "Pick one hedge, or make a claim someone could check." },
  "future-narrative": { severity: "high", message: 'A vague line about the future that nobody could ever check: "is set to reshape the industry".', suggestion: "Say something concrete a reader could test." },
  "real-actual-inflation": { severity: "medium", message: '"Real" or "actual" is doing no work here, as in "real value" or "actual impact".', suggestion: "Cut the word, or say what makes it real." },
  "social-cta-closer": { severity: "high", message: 'A closing line begging for engagement: "What do you think? Let me know below."', suggestion: "Give the reader a reason to care instead of an instruction." },
  "formulaic-opener": { severity: "high", message: `A stock opening line that would fit any article: "In today's fast-paced world\u2026".`, suggestion: "Open on a fact or a specific detail." },
  "speculative-opener": { severity: "high", message: 'The piece opens by asking you to picture a scene: "Imagine a world where\u2026".', suggestion: "Make the point directly." },
  "title-case-header": { severity: "medium", message: "The heading puts a capital on nearly every word, the way a lot of marketing copy does.", suggestion: "Capitalise the first word only, as you would in a sentence." },
  "parenthetical-hedge": { severity: "medium", message: 'An aside in brackets that sounds thoughtful and adds nothing: "(at least in most cases)".', suggestion: "Cut it, or make it a proper sentence." },
  "smart-punct-signature": { severity: "high", message: "Curly quotes, an em dash, an Oxford comma and no typos, all in one piece. That combination is rare in text somebody typed straight out by hand.", suggestion: "Nothing to fix. This is just something we noticed." },
  "punct-distribution": { severity: "medium", message: "Every paragraph uses about the same amount of punctuation.", suggestion: "Let some paragraphs run busier than others." },
  "fnword-trigram-entropy": { severity: "medium", message: "Sentences are built to the same grammar pattern again and again.", suggestion: "Change the way you build some of the sentences." },
  "cross-para-burstiness": { severity: "medium", message: "Every paragraph has the same inner rhythm of long and short sentences.", suggestion: "Let some paragraphs be clipped and others rambling." },
  "normalization-flag": { severity: "high", message: "The text held invisible characters or lookalike letters, the kind used to hide copied text from checkers. We swapped them back before reading it.", suggestion: "Take the hidden characters out and check the text again." },
  "low-ttr": { severity: "low", message: "The same words come round a lot for a piece this long.", suggestion: "Vary the nouns and verbs, unless the subject really does need the repeating." },
  "ai-placeholder": { severity: "high", message: 'A blank somebody forgot to fill in is still here, like "[INSERT NAME]".', suggestion: "Fill it in or delete it before this goes out." },
  "ai-citation-markup": { severity: "high", message: "Chatbot citation code was pasted in along with the text.", suggestion: "Delete it and put a real reference in its place." },
  "ai-utm-source": { severity: "high", message: 'A link carries a tracking tag that AI tools add to the links they hand out, like "utm_source=chatgpt.com".', suggestion: "Strip the tracking part off the link." }
};
var V3_ISSUE_WEIGHTS = {
  // artefact forensics
  "ai-citation-token": 15,
  "reasoning-leak": 12,
  "placeholder-token": 10,
  "pua-character": 14,
  "math-alphanumeric": 12,
  "arrow-decoration": 4,
  "escaped-markup-literal": 3,
  // tier A phrase/structural
  "neg-parallelism": 5,
  "tripled-negation": 5,
  "despite-challenges-arc": 5,
  "metaphor-cluster": 4,
  "participial-tail": 5,
  "focal-density": 5,
  "owner-phrase": 5,
  "power-verb-compound": 6,
  "outcome-tail": 4,
  "conclusion-cta": 6,
  // tier B (low weights; corroboration)
  "liang-cluster": 2,
  "kobak-density": 2,
  "promo-travel": 2,
  "pivotal-role": 2,
  "legacy-framing": 3,
  "notability-canned": 2,
  "buzzword-phrase": 2,
  "faux-insight": 2,
  "rhetorical-qa": 2,
  "didactic-note": 2,
  "narrative-cliche": 3,
  "valuable-insights": 2,
  "copula-avoidance": 3,
  "bold-label-bullets": 3,
  "emoji-decoration": 2,
  "heading-inflation": 3,
  "staccato-fragments": 3,
  "tricolon-density": 2,
  "transition-stacking": 3,
  "quote-inconsistency": 2,
  "token-cutoff": 2,
  "setup-expansion-cadence": 3,
  "passive-ratio": 3,
  "low-specificity": 2,
  "adjacent-lemma-repeat": 3,
  "fiction-claudeism": 3,
  "fiction-promptonym": 3,
  "fiction-slop-phrase": 2,
  "owner-phrase-b": 2,
  "owner-vocab-b": 2,
  "directive-colon-bullets": 3,
  "teach-preach-headings": 2,
  "by-ving-template": 3,
  "invalid-isbn": 3,
  "proximity-cluster": 2,
  // 2026.08.6 furniture rules (low weights; the escalation floors carry the
  // detection, and the weights stay small so furniture cannot fake breadth).
  "markdown-bold": 3,
  "markdown-heading": 3,
  "markdown-furniture": 4
};
var PASTE = "This only shows up when chat formatting survives the paste. If an editor stripped the formatting, the check finds nothing, which says nothing either way.";
var FORMAL = "Formal writing, and writing by people whose first language is not English, can read this way too.";
var V3_CATEGORY_META = {
  "ai-citation-token": { severity: "high", message: "A chatbot's own citation code is sitting in the text. The code itself says which chatbot it came from.", suggestion: "Delete the code and put a real reference in its place." },
  "reasoning-leak": { severity: "high", message: 'Parts of this text talk about the writing job itself, the kind of notes an AI leaves in its answer, like "as requested" or "let me revise".', suggestion: "Delete those notes and keep the finished writing." },
  "placeholder-token": { severity: "high", message: 'A machine placeholder is still in the text, something like "{{name}}" or "<insert>".', suggestion: "Fill it in or delete it before this goes out." },
  "pua-character": { severity: "high", message: "The text holds characters from a private corner of Unicode that has no agreed meaning. ChatGPT wraps its citation codes in these. Icon fonts are the only other common reason for them.", suggestion: "Delete them, and look for chatbot citation codes next to them." },
  "math-alphanumeric": { severity: "high", message: "Fake bold or italic letters built from maths symbols (\u{1D5F9}\u{1D5F6}\u{1D5F8}\u{1D5F2} \u{1D601}\u{1D5F5}\u{1D5F6}\u{1D600}). They come from chatbot copy-paste and social-media text formatters.", suggestion: "Retype them as ordinary letters and use real bold or italic." },
  "arrow-decoration": { severity: "medium", message: 'Arrows stand in for words again and again: "input \u2192 output \u2192 result".', suggestion: "Write the connection out in words." },
  "escaped-markup-literal": { severity: "low", message: 'A stray scrap of code is showing through the text, like "&nbsp;" or "\\n". It usually comes from pasting out of a chat window.', suggestion: "Delete it." },
  "neg-parallelism": { severity: "medium", message: 'The "not only X but Y" shape comes back more than once.', suggestion: "Keep one. Say the rest plainly." },
  "tripled-negation": { severity: "medium", message: 'The "Not X. Not Y. Just Z." shape.', suggestion: "Say what it is, without the three-part build-up." },
  "despite-challenges-arc": { severity: "medium", message: 'The stock "despite challenges, it continues to thrive" story shape.', suggestion: "Name the real problem and what was really done about it." },
  "metaphor-cluster": { severity: "medium", message: 'Several worn-out picture words are stacked together: "tapestry", "interplay", "evolving landscape", "testament to".', suggestion: "Say the plain facts they are standing in for." },
  "participial-tail": { severity: "medium", message: 'Sentences keep ending with a tacked-on "-ing" clause that tells you why it mattered: ", highlighting the need for\u2026", ", underscoring the importance of\u2026". That ending turns up several times more often in machine writing than in human writing.', suggestion: "Stop the sentence at the fact. Cut the tail, or turn it into a claim you can source." },
  "focal-density": { severity: "medium", message: 'A lot of words from the AI-favourite list turn up here: "delve", "showcase", "pivotal", "meticulous". Any one of them is normal English. It is how many there are that stands out.', suggestion: "Swap most of them for plainer verbs and adjectives." },
  "owner-phrase": { severity: "medium", message: "A ready-made phrase from the generic-writing phrasebook.", suggestion: "Replace it with something specific to your subject." },
  "power-verb-compound": { severity: "high", message: 'A big verb glued to a vague adjective: "leverage a robust solution", "ensure seamless delivery". It sounds like value and says nothing.', suggestion: "Name the real action and the thing you can measure." },
  "outcome-tail": { severity: "medium", message: 'The sentence trails off into a vague result: ", leading to increased engagement".', suggestion: "Say the exact result, or cut the tail." },
  "conclusion-cta": { severity: "high", message: 'The stock marketing sign-off: "by following these steps you can boost\u2026".', suggestion: "Close on something specific, not a general promise." },
  "liang-cluster": { severity: "low", message: 'Several judgement words from the AI-overuse lists sit close together, like "crucial", "notable" and "significant".', suggestion: "Keep the judgements you can back up with detail." },
  "kobak-density": { severity: "low", message: "Several words sit here that turned up far more often in machine writing when a large body of text was counted.", suggestion: "Vary the words, or back the claims with detail." },
  "promo-travel": { severity: "low", message: 'Brochure words are bunched together: "nestled", "breathtaking", "hidden gem". They stand out most when the piece is not a travel brochure.', suggestion: "Describe the place or the product with real detail." },
  "pivotal-role": { severity: "low", message: 'The "plays a crucial role in shaping" formula.', suggestion: "Say what it actually does." },
  "legacy-framing": { severity: "low", message: 'Several grand phrases about legacy and importance are stacked up: "enduring legacy", "pivotal moment".', suggestion: "Let the events speak for themselves." },
  "notability-canned": { severity: "low", message: 'A canned line about how well known something is: "profiled in multiple outlets".', suggestion: "Name the outlets, or drop the claim." },
  "buzzword-phrase": { severity: "low", message: 'A stock office phrase: "harness the power of", "at the forefront of".', suggestion: "Say what it can actually do." },
  "faux-insight": { severity: "low", message: `A line promising a secret: "here's what nobody tells you".`, suggestion: "Show the point. Do not announce it." },
  "rhetorical-qa": { severity: "low", message: 'The "The result? X." trick keeps coming back.', suggestion: "Use it once at most." },
  "didactic-note": { severity: "low", message: `A teacherly disclaimer: "it's important to understand", "results may vary".`, suggestion: "Cut it, or make it specific." },
  "narrative-cliche": { severity: "low", message: 'A worn-out story phrase: "faced numerous challenges", "a poignant reminder".', suggestion: "Say what actually happened." },
  "valuable-insights": { severity: "low", message: 'A stock academic filler phrase: "provides valuable insights into".', suggestion: "State the insight itself." },
  "copula-avoidance": { severity: "low", message: 'The text keeps dodging plain "is" and "has" in favour of "serves as", "stands as" and "functions as". ' + FORMAL, suggestion: 'Use "is" and "has" where they fit.' },
  "bold-label-bullets": { severity: "low", message: 'A run of bullets all shaped "**Label:** description". Technical documents use this shape too.', suggestion: "Turn it into sentences, or vary the shape of the items." },
  "emoji-decoration": { severity: "low", message: "Emoji are used on headings or bullets. That is a chat-window habit in a piece of business writing.", suggestion: "Take the decorative emoji out of this kind of writing." },
  "heading-inflation": { severity: "low", message: "There are a lot of headings for the amount of writing under them. SEO advice produces the same shape.", suggestion: "Merge sections whose body is only a sentence or two." },
  "staccato-fragments": { severity: "low", message: "A run of very short, punchy fragments. Ad copy does this on purpose too.", suggestion: "Join some of them into full sentences." },
  "tricolon-density": { severity: "low", message: 'Three-part lists such as "faster, cheaper, simpler" turn up a lot for a piece this long.', suggestion: "Break the pattern: use two items, or four." },
  "transition-stacking": { severity: "low", message: 'Most paragraphs open on a formal joining word: "Furthermore", "Moreover", "Additionally". ' + FORMAL, suggestion: "Let the content do the joining in most paragraphs." },
  "quote-inconsistency": { severity: "low", message: "Curly and straight quotation marks are mixed together. That usually comes from pasting out of a chat window, though word processors do it too.", suggestion: "Make the quotation marks match, either way round." },
  "token-cutoff": { severity: "low", message: "The text stops in the middle of a sentence, the shape of an answer that ran out of room, or a paste that went wrong.", suggestion: "Finish the last sentence, or delete it." },
  "setup-expansion-cadence": { severity: "low", message: "Short sentence, then long one, over and over, or the other way round. " + FORMAL, suggestion: "Keep the pattern only where the short sentence works on its own." },
  "passive-ratio": { severity: "low", message: 'A lot of the sentences hide who did the thing: "mistakes were made". That is high for a blog or a marketing piece. Academic writing does it constantly. ' + FORMAL, suggestion: "Rewrite most sentences so the person or thing doing it comes first." },
  "low-specificity": { severity: "low", message: "Almost no numbers, dates or names for a piece this long. Corporate writers produce empty writing too.", suggestion: "Add facts a reader could go and check." },
  "adjacent-lemma-repeat": { severity: "low", message: "Neighbouring sentences keep reusing the same word. " + FORMAL, suggestion: "Merge the repetitive sentences, or change the wording where it reads naturally." },
  "fiction-claudeism": { severity: "low", message: "Phrases that turn up a lot in Claude's fiction writing. Romance authors use several of them quite normally.", suggestion: "Put the stock phrases into your own words." },
  "fiction-promptonym": { severity: "low", message: 'A character name that AI writing produces far more often than people do. "Elara Voss" is the best-known one.', suggestion: "Pick a less loaded name if you want one." },
  "fiction-slop-phrase": { severity: "low", message: "Several well-worn fiction lines land in the same piece. All of them were human clich\xE9s long before AI.", suggestion: "Cut or rework the stock moments." },
  "owner-phrase-b": { severity: "low", message: "A phrase from the second generic-writing phrasebook.", suggestion: "Replace it with something specific." },
  "owner-vocab-b": { severity: "low", message: 'Several second-string filler words sit close together: "essence", "facet", "pesky", "folks".', suggestion: "Swap them for plainer words where they add nothing." },
  "directive-colon-bullets": { severity: "low", message: 'Several list items open on an order and a colon: "Ensure X:", "Optimise Y:". Real technical checklists look like this too.', suggestion: "Vary the way the items are built." },
  "teach-preach-headings": { severity: "low", message: 'Stock tutorial headings hold the piece together: "Why it matters", "Final thoughts", "Key takeaways".', suggestion: "Name each section after what is actually in it." },
  "by-ving-template": { severity: "low", message: 'The "By doing X, you can Y" shape keeps coming back.', suggestion: "Say the benefit straight out most of the time." },
  "invalid-isbn": { severity: "low", message: "An ISBN in the text does not add up. Made-up references often fail this check, and so do typos.", suggestion: "Check the reference against the real book." },
  "proximity-cluster": { severity: "low", message: "The same flagged buzzword comes back within a sentence or two.", suggestion: "Keep one use at most in each passage." },
  // 2026.08.6 chat-formatting rules. Each one states the paste caveat: the
  // check can only see formatting that survived the paste, so its ABSENCE says
  // nothing about who wrote the text.
  "markdown-bold": { severity: "low", message: "Raw **bold** markdown is showing in the text. None of the 169 human-written documents we checked had it. " + PASTE, suggestion: "Delete the stars, or apply real bold." },
  "markdown-heading": { severity: "low", message: "A raw markdown heading line, the kind that starts with # signs, is showing in the text. None of the 169 human-written documents we checked had one. " + PASTE, suggestion: "Turn it into a real heading, or delete it." },
  "markdown-furniture": { severity: "low", message: "Chat-window formatting shapes this text: runs of bold, heading lines, or a wall of bullets. None of the 169 human-written documents we checked had that combination. " + PASTE, suggestion: "Rebuild the formatting properly for wherever this is going." }
};
var V4_ISSUE_WEIGHTS = {
  "sentence-length-spectral-flatness": 2,
  "conditional-compression": 2,
  "lexical-register-distance": 2,
  "punchline-fragment-density": 2,
  "mic-drop-paragraph": 2,
  "contrast-density": 2,
  "rhetorical-procedural-ratio": 2
};
var V4_CATEGORY_META = {
  "sentence-length-spectral-flatness": {
    severity: "low",
    message: "Sentence lengths follow a pattern that is more regular than most writing this long. We only measure it on fixed-size chunks, so short pieces are skipped. Careful human editing produces the same shape.",
    suggestion: "Nothing to change unless the other checks agree. Varying sentence length is a choice, not a rule."
  },
  "conditional-compression": {
    severity: "low",
    message: "Held up against a sample of varied human writing, this text has less in common with it than most. Copy written to a tight template scores the same way.",
    suggestion: "Nothing to change on its own. If the other checks agree, vary phrasing you have repeated."
  },
  "lexical-register-distance": {
    severity: "low",
    message: "The mix of small joining words, and the length of the words, sits a long way from our sample of everyday human writing. Worth knowing: that sample is general writing, so academic, legal and technical pieces land far away quite fairly.",
    suggestion: "Nothing to change on its own. Plainer wording moves it closer if the other checks agree."
  },
  "punchline-fragment-density": {
    severity: "low",
    message: `Very short, abstract closing lines keep turning up, especially at the end of paragraphs: "That's the point." Good copywriters use punchlines on purpose, which is why we only count how many there are.`,
    suggestion: "Keep the punchlines that earn their place. Turn the rest into full sentences."
  },
  "mic-drop-paragraph": {
    severity: "low",
    message: "Several paragraphs are built the same way: a few medium sentences, then a much shorter line to land on. One paragraph like that is ordinary. It is the repeat that stands out.",
    suggestion: "Let some paragraphs finish on their facts instead of a quotable line."
  },
  "contrast-density": {
    severity: "low",
    message: `Two-sided contrasts keep coming back: "not X, but Y"; "It wasn't A. It was B." One is ordinary writing. It is the rate that stands out.`,
    suggestion: "Keep the strongest contrast and say the rest plainly."
  },
  "rhetorical-procedural-ratio": {
    severity: "low",
    message: "Sentences making broad claims heavily outnumber sentences naming a real action, object or number. We count a sentence as concrete when it holds a number, a name, or a specific action verb. Opinion and vision pieces are broad on purpose.",
    suggestion: "Back more claims with a specific action, name or figure if the other checks agree."
  }
};
var MERGED_WEIGHTS = { ...ISSUE_WEIGHTS, ...V3_ISSUE_WEIGHTS, ...V4_ISSUE_WEIGHTS };
var MERGED_META = { ...CATEGORY_META, ...V3_CATEGORY_META, ...V4_CATEGORY_META };
var byLengthDesc = (a, b) => b.length - a.length || a.localeCompare(b);
var TIER1_WORD_RE = new RegExp("\\b(?:" + Object.keys(TIER1).sort(byLengthDesc).join("|") + ")\\b", "gi");
var TIER2_WORD_RE = new RegExp("\\b(?:" + Object.keys(TIER2).sort(byLengthDesc).join("|") + ")\\b", "gi");
var TIER3_LOOKUP = /* @__PURE__ */ new Map();
for (const word of TIER3) {
  TIER3_LOOKUP.set(word, word);
  const dashless = word.replace(/-/g, "");
  if (dashless !== word) TIER3_LOOKUP.set(dashless, word);
}
var METHODS = Object.freeze([
  Object.freeze({ id: "unicode.invisible", category: "unicode", version: "unicode:2026.08.1", state: "available", privacy_routes: ["browser"], limitations: ["Controls can be legitimate in multilingual text."] }),
  Object.freeze({ id: "unicode.homoglyph", category: "unicode", version: "unicode:2026.08.1", state: "available", privacy_routes: ["browser"], limitations: ["Mixed scripts require contextual human review."] }),
  Object.freeze({ id: "style.patterns", category: "pattern", version: "en-gb:2026.08.1", state: "available", privacy_routes: ["browser"], limitations: ["Editorial pattern findings are not authorship evidence."] }),
  Object.freeze({ id: "watermark.anthropic", category: "watermark", version: "adapter-placeholder/1", state: "unsupported", privacy_routes: ["browser"], limitations: ["No official detector interface is available."] })
]);
var CYCLE5_MODEL_IDENTITY = {
  identity: "tier3-cycle5-v1",
  serverRegistryIdentity: "tier3-cycle5-full",
  segmentationContract: "segments-v3",
  inputContract: "raw-v1",
  featuresContract: "features-v1",
  scoringContract: "margin-v1",
  flagRule: {
    expression: "max(m1, m2 + 0.34) >= 3.570935",
    primaryMargin: 3.570935,
    secondaryGap: 0.34
  }
};
var CHECKER_SCORE_SCALE = "zero_to_one_pattern_similarity";
var CHECKER_HONESTY_LINE = "No AI checker can prove who wrote a text \u2014 this is a pattern reading.";
var CHECKER_LEVELS = {
  "signal-strongly-ai": {
    name: "Strongly AI",
    support: "This draft very strongly matches AI writing \u2014 the kind of match we rarely see in human work."
  },
  "signal-likely-ai": {
    name: "Likely AI",
    support: "Much of this draft reads like AI writing."
  },
  "signal-potentially-ai": {
    name: "Potentially AI",
    support: "Parts of this draft resemble AI writing, but the match is not strong enough to be sure."
  },
  "signal-unclear": {
    name: "Unclear",
    support: "We can't call this one either way. Some passages read slightly machine-like, but people write that way too."
  },
  "signal-likely-human": {
    name: "Likely human",
    support: "This reads like human writing. Nothing here matches the AI patterns we test for \u2014 though a heavily disguised AI draft can slip past any checker, ours included."
  }
};
var BAND_TO_LEVEL = {
  very_likely_ai: "signal-strongly-ai",
  uncertain: "signal-potentially-ai",
  likely_human: "signal-unclear",
  very_likely_human: "signal-likely-human"
};
var METHOD_STATUSES = /* @__PURE__ */ new Set(["pass", "attention", "fail", "inconclusive", "unsupported", "not_configured", "not_run", "error"]);
var CONTENT_KEYS = /* @__PURE__ */ new Set(["content", "text", "passage", "excerpt", "source_uri", "candidate", "route_path", "evidence"]);
function probability(value, name) {
  if (!Number.isFinite(value) || value < 0 || value > 1) throw new RangeError(`${name} must be a finite zero-to-one score.`);
  return value;
}
function levelForCycle5Score(rawScore, bandId, secondaryThreshold) {
  probability(rawScore, "rawScore");
  const level2 = BAND_TO_LEVEL[bandId];
  if (!level2) throw new Error(`Unknown Cycle-5 band: ${String(bandId)}`);
  if (bandId === "uncertain" && secondaryThreshold !== void 0) {
    probability(secondaryThreshold, "secondaryThreshold");
    if (rawScore >= secondaryThreshold) return "signal-likely-ai";
  }
  return level2;
}
function formatCheckerScoreTexts(entries, startDecimals = 2, maxDecimals = 6) {
  if (!Number.isInteger(startDecimals) || !Number.isInteger(maxDecimals) || startDecimals < 0 || maxDecimals < startDecimals) {
    throw new RangeError("Score precision bounds are invalid.");
  }
  entries.forEach((entry, index) => probability(entry.rawScore, `entries[${index}].rawScore`));
  const decimals = entries.map(() => startDecimals);
  for (let pass = startDecimals; pass < maxDecimals; pass += 1) {
    const groups = /* @__PURE__ */ new Map();
    entries.forEach((entry, index) => {
      const text2 = entry.rawScore.toFixed(decimals[index]);
      const group = groups.get(text2);
      if (group) group.push(index);
      else groups.set(text2, [index]);
    });
    let changed = false;
    for (const group of groups.values()) {
      if (new Set(group.map((index) => entries[index].level)).size > 1) {
        for (const index of group) decimals[index] = decimals[index] + 1;
        changed = true;
      }
    }
    if (!changed) break;
  }
  return entries.map((entry, index) => entry.rawScore.toFixed(decimals[index]));
}
var DEFAULT_AI_LIMITATIONS = [
  "The score is a zero-to-one pattern-similarity reading, not a percentage of the text written by AI.",
  "This result does not prove authorship, and edited or out-of-register writing may be missed."
];
function presentCycle5Result(input) {
  probability(input.rawScore, "rawScore");
  probability(input.primaryDisplayThreshold, "primaryDisplayThreshold");
  probability(input.secondaryDisplayThreshold, "secondaryDisplayThreshold");
  if (!input.sections.length) throw new Error("An assessed Cycle-5 result requires at least one scored section.");
  const sections = input.sections.map((section, position) => {
    if (!Number.isInteger(section.index) || section.index !== position) throw new Error("Scored sections must be zero-based and in source order.");
    if (!Number.isInteger(section.startUtf16) || !Number.isInteger(section.endUtf16) || section.startUtf16 < 0 || section.endUtf16 <= section.startUtf16) {
      throw new Error(`Section ${section.index} has an invalid UTF-16 range.`);
    }
    if (position > 0 && section.startUtf16 < input.sections[position - 1].endUtf16) throw new Error("Scored section ranges must not overlap or move backwards.");
    if (!Number.isInteger(section.wordCount) || section.wordCount < 0) throw new Error(`Section ${section.index} has an invalid word count.`);
    if (section.passage === void 0 && section.locator === void 0) throw new Error(`Section ${section.index} needs a passage or a content-free locator.`);
    return {
      index: section.index,
      start_utf16: section.startUtf16,
      end_utf16: section.endUtf16,
      word_count: section.wordCount,
      raw_score: probability(section.rawScore, `sections[${section.index}].rawScore`),
      raw_margin: finiteNumber(section.rawMargin, `sections[${section.index}].rawMargin`),
      display_score: "",
      level: levelForCycle5Score(section.rawScore, section.bandId, input.secondaryDisplayThreshold),
      band_id: section.bandId,
      ...section.passage === void 0 ? {} : { passage: section.passage },
      ...section.locator === void 0 ? {} : { locator: { ...section.locator } },
      evidence: section.evidence.map((item2) => ({ ...item2 }))
    };
  });
  const strongest = sections.reduce((best, section) => section.raw_score > best.raw_score ? section : best, sections[0]);
  if (Math.abs(strongest.raw_score - input.rawScore) > Number.EPSILON) throw new Error("The run-wide score must equal the strongest section's raw score.");
  if (Math.abs(strongest.raw_margin - input.rawMargin) > Number.EPSILON) throw new Error("The run-wide margin must equal the strongest section's raw margin.");
  const margins = sections.map((section) => section.raw_margin).sort((a, b) => b - a);
  const primaryFired = margins[0] >= CYCLE5_MODEL_IDENTITY.flagRule.primaryMargin;
  const secondaryFired = margins.length > 1 && margins[1] + CYCLE5_MODEL_IDENTITY.flagRule.secondaryGap >= CYCLE5_MODEL_IDENTITY.flagRule.primaryMargin;
  const expectedFlagged = primaryFired || secondaryFired;
  const expectedReason = primaryFired ? "primary" : secondaryFired ? "secondary" : null;
  if (input.flagged !== expectedFlagged || input.flagReason !== expectedReason) throw new Error("The supplied flag state contradicts the Cycle-5 margin rule.");
  const level2 = levelForCycle5Score(input.rawScore, input.bandId, input.secondaryDisplayThreshold);
  const display = formatCheckerScoreTexts([
    { rawScore: input.rawScore, level: level2 },
    ...sections.map((section) => ({ rawScore: section.raw_score, level: section.level }))
  ]);
  sections.forEach((section, index) => {
    section.display_score = display[index + 1];
  });
  const limits2 = [.../* @__PURE__ */ new Set([...input.limitations ?? [], ...DEFAULT_AI_LIMITATIONS])];
  const result2 = {
    ai_pattern: {
      assessment_status: "assessed",
      method_status: input.flagged ? "attention" : "pass",
      source: input.source,
      raw_score: input.rawScore,
      raw_margin: input.rawMargin,
      display_score: display[0],
      score_scale: CHECKER_SCORE_SCALE,
      level: level2,
      primary_display_threshold: input.primaryDisplayThreshold,
      secondary_display_threshold: input.secondaryDisplayThreshold,
      flagged: input.flagged,
      flag_reason: input.flagReason,
      strongest_section_index: strongest.index,
      reason: input.reason ?? CHECKER_LEVELS[level2].support,
      limitations: limits2
    },
    sections
  };
  return deepFreeze4(result2);
}
function buildContentFreeSharePayload(input) {
  if (!Number.isInteger(input.wordCount) || input.wordCount < 0) throw new Error("Share word count must be a non-negative integer.");
  const date = new Date(input.generatedAt);
  if (!Number.isFinite(date.valueOf())) throw new Error("Share generation time must be a valid date-time.");
  const payload = {
    version: 1,
    result_id: input.resultId,
    level: input.presented.ai_pattern.level,
    display_score: input.presented.ai_pattern.display_score,
    sections: input.presented.sections.map((section) => ({
      index: section.index,
      raw_score: section.raw_score,
      display_score: section.display_score,
      level: section.level
    })),
    word_count: input.wordCount,
    date: date.toISOString().slice(0, 10),
    model_version: input.modelVersion,
    honesty_line: CHECKER_HONESTY_LINE,
    contains_content: false
  };
  assertContentFree(payload);
  return deepFreeze4(payload);
}
function assertContentFree(value, path = "share") {
  if (Array.isArray(value)) {
    value.forEach((item2, index) => assertContentFree(item2, `${path}[${index}]`));
    return;
  }
  if (typeof value !== "object" || value === null) return;
  for (const [key, item2] of Object.entries(value)) {
    if (CONTENT_KEYS.has(key.toLowerCase())) throw new Error(`${path}.${key} is content-bearing and cannot appear in a share payload.`);
    assertContentFree(item2, `${path}.${key}`);
  }
}
function assertCheckerResultInvariants(result2) {
  if (result2.schema_version !== "1.0" || !/^1\./u.test(result2.contract_version)) throw new Error("Unsupported checker result contract.");
  for (const method2 of result2.methods) if (!METHOD_STATUSES.has(method2.status)) throw new Error(`Unknown method status: ${String(method2.status)}`);
  if (result2.exports.receipt.contains_content !== false) throw new Error("The default receipt must be content-free.");
  if (result2.exports.share.contains_content !== false) throw new Error("The share export must be content-free.");
  if (result2.exports.share.payload) assertContentFree(result2.exports.share.payload);
  if (result2.provenance.safe_fixes.preview_first !== true || result2.provenance.safe_fixes.explicit_approval_required !== true || result2.provenance.safe_fixes.automatic_homoglyph_replacement !== false || result2.provenance.safe_fixes.c2pa_wrapper_protected !== true) {
    throw new Error("Safe-fix and C2PA wrapper invariants were weakened.");
  }
  for (const watermark of result2.provenance.watermarks) {
    if (watermark.method_id === "watermark.anthropic" && (watermark.method_status !== "unsupported" || !["not_available", "not_supported"].includes(watermark.outcome))) {
      throw new Error("watermark.anthropic must remain unsupported until an official interface exists.");
    }
  }
  const ai = result2.axes.ai_pattern;
  if (ai.assessment_status === "assessed") {
    if (!result2.route.model) throw new Error("Only a trained model may set the AI-pattern reading.");
    assertCycle5Identity(result2.route.model);
    if (!result2.sections.length) throw new Error("An assessed result needs scored sections.");
    const ordered = [...result2.sections].sort((a, b) => a.index - b.index);
    ordered.forEach((section, index) => {
      if (section.index !== index || section !== result2.sections[index]) throw new Error("Scored sections must remain in source order.");
      if (!section.band_id) throw new Error(`Section ${section.index} has no measured band identity.`);
      const bandId = section.band_id;
      const expectedLevel = ai.secondary_display_threshold === null && bandId === "uncertain" ? section.level : levelForCycle5Score(section.raw_score, bandId, ai.secondary_display_threshold ?? void 0);
      if (section.level !== expectedLevel || bandId === "uncertain" && ai.secondary_display_threshold === null && !["signal-potentially-ai", "signal-likely-ai"].includes(section.level)) {
        throw new Error(`Section ${section.index} level does not match its raw score and measured band.`);
      }
    });
    const strongest = result2.sections.reduce((best, section) => section.raw_score > best.raw_score ? section : best, result2.sections[0]);
    if (ai.strongest_section_index !== strongest.index || ai.raw_score !== strongest.raw_score || ai.raw_margin !== strongest.raw_margin) throw new Error("The run-wide result does not identify the strongest section.");
    if (ai.level !== strongest.level) throw new Error("The run-wide level does not match the strongest section.");
    if (ai.source !== result2.route.model.identity) throw new Error("The AI-pattern source does not match the executed model.");
    if (result2.source.section_count !== result2.sections.length) throw new Error("The source section count does not match the scored section set.");
    if (ai.method_status !== (ai.flagged ? "attention" : "pass")) throw new Error("The AI method status contradicts its flag state.");
    result2.sections.forEach((section, index) => {
      if (index > 0 && section.start_utf16 < result2.sections[index - 1].end_utf16) throw new Error("Scored section ranges overlap or move backwards.");
      if (section.locator && (section.locator.content_hash !== result2.source.content_hash || section.locator.start_utf16 !== section.start_utf16 || section.locator.end_utf16 !== section.end_utf16)) {
        throw new Error(`Section ${section.index} locator does not match its source or range.`);
      }
    });
    const margins = result2.sections.map((section) => section.raw_margin).sort((a, b) => b - a);
    const primaryFired = margins[0] >= CYCLE5_MODEL_IDENTITY.flagRule.primaryMargin;
    const secondaryFired = margins.length > 1 && margins[1] + CYCLE5_MODEL_IDENTITY.flagRule.secondaryGap >= CYCLE5_MODEL_IDENTITY.flagRule.primaryMargin;
    const expectedFlagged = primaryFired || secondaryFired;
    const expectedReason = primaryFired ? "primary" : secondaryFired ? "secondary" : null;
    if (ai.flagged !== expectedFlagged || ai.flag_reason !== expectedReason) throw new Error("The AI flag state contradicts the recorded Cycle-5 margins.");
    const expected = formatCheckerScoreTexts([
      { rawScore: ai.raw_score, level: ai.level },
      ...result2.sections.map((section) => ({ rawScore: section.raw_score, level: section.level }))
    ]);
    if (ai.display_score !== expected[0] || result2.sections.some((section, index) => section.display_score !== expected[index + 1])) {
      throw new Error("Visible/exported scores were not produced by the run-wide formatter.");
    }
    if (result2.profile === "full_checker" && (!result2.exports.report.available || !result2.exports.report.complete_evidence)) {
      throw new Error("An assessed full-checker result requires a complete report export.");
    }
  } else {
    if (ai.raw_score !== null || ai.raw_margin !== null || ai.display_score !== null || ai.level !== null || ai.flagged !== null || ai.strongest_section_index !== null) {
      throw new Error("An unassessed, withheld or errored AI axis cannot publish a score or level.");
    }
    if (result2.sections.length) throw new Error("An unassessed result cannot publish model-scored sections.");
  }
  if (result2.route.model === null && ai.assessment_status === "assessed") throw new Error("Deterministic evidence cannot set the AI-pattern reading.");
  assertRouteConsistency(result2);
  if (result2.abuse_controls.request_body_logging !== "excluded" && result2.abuse_controls.request_body_logging !== "not_applicable") {
    throw new Error("A checker route may not claim readiness while request-body logging is unconfigured.");
  }
}
function assertRouteConsistency(result2) {
  const { route: route2, abuse_controls: controls } = result2;
  if (route2.kind === "browser_model") {
    if (route2.content_transfer !== "none" || route2.privacy_route !== "browser" || route2.model?.precision !== "int8") throw new Error("Browser-model route metadata is inconsistent.");
  } else if (route2.kind === "eu_server") {
    if (route2.content_transfer !== "eu_server" || route2.consent !== "explicit" || route2.model?.precision !== "fp32") throw new Error("EU-server route metadata is inconsistent.");
    if (!["browser_pow_token", "chrome_extension_challenge_token", "wordpress_challenge_token"].includes(controls.channel_authentication)) throw new Error("EU-server results require their real channel authentication class.");
  } else if (route2.kind === "wordpress_same_site") {
    if (route2.content_transfer !== "same_site" || route2.privacy_route !== "wordpress_local" || controls.channel_authentication !== "same_site_nonce") throw new Error("WordPress same-site route metadata is inconsistent.");
  } else if (route2.kind === "loopback_engine") {
    if (route2.content_transfer !== "loopback" || route2.privacy_route !== "local_service" || controls.channel_authentication !== "loopback_bearer") throw new Error("Loopback route metadata is inconsistent.");
  } else if (route2.kind === "deterministic_only") {
    if (route2.content_transfer !== "none" || route2.model !== null || result2.axes.ai_pattern.assessment_status === "assessed") throw new Error("A deterministic-only route cannot publish a model result.");
  }
}
function assertCycle5Identity(model) {
  if (model.identity !== CYCLE5_MODEL_IDENTITY.identity || model.segmentation_contract !== CYCLE5_MODEL_IDENTITY.segmentationContract || model.input_contract !== CYCLE5_MODEL_IDENTITY.inputContract || model.features_contract !== CYCLE5_MODEL_IDENTITY.featuresContract || model.scoring_contract !== CYCLE5_MODEL_IDENTITY.scoringContract || model.flag_rule.expression !== CYCLE5_MODEL_IDENTITY.flagRule.expression || model.flag_rule.primary_margin !== CYCLE5_MODEL_IDENTITY.flagRule.primaryMargin || model.flag_rule.secondary_gap !== CYCLE5_MODEL_IDENTITY.flagRule.secondaryGap) throw new Error("The assessed result does not identify the current Cycle-5 contracts and margin rule.");
  if (model.precision === "fp32" && model.registry_identity !== CYCLE5_MODEL_IDENTITY.serverRegistryIdentity) {
    throw new Error("The fp32 server route must identify the Cycle-5 server registry entry.");
  }
}
function finiteNumber(value, name) {
  if (!Number.isFinite(value)) throw new RangeError(`${name} must be finite.`);
  return value;
}
function deepFreeze4(value) {
  if (typeof value !== "object" || value === null || Object.isFrozen(value)) return value;
  for (const child of Object.values(value)) deepFreeze4(child);
  return Object.freeze(value);
}
var DEFAULT_SUPPORT = "https://opace.agency/tools/ai/content-verification-integrity/";
var LEGACY_NO_MODEL_LIMITATIONS = /* @__PURE__ */ new Set([
  "No trained model ran on this text, so the AI-pattern reading is not assessed.",
  "This reduced deterministic result is not full-checker parity."
]);
var withoutLegacyNoModelLimitations = (values) => values.filter((value) => !LEGACY_NO_MODEL_LIMITATIONS.has(value));
function composeCycle5BrowserCheckerResult(primitive, score, sourceText, options) {
  if (primitive.axes.ai_pattern.assessment_status !== "not_assessed" || primitive.route.model !== null) {
    throw new Error("The on-device composer requires a deterministic primitive result with an unassessed AI axis.");
  }
  if (prefixedSha256(sourceText) !== primitive.source.content_hash) {
    throw new Error("The deterministic and on-device model results do not describe the same source bytes.");
  }
  const presented = presentCycle5Result({
    source: CYCLE5_MODEL_IDENTITY.identity,
    rawScore: score.rawScore,
    rawMargin: score.rawMargin,
    bandId: score.sections.find((section) => section.rawScore === score.rawScore).bandId,
    primaryDisplayThreshold: CYCLE5_PRIMARY_DISPLAY_THRESHOLD,
    secondaryDisplayThreshold: CYCLE5_SECONDARY_DISPLAY_THRESHOLD,
    flagged: score.flagged,
    flagReason: score.flagReason,
    sections: score.sections.map((section) => ({
      index: section.index,
      startUtf16: section.startUtf16,
      endUtf16: section.endUtf16,
      wordCount: section.wordCount,
      rawScore: section.rawScore,
      rawMargin: section.rawMargin,
      bandId: section.bandId,
      passage: section.passage,
      evidence: [{
        id: `cycle5-section-${section.index}`,
        kind: "trained_model",
        summary: section.rawScore === score.rawScore ? "The strongest passage shaped the result." : "This passage was scored by the same trained model.",
        detail: "The score and level beside this exact section come from the Cycle-5 model; deterministic checks did not set them.",
        basis: "tier3-cycle5-v1, int8, onnxruntime-web WASM"
      }]
    }))
  });
  const generatedAt = options.generatedAt ?? (/* @__PURE__ */ new Date()).toISOString();
  const supportDestination = options.supportDestination ?? DEFAULT_SUPPORT;
  const share = buildContentFreeSharePayload({
    resultId: options.resultId,
    generatedAt,
    wordCount: primitive.source.word_count,
    modelVersion: CYCLE5_MODEL_IDENTITY.identity,
    presented
  });
  const detector = {
    id: "detector.cycle5",
    category: "detector",
    provider_or_method: "Opace Cycle-5 AI-pattern model",
    version: CYCLE5_MODEL_IDENTITY.identity,
    status: presented.ai_pattern.method_status,
    availability: "available",
    native_outcome: presented.ai_pattern.level,
    score: score.rawScore,
    score_scale: { id: "zero_to_one_pattern_similarity" },
    threshold: {
      scoring_contract: CYCLE5_MODEL_IDENTITY.scoringContract,
      primary_margin: CYCLE5_MODEL_IDENTITY.flagRule.primaryMargin,
      secondary_gap: CYCLE5_MODEL_IDENTITY.flagRule.secondaryGap
    },
    segments: presented.sections.map((section) => ({ index: section.index, raw_margin: section.raw_margin })),
    evidence: [{ type: "strongest_section", index: presented.ai_pattern.strongest_section_index }],
    limitations: [...presented.ai_pattern.limitations],
    started_at: generatedAt,
    completed_at: generatedAt,
    privacy_route: "browser"
  };
  const result2 = {
    ...primitive,
    result_id: options.resultId,
    profile: "full_checker",
    generated_at: generatedAt,
    contains_content: true,
    source: {
      ...primitive.source,
      normalised_hash: primitive.source.normalised_hash ?? primitive.source.content_hash,
      character_count: sourceText.length,
      section_count: presented.sections.length
    },
    route: {
      kind: "browser_model",
      location: `${options.surface}, this browser`,
      content_transfer: "none",
      privacy_route: "browser",
      retention: { source: "session", result: "session", statement: "The draft and result stay in this browser view and are not sent for scoring." },
      consent: "explicit",
      model: {
        identity: CYCLE5_MODEL_IDENTITY.identity,
        registry_identity: null,
        precision: "int8",
        artefact_hash: `sha256:${CYCLE5_MODEL_SHA256}`,
        segmentation_contract: CYCLE5_MODEL_IDENTITY.segmentationContract,
        input_contract: CYCLE5_MODEL_IDENTITY.inputContract,
        features_contract: CYCLE5_MODEL_IDENTITY.featuresContract,
        scoring_contract: CYCLE5_MODEL_IDENTITY.scoringContract,
        flag_rule: {
          expression: CYCLE5_MODEL_IDENTITY.flagRule.expression,
          primary_margin: CYCLE5_MODEL_IDENTITY.flagRule.primaryMargin,
          secondary_gap: CYCLE5_MODEL_IDENTITY.flagRule.secondaryGap
        }
      },
      transport: { endpoint_class: "verified_static_asset_download", region: null, requests: 0, words_sent: 0, processed: "in browser", retained: "not retained" }
    },
    axes: {
      ...primitive.axes,
      ai_pattern: presented.ai_pattern,
      text_integrity: { ...primitive.axes.text_integrity, limitations: withoutLegacyNoModelLimitations(primitive.axes.text_integrity.limitations) },
      editorial: { ...primitive.axes.editorial, limitations: withoutLegacyNoModelLimitations(primitive.axes.editorial.limitations) }
    },
    sections: presented.sections,
    methods: [detector, ...primitive.methods.filter((method) => method.id !== "detector.cycle5" && method.id !== "detector.local")],
    exports: {
      ...primitive.exports,
      receipt: { ...primitive.exports.receipt, available: true, contains_content: false },
      share: { available: true, contains_content: false, payload: share },
      report: {
        available: true,
        format: options.reportFormat,
        contains_content: true,
        explicit_user_action: true,
        complete_evidence: true,
        product_identity: "Opace AI Content Integrity",
        support_destination: supportDestination
      }
    },
    abuse_controls: {
      max_words: null,
      max_characters: options.maxCharacters,
      max_request_bytes: null,
      explicit_capture: "enforced",
      consent_before_transfer: "enforced",
      refuse_not_truncate: "enforced",
      cancellation: "enforced",
      channel_authentication: "not_applicable",
      proof_of_work: "not_applicable",
      origin_validation: "enforced",
      per_ip_limit: "not_applicable",
      per_site_limit: "not_applicable",
      per_connection_limit: "not_applicable",
      global_inference_limit: "not_applicable",
      request_body_logging: "not_applicable",
      unexpected_network_requests: "blocked",
      fallback: "not_configured",
      kill_switch: "not_applicable"
    },
    limitations: [.../* @__PURE__ */ new Set([
      ...withoutLegacyNoModelLimitations(primitive.limitations),
      ...presented.ai_pattern.limitations,
      "The on-device model and vocabulary are fetched only after explicit consent; draft text is never transferred for this route."
    ])]
  };
  assertCheckerResultInvariants(result2);
  return Object.freeze(result2);
}
function composeCycle5ServerCheckerResult(primitive, score, sourceText, options) {
  const browserShape = { ...score, provider: "onnxruntime-web-wasm" };
  const composed = structuredClone(composeCycle5BrowserCheckerResult(primitive, browserShape, sourceText, {
    surface: options.surface,
    resultId: options.resultId,
    reportFormat: options.reportFormat,
    maxCharacters: options.maxCharacters,
    generatedAt: options.generatedAt,
    supportDestination: options.supportDestination
  }));
  composed.route = {
    kind: "eu_server",
    location: "Opace EU server, europe-west1",
    content_transfer: "eu_server",
    privacy_route: "hub_provider",
    retention: { source: "request_only", result: "none", statement: "The text was processed once in EU server memory and was not retained." },
    consent: "explicit",
    model: {
      identity: CYCLE5_MODEL_IDENTITY.identity,
      registry_identity: "tier3-cycle5-full",
      precision: "fp32",
      artefact_hash: "sha256:45e00978b10d1df6b24db3770a228701f6c5d63e99d96aa1c0458e5932566057",
      segmentation_contract: CYCLE5_MODEL_IDENTITY.segmentationContract,
      input_contract: CYCLE5_MODEL_IDENTITY.inputContract,
      features_contract: CYCLE5_MODEL_IDENTITY.featuresContract,
      scoring_contract: CYCLE5_MODEL_IDENTITY.scoringContract,
      flag_rule: {
        expression: CYCLE5_MODEL_IDENTITY.flagRule.expression,
        primary_margin: CYCLE5_MODEL_IDENTITY.flagRule.primaryMargin,
        secondary_gap: CYCLE5_MODEL_IDENTITY.flagRule.secondaryGap
      }
    },
    transport: { endpoint_class: "first_party_browser", region: "europe-west1", requests: options.requestCount ?? 3, words_sent: score.wordCount, processed: "once", retained: "not retained" }
  };
  const detector = composed.methods.find((method) => method.id === "detector.cycle5");
  if (detector) {
    detector.privacy_route = "hub_provider";
    detector.evidence = [{ type: "strongest_section", index: composed.axes.ai_pattern.strongest_section_index, route: "Opace EU server", precision: "fp32" }];
  }
  composed.abuse_controls = {
    max_words: options.maxWords,
    max_characters: options.maxCharacters,
    max_request_bytes: null,
    explicit_capture: "enforced",
    consent_before_transfer: "enforced",
    refuse_not_truncate: "enforced",
    cancellation: "enforced",
    channel_authentication: "chrome_extension_challenge_token",
    proof_of_work: "enforced",
    origin_validation: "enforced",
    per_ip_limit: "enforced",
    per_site_limit: "not_applicable",
    per_connection_limit: "enforced",
    global_inference_limit: "enforced",
    request_body_logging: "excluded",
    unexpected_network_requests: "blocked",
    fallback: "enforced",
    kill_switch: "enforced"
  };
  composed.limitations = [.../* @__PURE__ */ new Set([
    ...withoutLegacyNoModelLimitations(composed.limitations),
    "This route transfers the draft only after explicit choice and optional host permission; the service processes it once in EU memory and does not retain it.",
    "If this service route is unavailable or refused, the same screen offers the on-device Cycle-5 route."
  ])];
  assertCheckerResultInvariants(composed);
  return Object.freeze(composed);
}
var MODEL_BUILD = "45e00978b10d1df6";
var ROUNDING_TOLERANCE = 50001e-9;
var countWords = (value) => value.match(/\S+/gu)?.length ?? 0;
var probabilityFromMargin2 = (margin) => 1 / (1 + Math.exp(-margin / CYCLE5_TEMPERATURE));
var bandFor2 = (score) => CYCLE5_BANDS.find((band) => score >= band.min).id;
var record = (value) => {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error("cycle5_server_response_invalid");
  return value;
};
var number = (value, field) => {
  if (typeof value !== "number" || !Number.isFinite(value)) throw new Error(`cycle5_server_${field}_invalid`);
  return value;
};
var integer = (value, field) => {
  const parsed = number(value, field);
  if (!Number.isInteger(parsed)) throw new Error(`cycle5_server_${field}_invalid`);
  return parsed;
};
var exact = (actual, expected, field) => {
  if (actual !== expected) throw new Error(`cycle5_server_${field}_mismatch`);
};
var sameRoundedProbability = (reported, margin, field) => {
  const reconstructed = probabilityFromMargin2(margin);
  if (Math.abs(reported - reconstructed) > ROUNDING_TOLERANCE) throw new Error(`cycle5_server_${field}_probability_mismatch`);
  return reconstructed;
};
function parseCycle5ChromeServerResponse(value, sourceText) {
  const body = record(value);
  exact(body.channel, "chrome-extension-v1", "channel");
  exact(body.model, "tier3-cycle5-v1", "model");
  exact(body.model_build, MODEL_BUILD, "model_build");
  exact(body.precision, "fp32", "precision");
  exact(body.segmentation_contract, "segments-v3", "segmentation_contract");
  exact(body.input_normalisation, "raw-v1", "input_contract");
  exact(body.features_contract, "features-v1", "features_contract");
  exact(body.scoring, "margin-v1", "scoring_contract");
  exact(body.aggregation, "max", "aggregation");
  exact(body.threshold, null, "probability_threshold");
  exact(number(body.threshold_margin, "threshold_margin"), CYCLE5_PRIMARY_MARGIN, "threshold_margin");
  exact(number(body.secondary_gap, "secondary_gap"), CYCLE5_SECONDARY_GAP, "secondary_gap");
  exact(body.processed, "server", "processed");
  exact(body.retained, "nothing", "retained");
  exact(body.truncated, false, "truncated");
  const wordCount = countWords(sourceText);
  exact(integer(body.word_count, "word_count"), wordCount, "word_count");
  exact(integer(body.words_sent, "words_sent"), wordCount, "words_sent");
  if (!Array.isArray(body.segments) || body.segments.length === 0) throw new Error("cycle5_server_segments_invalid");
  exact(integer(body.segment_count, "segment_count"), body.segments.length, "segment_count");
  const sections = body.segments.map((candidate2, position) => {
    const segment = record(candidate2);
    exact(integer(segment.index, `segment_${position}_index`), position, `segment_${position}_index`);
    const startUtf16 = integer(segment.char_start, `segment_${position}_start`);
    const endUtf16 = integer(segment.char_end, `segment_${position}_end`);
    if (startUtf16 < 0 || endUtf16 <= startUtf16 || endUtf16 > sourceText.length) throw new Error(`cycle5_server_segment_${position}_offset_invalid`);
    const passage = sourceText.slice(startUtf16, endUtf16);
    const segmentWordCount = integer(segment.words, `segment_${position}_words`);
    exact(segmentWordCount, countWords(passage), `segment_${position}_words`);
    const rawMargin = number(segment.margin, `segment_${position}_margin`);
    const reportedProbability = number(segment.probability_ai, `segment_${position}_probability`);
    const rawScore = sameRoundedProbability(reportedProbability, rawMargin, `segment_${position}`);
    exact(segment.flagged, rawMargin >= CYCLE5_PRIMARY_MARGIN, `segment_${position}_flagged`);
    exact(segment.truncated, false, `segment_${position}_truncated`);
    return {
      index: position,
      startUtf16,
      endUtf16,
      wordCount: segmentWordCount,
      tokenCount: integer(segment.tokens_scored, `segment_${position}_tokens`),
      rawScore,
      rawMargin,
      bandId: bandFor2(rawScore),
      passage
    };
  });
  const ranked = [...sections].sort((left, right) => right.rawMargin - left.rawMargin);
  const strongest = ranked[0];
  const runnerUp = ranked[1];
  const primary = strongest.rawMargin >= CYCLE5_PRIMARY_MARGIN;
  const secondary = Boolean(runnerUp && runnerUp.rawMargin + CYCLE5_SECONDARY_GAP >= CYCLE5_PRIMARY_MARGIN);
  const flagged = primary || secondary;
  const flagReason = primary ? "primary" : secondary ? "secondary" : null;
  exact(body.flagged, flagged, "flagged");
  exact(body.flag_reason, flagReason, "flag_reason");
  exact(integer(body.strongest_segment, "strongest_segment"), strongest.index, "strongest_segment");
  exact(number(body.margin, "margin"), strongest.rawMargin, "margin");
  sameRoundedProbability(number(body.probability_ai, "probability"), strongest.rawMargin, "document");
  if (runnerUp) {
    exact(integer(body.second_segment, "second_segment"), runnerUp.index, "second_segment");
    exact(number(body.second_margin, "second_margin"), runnerUp.rawMargin, "second_margin");
    sameRoundedProbability(number(body.second_probability_ai, "second_probability"), runnerUp.rawMargin, "second");
  } else {
    exact(body.second_segment, null, "second_segment");
    exact(body.second_margin, null, "second_margin");
    exact(body.second_probability_ai, null, "second_probability");
  }
  return {
    status: "scored",
    provider: "opace-eu-server-fp32",
    modelVersion: "tier3-cycle5-v1",
    modelBuild: MODEL_BUILD,
    rawScore: strongest.rawScore,
    rawMargin: strongest.rawMargin,
    flagged,
    flagReason,
    wordCount,
    sections
  };
}

// node_modules/@opace/content-integrity-core/dist/bundle.js
var K2 = new Uint32Array([
  1116352408,
  1899447441,
  3049323471,
  3921009573,
  961987163,
  1508970993,
  2453635748,
  2870763221,
  3624381080,
  310598401,
  607225278,
  1426881987,
  1925078388,
  2162078206,
  2614888103,
  3248222580,
  3835390401,
  4022224774,
  264347078,
  604807628,
  770255983,
  1249150122,
  1555081692,
  1996064986,
  2554220882,
  2821834349,
  2952996808,
  3210313671,
  3336571891,
  3584528711,
  113926993,
  338241895,
  666307205,
  773529912,
  1294757372,
  1396182291,
  1695183700,
  1986661051,
  2177026350,
  2456956037,
  2730485921,
  2820302411,
  3259730800,
  3345764771,
  3516065817,
  3600352804,
  4094571909,
  275423344,
  430227734,
  506948616,
  659060556,
  883997877,
  958139571,
  1322822218,
  1537002063,
  1747873779,
  1955562222,
  2024104815,
  2227730452,
  2361852424,
  2428436474,
  2756734187,
  3204031479,
  3329325298
]);
var rotr2 = (x, n) => x >>> n | x << 32 - n;
function utf8Bytes2(value) {
  return new TextEncoder().encode(value);
}
function sha256Hex2(value) {
  const source = utf8Bytes2(value);
  const bitLength = source.length * 8;
  const paddedLength = Math.ceil((source.length + 9) / 64) * 64;
  const bytes = new Uint8Array(paddedLength);
  bytes.set(source);
  bytes[source.length] = 128;
  const view = new DataView(bytes.buffer);
  view.setUint32(paddedLength - 4, bitLength >>> 0, false);
  view.setUint32(paddedLength - 8, Math.floor(bitLength / 4294967296), false);
  const h = new Uint32Array([1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924, 528734635, 1541459225]);
  const w = new Uint32Array(64);
  for (let offset = 0; offset < paddedLength; offset += 64) {
    for (let i = 0; i < 16; i++) w[i] = view.getUint32(offset + i * 4, false);
    for (let i = 16; i < 64; i++) {
      const a2 = w[i - 15], b2 = w[i - 2];
      w[i] = (rotr2(a2, 7) ^ rotr2(a2, 18) ^ a2 >>> 3) + w[i - 16] + (rotr2(b2, 17) ^ rotr2(b2, 19) ^ b2 >>> 10) + w[i - 7] >>> 0;
    }
    let [a, b, c, d, e, f, g, hh] = h;
    for (let i = 0; i < 64; i++) {
      const s1 = rotr2(e, 6) ^ rotr2(e, 11) ^ rotr2(e, 25);
      const ch = e & f ^ ~e & g;
      const t1 = hh + s1 + ch + K2[i] + w[i] >>> 0;
      const s0 = rotr2(a, 2) ^ rotr2(a, 13) ^ rotr2(a, 22);
      const maj = a & b ^ a & c ^ b & c;
      const t2 = s0 + maj >>> 0;
      hh = g;
      g = f;
      f = e;
      e = d + t1 >>> 0;
      d = c;
      c = b;
      b = a;
      a = t1 + t2 >>> 0;
    }
    h[0] = h[0] + a >>> 0;
    h[1] = h[1] + b >>> 0;
    h[2] = h[2] + c >>> 0;
    h[3] = h[3] + d >>> 0;
    h[4] = h[4] + e >>> 0;
    h[5] = h[5] + f >>> 0;
    h[6] = h[6] + g >>> 0;
    h[7] = h[7] + hh >>> 0;
  }
  return Array.from(h, (n) => n.toString(16).padStart(8, "0")).join("");
}
var prefixedSha2562 = (value) => `sha256:${sha256Hex2(value)}`;
var MSG_INVISIBLE2 = (what) => `An invisible ${what} is present.`;
var MSG_BIDI2 = "A bidirectional formatting control is present.";
var BIDI_LIMIT2 = "Bidirectional controls are required for correct display of mixed right-to-left and left-to-right text.";
var CARRIER_RULES2 = [
  // Soft hyphen and combining grapheme joiner
  { from: 173, name: "SOFT HYPHEN", severity: "low", fix: "remove", message: "A discretionary soft hyphen is present." },
  { from: 847, name: "COMBINING GRAPHEME JOINER", severity: "medium", fix: "remove", message: MSG_INVISIBLE2("combining grapheme joiner"), limitation: "The combining grapheme joiner has rare legitimate uses in collation and diacritic ordering." },
  // Script-specific format characters
  { from: 1564, name: "ARABIC LETTER MARK", severity: "medium", fix: "review", message: MSG_BIDI2, limitation: BIDI_LIMIT2 },
  { from: 1807, name: "SYRIAC ABBREVIATION MARK", severity: "medium", fix: "review", message: "A Syriac abbreviation mark format character is present.", limitation: "This character is legitimate inside Syriac-script text." },
  { from: 2192, to: 2193, name: (cp) => cp === 2192 ? "ARABIC POUND MARK ABOVE" : "ARABIC PIASTRE MARK ABOVE", severity: "medium", fix: "review", message: "An Arabic prepended format mark is present.", limitation: "This character is legitimate inside Arabic-script text." },
  { from: 2274, name: "ARABIC DISPUTED END OF AYAH", severity: "medium", fix: "review", message: "An Arabic prepended format mark is present.", limitation: "This character is legitimate inside Arabic-script text." },
  { from: 6155, to: 6157, name: (cp) => `MONGOLIAN FREE VARIATION SELECTOR-${cp - 6154}`, severity: "medium", fix: "remove", message: MSG_INVISIBLE2("Mongolian free variation selector"), context: "variation", limitation: "Free variation selectors are legitimate inside Mongolian-script text." },
  { from: 6158, name: "MONGOLIAN VOWEL SEPARATOR", severity: "medium", fix: "remove", message: MSG_INVISIBLE2("Mongolian vowel separator"), limitation: "This character is legitimate inside Mongolian-script text." },
  { from: 6159, name: "MONGOLIAN FREE VARIATION SELECTOR-4", severity: "medium", fix: "remove", message: MSG_INVISIBLE2("Mongolian free variation selector"), context: "variation", limitation: "Free variation selectors are legitimate inside Mongolian-script text." },
  // Zero-width and joining controls
  { from: 8203, name: "ZERO WIDTH SPACE", severity: "medium", fix: "remove", message: MSG_INVISIBLE2("zero-width space") },
  { from: 8204, name: "ZERO WIDTH NON-JOINER", severity: "medium", fix: "remove", message: MSG_INVISIBLE2("zero-width non-joiner"), context: "joiner", limitation: "The zero-width non-joiner is standard orthography in Persian and several Indic languages." },
  { from: 8205, name: "ZERO WIDTH JOINER", severity: "medium", fix: "remove", message: MSG_INVISIBLE2("zero-width joiner"), context: "joiner", limitation: "The zero-width joiner is standard in emoji sequences and several complex scripts." },
  // Bidirectional controls
  { from: 8206, name: "LEFT-TO-RIGHT MARK", severity: "medium", fix: "review", message: MSG_BIDI2, limitation: BIDI_LIMIT2 },
  { from: 8207, name: "RIGHT-TO-LEFT MARK", severity: "medium", fix: "review", message: MSG_BIDI2, limitation: BIDI_LIMIT2 },
  { from: 8234, to: 8238, name: (cp) => ["LEFT-TO-RIGHT EMBEDDING", "RIGHT-TO-LEFT EMBEDDING", "POP DIRECTIONAL FORMATTING", "LEFT-TO-RIGHT OVERRIDE", "RIGHT-TO-LEFT OVERRIDE"][cp - 8234], severity: "medium", fix: "review", message: MSG_BIDI2, limitation: BIDI_LIMIT2 },
  { from: 8294, to: 8297, name: (cp) => ["LEFT-TO-RIGHT ISOLATE", "RIGHT-TO-LEFT ISOLATE", "FIRST STRONG ISOLATE", "POP DIRECTIONAL ISOLATE"][cp - 8294], severity: "medium", fix: "review", message: MSG_BIDI2, limitation: BIDI_LIMIT2 },
  // Word joiner, invisible operators and deprecated format characters
  { from: 8288, name: "WORD JOINER", severity: "medium", fix: "remove", message: MSG_INVISIBLE2("word joiner") },
  { from: 8289, to: 8292, name: (cp) => ["FUNCTION APPLICATION", "INVISIBLE TIMES", "INVISIBLE SEPARATOR", "INVISIBLE PLUS"][cp - 8289], severity: "medium", fix: "remove", message: MSG_INVISIBLE2("mathematical operator character"), limitation: "Invisible operators are legitimate inside machine-generated mathematical notation." },
  { from: 8298, to: 8303, name: (cp) => ["INHIBIT SYMMETRIC SWAPPING", "ACTIVATE SYMMETRIC SWAPPING", "INHIBIT ARABIC FORM SHAPING", "ACTIVATE ARABIC FORM SHAPING", "NATIONAL DIGIT SHAPES", "NOMINAL DIGIT SHAPES"][cp - 8298], severity: "medium", fix: "remove", message: "A deprecated invisible format character is present.", limitation: "These characters are deprecated by Unicode and have no place in modern interchange text." },
  // BOM, interlinear annotation, replacement
  { from: 65279, name: "BYTE ORDER MARK", severity: "low", fix: "remove", message: "A byte-order mark is present." },
  { from: 65529, to: 65531, name: (cp) => ["INTERLINEAR ANNOTATION ANCHOR", "INTERLINEAR ANNOTATION SEPARATOR", "INTERLINEAR ANNOTATION TERMINATOR"][cp - 65529], severity: "medium", fix: "review", message: "An interlinear annotation control is present.", limitation: "Interlinear annotation controls are legitimate in Japanese ruby markup pipelines." },
  { from: 65533, name: "REPLACEMENT CHARACTER", severity: "high", fix: "review", message: "A replacement character may indicate damaged text." },
  // Supplementary-plane format characters
  { from: 69821, name: "KAITHI NUMBER SIGN", severity: "medium", fix: "review", message: "A Kaithi number-sign format character is present.", limitation: "This character is legitimate inside Kaithi-script text." },
  { from: 69837, name: "KAITHI NUMBER SIGN ABOVE", severity: "medium", fix: "review", message: "A Kaithi number-sign format character is present.", limitation: "This character is legitimate inside Kaithi-script text." },
  // Tag characters: the classic covert payload carrier
  { from: 917505, name: "LANGUAGE TAG", severity: "high", fix: "remove", message: "A deprecated invisible language tag is present." },
  { from: 917536, to: 917631, name: (cp) => cp === 917631 ? "CANCEL TAG" : `TAG ${String.fromCodePoint(cp - 917504) === " " ? "SPACE" : `CHARACTER '${String.fromCodePoint(cp - 917504)}'`}`, severity: "high", fix: "remove", message: "An invisible tag character is present; tag runs are a known covert payload carrier.", limitation: "Tag characters have no legitimate use in ordinary interchange text outside emoji flag sequences." },
  // Variation selectors
  { from: 65024, to: 65039, name: (cp) => `VARIATION SELECTOR-${cp - 65024 + 1}`, severity: "medium", fix: "remove", message: MSG_INVISIBLE2("variation selector"), context: "variation", limitation: "Variation selectors are legitimate after emoji-capable and CJK base characters." },
  { from: 917760, to: 917999, name: (cp) => `VARIATION SELECTOR-${cp - 917760 + 17}`, severity: "medium", fix: "review", message: MSG_INVISIBLE2("supplementary variation selector"), context: "variation_sup", limitation: "Supplementary variation selectors are legitimate after CJK ideographs to select registered glyph variants." },
  // Space separators beyond U+0020
  { from: 160, name: "NO-BREAK SPACE", severity: "note", fix: "space", message: "A non-breaking space is present.", limitation: "Non-breaking spaces are standard French and general typographic practice." },
  { from: 5760, name: "OGHAM SPACE MARK", severity: "low", fix: "space", message: "An unusual space character is present.", limitation: "This character is legitimate inside Ogham-script text." },
  { from: 8192, to: 8200, name: (cp) => ["EN QUAD", "EM QUAD", "EN SPACE", "EM SPACE", "THREE-PER-EM SPACE", "FOUR-PER-EM SPACE", "SIX-PER-EM SPACE", "FIGURE SPACE", "PUNCTUATION SPACE"][cp - 8192], severity: "low", fix: "space", message: "A typographic space that substitutes for an ordinary space is present.", limitation: "Fixed-width spaces are legitimate in carefully typeset material." },
  { from: 8201, name: "THIN SPACE", severity: "note", fix: "space", message: "A thin space is present.", limitation: "Thin spaces are standard French and general typographic practice." },
  { from: 8202, name: "HAIR SPACE", severity: "low", fix: "space", message: "A hair space that substitutes for an ordinary space is present.", limitation: "Hair spaces are legitimate in carefully typeset material." },
  { from: 8239, name: "NARROW NO-BREAK SPACE", severity: "note", fix: "space", message: "A narrow no-break space is present.", limitation: "Narrow no-break spaces are standard French punctuation spacing and appear in Mongolian text." },
  { from: 8287, name: "MEDIUM MATHEMATICAL SPACE", severity: "note", fix: "space", message: "A medium mathematical space is present.", limitation: "This space is legitimate inside typeset mathematical notation." },
  { from: 12288, name: "IDEOGRAPHIC SPACE", severity: "note", fix: "space", message: "An ideographic space is present.", limitation: "Ideographic spaces are standard in Chinese and Japanese text." },
  // Line and paragraph separators
  { from: 8232, name: "LINE SEPARATOR", severity: "low", fix: "review", message: "A Unicode line separator is present instead of a conventional line break." },
  { from: 8233, name: "PARAGRAPH SEPARATOR", severity: "low", fix: "review", message: "A Unicode paragraph separator is present instead of a conventional line break." }
];
var TABLE2 = /* @__PURE__ */ new Map();
for (const rule of CARRIER_RULES2) {
  for (let cp = rule.from; cp <= (rule.to ?? rule.from); cp++) {
    TABLE2.set(cp, { name: typeof rule.name === "function" ? rule.name(cp) : rule.name, severity: rule.severity, fix: rule.fix, message: rule.message, context: rule.context, limitation: rule.limitation });
  }
}
var NAME_STOPLIST2 = new Set("The A An This That These Those It He She They We You I In On At For To From With By Of And But Or Nor If As Is Are Was Were Be Been Not No Yes See Run New Our Your Their His Her Its My Do Does Did Will Would Can Could Should May Might Must Have Has Had So Then There Here What Which Who Whose When Where Why How All Any Each Per Both More Most Some Such Other Also Just Only Now Today Yesterday Tomorrow Please Note".split(" "));
var TIER12 = {
  "delve": "explore, dig into, look at",
  "tapestry": "describe the actual complexity",
  "paradigm": "model, approach, framework",
  "beacon": "rewrite entirely",
  "robust": "strong, reliable, solid",
  "comprehensive": "thorough, complete, full",
  "cutting-edge": "latest, newest, advanced",
  "pivotal": "important, key, critical",
  "meticulous": "careful, detailed, precise",
  "meticulously": "carefully, precisely",
  "seamless": "smooth, easy, without friction",
  "seamlessly": "smoothly, easily",
  "game-changer": "describe what changed",
  "game-changing": "describe what changed",
  "nestled": "is located, sits",
  "vibrant": "describe what makes it active",
  "thriving": "growing, active",
  "bustling": "busy, active",
  "intricate": "complex, detailed",
  "intricacies": "complexities, details",
  "ever-evolving": "changing, growing",
  "enduring": "lasting, long-running",
  "daunting": "hard, difficult",
  "holistic": "complete, full, whole",
  "holistically": "completely, fully",
  "actionable": "practical, useful, concrete",
  "impactful": "effective, significant",
  "learnings": "lessons, findings, takeaways",
  "synergy": "describe the combined effect",
  "synergies": "describe the combined effect",
  "interplay": "relationship, connection",
  "symphony": "describe the coordination",
  "embrace": "adopt, accept, use",
  // 2026.08.3 owner-docs tier A additions (OWNER-DOCS-TELLS.md §8).
  "enigma": "mystery, puzzle",
  "labyrinth": "maze, tangle",
  "top-notch": "excellent, first-rate"
};
var TIER22 = {
  "harness": "use, take advantage of",
  "navigate": "work through, handle",
  "navigating": "working through, handling",
  "foster": "encourage, support, build",
  "elevate": "improve, raise, strengthen",
  "unleash": "release, enable, unlock",
  "streamline": "simplify, speed up",
  "empower": "enable, let, allow",
  "bolster": "support, strengthen",
  "spearhead": "lead, drive, run",
  "resonate": "connect with, appeal to",
  "resonates": "connects with, appeals to",
  "revolutionize": "change, transform",
  "facilitate": "enable, help, allow",
  "facilitates": "enables, helps, allows",
  "underpin": "support, form the basis of",
  "nuanced": "specific, subtle, detailed",
  "crucial": "important, key, necessary",
  "multifaceted": "describe the actual facets",
  "ecosystem": "system, community, network",
  "myriad": "many, numerous",
  "plethora": "many, a lot of",
  "encompass": "include, cover, span",
  "catalyze": "start, trigger, accelerate",
  "reimagine": "rethink, redesign, rebuild",
  "galvanize": "motivate, rally, push",
  "augment": "add to, expand, supplement",
  "cultivate": "build, develop, grow",
  "illuminate": "clarify, explain, show",
  "elucidate": "explain, clarify",
  "juxtapose": "compare, contrast",
  "transformative": "describe what changed",
  "transformation": "describe what changed",
  "cornerstone": "foundation, basis, key part",
  "paramount": "most important, top priority",
  "poised": "ready, set, about to",
  "burgeoning": "growing, emerging",
  "nascent": "new, early-stage",
  "quintessential": "typical, classic, defining",
  "overarching": "main, central, broad",
  "quietly": "cut, or name the concrete contrast",
  "underpinning": "basis, foundation",
  "underpinnings": "basis, foundations",
  "paradigm-shifting": "describe what shifted",
  // 2026.08.3 owner-docs additions (medium FP → cluster-scored tier 2).
  "revolutionary": "describe what changed",
  "ai-powered": "say what the AI part actually does"
};
var TIER32 = [
  "significant",
  "significantly",
  "innovative",
  "innovation",
  "effective",
  "effectively",
  "dynamic",
  "dynamics",
  "scalable",
  "scalability",
  "compelling",
  "unprecedented",
  "exceptional",
  "exceptionally",
  "remarkable",
  "remarkably",
  "sophisticated",
  "instrumental",
  "world-class",
  "state-of-the-art",
  "best-in-class",
  "verbatim"
];
var ISSUE_WEIGHTS2 = {
  "tier1": 5,
  "tier1-clarity": 3,
  "tier2": 3,
  "tier3": 2,
  "transition": 2,
  "chatbot": 8,
  "sycophantic": 8,
  "filler": 2,
  "generic-conclusion": 3,
  "lets-construction": 2,
  "reasoning-artifact": 6,
  "acknowledgment-loop": 3,
  "significance-inflation": 4,
  "vague-attribution": 5,
  "hollow-intensifier": 2,
  "emotional-flatline": 2,
  "lingering-attention": 3,
  "novelty-inflation": 3,
  "cutoff-disclaimer": 10,
  "template-phrase": 3,
  "false-concession": 2,
  "rhetorical-question": 2,
  "confidence-calibration": 2,
  "em-dash-density": 4,
  "not-just-contrast": 6,
  "uniform-sections": 5,
  "uniform-list-items": 4,
  "sentence-flatline": 5,
  "uniformity": 5,
  "formatting": 3,
  "tier3-phrase": 3,
  "tier3-phrase-cluster": 12,
  "hashtag-stuff": 12,
  "bullet-np-list": 10,
  "hedge-stack": 6,
  "future-narrative": 12,
  "real-actual-inflation": 5,
  "social-cta-closer": 8,
  "formulaic-opener": 8,
  "speculative-opener": 8,
  "title-case-header": 4,
  "parenthetical-hedge": 3,
  "smart-punct-signature": 6,
  "punct-distribution": 6,
  "fnword-trigram-entropy": 5,
  "cross-para-burstiness": 5,
  "normalization-flag": 9,
  "low-ttr": 3,
  "ai-placeholder": 10,
  "ai-citation-markup": 15,
  "ai-utm-source": 12
};
var CATEGORY_META2 = {
  "tier1": { severity: "high", message: 'A word that turns up a lot in generic machine-written copy, like "delve", "robust" or "seamless".', suggestion: "Swap it for a plainer word." },
  "tier1-clarity": { severity: "medium", message: 'This is a long way of saying something short, like "in order to" for "to", or "due to the fact that" for "because".', suggestion: "Use the shorter form." },
  "tier2": { severity: "medium", message: 'Several buzzwords sit in one paragraph, words like "foster", "facilitate" and "ecosystem". One is fine. A pile of them reads as filler.', suggestion: "Keep one at most, and say the plain thing instead." },
  "tier3": { severity: "low", message: 'A vague filler word such as "significant", "effective" or "dynamic" is used a lot for a piece this long.', suggestion: "Cut some of them, or say what you actually mean." },
  "transition": { severity: "medium", message: 'A joining phrase that could link any two sentences, like "Moreover", "Furthermore" or "In conclusion".', suggestion: "Cut it, or say how the two sentences really connect." },
  "chatbot": { severity: "high", message: 'A line from a chat window is still in the text, like "I hope this helps" or "Certainly!".', suggestion: "Delete it." },
  "sycophantic": { severity: "high", message: `A compliment aimed at the reader's question, the way a chatbot opens a reply: "Great question!".`, suggestion: "Delete it and go straight to the point." },
  "filler": { severity: "medium", message: "A phrase that adds words but no meaning.", suggestion: "Cut it. The sentence almost always still works." },
  "generic-conclusion": { severity: "medium", message: 'A closing line that could end any article, like "only time will tell" or "the future looks bright".', suggestion: "End on something specific instead." },
  "lets-construction": { severity: "medium", message: `A "let's take a look at\u2026" line, the way a tutorial talks to you.`, suggestion: "Just say the thing. Do not announce it first." },
  "reasoning-artifact": { severity: "high", message: 'Step-by-step working is still showing, like "First, let me\u2026" or "Step 1:".', suggestion: "Delete the working and keep the answer." },
  "acknowledgment-loop": { severity: "medium", message: 'The text repeats the question back before answering it: "You asked about X. X is\u2026".', suggestion: "Answer straight away." },
  "significance-inflation": { severity: "high", message: 'A stock line telling the reader how big something was, instead of saying what happened: "marking a pivotal moment".', suggestion: "Say what happened and let the reader judge." },
  "vague-attribution": { severity: "high", message: 'A claim is credited to nobody in particular: "experts say", "studies show".', suggestion: "Name the study or the person, or drop the claim." },
  "hollow-intensifier": { severity: "medium", message: 'An emphasis word that adds no information, like "truly", "incredibly" or "absolutely".', suggestion: "Cut it." },
  "emotional-flatline": { severity: "low", message: 'A ready-made feeling word stands in for a real reaction, like "fascinating" or "surprising".', suggestion: "Say what was actually surprising, or cut it." },
  "lingering-attention": { severity: "medium", message: 'A share-post line about how long an idea stayed with you, which tells the reader nothing about the idea: "this stuck with me for days".', suggestion: "Say why it matters instead." },
  "novelty-inflation": { severity: "medium", message: 'The text announces that it is about to say something rare: "few people realise".', suggestion: "Show the point. Do not advertise it." },
  "cutoff-disclaimer": { severity: "high", message: 'A line where a chatbot describes itself or its training cut-off, like "as of my last update" or "as an AI language model".', suggestion: "Delete it, and check the facts around it yourself." },
  "template-phrase": { severity: "high", message: "A ready-made phrase that turns up in a lot of generated copy.", suggestion: "Replace it with something specific to your subject." },
  "false-concession": { severity: "medium", message: `A formula that pretends to give ground before making the point: "while it's true that\u2026".`, suggestion: "Name the real trade-off, or drop it." },
  "rhetorical-question": { severity: "medium", message: 'A question the writer asks and then answers: "So what does this mean?".', suggestion: "Give the answer without asking first." },
  "confidence-calibration": { severity: "low", message: 'Words like "clearly", "certainly" and "undoubtedly" pile up across the text.', suggestion: "Keep the one or two you have earned and cut the rest." },
  "em-dash-density": { severity: "medium", message: "Em dashes (\u2014), or spaced hyphens used as dashes, turn up a lot for a piece this long. Worth knowing: since OpenAI cut back on em dashes in late 2025, heavy dash use is more common in Claude's writing than in machine writing generally, and plenty of professional human writers use more dashes than this.", suggestion: "Swap some for commas, colons or full stops." },
  "not-just-contrast": { severity: "high", message: `The "it isn't just X, it's Y" shape.`, suggestion: "Say what it is, without the set-up." },
  "uniform-sections": { severity: "medium", message: "Every section is close to the same length. Real writing runs long in places and short in others.", suggestion: "Let each section be as long as its content needs." },
  "uniform-list-items": { severity: "medium", message: "The list items are all close to the same length. Real lists are lumpy.", suggestion: "Let some items run shorter or longer, or merge ones that repeat." },
  "sentence-flatline": { severity: "medium", message: "Sentence lengths barely change across the whole piece. Real writing swings between short and long.", suggestion: "Mix a few short, punchy sentences in with the longer ones." },
  "uniformity": { severity: "medium", message: "The paragraphs are all close to the same size.", suggestion: "Make some paragraphs shorter or longer on purpose." },
  "formatting": { severity: "medium", message: "A lot of bold is used.", suggestion: "Take the bold off most phrases, and put the important thing first." },
  "tier3-phrase": { severity: "medium", message: "The same stock phrase keeps coming back through the text.", suggestion: "Replace at least one of them with something concrete." },
  "tier3-phrase-cluster": { severity: "high", message: "Several different stock phrases are stacked up in one piece.", suggestion: "Rewrite it around one real point." },
  "hashtag-stuff": { severity: "medium", message: "A long block of hashtags.", suggestion: "Cut to two or three that fit, or none." },
  "bullet-np-list": { severity: "high", message: "A long bullet list where every item is a bare noun phrase with no verb.", suggestion: "Turn it into a paragraph, or join the items up." },
  "hedge-stack": { severity: "high", message: 'Two hedges on the same claim, like "may potentially" or "could possibly".', suggestion: "Pick one hedge, or make a claim someone could check." },
  "future-narrative": { severity: "high", message: 'A vague line about the future that nobody could ever check: "is set to reshape the industry".', suggestion: "Say something concrete a reader could test." },
  "real-actual-inflation": { severity: "medium", message: '"Real" or "actual" is doing no work here, as in "real value" or "actual impact".', suggestion: "Cut the word, or say what makes it real." },
  "social-cta-closer": { severity: "high", message: 'A closing line begging for engagement: "What do you think? Let me know below."', suggestion: "Give the reader a reason to care instead of an instruction." },
  "formulaic-opener": { severity: "high", message: `A stock opening line that would fit any article: "In today's fast-paced world\u2026".`, suggestion: "Open on a fact or a specific detail." },
  "speculative-opener": { severity: "high", message: 'The piece opens by asking you to picture a scene: "Imagine a world where\u2026".', suggestion: "Make the point directly." },
  "title-case-header": { severity: "medium", message: "The heading puts a capital on nearly every word, the way a lot of marketing copy does.", suggestion: "Capitalise the first word only, as you would in a sentence." },
  "parenthetical-hedge": { severity: "medium", message: 'An aside in brackets that sounds thoughtful and adds nothing: "(at least in most cases)".', suggestion: "Cut it, or make it a proper sentence." },
  "smart-punct-signature": { severity: "high", message: "Curly quotes, an em dash, an Oxford comma and no typos, all in one piece. That combination is rare in text somebody typed straight out by hand.", suggestion: "Nothing to fix. This is just something we noticed." },
  "punct-distribution": { severity: "medium", message: "Every paragraph uses about the same amount of punctuation.", suggestion: "Let some paragraphs run busier than others." },
  "fnword-trigram-entropy": { severity: "medium", message: "Sentences are built to the same grammar pattern again and again.", suggestion: "Change the way you build some of the sentences." },
  "cross-para-burstiness": { severity: "medium", message: "Every paragraph has the same inner rhythm of long and short sentences.", suggestion: "Let some paragraphs be clipped and others rambling." },
  "normalization-flag": { severity: "high", message: "The text held invisible characters or lookalike letters, the kind used to hide copied text from checkers. We swapped them back before reading it.", suggestion: "Take the hidden characters out and check the text again." },
  "low-ttr": { severity: "low", message: "The same words come round a lot for a piece this long.", suggestion: "Vary the nouns and verbs, unless the subject really does need the repeating." },
  "ai-placeholder": { severity: "high", message: 'A blank somebody forgot to fill in is still here, like "[INSERT NAME]".', suggestion: "Fill it in or delete it before this goes out." },
  "ai-citation-markup": { severity: "high", message: "Chatbot citation code was pasted in along with the text.", suggestion: "Delete it and put a real reference in its place." },
  "ai-utm-source": { severity: "high", message: 'A link carries a tracking tag that AI tools add to the links they hand out, like "utm_source=chatgpt.com".', suggestion: "Strip the tracking part off the link." }
};
var V3_ISSUE_WEIGHTS2 = {
  // artefact forensics
  "ai-citation-token": 15,
  "reasoning-leak": 12,
  "placeholder-token": 10,
  "pua-character": 14,
  "math-alphanumeric": 12,
  "arrow-decoration": 4,
  "escaped-markup-literal": 3,
  // tier A phrase/structural
  "neg-parallelism": 5,
  "tripled-negation": 5,
  "despite-challenges-arc": 5,
  "metaphor-cluster": 4,
  "participial-tail": 5,
  "focal-density": 5,
  "owner-phrase": 5,
  "power-verb-compound": 6,
  "outcome-tail": 4,
  "conclusion-cta": 6,
  // tier B (low weights; corroboration)
  "liang-cluster": 2,
  "kobak-density": 2,
  "promo-travel": 2,
  "pivotal-role": 2,
  "legacy-framing": 3,
  "notability-canned": 2,
  "buzzword-phrase": 2,
  "faux-insight": 2,
  "rhetorical-qa": 2,
  "didactic-note": 2,
  "narrative-cliche": 3,
  "valuable-insights": 2,
  "copula-avoidance": 3,
  "bold-label-bullets": 3,
  "emoji-decoration": 2,
  "heading-inflation": 3,
  "staccato-fragments": 3,
  "tricolon-density": 2,
  "transition-stacking": 3,
  "quote-inconsistency": 2,
  "token-cutoff": 2,
  "setup-expansion-cadence": 3,
  "passive-ratio": 3,
  "low-specificity": 2,
  "adjacent-lemma-repeat": 3,
  "fiction-claudeism": 3,
  "fiction-promptonym": 3,
  "fiction-slop-phrase": 2,
  "owner-phrase-b": 2,
  "owner-vocab-b": 2,
  "directive-colon-bullets": 3,
  "teach-preach-headings": 2,
  "by-ving-template": 3,
  "invalid-isbn": 3,
  "proximity-cluster": 2,
  // 2026.08.6 furniture rules (low weights; the escalation floors carry the
  // detection, and the weights stay small so furniture cannot fake breadth).
  "markdown-bold": 3,
  "markdown-heading": 3,
  "markdown-furniture": 4
};
var PASTE2 = "This only shows up when chat formatting survives the paste. If an editor stripped the formatting, the check finds nothing, which says nothing either way.";
var FORMAL2 = "Formal writing, and writing by people whose first language is not English, can read this way too.";
var V3_CATEGORY_META2 = {
  "ai-citation-token": { severity: "high", message: "A chatbot's own citation code is sitting in the text. The code itself says which chatbot it came from.", suggestion: "Delete the code and put a real reference in its place." },
  "reasoning-leak": { severity: "high", message: 'Parts of this text talk about the writing job itself, the kind of notes an AI leaves in its answer, like "as requested" or "let me revise".', suggestion: "Delete those notes and keep the finished writing." },
  "placeholder-token": { severity: "high", message: 'A machine placeholder is still in the text, something like "{{name}}" or "<insert>".', suggestion: "Fill it in or delete it before this goes out." },
  "pua-character": { severity: "high", message: "The text holds characters from a private corner of Unicode that has no agreed meaning. ChatGPT wraps its citation codes in these. Icon fonts are the only other common reason for them.", suggestion: "Delete them, and look for chatbot citation codes next to them." },
  "math-alphanumeric": { severity: "high", message: "Fake bold or italic letters built from maths symbols (\u{1D5F9}\u{1D5F6}\u{1D5F8}\u{1D5F2} \u{1D601}\u{1D5F5}\u{1D5F6}\u{1D600}). They come from chatbot copy-paste and social-media text formatters.", suggestion: "Retype them as ordinary letters and use real bold or italic." },
  "arrow-decoration": { severity: "medium", message: 'Arrows stand in for words again and again: "input \u2192 output \u2192 result".', suggestion: "Write the connection out in words." },
  "escaped-markup-literal": { severity: "low", message: 'A stray scrap of code is showing through the text, like "&nbsp;" or "\\n". It usually comes from pasting out of a chat window.', suggestion: "Delete it." },
  "neg-parallelism": { severity: "medium", message: 'The "not only X but Y" shape comes back more than once.', suggestion: "Keep one. Say the rest plainly." },
  "tripled-negation": { severity: "medium", message: 'The "Not X. Not Y. Just Z." shape.', suggestion: "Say what it is, without the three-part build-up." },
  "despite-challenges-arc": { severity: "medium", message: 'The stock "despite challenges, it continues to thrive" story shape.', suggestion: "Name the real problem and what was really done about it." },
  "metaphor-cluster": { severity: "medium", message: 'Several worn-out picture words are stacked together: "tapestry", "interplay", "evolving landscape", "testament to".', suggestion: "Say the plain facts they are standing in for." },
  "participial-tail": { severity: "medium", message: 'Sentences keep ending with a tacked-on "-ing" clause that tells you why it mattered: ", highlighting the need for\u2026", ", underscoring the importance of\u2026". That ending turns up several times more often in machine writing than in human writing.', suggestion: "Stop the sentence at the fact. Cut the tail, or turn it into a claim you can source." },
  "focal-density": { severity: "medium", message: 'A lot of words from the AI-favourite list turn up here: "delve", "showcase", "pivotal", "meticulous". Any one of them is normal English. It is how many there are that stands out.', suggestion: "Swap most of them for plainer verbs and adjectives." },
  "owner-phrase": { severity: "medium", message: "A ready-made phrase from the generic-writing phrasebook.", suggestion: "Replace it with something specific to your subject." },
  "power-verb-compound": { severity: "high", message: 'A big verb glued to a vague adjective: "leverage a robust solution", "ensure seamless delivery". It sounds like value and says nothing.', suggestion: "Name the real action and the thing you can measure." },
  "outcome-tail": { severity: "medium", message: 'The sentence trails off into a vague result: ", leading to increased engagement".', suggestion: "Say the exact result, or cut the tail." },
  "conclusion-cta": { severity: "high", message: 'The stock marketing sign-off: "by following these steps you can boost\u2026".', suggestion: "Close on something specific, not a general promise." },
  "liang-cluster": { severity: "low", message: 'Several judgement words from the AI-overuse lists sit close together, like "crucial", "notable" and "significant".', suggestion: "Keep the judgements you can back up with detail." },
  "kobak-density": { severity: "low", message: "Several words sit here that turned up far more often in machine writing when a large body of text was counted.", suggestion: "Vary the words, or back the claims with detail." },
  "promo-travel": { severity: "low", message: 'Brochure words are bunched together: "nestled", "breathtaking", "hidden gem". They stand out most when the piece is not a travel brochure.', suggestion: "Describe the place or the product with real detail." },
  "pivotal-role": { severity: "low", message: 'The "plays a crucial role in shaping" formula.', suggestion: "Say what it actually does." },
  "legacy-framing": { severity: "low", message: 'Several grand phrases about legacy and importance are stacked up: "enduring legacy", "pivotal moment".', suggestion: "Let the events speak for themselves." },
  "notability-canned": { severity: "low", message: 'A canned line about how well known something is: "profiled in multiple outlets".', suggestion: "Name the outlets, or drop the claim." },
  "buzzword-phrase": { severity: "low", message: 'A stock office phrase: "harness the power of", "at the forefront of".', suggestion: "Say what it can actually do." },
  "faux-insight": { severity: "low", message: `A line promising a secret: "here's what nobody tells you".`, suggestion: "Show the point. Do not announce it." },
  "rhetorical-qa": { severity: "low", message: 'The "The result? X." trick keeps coming back.', suggestion: "Use it once at most." },
  "didactic-note": { severity: "low", message: `A teacherly disclaimer: "it's important to understand", "results may vary".`, suggestion: "Cut it, or make it specific." },
  "narrative-cliche": { severity: "low", message: 'A worn-out story phrase: "faced numerous challenges", "a poignant reminder".', suggestion: "Say what actually happened." },
  "valuable-insights": { severity: "low", message: 'A stock academic filler phrase: "provides valuable insights into".', suggestion: "State the insight itself." },
  "copula-avoidance": { severity: "low", message: 'The text keeps dodging plain "is" and "has" in favour of "serves as", "stands as" and "functions as". ' + FORMAL2, suggestion: 'Use "is" and "has" where they fit.' },
  "bold-label-bullets": { severity: "low", message: 'A run of bullets all shaped "**Label:** description". Technical documents use this shape too.', suggestion: "Turn it into sentences, or vary the shape of the items." },
  "emoji-decoration": { severity: "low", message: "Emoji are used on headings or bullets. That is a chat-window habit in a piece of business writing.", suggestion: "Take the decorative emoji out of this kind of writing." },
  "heading-inflation": { severity: "low", message: "There are a lot of headings for the amount of writing under them. SEO advice produces the same shape.", suggestion: "Merge sections whose body is only a sentence or two." },
  "staccato-fragments": { severity: "low", message: "A run of very short, punchy fragments. Ad copy does this on purpose too.", suggestion: "Join some of them into full sentences." },
  "tricolon-density": { severity: "low", message: 'Three-part lists such as "faster, cheaper, simpler" turn up a lot for a piece this long.', suggestion: "Break the pattern: use two items, or four." },
  "transition-stacking": { severity: "low", message: 'Most paragraphs open on a formal joining word: "Furthermore", "Moreover", "Additionally". ' + FORMAL2, suggestion: "Let the content do the joining in most paragraphs." },
  "quote-inconsistency": { severity: "low", message: "Curly and straight quotation marks are mixed together. That usually comes from pasting out of a chat window, though word processors do it too.", suggestion: "Make the quotation marks match, either way round." },
  "token-cutoff": { severity: "low", message: "The text stops in the middle of a sentence, the shape of an answer that ran out of room, or a paste that went wrong.", suggestion: "Finish the last sentence, or delete it." },
  "setup-expansion-cadence": { severity: "low", message: "Short sentence, then long one, over and over, or the other way round. " + FORMAL2, suggestion: "Keep the pattern only where the short sentence works on its own." },
  "passive-ratio": { severity: "low", message: 'A lot of the sentences hide who did the thing: "mistakes were made". That is high for a blog or a marketing piece. Academic writing does it constantly. ' + FORMAL2, suggestion: "Rewrite most sentences so the person or thing doing it comes first." },
  "low-specificity": { severity: "low", message: "Almost no numbers, dates or names for a piece this long. Corporate writers produce empty writing too.", suggestion: "Add facts a reader could go and check." },
  "adjacent-lemma-repeat": { severity: "low", message: "Neighbouring sentences keep reusing the same word. " + FORMAL2, suggestion: "Merge the repetitive sentences, or change the wording where it reads naturally." },
  "fiction-claudeism": { severity: "low", message: "Phrases that turn up a lot in Claude's fiction writing. Romance authors use several of them quite normally.", suggestion: "Put the stock phrases into your own words." },
  "fiction-promptonym": { severity: "low", message: 'A character name that AI writing produces far more often than people do. "Elara Voss" is the best-known one.', suggestion: "Pick a less loaded name if you want one." },
  "fiction-slop-phrase": { severity: "low", message: "Several well-worn fiction lines land in the same piece. All of them were human clich\xE9s long before AI.", suggestion: "Cut or rework the stock moments." },
  "owner-phrase-b": { severity: "low", message: "A phrase from the second generic-writing phrasebook.", suggestion: "Replace it with something specific." },
  "owner-vocab-b": { severity: "low", message: 'Several second-string filler words sit close together: "essence", "facet", "pesky", "folks".', suggestion: "Swap them for plainer words where they add nothing." },
  "directive-colon-bullets": { severity: "low", message: 'Several list items open on an order and a colon: "Ensure X:", "Optimise Y:". Real technical checklists look like this too.', suggestion: "Vary the way the items are built." },
  "teach-preach-headings": { severity: "low", message: 'Stock tutorial headings hold the piece together: "Why it matters", "Final thoughts", "Key takeaways".', suggestion: "Name each section after what is actually in it." },
  "by-ving-template": { severity: "low", message: 'The "By doing X, you can Y" shape keeps coming back.', suggestion: "Say the benefit straight out most of the time." },
  "invalid-isbn": { severity: "low", message: "An ISBN in the text does not add up. Made-up references often fail this check, and so do typos.", suggestion: "Check the reference against the real book." },
  "proximity-cluster": { severity: "low", message: "The same flagged buzzword comes back within a sentence or two.", suggestion: "Keep one use at most in each passage." },
  // 2026.08.6 chat-formatting rules. Each one states the paste caveat: the
  // check can only see formatting that survived the paste, so its ABSENCE says
  // nothing about who wrote the text.
  "markdown-bold": { severity: "low", message: "Raw **bold** markdown is showing in the text. None of the 169 human-written documents we checked had it. " + PASTE2, suggestion: "Delete the stars, or apply real bold." },
  "markdown-heading": { severity: "low", message: "A raw markdown heading line, the kind that starts with # signs, is showing in the text. None of the 169 human-written documents we checked had one. " + PASTE2, suggestion: "Turn it into a real heading, or delete it." },
  "markdown-furniture": { severity: "low", message: "Chat-window formatting shapes this text: runs of bold, heading lines, or a wall of bullets. None of the 169 human-written documents we checked had that combination. " + PASTE2, suggestion: "Rebuild the formatting properly for wherever this is going." }
};
var V4_ISSUE_WEIGHTS2 = {
  "sentence-length-spectral-flatness": 2,
  "conditional-compression": 2,
  "lexical-register-distance": 2,
  "punchline-fragment-density": 2,
  "mic-drop-paragraph": 2,
  "contrast-density": 2,
  "rhetorical-procedural-ratio": 2
};
var V4_CATEGORY_META2 = {
  "sentence-length-spectral-flatness": {
    severity: "low",
    message: "Sentence lengths follow a pattern that is more regular than most writing this long. We only measure it on fixed-size chunks, so short pieces are skipped. Careful human editing produces the same shape.",
    suggestion: "Nothing to change unless the other checks agree. Varying sentence length is a choice, not a rule."
  },
  "conditional-compression": {
    severity: "low",
    message: "Held up against a sample of varied human writing, this text has less in common with it than most. Copy written to a tight template scores the same way.",
    suggestion: "Nothing to change on its own. If the other checks agree, vary phrasing you have repeated."
  },
  "lexical-register-distance": {
    severity: "low",
    message: "The mix of small joining words, and the length of the words, sits a long way from our sample of everyday human writing. Worth knowing: that sample is general writing, so academic, legal and technical pieces land far away quite fairly.",
    suggestion: "Nothing to change on its own. Plainer wording moves it closer if the other checks agree."
  },
  "punchline-fragment-density": {
    severity: "low",
    message: `Very short, abstract closing lines keep turning up, especially at the end of paragraphs: "That's the point." Good copywriters use punchlines on purpose, which is why we only count how many there are.`,
    suggestion: "Keep the punchlines that earn their place. Turn the rest into full sentences."
  },
  "mic-drop-paragraph": {
    severity: "low",
    message: "Several paragraphs are built the same way: a few medium sentences, then a much shorter line to land on. One paragraph like that is ordinary. It is the repeat that stands out.",
    suggestion: "Let some paragraphs finish on their facts instead of a quotable line."
  },
  "contrast-density": {
    severity: "low",
    message: `Two-sided contrasts keep coming back: "not X, but Y"; "It wasn't A. It was B." One is ordinary writing. It is the rate that stands out.`,
    suggestion: "Keep the strongest contrast and say the rest plainly."
  },
  "rhetorical-procedural-ratio": {
    severity: "low",
    message: "Sentences making broad claims heavily outnumber sentences naming a real action, object or number. We count a sentence as concrete when it holds a number, a name, or a specific action verb. Opinion and vision pieces are broad on purpose.",
    suggestion: "Back more claims with a specific action, name or figure if the other checks agree."
  }
};
var MERGED_WEIGHTS2 = { ...ISSUE_WEIGHTS2, ...V3_ISSUE_WEIGHTS2, ...V4_ISSUE_WEIGHTS2 };
var MERGED_META2 = { ...CATEGORY_META2, ...V3_CATEGORY_META2, ...V4_CATEGORY_META2 };
var byLengthDesc2 = (a, b) => b.length - a.length || a.localeCompare(b);
var TIER1_WORD_RE2 = new RegExp("\\b(?:" + Object.keys(TIER12).sort(byLengthDesc2).join("|") + ")\\b", "gi");
var TIER2_WORD_RE2 = new RegExp("\\b(?:" + Object.keys(TIER22).sort(byLengthDesc2).join("|") + ")\\b", "gi");
var TIER3_LOOKUP2 = /* @__PURE__ */ new Map();
for (const word of TIER32) {
  TIER3_LOOKUP2.set(word, word);
  const dashless = word.replace(/-/g, "");
  if (dashless !== word) TIER3_LOOKUP2.set(dashless, word);
}
var LATIN_LETTER = new RegExp("\\p{Script=Latin}", "u");
function validateProtected(source, candidate2, spans) {
  const failures = [];
  for (const span of spans) {
    const count = candidate2.split(span.text).length - 1;
    if (count === 0) failures.push({ protected_span_id: span.id, expected_hash: span.content_hash, observed: "missing" });
    else if (count > source.split(span.text).length - 1) failures.push({ protected_span_id: span.id, expected_hash: span.content_hash, observed: "duplicated" });
  }
  return { id: "protected_spans.exact", version: "1.0.0", status: failures.length ? "fail" : "pass", hard: true, summary: failures.length ? `${failures.length} protected item(s) changed` : "Protected items remain present", failures, limitations: [] };
}
function validateAdditions(source, candidate2) {
  const pattern = /https?:\/\/[^\s<>)\]]+|```[\s\S]*?```|`[^`\n]+`|\[[0-9]+\]|[“"][^”"\n]+[”"]/g;
  const original = new Set(source.match(pattern) ?? []);
  const added = (candidate2.match(pattern) ?? []).filter((x) => !original.has(x));
  return { id: "unsupported_additions", version: "1.0.0", status: added.length ? "fail" : "pass", hard: true, summary: added.length ? `${added.length} unsupported reference(s) added` : "No unsupported URLs, citations, quotations or code added", failures: added.map((observed) => ({ observed })), limitations: [] };
}
function validateCandidate(source, candidate2, spans, policy = {}) {
  const gates = [validateProtected(source.content, candidate2, spans), validateAdditions(source.content, candidate2)];
  const current = prefixedSha2562(source.content), expected = policy.expected_source_hash ?? source.content_hash ?? current;
  gates.push({ id: "source_version", version: "1.0.0", status: current === expected ? "pass" : "fail", hard: true, summary: current === expected ? "Source hash matches" : "Source changed since protection", failures: current === expected ? [] : [{ expected_hash: expected, observed: current }], limitations: [] });
  const executable = /<\s*(?:script|iframe|object|embed|form)\b|\son\w+\s*=|javascript:/i.test(candidate2);
  gates.push({ id: "html_safety", version: "1.0.0", status: executable ? "fail" : "pass", hard: true, summary: executable ? "Executable or unsafe HTML found" : "No executable HTML found", failures: executable ? [{ observed: "executable_markup" }] : [], limitations: ["This deterministic gate is not a complete HTML sanitiser."] });
  const max = policy.max_length_ratio ?? 2;
  const ratio = source.content.length ? candidate2.length / source.content.length : 1;
  gates.push({ id: "language_length", version: "1.0.0", status: ratio > max ? "fail" : "pass", hard: true, summary: ratio > max ? "Candidate exceeds the configured length bound" : "Candidate is within the configured length bound", failures: ratio > max ? [{ observed_ratio: ratio, max_ratio: max }] : [], limitations: ["CORE-10 does not infer language; it preserves the requested language as a host-reviewed constraint."] });
  const leakage = /\b(?:protected_span_id|system prompt|<\|(?:system|assistant|user)\|>)\b/i.test(candidate2);
  gates.push({ id: "output_safety", version: "1.0.0", status: leakage ? "fail" : "pass", hard: true, summary: leakage ? "Prompt or protected-ID leakage found" : "No prompt/control-token leakage found", failures: leakage ? [{ observed: "control_or_prompt_marker" }] : [], limitations: [] });
  gates.push({ id: "semantic_entailment", version: "unconfigured/1", status: "not_configured", hard: true, summary: "Semantic entailment is not configured in the deterministic core", failures: [], limitations: ["Strict policy must treat this required semantic gate as blocking when generation depends on semantic fidelity."] });
  return gates;
}
var tokens = (s) => s.match(/\s+|[^\s]+/g) ?? [];
function diff(source, candidate2) {
  if (source.length + candidate2.length > 8e4) return lineDiff(source, candidate2);
  const a = tokens(source), b = tokens(candidate2);
  if (a.length * b.length > 2e6) return lineDiff(source, candidate2);
  const matches = hirschberg(a, b);
  let i = 0, j = 0, sp = 0, cp = 0, mi = 0;
  const out = [];
  const push = (type, text2, ss2, se, cs2, ce) => {
    const last = out.at(-1);
    if (last?.type === type && last.source_end === ss2 && last.candidate_end === cs2) {
      last.text += text2;
      last.source_end = se;
      last.candidate_end = ce;
    } else out.push({ type, text: text2, source_start: ss2, source_end: se, candidate_start: cs2, candidate_end: ce });
  };
  while (i < a.length || j < b.length) {
    const match = matches[mi];
    if (match && i === match[0] && j === match[1]) {
      const t = a[i];
      push("equal", t, sp, sp + t.length, cp, cp + t.length);
      sp += t.length;
      cp += t.length;
      i++;
      j++;
      mi++;
    } else if (j < b.length && (!match || j < match[1])) {
      const t = b[j];
      push("insert", t, sp, sp, cp, cp + t.length);
      cp += t.length;
      j++;
    } else {
      const t = a[i];
      push("delete", t, sp, sp + t.length, cp, cp);
      sp += t.length;
      i++;
    }
  }
  return { version: "lcs-token/1.0.0", source_hash: prefixedSha2562(source), candidate_hash: prefixedSha2562(candidate2), change_count: out.filter((x) => x.type !== "equal").length, segments: out, fallback: false };
}
function rowScores(a, a0, a1, b, b0, b1, reverse = false) {
  const width = b1 - b0;
  let previous = new Uint32Array(width + 1), current = new Uint32Array(width + 1);
  for (let ai = 0; ai < a1 - a0; ai++) {
    const av = a[reverse ? a1 - 1 - ai : a0 + ai];
    for (let bj = 0; bj < width; bj++) {
      const bv = b[reverse ? b1 - 1 - bj : b0 + bj];
      current[bj + 1] = av === bv ? previous[bj] + 1 : Math.max(previous[bj + 1], current[bj]);
    }
    const swap = previous;
    previous = current;
    current = swap;
    current.fill(0);
  }
  return previous;
}
function hirschberg(a, b) {
  const out = [];
  const walk = (a0, a1, b0, b1) => {
    if (a0 >= a1 || b0 >= b1) return;
    if (a1 - a0 === 1) {
      for (let j = b0; j < b1; j++) if (a[a0] === b[j]) {
        out.push([a0, j]);
        break;
      }
      return;
    }
    const mid = a0 + a1 >> 1;
    let left = rowScores(a, a0, mid, b, b0, b1), right = rowScores(a, mid, a1, b, b0, b1, true);
    let split = 0, best = -1;
    for (let j = 0; j <= b1 - b0; j++) {
      const score = left[j] + right[b1 - b0 - j];
      if (score > best) {
        best = score;
        split = j;
      }
    }
    left = void 0;
    right = void 0;
    walk(a0, mid, b0, b0 + split);
    walk(mid, a1, b0 + split, b1);
  };
  walk(0, a.length, 0, b.length);
  return out;
}
function lineDiff(source, candidate2) {
  const segments = source === candidate2 ? source ? [{ type: "equal", text: source, source_start: 0, source_end: source.length, candidate_start: 0, candidate_end: candidate2.length }] : [] : [];
  if (source !== candidate2) {
    if (source) segments.push({ type: "delete", text: source, source_start: 0, source_end: source.length, candidate_start: 0, candidate_end: 0 });
    if (candidate2) segments.push({ type: "insert", text: candidate2, source_start: source.length, source_end: source.length, candidate_start: 0, candidate_end: candidate2.length });
  }
  return { version: "lcs-token/1.0.0", source_hash: prefixedSha2562(source), candidate_hash: prefixedSha2562(candidate2), change_count: segments.filter((item2) => item2.type !== "equal").length, segments, fallback: true };
}
var MAGIC = [67, 50, 80, 65, 84, 88, 84, 0];
var HEADER_BYTES = 13;
var SENTINEL = 65279;
var variationSelectorToByte = (codePoint) => codePoint >= 65024 && codePoint <= 65039 ? codePoint - 65024 : codePoint >= 917760 && codePoint <= 917999 ? codePoint - 917760 + 16 : null;
function detectC2paTextCredentials(text2) {
  const found = [];
  for (let i = 0; i < text2.length; ) {
    const codePoint = text2.codePointAt(i);
    const width = codePoint > 65535 ? 2 : 1;
    if (codePoint !== SENTINEL) {
      i += width;
      continue;
    }
    const bytes = [];
    let cursor = i + width;
    while (cursor < text2.length) {
      const next = text2.codePointAt(cursor);
      const byte = variationSelectorToByte(next);
      if (byte === null) break;
      bytes.push(byte);
      cursor += next > 65535 ? 2 : 1;
    }
    if (bytes.length < HEADER_BYTES || !MAGIC.every((value, index) => bytes[index] === value)) {
      i += width;
      continue;
    }
    const manifestLength = (bytes[9] << 24 | bytes[10] << 16 | bytes[11] << 8 | bytes[12]) >>> 0;
    found.push({
      start_utf16: i,
      end_utf16: cursor,
      version: bytes[8],
      manifest_length: manifestLength,
      status: bytes.length >= HEADER_BYTES + manifestLength ? "ok" : "truncated"
    });
    i = cursor;
  }
  return found;
}
var withinCredential = (credentials, span) => credentials.some(
  (credential) => span.start_utf16 < credential.end_utf16 && span.end_utf16 > credential.start_utf16
);
function previewSafeFixes(source, findings, selectedFindingIds, protectedSpans = [], options = {}) {
  const credentials = options.allow_c2pa_credential_removal ? [] : detectC2paTextCredentials(source);
  const selected = new Set(selectedFindingIds), edits = [], skipped = [];
  for (const f of findings) {
    if (!selected.has(f.id)) continue;
    const raw = source.slice(f.span.start_utf16, f.span.end_utf16);
    if (!f.id.startsWith("unicode_") || f.span.end_utf16 <= f.span.start_utf16 || f.matched_text_hash !== prefixedSha2562(raw)) {
      skipped.push({ id: f.id, reason: "invalid_finding_provenance" });
      continue;
    }
    if (f.code_point === "U+FEFF" && f.span.start_utf16 !== 0) {
      skipped.push({ id: f.id, reason: "invalid_bom_position" });
      continue;
    }
    if (f.fix === "review") {
      skipped.push({ id: f.id, reason: "user_review" });
      continue;
    }
    if (withinCredential(credentials, f.span)) {
      skipped.push({ id: f.id, reason: "c2pa_text_credential" });
      continue;
    }
    if (protectedSpans.some((p) => f.span.start_utf16 < p.end_utf16 && f.span.end_utf16 > p.start_utf16)) {
      skipped.push({ id: f.id, reason: "protected_span" });
      continue;
    }
    if (edits.some((e) => f.span.start_utf16 < e.end && f.span.end_utf16 > e.start)) {
      skipped.push({ id: f.id, reason: "overlapping_edit" });
      continue;
    }
    edits.push({ start: f.span.start_utf16, end: f.span.end_utf16, value: f.fix === "space" ? " " : "", id: f.id });
  }
  edits.sort((a, b) => b.start - a.start);
  let candidate2 = source;
  for (const e of edits) candidate2 = candidate2.slice(0, e.start) + e.value + candidate2.slice(e.end);
  return deepFreeze2({ source_hash: prefixedSha2562(source), candidate_hash: prefixedSha2562(candidate2), candidate: candidate2, applied_finding_ids: edits.map((e) => e.id).reverse(), skipped, diff: diff(source, candidate2) });
}
function deepFreeze2(value) {
  if (value && typeof value === "object" && !Object.isFrozen(value)) {
    Object.freeze(value);
    for (const child of Object.values(value)) deepFreeze2(child);
  }
  return value;
}
function hasLoneSurrogate(value) {
  for (let i = 0; i < value.length; i++) {
    const code = value.charCodeAt(i);
    if (code >= 55296 && code <= 56319) {
      if (i === value.length - 1) {
        return true;
      }
      const next = value.charCodeAt(i + 1);
      if (!(next >= 56320 && next <= 57343)) {
        return true;
      }
      i++;
    } else if (code >= 56320 && code <= 57343) {
      return true;
    }
  }
  return false;
}
function canonicalize(object, seen = /* @__PURE__ */ new Set()) {
  if (typeof object === "number" && isNaN(object)) {
    throw new Error("NaN is not allowed");
  }
  if (typeof object === "number" && !isFinite(object)) {
    throw new Error("Infinity is not allowed");
  }
  if (typeof object === "string" && hasLoneSurrogate(object)) {
    throw new Error("Lone surrogate is not allowed");
  }
  if (object === null || typeof object !== "object") {
    return JSON.stringify(object);
  }
  if (typeof object.toJSON === "function") {
    if (seen.has(object)) {
      throw new Error("Circular reference detected");
    }
    seen.add(object);
    const result22 = canonicalize(object.toJSON(), seen);
    seen.delete(object);
    return result22;
  }
  if (seen.has(object)) {
    throw new Error("Circular reference detected");
  }
  seen.add(object);
  let result2;
  if (Array.isArray(object)) {
    const values = object.map((cv) => {
      const value = cv === void 0 || typeof cv === "symbol" ? null : cv;
      return canonicalize(value, seen);
    });
    result2 = `[${values.join(",")}]`;
  } else {
    const parts = [];
    for (const key of Object.keys(object).sort()) {
      if (object[key] === void 0 || typeof object[key] === "symbol") {
        continue;
      }
      parts.push(`${canonicalize(key)}:${canonicalize(object[key], seen)}`);
    }
    result2 = `{${parts.join(",")}}`;
  }
  seen.delete(object);
  return result2;
}
var payloadForHash = (receipt2) => {
  const clone = structuredClone(receipt2);
  delete clone.integrity?.payload_hash;
  delete clone.integrity?.signature;
  return clone;
};
var canonical = (value) => {
  const output = canonicalize(value);
  if (output === void 0) throw new Error("receipt_canonicalisation_failed");
  return output;
};
async function buildReceipt(input) {
  if (input.contains_content !== input.policy.retain_content) throw new Error("receipt_content_consent_mismatch");
  if (input.contains_content && input.rewrite && !input.rewrite.candidate_content) throw new Error("receipt_candidate_content_required");
  const sourceHash = prefixedSha2562(input.source.content), normalisedHash = prefixedSha2562(input.source.normalised_text ?? input.source.content);
  const source = { content_hash: sourceHash, normalised_hash: normalisedHash, content_type: input.source.content_type, language: input.source.language, word_count: (input.source.content.trim().match(/\S+/g) ?? []).length };
  if (input.contains_content) source.content = input.source.content;
  const rewrite = input.rewrite ? (() => {
    const { candidate_content, source_content: _callerSourceContent, ...metadata } = input.rewrite;
    return { ...metadata, ...input.contains_content ? { source_content: input.source.content, candidate_content } : {} };
  })() : null;
  const receipt2 = { schema_version: "1.0", contract_version: "1.0.0", product_version: input.product_version, receipt_id: input.receipt_id, created_at: input.created_at, source, policy: input.policy, methods: input.methods, rewrite, approval: input.approval, limitations: input.limitations, contains_content: input.contains_content, integrity: { canonicalisation: "RFC8785", payload_hash: "sha256:" + "0".repeat(64) } };
  receipt2.integrity.payload_hash = prefixedSha2562(canonical(payloadForHash(receipt2)));
  return deepFreeze3(receipt2);
}
function deepFreeze3(value) {
  if (value && typeof value === "object" && !Object.isFrozen(value)) {
    Object.freeze(value);
    for (const child of Object.values(value)) deepFreeze3(child);
  }
  return value;
}
var METHODS2 = Object.freeze([
  Object.freeze({ id: "unicode.invisible", category: "unicode", version: "unicode:2026.08.1", state: "available", privacy_routes: ["browser"], limitations: ["Controls can be legitimate in multilingual text."] }),
  Object.freeze({ id: "unicode.homoglyph", category: "unicode", version: "unicode:2026.08.1", state: "available", privacy_routes: ["browser"], limitations: ["Mixed scripts require contextual human review."] }),
  Object.freeze({ id: "style.patterns", category: "pattern", version: "en-gb:2026.08.1", state: "available", privacy_routes: ["browser"], limitations: ["Editorial pattern findings are not authorship evidence."] }),
  Object.freeze({ id: "watermark.anthropic", category: "watermark", version: "adapter-placeholder/1", state: "unsupported", privacy_routes: ["browser"], limitations: ["No official detector interface is available."] })
]);

// ../../shared/presentation/checker-result-presentation.mjs
var CHECKER_LEVEL_LABELS = Object.freeze({
  "signal-strongly-ai": "Strongly AI",
  "signal-likely-ai": "Likely AI",
  "signal-potentially-ai": "Potentially AI",
  "signal-unclear": "Unclear",
  "signal-likely-human": "Likely human"
});
var LEVEL_IDS = new Set(Object.keys(CHECKER_LEVEL_LABELS));
var METHOD_STATE_LABEL = Object.freeze({
  pass: "No issue found",
  attention: "Review evidence",
  fail: "Failed",
  inconclusive: "Inconclusive",
  unsupported: "Unavailable",
  not_configured: "Not configured",
  not_run: "Not run",
  error: "Error"
});
var asRecord = (value) => value !== null && typeof value === "object" && !Array.isArray(value) ? value : null;
var cleanText = (value, fallback) => typeof value === "string" && value.trim() ? value.trim() : fallback;
var unique = (values) => [...new Set(values.filter((value) => typeof value === "string" && value.trim()))];
function assertCanonicalResult(result2) {
  if (!asRecord(result2) || result2.schema_version !== "1.0" || !String(result2.contract_version).startsWith("1.")) throw new Error("checker_result_contract_invalid");
  if (!["full_checker", "primitive"].includes(result2.profile)) throw new Error("checker_result_profile_invalid");
  if (!asRecord(result2.source) || !asRecord(result2.route) || !asRecord(result2.axes)) throw new Error("checker_result_structure_invalid");
  if (!asRecord(result2.provenance) || !asRecord(result2.provenance.protected_facts) || !asRecord(result2.exports) || !asRecord(result2.exports.report) || !asRecord(result2.abuse_controls)) {
    throw new Error("checker_result_supporting_contract_invalid");
  }
  const ai = asRecord(result2.axes.ai_pattern);
  const integrity = asRecord(result2.axes.text_integrity);
  const editorial = asRecord(result2.axes.editorial);
  if (!ai || !integrity || !editorial || !Array.isArray(result2.sections) || !Array.isArray(result2.methods)) throw new Error("checker_result_axes_invalid");
  if (ai.assessment_status === "assessed") {
    if (!asRecord(result2.route.model) || typeof ai.raw_margin !== "number" || !Number.isFinite(ai.raw_margin) || typeof ai.display_score !== "string" || !/^(?:0(?:\.[0-9]+)?|1(?:\.0+)?)$/u.test(ai.display_score) || !LEVEL_IDS.has(ai.level) || !Number.isInteger(ai.strongest_section_index)) {
      throw new Error("checker_result_assessed_identity_invalid");
    }
    if (!result2.sections.length) throw new Error("checker_result_assessed_sections_required");
    result2.sections.forEach((section, position) => {
      if (!asRecord(section) || section.index !== position || typeof section.raw_margin !== "number" || !Number.isFinite(section.raw_margin) || typeof section.display_score !== "string" || !/^(?:0(?:\.[0-9]+)?|1(?:\.0+)?)$/u.test(section.display_score) || !LEVEL_IDS.has(section.level)) {
        throw new Error("checker_result_section_contract_invalid");
      }
    });
    if (!result2.sections.some((section) => section.index === ai.strongest_section_index)) throw new Error("checker_result_strongest_section_invalid");
    if (result2.profile === "full_checker" && (!result2.exports.report.available || !result2.exports.report.complete_evidence)) throw new Error("checker_result_full_report_required");
  } else if (ai.assessment_status === "not_assessed" || ai.assessment_status === "withheld" || ai.assessment_status === "error") {
    if (ai.raw_score !== null || ai.raw_margin !== null || ai.display_score !== null || ai.level !== null || ai.strongest_section_index !== null) {
      throw new Error("checker_result_unassessed_score_forbidden");
    }
    if (result2.sections.length) throw new Error("checker_result_unassessed_sections_forbidden");
  } else {
    throw new Error("checker_result_assessment_status_invalid");
  }
}
function legacyCombined(result2) {
  const combined = asRecord(result2.combined_verdict);
  const integrity = asRecord(combined?.text_integrity);
  const editorial = asRecord(combined?.editorial);
  return {
    integrity: {
      reading: ["clean", "attention", "manipulated"].includes(integrity?.status) ? integrity.status : "inconclusive",
      reason: cleanText(integrity?.reason, "No combined text-integrity reading was supplied."),
      findings: Array.isArray(integrity?.findings) ? integrity.findings : []
    },
    editorial: {
      reading: ["none", "some", "many"].includes(editorial?.suggestion_level) ? editorial.suggestion_level : "not_assessed",
      reason: cleanText(editorial?.reason, "No combined editorial reading was supplied."),
      findings: Array.isArray(editorial?.categories_hit) ? editorial.categories_hit.map((category) => ({ category })) : []
    }
  };
}
function adaptLegacyAnalysisResult(result2, options) {
  if (!asRecord(result2) || result2.schema_version !== "1.0" || !asRecord(result2.source) || !Array.isArray(result2.methods)) throw new Error("legacy_analysis_result_invalid");
  if (!asRecord(options) || !cleanText(options.surface, "")) throw new Error("legacy_surface_invalid");
  const combined = legacyCombined(result2);
  const limitations = unique([
    ...Array.isArray(result2.limitations) ? result2.limitations : [],
    "No trained model ran on this text, so the AI-pattern reading is not assessed.",
    "This reduced deterministic result is not full-checker parity.",
    "No result proves authorship."
  ]);
  const watermarkMethods = result2.methods.filter((method) => method.id?.startsWith("watermark."));
  const checkerResult2 = {
    schema_version: "1.0",
    contract_version: String(result2.contract_version ?? "1.0.0"),
    result_id: cleanText(result2.analysis_id, cleanText(result2.request_id, "legacy-result")),
    profile: "primitive",
    generated_at: cleanText(result2.completed_at, (/* @__PURE__ */ new Date(0)).toISOString()),
    contains_content: false,
    source: {
      content_hash: cleanText(result2.source.content_hash, "sha256:unknown"),
      normalised_hash: cleanText(result2.source.normalised_hash, cleanText(result2.source.content_hash, "sha256:unknown")),
      content_type: result2.source.content_type ?? "plain_text",
      language: cleanText(result2.source.language, "en-GB"),
      word_count: Number.isInteger(result2.source.word_count) ? result2.source.word_count : 0,
      character_count: Number.isInteger(options.characterCount) ? options.characterCount : 0,
      section_count: 0
    },
    route: {
      kind: "deterministic_only",
      location: `${options.surface} browser Worker`,
      content_transfer: "none",
      privacy_route: "browser",
      retention: { source: "none", result: "none", statement: "Source and result stay in memory for the active view only." },
      consent: "not_required",
      model: null,
      transport: { endpoint_class: "none", region: null, requests: 0, words_sent: 0, processed: "in browser", retained: "not retained" }
    },
    axes: {
      ai_pattern: {
        assessment_status: "not_assessed",
        method_status: "not_run",
        source: null,
        raw_score: null,
        raw_margin: null,
        display_score: null,
        score_scale: "zero_to_one_pattern_similarity",
        level: null,
        primary_display_threshold: null,
        secondary_display_threshold: null,
        flagged: null,
        flag_reason: null,
        strongest_section_index: null,
        reason: "No trained model ran on this text, so no AI-pattern reading is available.",
        limitations: ["Character findings and writing rules cannot supply an AI-pattern reading."]
      },
      text_integrity: {
        method_status: combined.integrity.reading === "clean" ? "pass" : combined.integrity.reading === "inconclusive" ? "inconclusive" : "attention",
        reading: combined.integrity.reading,
        reason: combined.integrity.reason,
        findings: combined.integrity.findings,
        limitations
      },
      editorial: {
        method_status: combined.editorial.reading === "none" ? "pass" : combined.editorial.reading === "not_assessed" ? "not_run" : "attention",
        reading: combined.editorial.reading,
        reason: combined.editorial.reason,
        findings: combined.editorial.findings,
        limitations
      }
    },
    sections: [],
    methods: result2.methods,
    provenance: {
      protected_facts: {
        count: Array.isArray(result2.protected_spans) ? result2.protected_spans.length : 0,
        categories: unique(Array.isArray(result2.protected_spans) ? result2.protected_spans.map((span) => span.kind) : [])
      },
      c2pa_text: { status: "not_run", wrapper_protected: true, limitations: ["C2PA text verification did not run in this deterministic browser route."] },
      c2pa_files: [],
      watermarks: watermarkMethods.map((method) => ({
        method_id: method.id,
        method_status: method.status,
        key_scope: "none",
        outcome: method.native_outcome ?? (method.status === "unsupported" ? "not_available" : "not_run"),
        limitations: method.limitations
      })),
      safe_fixes: { preview_first: true, explicit_approval_required: true, automatic_homoglyph_replacement: false, c2pa_wrapper_protected: true }
    },
    exports: {
      receipt: { available: true, contains_content: false, canonicalisation: "none", payload_hash: null },
      share: { available: false, contains_content: false, payload: null },
      report: { available: false, format: "none", contains_content: false, explicit_user_action: true, complete_evidence: false, product_identity: "Opace AI Content Integrity", support_destination: "https://opace.agency/tools/ai/content-verification-integrity/" }
    },
    abuse_controls: {
      max_words: null,
      max_characters: options.maxCharacters,
      max_request_bytes: null,
      explicit_capture: "enforced",
      consent_before_transfer: "not_applicable",
      refuse_not_truncate: options.refuseNotTruncate ? "enforced" : "not_configured",
      cancellation: "enforced",
      channel_authentication: "not_applicable",
      proof_of_work: "not_applicable",
      origin_validation: "not_applicable",
      per_ip_limit: "not_applicable",
      per_site_limit: "not_applicable",
      per_connection_limit: "not_applicable",
      global_inference_limit: "not_applicable",
      request_body_logging: "not_applicable",
      unexpected_network_requests: "blocked",
      fallback: "not_configured",
      kill_switch: "not_applicable"
    },
    limitations
  };
  assertCanonicalResult(checkerResult2);
  return checkerResult2;
}
function escapeResultHtml(value) {
  return String(value).replace(/[&<>"']/gu, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[character] ?? character);
}
var PRODUCT_LOGO_DATA_URI = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAMAAADVRocKAAADAFBMVEUCG1EBG1ABGFABHVUBG1EBG1IBGlACHFICG1ICHFMBGlEBEkoBGlMBHVQBFk4BE0sBDkcBHFMBFEsBHFIBEEkCHlQBD0gBEksBHVMBFU0BIVYBDUYFHVEDHFEBV4cBq9IA7f8BGE8As9oBH1UBH1YBPnEAE1QA5P8AzfIBHlQA6P8BZpYBP3IAFlMBgq4BJVsBL2QBIlkA5f8A6/8pMEwBCUMA1PoAFFcBEEoAFVUBG1QBPnD/qy8A5v8AGVQBC0MBJ10Ax+0AEVUA6v8A4v8EHVMA2PwBUoMBFlAAncazfzsAfakBg6//sioLH0//sy0AGFMAEFMIHlEBZpQBToAAt98AFVQBIFgBGlIA4f8BOW0BVYUAoMoBqtEBE00AfqlhUEMBKV9KQkUA3f8FEkkBQXQA2v4A3/8AF1UAElNMRUgBYJABY5JiUUMBZ5X/tSwAtd0BLGEAnsj/sDABPG8Am8QAga0BS32hdT0BCkUAyO4BWImGZj8BNGmRbD8AClYAFVLMjDYAzvQxNk4BMWYBN2sVI04A0vcA2fgAsdk5OUn/sC0A3fsBjLcAzvEAmcR7XkL/sCkBW4sBBkEBHFYBZZMAueD0oC8BhLEBeqYAzPABapevfDsAGlVORETvoTHHiTcBXo3UlDZmVEUBqM77pzABgKsA0PZeUEUBd6NvWEMAxeolLUwBATwBw+UBibSWcD8Apc0Bu+IAw+o/PUdDP0gA1vk0OE8AvuQBbZsBZ5gBl8BaTUQcKUrChzgBSHsBsNX/rCv/rS8A1PfZlTT1pTEBkbwAGFIAy/EYJ1ABlL4LIVMBAz8B0vMBrM+BYkAAv+i8gzkAossBRXf/uSzQjjUPIFBiUkbyni8Ah7FGQkibcT4sM0wA9v8fK08By+wAyu/RkDmrezronjKoeT0BcZ0A8/8GG09yW0GNaD0FGlAAF1ICc59SSEkATYSzg0MDGFPhmDUAImEQGFNGOUBKTVD/pyEANXgAV5UEQnEAKGZLbGxH0ckACk1IvbcCGVCPoTixAAAACXBIWXMAAAsSAAALEgHS3X78AAAS/0lEQVRo3o1ad0AU19af3Z3h3pntlV1Y0IV1BQRpFkCwIAKiEQUERCXBqFgIKPYYexd9GFvsLZZYYi+xxJiiKaZpEk176b28l1e//u27Ze7MLOaPd8SZ2dnZ87v39HvucBwAQCR/AKITIoD/0EeB3iU37XanUwTsBoAQ3YM8PqDnBEhv4q8hJDxEygjd5ThICJAj+wo/he+IlL0IBUFgX0HED2J26IKAAvl36Bv1A0WAGEBGoDBApAzxmCCHYQEZo0B/B+yAPEUGJACnAMiTmBMdESXMBMpsOB1FYECyBLR3yFGRF7mDpUIfpiMA6oOMCZSf1wBQjgBGkoBuohnwkDGH8gAAkQhHWGEGyg8iUOJkvhwjdUQUWICcwAvK3ACAbMBQgcJnHj5A+Ms4xpbTIgAyCnVIgjwsoOENVSCqcI481xGB+x1Svuc4gQ1TIHCKDoBGOZAD8qXA8VoZ8bAjf14+8MpP5QE6BawFAUQAAHKTmY0yKl6rf4IgSZSzRlSUAwc1siY2qyoBQnUm1MUU8XBQ8Tv8FOan47UC4hR4NHeO59EfsVJqPzIC9SkAndT1gWo7VEaA+ACdge73NMDUA71utzvZbSDkRufERHKZmOh2ewUSFmRP1wifDFFkEtLIh9P6FvkQ53XE2mIR2WzkFMs+edANnxk9R0MXBE6osQ1sHAp/TidLCDJvUAGg5OiypRuh5uZu3Sq7VTZXdmuurOzW7Uq3bk0Lou3YcIncRFk1nGwYggrGnEsxGoFZIMeBwNDG7OzOMmUTkk/ZA7OLm61ezNVr5mRT1jgJ9U0YIXeOx1GBWAEWHM+5XftTxm6cHx8fP3p0vErkw/zRU99t7OJACF6LVZCtgihFdRA8I6piPtLBIKS3gLW1uKGn0WV0ITK6PBFk3DQn5Wg/AxQDdXP0NO4Ici5QjQoh6GQX43momoAMCRyddhjsZovPgklA5oQI2RS5CFpmFh3uZxDMxsFv1YRFJZRAoA2HipHylCXk1PFznNMxdkdiAKyoW1FXVzczXQJeu9dsRgcv+u929Cl6GAM4xhzJ1ItMewKMCNyqeSJ/jox7PM9jgBjP6OJ1RUVF6xqvWsUcK6Lo6Gh0zJF8FMDgaU/ySoAmCYFERsGpDhIqg2f+gB7h6X3ebh37WoxtZ8GZU7fW3ypOsAYPj5k1GBE+zFph61N0OLYmaEmfVtwnWp0BGhhHZMNr8wBPUfB32MTwt+hot3b6Q4xtS+c5z7rmWY4nuDLPFk18VKbGqnldirY/a7FNP3l85MUqo1kNokKEfHiZPx40wVA0LfB2x1gEUJkdX1+Tl348wShlZjBaPl2snzBx5Po31o8826Bvf07PcoaSO2QIFMN1EpuMEqo4PAqsAzQDDwKw1ojpAxKM5tieCs2r9U3oNbF4YnHK7E3zRr+VqXcyzmraISYFuKgoHc/iEc9cDoNhAKTkLdlVm+o9tccTou1bPpo9tHv37rPRvyEZrtRRp9LrGravrlqw9aDVzvOCxpA0RQAGwNEIK4cCUA0TM+2ElNxcMKRqfvz+pDWu9JPZXQsQZWVlFaWU9Eztuv3NWl9ee3HxtAwLAkCESgNsRZEeGyVRfuS/AKFaARAle7akZKWkpBQMHGsVMyakYurSJXVCXaIVmWls0CC6zqzKdJhJ1hc0ZYVArQVRlKTGaxJYsfiJ9YpIB0FL/6lNUxFV9rGYLUbsAkaj0Wp12DFAv0TB4Ghdmik5AZW+Jt6QwVIAxWJ5OSBhHeAZIB0khiUrIaNFEJAfGwzIl71mr5l6ciI0O1qxJwO1iJIVTXRCAEjkR+KnfobEyPEsVHTakRyQAawBVDeazThUOJ0A2L0IYAgKdmZj65EYvZr0tTGTJkxdZGGBZIkCH/EKJKLXEi2Z8fPRv/iNKwJmqJcw6QMBfdhsJQCC2dd6JD3sJCMWaLAnMmCeptOGO56XnRvSUEGsaP+oouyBA7MKzlgh1z89vT8idMyU6rGIgnbDvPal4YCdqlSWPmEoqAAsUHCqOWEASSChorlg28amqZVLE4w1Z5IGPP7F44S+eAGHik21emvlxaJT9rATD524DydIiqE/KCKOmDOLpkYcKrZkz3k2JzaAYlHwjZFrEhilxvZp/CguI3Nq4+xuqz/KcfLEMIh21ZKOxwAk2ajsKQa56zSiGcQ2Z8c7Yuw4VAhGn8XhcyDyWYwBR2qvXquOJDVeje3Z/FZNII56moB1KAMQHes4iTowxyvDJ8UWzwC2IIAaMwbgffoASm0BTL6wNbX4uVl32weMcfX85XNvlDw0NcqxooWaDpSlr+oCgTixDmKbskm4PrfGlXj1uWkjZUroEovDdem8Cevah6w76jLjkcuJF9DClwFEKYmHY4OXUw/2ZCSigllDtnXf1muNseZg0gCZjg/ASsYJx/fC51mXS7ETcxzNJKx2A4qj8bIrs/TGEPAMgrb5jzZmZXVtbBxsFAKJhuRk7GzmZEmiORka+l19TR+2sxqWphZWvSO3iMMz4JVljhq4JQqQGEie8N4ERO9ND4tQUqiWOloymiYKFWG7oNQjVMI0KkM12Ol4VU50kcBBHE2TA8BHKUxXA6IJn4HgtdIZiMbWpTEBvM5FYxZkY9EUFDoS7CTmY5rFFIRoBjuSw2EPLrlcHoedF+x4QW6320XR6bXOHEVj0WAUTRF/nsZrXqmxeFkDUVGEsxRFpyZbFZ4NAbD0b965c+eVK5cn+MxSQF+KTFRfqtfrMQBSsgHa7q6KsdrlX5GaBMq1A2aC2EZJOiIo3QOLKSSi17AnF6BYlNL5baPgbcCRqH9D/4aGzFrrTGSm9S7p1sTihOkBXFhrMo1AorIsIkZc5GqBBLsdqKrIGjJndEn8jjXRwWkTV12ktKq4qmfqo1ffi3/h1MtVdWfP4JxMVECiPbEmWeQMQEcAsPx0yiyc1rHYkztXbXKgpL/GZeh+pnXMmDF3x4xpHdM60zbhSCPKpp2HbpoX/1ZmgHoxMQSeFVq8ZgZa2bBrwUrrotHWoIDrIjvOlShbWnwoJv3k+6+ssU2/VB48mz7+1skwD9UugTx2BoBGjIwoStdxRRvFC0YkotjKzvHWRDH9+BpjrZSJKN2gN4Pq3rkj/rv9T2/+36a/nnt3Wq8/RQMuIo9pl/YIIuoBADoDI/ZkXBdZciQUi4J3H3/33Llz76bW7/50ypQp4/4+7h/o+I///9//+fu9tDgavyD/wOJeh22VU4SkIWBE1bVtZ9dO7YPbBxcnGIOzSLCbVuc7/eJDiFpayssfKn/yn/98sfyVS4vjaD5UkoEa7OjgOyBgEyYArpJVxajYLZ74hlVy8FJUlGAZ8XTLrmuPPULp/tP37z+z4dC+AE/qBhqq2YJJDtc6CfmaTnFgsg4R8IxRNHWH4fTpDdOnT8+IiRJQ2pJ4Hkza9dTKwhCmyZOrCxcVhqoXLczvsTiOo8me5QK62NbRpYfERyyVaaRFKTMpOexENoMXUWFWGg6aVPbhMJ3f769Af2knfljJDZv8RH4PrAWopJzfy8k8W6GRNgOCwiJKriVrMrS4N+OlEyq9zO5JZU8NQ6N6NcT5F7/+wfvXJlcUUgC6wmDikYNpRNKHylqTFL/GMRdjYh3R0ahYxP/JCS2gqtEMauNeXbn2t+qV11vK7tX6RxAAGn2UpTzNQSxc8x27RejS69mZ/UYfXOxiSlXorwjgVX9oYcsP399puXOvNM5PZ8CThbaWB+GjLX61HQtkppK5fSCu1wtSyBHV7QW4cv/PP384TPKnXdh7c8mT+1aWxkkUAPDySilyxR3ZaNH0jJA0xTCM775t6NCh2/BBof/AAFxc6MLeliUrF/t5joioGuCcIOBfahtyKt8I6cgfvILRRsgjn/DZsxiJiPPHVUz+eO6Jn5Ep+bEVfVoNItZP8kS4OA5q2yxyG0sFcydiCgaDiaRXhI9B5Af3CtNCobQRi/ApFPpt0Y9kBhEdQbVlEDloICoNO7rQEp1yrxiSJgQU/b1/aPnkwp5x48bt2YOP4/aMe+SpAxUmIESMPVIYqoxIh1jToFVb3bTPIToHmW7vehLHoicxkYuWvR9XDxJoT6hDb1Nt5kT2W9R2A+NtUlGGfz/usUcew9FIPlz7bLEoduhSdJiDyp12S9xu1DZ3mkUMgJt0iC9aPhm8ooi+iTPkhnpjKuwt06vAjJ9DTg/klM9IjkUdVz+iw2YBIOAJoLrfYMlBvQ/RXI9OpWbJZRTzHON/Go/pJx86+PzjHeY8l7XUk5Pj8uhFTmmaY56sNo2Ujegr+SjVZ1lxeLnFLlpnnmr9NlPvSF3ferShPv1ok94Sf7n/w7MfPjx0+fxth09trBmysTTQPHX67MNDZg9pCOB+OUNQil9O4U4arlLmye9mOVxNfxydE4yuWv3y2ey360vWrd7a9WRDxrqiOT0Pfj4z6eWCi0tLbqQkTby1YtTqPraTN144cjHr4hcrHCJt4coc49TsCVn7HrpRltn6h+U9p2aVGM1SQq+Znu03Fpz9YgHq4R1uSGqc9lv7F0Hr/KKmUvfWkY6a+rqkrgdz1qzJ810ZNdpi1jRe8VnjySxVYICr597ruuXZppQSayBj4qx+9nD9gqL1NrP03JqMXjfW/bJ+qcFWkrLRE5PQ68yNFxYUj123f+w0vaepoMpj0HZ2Idk/YP0JueGCQ1D/pXfnrDq4aSoGWF7cHgsl14Ks9f1ElPozHt3effXI4zWe0Sn7cxBA68H3FhRdeWPHgBtCNAJwKTOgaZ1sUMh5FLKzwbWxcVVx8dL0jQUl0eZwQnGqY0in5VuT6oxN2UcbHj1sOll0tsZTUrDRFRx51pJXWtd4Jf2tooP2nKaiKo9ZG3A4zcChsoeDbPTtdXOWX/7jlnisZGPJ6tXnssdaq9atfq5gWmZG1vo356d8jmbw3dScmq1ZA1bdWtD56Js7v7thyqn8roQCKDqOiKIcUDzx6M766JjuVQuGLg8As7Hu1KzLNWFf3dDBl/vXp2+fYwl/+y0XWN59RanYtK37+v3ph1N97qNTLYGZszMsonbnhSVMpWUuqwe4jAa3aPNJtjD6ZLZ4bDkmu93iinVJXjjeYnKPz8mzB1w/iaIx1mWLNrlK8/I8RiAGbKTxFeFS2mysmClwG4BoCm421Zg4aNq9eXNN0LA7zxBTE9wtir0HVUzaHazNM2zOzcsz1GzeHHTX7DbwuxNNtW6DCIE2IAFNa5ZtS8k920Fp55ec+GzJj8N/Pr3w+SVLru975dKxD5YcKDNUvPOXvbtOFB77csmSdzYPu/P02lf2Xf+ybMoH9wt7LDkW8msHDyJypgJA+8P+0P33L116KX/PiAMfPP/N9RlflvX4asY33yz8eWFL2enyV0bMnfHVvpZjg2Z8sqzswIzrn7x+4OvFp9s+TQPabZDIPKPs61Ecf+4z5ZeWHTp0oGLfl5MK1864vyhU9vXzt/s+n182edHaa4WfPPW3v938puLQ3NCiDfknQoV72p7Yu7DQr4imQyLTbi7JM8h9puXSsvzTN5+48+XPaednPB2atCv/w7YNn5ZvKDy9a+Ht0/k/zp1x7Kf8uWmLN7zUY7h/eFnbX14fDpQNUSU20464dneJwvh74xmU/7ohf+8+KRcD5JbdvH/tsx5tCxe9c6D8xMKXPii/M2nloblpoQ2oZKnoPa78HToBoA11DIDeY1kYEwJAM2h7pvRA2/Xa6vNtGGDv2h49bh+4OeXeV/kVn9y899XelbcPzZ2EAYZX5K598dhkv7ojqQDEqa0FoBoAQJn9mfeXLSt/bNGUtn2v5p5/CIuo7VD+13lrv34xf8Y7i+YeGrasfOH3+XOrQxvaTqRVVK99iNgQUPbWyF4IZBvWQLsJSwTV9/Upw25PeX33bx+vHW5CF337fvrrlF/Pi5NWXnt6Wd+0HhfyTBfOix/3GD78syl+k4gfGQ5EtvmjUakMoIyf7jSjWsIUMply80QxrdpEL/qGQrm5dtA3VDhJ9PZFd3Jz83L7ovu5eaggMOFLUXxgt5juB2v5K7WDH0A/Og0ahD740WEQJnyNPgiA3CD3xUHkefwdEMWO/AHTMJGMyv6BiujfIgBFNaQxEVGZE+sVAVReJyBxWySvDfweK8jqsIiqDERsaZIbcoxgZSL9CcsY9K0G5U0GoLzNwK6VzUzyS+1GnbyrBlhlx4xL3dJV61T2aoX8BoRIp6q8GCHfiNgr10DRhKYWSsR+tdvIbGuMzZNiEhkBWbARcZjZubwTDzXpRhFSB1MDUDUzADUlMYUCDKlDpgGaYMepEOomt2YWQJ6YYm3U3pjHkldMHnAAWQE6rkM1DNT3GzjVNajG1T1x+Q8CoGoeaIfPZKZKiLm3HESAGj2YatW3HOi7GkDNH7Ka1c0n+hGo+YZUjrR8VIaiTFu2R6Y85f0a9igAysqFpxfU6tgOgrppx7P3NsiWIcdRI+BxF1Pg1MGzPV1FUaS5qLxNoklhOOX/CwO2lTmHAOC2AAAAAElFTkSuQmCC";
var PRODUCT_NAME = "Opace AI Content Integrity";
var PRODUCT_TAGLINE = "Evidence, not guarantees";
var CHECKER_GAUGE_ORDER = Object.freeze([
  "signal-likely-human",
  "signal-unclear",
  "signal-potentially-ai",
  "signal-likely-ai",
  "signal-strongly-ai"
]);
var CHECKER_LEVEL_MEANINGS = Object.freeze({
  "signal-strongly-ai": "This draft very strongly matches AI writing \u2014 the kind of match we rarely see in human work.",
  "signal-likely-ai": "Much of this draft reads like AI writing.",
  "signal-potentially-ai": "Parts of this draft resemble AI writing, but the match is not strong enough to be sure.",
  "signal-unclear": "We cannot call this one either way. Some passages read slightly machine-like, but people write that way too.",
  "signal-likely-human": "This reads like human writing. Nothing here matches the AI patterns we test for \u2014 though a heavily disguised AI draft can slip past any checker, ours included."
});
var CHECKER_METHOD_STATUS_LABELS = METHOD_STATE_LABEL;
function resolveCheckerLevels(levels) {
  if (levels === void 0 || levels === null) {
    return { labels: CHECKER_LEVEL_LABELS, meanings: CHECKER_LEVEL_MEANINGS };
  }
  const supplied = asRecord(levels);
  if (!supplied) throw new Error("checker_ui_levels_invalid");
  for (const id of Object.keys(supplied)) {
    if (!LEVEL_IDS.has(id) && id !== "signal-withheld") throw new Error("checker_ui_levels_unknown_id");
  }
  const labels = {};
  const meanings = {};
  for (const id of Object.keys(CHECKER_LEVEL_LABELS)) {
    const entry = supplied[id];
    const record2 = asRecord(entry);
    const name = record2 ? cleanText(record2.name ?? record2.label, "") : cleanText(entry, "");
    if (!name) throw new Error("checker_ui_levels_incomplete");
    labels[id] = name;
    meanings[id] = record2 ? cleanText(record2.support ?? record2.meaning, CHECKER_LEVEL_MEANINGS[id]) : CHECKER_LEVEL_MEANINGS[id];
  }
  return { labels: Object.freeze(labels), meanings: Object.freeze(meanings) };
}
var CHECKER_MEANING_PANEL = Object.freeze({
  meansTitle: "What this means",
  means: Object.freeze([
    "Parts of the writing match patterns common in AI text.",
    "The marked sections carry the strongest match and are worth a careful read."
  ]),
  notTitle: "What this does not mean",
  not: Object.freeze([
    "It does not prove who wrote the draft.",
    "It says nothing about whether the content is accurate or good.",
    "Human writing polished with an AI tool is deliberately not flagged."
  ])
});
var OVERLAP_NORMS = Object.freeze({ machineMedian: 2.1, humanMedian: 6.3, corpus: "25,723 documents" });
var INTEGRITY_READINGS = Object.freeze({
  clean: "Clean",
  attention: "Review",
  manipulated: "Planted pattern",
  inconclusive: "No clear answer",
  error: "Error"
});
var EDITORIAL_READINGS = Object.freeze({
  none: "No patterns to review",
  some: "A few patterns",
  many: "Several patterns",
  not_assessed: "Not assessed",
  error: "Error"
});
var ROUTE_KIND_LABELS = Object.freeze({
  browser_model: "On this device, in the browser",
  eu_server: "Opace EU server",
  wordpress_same_site: "This WordPress site",
  loopback_engine: "Local engine on this machine",
  deterministic_only: "Named rule checks only"
});
var TRANSFER_LABELS = Object.freeze({
  none: "The text stayed on this device.",
  same_site: "The text went to this site and nowhere else.",
  loopback: "The text went to the local engine on this machine and nowhere else.",
  eu_server: "The text was sent once to the Opace EU server for this request."
});
function routeLine(label, location2) {
  const a = cleanText(label, "");
  const b = cleanText(location2, "");
  if (!a) return b;
  if (!b) return a;
  const flat = (value) => value.toLowerCase().replace(/[^a-z0-9]+/gu, " ").trim();
  const flatA = flat(a);
  const flatB = flat(b);
  if (flatB.startsWith(flatA) || flatB.includes(flatA)) return b;
  if (flatA.startsWith(flatB) || flatA.includes(flatB)) return a;
  return `${a} \xB7 ${b}`;
}
var CONSENT_LABELS = Object.freeze({
  not_required: "No transfer, so no consent was needed.",
  explicit: "You agreed to this route before the run."
});
var escape = escapeResultHtml;
var safeId = (value) => String(value).replace(/[^A-Za-z0-9_-]/gu, "-");
var headingTag = (base, offset) => `h${Math.min(6, Math.max(1, base + offset))}`;
var countWord = (count, singular, plural) => `${count.toLocaleString("en-GB")} ${count === 1 ? singular : plural}`;
var isoDate = (value) => {
  const text2 = String(value ?? "");
  const match = /^(\d{4})-(\d{2})-(\d{2})/u.exec(text2);
  return match ? `${match[3]} ${["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"][Number(match[2]) - 1]} ${match[1]}` : text2;
};
function gaugePosition(level2) {
  const index = CHECKER_GAUGE_ORDER.indexOf(level2);
  if (index < 0) throw new Error("checker_result_level_not_on_gauge");
  return index * 20 + 10;
}
var MEASURE_STOPWORDS = /* @__PURE__ */ new Set(["the", "and", "that", "this", "with", "from", "have", "has", "had", "for", "are", "was", "were", "will", "would", "could", "should", "can", "may", "might", "been", "being", "but", "not", "you", "your", "our", "their", "they", "them", "its", "his", "her", "she", "him", "who", "what", "when", "where", "which", "while", "than", "then", "there", "here", "these", "those", "into", "onto", "over", "under", "about", "after", "before", "between", "through", "also", "more", "most", "some", "such", "only", "just", "very", "each", "other", "any", "all", "one", "two", "how", "why", "out", "off", "own", "same", "too", "did", "does", "doing", "because", "against", "during", "without", "within", "upon", "among"]);
var measureSentences = (text2) => String(text2).split(/(?<=[.!?…])\s+/u).map((part) => part.trim()).filter((part) => part.split(/\s+/u).length >= 3);
var measureContentWords = (sentence) => {
  const words = sentence.toLowerCase().match(/[\p{L}\p{N}][\p{L}\p{N}'’-]*/gu) ?? [];
  return new Set(words.filter((word) => word.length >= 4 && !MEASURE_STOPWORDS.has(word)));
};
var trimSentence = (sentence) => {
  const flat = sentence.replace(/\s+/gu, " ").trim();
  return flat.length > 110 ? `${flat.slice(0, 110).trimEnd()}\u2026` : flat;
};
function measurePassageOverlap(passage) {
  const sentences = measureSentences(passage ?? "");
  if (sentences.length < 3) return null;
  const sets = sentences.map(measureContentWords);
  let shared = 0;
  let pairs = 0;
  let worst = null;
  for (let index = 0; index < sets.length - 1; index += 1) {
    const a = sets[index];
    const b = sets[index + 1];
    if (!a.size || !b.size) continue;
    const common = [];
    for (const word of a) if (b.has(word)) common.push(word);
    const ratio = common.length / ((a.size + b.size) / 2);
    shared += ratio;
    pairs += 1;
    if (worst === null || ratio < worst.ratio) worst = { ratio, index, common };
  }
  const lengths = sentences.map((sentence) => sentence.split(/\s+/u).length);
  let run = 1;
  let longestRun = 1;
  for (let index = 1; index < lengths.length; index += 1) {
    if (Math.abs(lengths[index] - lengths[index - 1]) <= 3) run += 1;
    else run = 1;
    if (run > longestRun) longestRun = run;
  }
  const evenRun = longestRun >= 4 ? longestRun : null;
  if (!pairs || worst === null) return null;
  return {
    label: "Word re-use between neighbouring sentences",
    unit: "%",
    value: Math.round(shared / pairs * 1e3) / 10,
    scaleMax: 10,
    machineMedian: OVERLAP_NORMS.machineMedian,
    humanMedian: OVERLAP_NORMS.humanMedian,
    evenRun,
    leastConnected: {
      first: trimSentence(sentences[worst.index]),
      second: trimSentence(sentences[worst.index + 1]),
      sharedWords: worst.common
    },
    computed: true
  };
}
function sectionMeasure(section, options) {
  const supplied = section.evidence.find((item) => asRecord(item?.measure));
  if (supplied) {
    const measure = supplied.measure;
    const value = Number(measure.value);
    if (!Number.isFinite(value)) return null;
    return {
      label: cleanText(measure.label, "Measured signal"),
      unit: cleanText(measure.unit, ""),
      value,
      scaleMax: Number.isFinite(Number(measure.scale_max)) ? Number(measure.scale_max) : 10,
      machineMedian: Number.isFinite(Number(measure.machine_median)) ? Number(measure.machine_median) : null,
      humanMedian: Number.isFinite(Number(measure.human_median)) ? Number(measure.human_median) : null,
      evenRun: Number.isFinite(Number(measure.even_run)) ? Number(measure.even_run) : null,
      leastConnected: asRecord(measure.least_connected) ? {
        first: cleanText(measure.least_connected.first, ""),
        second: cleanText(measure.least_connected.second, ""),
        sharedWords: Array.isArray(measure.least_connected.shared_words) ? measure.least_connected.shared_words : []
      } : null,
      computed: false
    };
  }
  if (options.measurePassages === false) return null;
  return typeof section.passage === "string" ? measurePassageOverlap(section.passage) : null;
}
function renderMasthead(result2, options) {
  const tag = headingTag(options.headingLevel, 0);
  const logo = options.logoHtml ? options.logoHtml : `<img src="${escape(options.logoDataUri)}" alt="" width="44" height="44" decoding="async">`;
  const counts = [
    countWord(result2.source.word_count, "word", "words"),
    countWord(result2.source.character_count, "character", "characters")
  ];
  if (result2.source.section_count > 0) counts.push(countWord(result2.source.section_count, "section", "sections"));
  return `<header class="oaci-mast"><span class="oaci-mast__logo" data-oaci-logo>${logo}</span><div class="oaci-mast__identity"><${tag} class="oaci-mast__product">${escape(PRODUCT_NAME)}</${tag}><p class="oaci-mast__tagline">${escape(PRODUCT_TAGLINE)}</p></div><p class="oaci-mast__meta"><span>${escape(counts.join(" \xB7 "))}</span><span>${escape(isoDate(result2.generated_at))} \xB7 ${escape(options.surface)}</span></p></header>`;
}
function renderActions(options) {
  const actions = Array.isArray(options.actions) ? options.actions : [];
  if (!actions.length && !options.actionStatusSlot) return "";
  const buttons = actions.map((action) => {
    const id = safeId(cleanText(action.id, "action"));
    const label = cleanText(action.label, id);
    const glyph = action.glyph ? `<i class="oaci-action__glyph" aria-hidden="true">${escape(action.glyph)}</i>` : "";
    const described = action.description ? ` title="${escape(action.description)}"` : "";
    return `<button type="button" class="oaci-action" data-oaci-action="${escape(id)}"${action.disabled ? " disabled" : ""}${described}>${glyph}<span>${escape(label)}</span></button>`;
  }).join("");
  const status = options.actionStatusSlot ? '<p class="oaci-actions__status" role="status" data-oaci-action-status></p>' : "";
  return `<div class="oaci-actions" data-oaci-action-bar data-oaci-noprint>${buttons}${status}</div>`;
}
var DIAL_CX = 100;
var DIAL_CY = 98;
var DIAL_R = 78;
var DIAL_SWEEP = 180;
var DIAL_PAD = 2.4;
var dialPoint = (angle, radius) => {
  const rad = angle * Math.PI / 180;
  return { x: DIAL_CX + radius * Math.cos(rad), y: DIAL_CY - radius * Math.sin(rad) };
};
function renderDial(level2, names) {
  const position = gaugePosition(level2);
  const span = DIAL_SWEEP / CHECKER_GAUGE_ORDER.length;
  const segments = CHECKER_GAUGE_ORDER.map((id, index) => {
    const start = 180 - index * span - (index === 0 ? 0 : DIAL_PAD);
    const end = 180 - (index + 1) * span + (index === CHECKER_GAUGE_ORDER.length - 1 ? 0 : DIAL_PAD);
    const a = dialPoint(start, DIAL_R);
    const b = dialPoint(end, DIAL_R);
    return `<path class="oaci-dial__seg" data-level="${escape(id)}"${id === level2 ? ' data-active="true"' : ""} d="M ${a.x.toFixed(2)} ${a.y.toFixed(2)} A ${DIAL_R} ${DIAL_R} 0 0 1 ${b.x.toFixed(2)} ${b.y.toFixed(2)}"/>`;
  }).join("");
  const needleAngle = 180 - position * 1.8;
  const tip = dialPoint(needleAngle, DIAL_R - 24);
  const tail = dialPoint(needleAngle + 180, 10);
  const labels = CHECKER_GAUGE_ORDER.map((id) => `<span data-level="${escape(id)}"${id === level2 ? ' data-active="true"' : ""}>${escape(names[id])}</span>`).join("");
  return `<div class="oaci-dial" role="img" aria-label="${escape(`AI reading: ${names[level2]}, shown on the five-band dial from likely human to strongly AI`)}" data-oaci-dial data-level="${escape(level2)}" data-position="${position.toFixed(2)}"><svg viewBox="0 0 200 104" aria-hidden="true" focusable="false">${segments}<line class="oaci-dial__needle" x1="${tail.x.toFixed(2)}" y1="${tail.y.toFixed(2)}" x2="${tip.x.toFixed(2)}" y2="${tip.y.toFixed(2)}"/><circle class="oaci-dial__hub" cx="${DIAL_CX}" cy="${DIAL_CY}" r="5"/></svg><div class="oaci-dial__labels" aria-hidden="true">${labels}</div></div>`;
}
function withheldHeading(ai) {
  if (ai.assessment_status === "error") return "AI reading unavailable";
  if (ai.assessment_status === "not_assessed") return "No trained model ran";
  return ai.method_status === "inconclusive" ? "Not enough text to read" : "AI reading withheld";
}
function renderVerdict(result2, options, ids) {
  const ai = result2.axes.ai_pattern;
  const tag = headingTag(options.headingLevel, 1);
  const assessed = ai.assessment_status === "assessed";
  if (!assessed) {
    const stateClass = ai.assessment_status === "error" ? "oaci-state--error" : ai.assessment_status === "withheld" ? "oaci-state--withheld" : "";
    return `<section class="oaci-panel oaci-verdict" data-assessed="false" data-oaci-state="${escape(ai.assessment_status)}" aria-labelledby="${escape(ids.verdict)}"><p class="oaci-kicker">AI reading</p><${tag} class="oaci-verdict__level" id="${escape(ids.verdict)}">${escape(withheldHeading(ai))}</${tag}><p class="oaci-verdict__meaning">${escape(ai.reason)}</p><p class="oaci-state ${stateClass}">${escape(CHECKER_METHOD_STATUS_LABELS[ai.method_status] ?? String(ai.method_status).replaceAll("_", " "))}</p><p class="oaci-verdict__score">No score and no level are shown, because none was produced. Character findings and writing rules cannot supply an AI-pattern reading.</p></section>`;
  }
  const strongest = result2.sections.find((section) => section.index === ai.strongest_section_index);
  const strongestLine = strongest && result2.sections.length > 1 && ai.level !== "signal-likely-human" ? ` The strongest evidence is in section ${strongest.index + 1}.` : "";
  const meaning = `${options.levels.meanings[ai.level]}${strongestLine}`;
  return `<section class="oaci-panel oaci-verdict" data-assessed="true" data-oaci-state="assessed" data-level="${escape(ai.level)}" aria-labelledby="${escape(ids.verdict)}"><p class="oaci-kicker">AI reading</p>` + renderDial(ai.level, options.levels.labels) + `<${tag} class="oaci-verdict__level" id="${escape(ids.verdict)}" data-level="${escape(ai.level)}">${escape(options.levels.labels[ai.level])}</${tag}><p class="oaci-verdict__meaning">${escape(meaning)}</p><p class="oaci-verdict__score">Score <b data-oaci-display-score="${escape(ai.display_score)}">${escape(ai.display_score)}</b> on the zero-to-one pattern scale. It is not a percentage of the text written by AI.</p></section>`;
}
function renderSectionScores(result2, options, ids) {
  const ai = result2.axes.ai_pattern;
  if (ai.assessment_status !== "assessed" || !result2.sections.length) return "";
  const tag = headingTag(options.headingLevel, 1);
  const total = result2.sections.length;
  const rows = result2.sections.map((section) => {
    const number3 = section.index + 1;
    const strongest = section.index === ai.strongest_section_index;
    const confidence = Math.max(4, Math.round(Math.abs(section.raw_score - 0.5) * 200));
    const label = `Section ${number3} of ${total}: ${options.levels.labels[section.level]}, AI-writing similarity score ${section.display_score}${strongest ? ", the strongest section" : ""}. Show the evidence for this section.`;
    return `<li><button type="button" class="oaci-strip__bar" data-oaci-section-toggle="${escape(String(section.index))}" aria-expanded="true" aria-controls="${escape(ids.dive(section.index))}" data-level="${escape(section.level)}" data-strongest="${strongest}" aria-label="${escape(label)}"><span class="oaci-strip__name">Section ${number3}</span><span class="oaci-strip__track" aria-hidden="true"><i class="oaci-strip__fill" data-level="${escape(section.level)}" style="width:${confidence}%"></i></span><b class="oaci-strip__score" data-oaci-display-score="${escape(section.display_score)}">${escape(section.display_score)}</b><span class="oaci-strip__band" data-level="${escape(section.level)}">${escape(options.levels.labels[section.level])}</span><span class="oaci-strip__go" aria-hidden="true">\u203A</span></button></li>`;
  }).join("");
  return `<section class="oaci-panel oaci-strip" aria-labelledby="${escape(ids.strip)}"><div class="oaci-strip__head"><${tag} class="oaci-strip__title" id="${escape(ids.strip)}">Section scores</${tag}><p>In document order. The strongest section is marked, never moved to the top.</p></div><ol class="oaci-strip__list">${rows}</ol><p class="oaci-strip__foot">Bar length shows how confident the reading is, not how much of a section was written by AI.</p></section>`;
}
function renderMeasure(measure, section) {
  const clamp = (value) => Math.min(97, Math.max(3, value / measure.scaleMax * 100));
  const anchor = (position) => position < 25 ? "start" : position > 75 ? "end" : "middle";
  const mark = (kind, position, label, brief) => {
    const left = clamp(position);
    return `<span class="oaci-measure__mark oaci-measure__mark--${kind}" data-anchor="${anchor(left)}" style="left:${left.toFixed(2)}%"><i></i><small class="oaci-measure__full">${label}</small>` + (brief ? `<small class="oaci-measure__brief">${brief}</small>` : "") + `</span>`;
  };
  const marks = [];
  if (measure.machineMedian !== null) {
    const value = `${escape(String(measure.machineMedian))}${escape(measure.unit)}`;
    marks.push(mark("machine", measure.machineMedian, `typical AI ~${value}`, `AI ~${value}`));
  }
  if (measure.humanMedian !== null) {
    const value = `${escape(String(measure.humanMedian))}${escape(measure.unit)}`;
    marks.push(mark("human", measure.humanMedian, `typical human ~${value}`, `human ~${value}`));
  }
  marks.push(mark("this", measure.value, `this passage ${escape(String(measure.value))}${escape(measure.unit)}`));
  const aiSide = section.level === "signal-strongly-ai" || section.level === "signal-likely-ai" || section.level === "signal-potentially-ai";
  const humanSide = section.level === "signal-likely-human";
  const midpoint = measure.machineMedian !== null && measure.humanMedian !== null ? (measure.machineMedian + measure.humanMedian) / 2 : null;
  const machineLike = midpoint === null ? null : measure.value <= midpoint;
  let reading = null;
  if (machineLike !== null) {
    if (aiSide && !machineLike) {
      reading = measure.evenRun ? `This passage actually repeats words the way people do; its AI reading came from other patterns \u2014 for example, ${measure.evenRun} sentences in a row here are almost exactly the same length, an evenness people rarely keep up.` : "This passage actually repeats words the way people do; its AI reading came from other patterns in how the whole passage flows \u2014 the mix of sentence shapes and word choices the model has learnt to recognise.";
    } else if (humanSide && machineLike) {
      reading = "This passage repeats a little less than people typically do \u2014 common in list-like or link-heavy writing \u2014 and the model still read it as human on everything else it weighs.";
    } else if (!aiSide && !humanSide) {
      reading = "This passage sits between the typical ranges \u2014 one reason the model could not commit either way.";
    }
  }
  let example = "";
  const least = measure.leastConnected;
  if (aiSide && machineLike && least && least.sharedWords.length === 0 && least.first && least.second) {
    example = `<div class="oaci-measure__example"><b>The tell, in your own sentences:</b><p class="oaci-measure__note">These neighbours share no key words at all \u2014</p><p>\u201C${escape(least.first)}\u201D</p><p>\u201C${escape(least.second)}\u201D</p></div>`;
  } else if (humanSide && machineLike === false && least && least.sharedWords.length) {
    const words = least.sharedWords.slice(0, 3).map((word) => `\u201C${word}\u201D`).join(", ");
    example = `<p class="oaci-measure__note">For example, neighbouring sentences here carry ${escape(words)} across from one to the next \u2014 the thread human writing usually keeps.</p>`;
  }
  return `<div class="oaci-measure" data-oaci-measure="${measure.computed ? "measured-here" : "from-contract"}"><b class="oaci-measure__label">${escape(measure.label)}</b><div class="oaci-measure__scale" aria-hidden="true">${marks.join("")}</div><p class="oaci-sr">${escape(`${measure.label}: this passage ${measure.value}${measure.unit}${measure.machineMedian !== null ? `, typical AI about ${measure.machineMedian}${measure.unit}` : ""}${measure.humanMedian !== null ? `, typical human about ${measure.humanMedian}${measure.unit}` : ""}.`)}</p>` + (reading ? `<p class="oaci-measure__reading">${escape(reading)}</p>` : "") + example + `</div>`;
}
var ADVICE_LIMIT = 3;
function suppliedAdvice(section, options) {
  const source = options.advice;
  let entries = null;
  if (typeof source === "function") entries = source(section, section.index);
  else if (Array.isArray(source)) entries = source[section.index];
  else if (asRecord(source)) entries = source[section.index] ?? source[String(section.index)];
  if (!Array.isArray(entries)) return [];
  return entries.filter((entry) => asRecord(entry)).map((entry) => ({
    ruleId: cleanText(entry.rule_id ?? entry.ruleId, ""),
    title: cleanText(entry.quote ?? entry.matched, "") ? `\u201C${cleanText(entry.quote ?? entry.matched, "")}\u201D` : "In this passage",
    suggestion: cleanText(entry.suggestion, ""),
    why: cleanText(entry.message, "")
  }));
}
function contractAdvice(section) {
  return section.evidence.filter((item) => item.kind === "editorial_rule").map((item) => {
    const suggestion = cleanText(item.suggestion, cleanText(item.detail, ""));
    const basis = cleanText(item.basis, "");
    return {
      ruleId: cleanText(item.rule_id ?? item.id, ""),
      title: cleanText(item.summary, "In this passage"),
      suggestion,
      why: basis === suggestion ? "" : basis
    };
  });
}
function renderAdvice(section, options) {
  const tag = headingTag(options.headingLevel, 3);
  const all = [...contractAdvice(section), ...suppliedAdvice(section, options)];
  if (!all.length) {
    return `<div class="oaci-advice"><p class="oaci-advice__none">\u2713 Nothing to tweak here \u2014 this passage reads naturally.</p></div>`;
  }
  const shown = all.slice(0, ADVICE_LIMIT);
  const body = shown.map((card) => `<div class="oaci-advice__card"${card.ruleId ? ` data-oaci-rule="${escape(card.ruleId)}"` : ""}><b>${escape(card.title)}</b>` + (card.suggestion ? `<span class="oaci-advice__try">Try: ${escape(card.suggestion)}</span>` : "") + (card.why ? `<p class="oaci-advice__why">${escape(card.why)}</p>` : "") + `</div>`).join("");
  const more = all.length > shown.length ? `<p class="oaci-advice__more">${escape(`${all.length - shown.length} more suggestion${all.length - shown.length === 1 ? "" : "s"} in this passage, under the writing patterns to review.`)}</p>` : "";
  return `<div class="oaci-advice" data-oaci-advice="${all.length}"><${tag} class="oaci-advice__title">How to improve this passage</${tag}><p class="oaci-advice__note">Editing advice from our writing rules \u2014 it never counts towards the AI reading.</p>` + body + more + `</div>`;
}
function renderDive(result2, section, options, ids) {
  const ai = result2.axes.ai_pattern;
  const tag = headingTag(options.headingLevel, 2);
  const total = result2.sections.length;
  const number3 = section.index + 1;
  const strongest = section.index === ai.strongest_section_index;
  const passage = typeof section.passage === "string" && section.passage.trim() ? `<blockquote class="oaci-quote" data-level="${escape(section.level)}" tabindex="0" aria-label="${escape(`The passage the model read in section ${number3}`)}">${escape(section.passage.trim())}</blockquote>` : `<p class="oaci-locator">Content-free result: this section is identified by its position in the text, characters ${section.start_utf16}\u2013${section.end_utf16}. The passage itself was deliberately not carried.</p>`;
  const measure = sectionMeasure(section, options);
  const modelEvidence = section.evidence.filter((item) => item.kind !== "editorial_rule" && !asRecord(item.measure));
  const evidenceList = modelEvidence.length ? `<ul class="oaci-limits">${modelEvidence.map((item) => `<li>${escape(item.summary)}${item.detail ? ` ${escape(item.detail)}` : ""}</li>`).join("")}</ul>` : "";
  return `<section class="oaci-dive" id="${escape(ids.dive(section.index))}" data-oaci-section="${section.index}" data-level="${escape(section.level)}" data-strongest="${strongest}" aria-label="${escape(`Inside section ${number3} of ${total}`)}"><div class="oaci-dive__head"><${tag} class="oaci-dive__title">Inside section ${number3}${total > 1 ? ` of ${total}` : ""}</${tag}>` + (strongest && total > 1 ? `<span class="oaci-note">The strongest section</span>` : "") + `</div><div class="oaci-dive__sub"><span class="oaci-chip" data-level="${escape(section.level)}">${escape(options.levels.labels[section.level])}</span><span class="oaci-dive__score">Score <b data-oaci-display-score="${escape(section.display_score)}">${escape(section.display_score)}</b> \xB7 ${escape(countWord(section.word_count, "word", "words"))}</span></div>` + passage + (measure ? renderMeasure(measure, section) : "") + evidenceList + renderAdvice(section, options) + `</section>`;
}
function renderDives(result2, options, ids) {
  const ai = result2.axes.ai_pattern;
  if (ai.assessment_status !== "assessed" || !result2.sections.length) return "";
  const tag = headingTag(options.headingLevel, 1);
  return `<section class="oaci-dives" aria-labelledby="${escape(ids.dives)}"><${tag} id="${escape(ids.dives)}" class="oaci-sr">Section evidence</${tag}><p class="oaci-dives__intro">Each section below shows the passage the model read and one measured signal: how often key words carry over between neighbouring sentences. People average about six in a hundred; machine writing about two.</p>` + result2.sections.map((section) => renderDive(result2, section, options, ids)).join("") + `</section>`;
}
function renderAxes(result2, options, ids) {
  const tag = headingTag(options.headingLevel, 1);
  const cardTag = headingTag(options.headingLevel, 2);
  const ai = result2.axes.ai_pattern;
  const integrity = result2.axes.text_integrity;
  const editorial = result2.axes.editorial;
  const cards = [
    {
      id: "ai",
      label: "AI-pattern reading",
      reading: ai.level ? options.levels.labels[ai.level] : withheldHeading(ai),
      reason: ai.reason,
      state: ai.assessment_status,
      level: ai.level
    },
    {
      id: "integrity",
      label: "Text integrity",
      reading: INTEGRITY_READINGS[integrity.reading] ?? "Not assessed",
      reason: integrity.reason,
      state: integrity.reading,
      level: null
    },
    {
      id: "editorial",
      label: "Editorial signals",
      reading: EDITORIAL_READINGS[editorial.reading] ?? "Not assessed",
      reason: editorial.reason,
      state: editorial.reading,
      level: null
    }
  ];
  const body = cards.map((card) => `<div class="oaci-axis" data-axis="${escape(card.id)}" data-state="${escape(card.state)}"${card.level ? ` data-level="${escape(card.level)}"` : ""}><${cardTag} class="oaci-axis__label">${escape(card.label)}</${cardTag}><p class="oaci-axis__reading">${escape(card.reading)}</p><p class="oaci-axis__reason">${escape(card.reason)}</p></div>`).join("");
  return `<section aria-labelledby="${escape(ids.axes)}"><${tag} id="${escape(ids.axes)}" class="oaci-kicker">Three separate readings</${tag}><div class="oaci-axes">${body}</div></section>`;
}
function renderChecks(result2, options, ids) {
  const tag = headingTag(options.headingLevel, 1);
  const checks = result2.methods.map((method) => {
    const name = method.id === "watermark.anthropic" ? "Anthropic official watermark verifier" : cleanText(method.provider_or_method, method.id);
    const status = CHECKER_METHOD_STATUS_LABELS[method.status] ?? String(method.status).replaceAll("_", " ");
    const limitation = Array.isArray(method.limitations) && method.limitations.length ? method.limitations[0] : "";
    return `<li class="oaci-check" data-method="${escape(method.id)}" data-status="${escape(method.status)}"><div class="oaci-check__top"><span class="oaci-check__name">${escape(name)}</span><span class="oaci-status" data-status="${escape(method.status)}">${escape(status)}</span></div><span class="oaci-check__id">${escape(method.id)} \xB7 ${escape(method.version)}</span><span class="oaci-check__where">Ran on the ${escape(String(method.privacy_route).replaceAll("_", " "))} route</span>` + (limitation ? `<p class="oaci-check__limit">${escape(limitation)}</p>` : "") + `</li>`;
  }).join("");
  const limitations = unique([...result2.limitations, "A check that did not run is never counted as a pass.", "No result proves who wrote a text."]);
  return `<section class="oaci-panel oaci-checks" aria-labelledby="${escape(ids.checks)}"><${tag} class="oaci-checks__title" id="${escape(ids.checks)}">Named checks and limitations</${tag}><ul class="oaci-checks__list">${checks}</ul><ul class="oaci-limits">${limitations.map((item) => `<li>${escape(item)}</li>`).join("")}</ul></section>`;
}
function renderMeaningPanel(result2, options, ids) {
  const ai = result2.axes.ai_pattern;
  if (ai.assessment_status !== "assessed") return "";
  const tag = headingTag(options.headingLevel, 1);
  const colTag = headingTag(options.headingLevel, 2);
  return `<section aria-labelledby="${escape(ids.meaning)}"><${tag} id="${escape(ids.meaning)}" class="oaci-sr">What this result means, and what it does not</${tag}><div class="oaci-meaning"><div><${colTag} class="oaci-meaning__title">${escape(CHECKER_MEANING_PANEL.meansTitle)}</${colTag}>${CHECKER_MEANING_PANEL.means.map((line) => `<p>${escape(line)}</p>`).join("")}</div><div><${colTag} class="oaci-meaning__title">${escape(CHECKER_MEANING_PANEL.notTitle)}</${colTag}>${CHECKER_MEANING_PANEL.not.map((line) => `<p>${escape(line)}</p>`).join("")}</div></div></section>`;
}
function renderCertainty(result2, options) {
  const ai = result2.axes.ai_pattern;
  if (ai.assessment_status !== "assessed") return "";
  const model = result2.route.model;
  const raw = String(ai.raw_score);
  const primary = ai.primary_display_threshold;
  const secondary = ai.secondary_display_threshold;
  const barLine = primary === null ? "This run did not record a display equivalent for the certainty bar, so no bar figure is quoted. The bar is a margin rule, not a probability cut-off." : `Certainty bar: ${primary} on its own, or ${secondary === null ? "a second passage agreeing" : `${secondary} twice`}.`;
  const meter = primary === null ? "" : `<span class="oaci-certainty__meter" aria-hidden="true"><i style="width:${Math.min(100, Math.max(2, ai.raw_score / Math.max(primary, 1e-4) * 100)).toFixed(2)}%"></i></span>`;
  const flag = ai.flagged ? ai.flag_reason === "secondary" ? "This reading also cleared our strictest certainty bar the second way: two passages agreed. Two passages reading as AI together is stronger evidence than one alone." : "This reading also cleared our strictest certainty bar: the strongest passage went past it on its own." : "The reading above comes from where the strongest passages sit on the scale. Our separate, strictest certainty bar was not met in this run. It is set deliberately high on purpose, so that few human documents are ever wrongly accused.";
  const rawNote = model && model.input_contract === "raw-v1" ? "The model reads your text exactly as you supplied it, formatting included (input contract raw-v1): it was trained and measured on raw text with the markdown left in, so formatting symbols carry no false weight." : model ? `The model reads your text through the ${model.input_contract} input contract.` : "";
  const identity = model ? `Read by ${model.identity}${model.registry_identity ? ` (${model.registry_identity})` : ""}, ${model.precision}, ${result2.route.location}.` : `Read on the ${ROUTE_KIND_LABELS[result2.route.kind] ?? result2.route.kind} route.`;
  return `<details class="oaci-certainty" data-oaci-certainty><summary>How certain is this reading?</summary><p>${escape(flag)}</p><p class="oaci-certainty__plain">In plain terms: the model gives every section a score between 0 and 1, and the reading above comes from where the strongest sections sit on the scale. On the section bars, a full bar means a confident reading and the small number is that raw score, never a percentage of AI text. The certainty bar is a separate, stricter test: a real AI draft can sit just under it, because it is set high on purpose to protect human writers.</p>` + meter + `<p class="oaci-certainty__raw">Raw model reading: ${escape(raw)} on a zero-to-one pattern scale \u2014 not a percentage of AI text. ${escape(barLine)}</p><p>${escape(identity)}</p>` + (rawNote ? `<p>${escape(rawNote)}</p>` : "") + `</details>`;
}
function renderRunRecord(result2, options, ids) {
  const tag = headingTag(options.headingLevel, 1);
  const route2 = result2.route;
  const model = route2.model;
  const report = result2.exports.report;
  const rows = [
    ["Route", routeLine(ROUTE_KIND_LABELS[route2.kind] ?? route2.kind, route2.location)],
    ["Where the text went", TRANSFER_LABELS[route2.content_transfer] ?? String(route2.content_transfer).replaceAll("_", " ")],
    ["What was kept", cleanText(route2.retention?.statement, `Source: ${route2.retention?.source ?? "unknown"}. Result: ${route2.retention?.result ?? "unknown"}.`)],
    ["Consent", CONSENT_LABELS[route2.consent] ?? String(route2.consent).replaceAll("_", " ")],
    ["Model", model ? `${model.identity}${model.registry_identity ? ` \xB7 ${model.registry_identity}` : ""} \xB7 ${model.precision} \xB7 ${model.segmentation_contract}, ${model.input_contract}, ${model.features_contract}, ${model.scoring_contract}` : "No trained model ran in this result."],
    ["Counts", `${countWord(result2.source.word_count, "word", "words")} \xB7 ${countWord(result2.source.character_count, "character", "characters")} \xB7 ${countWord(result2.source.section_count, "scored section", "scored sections")} \xB7 ${countWord(result2.methods.length, "named check", "named checks")} \xB7 ${countWord(result2.provenance.protected_facts.count, "protected fact", "protected facts")}`],
    ["Result reference", result2.result_id],
    ["Report export", report.available && report.complete_evidence ? `${report.format}, complete evidence, created only when you ask for it` : "Not available from this result."]
  ];
  return `<section class="oaci-run" aria-labelledby="${escape(ids.run)}"><${tag} class="oaci-run__title" id="${escape(ids.run)}">Run record</${tag}><dl>${rows.map(([term, value]) => `<div><dt>${escape(term)}</dt><dd>${escape(value)}</dd></div>`).join("")}</dl></section>`;
}
function normaliseOptions(options) {
  const given = asRecord(options) ?? {};
  const surface = cleanText(given.surface, "");
  if (!surface) throw new Error("checker_ui_surface_required");
  const logoDataUri = cleanText(given.logoDataUri, PRODUCT_LOGO_DATA_URI);
  const headingLevel = Number.isInteger(given.headingLevel) ? Math.min(3, Math.max(1, given.headingLevel)) : 2;
  return {
    surface,
    logoDataUri,
    logoHtml: typeof given.logoHtml === "string" && given.logoHtml.trim() ? given.logoHtml : "",
    headingLevel,
    idPrefix: safeId(cleanText(given.idPrefix, "oaci")),
    actions: Array.isArray(given.actions) ? given.actions : [],
    actionStatusSlot: given.actionStatusSlot !== false,
    measurePassages: given.measurePassages !== false,
    advice: typeof given.advice === "function" || Array.isArray(given.advice) || asRecord(given.advice) ? given.advice : null,
    theme: given.theme === "light" || given.theme === "dark" ? given.theme : null,
    levels: resolveCheckerLevels(given.levels),
    onAction: typeof given.onAction === "function" ? given.onAction : null,
    onToggleSection: typeof given.onToggleSection === "function" ? given.onToggleSection : null
  };
}
function buildIds(prefix) {
  return {
    verdict: `${prefix}-verdict`,
    strip: `${prefix}-sections`,
    dives: `${prefix}-evidence`,
    axes: `${prefix}-axes`,
    checks: `${prefix}-checks`,
    meaning: `${prefix}-meaning`,
    run: `${prefix}-run`,
    dive: (index) => `${prefix}-section-${index + 1}`
  };
}
function renderCheckerResult(result2, options) {
  assertCanonicalResult(result2);
  const settings = normaliseOptions(options);
  const ids = buildIds(settings.idPrefix);
  const ai = result2.axes.ai_pattern;
  return `<article class="oaci-result" data-oaci-result` + (settings.theme ? ` data-theme="${escape(settings.theme)}"` : "") + ` data-oaci-status="${escape(ai.assessment_status)}" data-oaci-profile="${escape(result2.profile)}"` + (ai.level ? ` data-oaci-level="${escape(ai.level)}"` : "") + ` data-oaci-surface="${escape(settings.surface)}">` + renderMasthead(result2, settings) + renderActions(settings) + `<div class="oaci-result__body">` + renderVerdict(result2, settings, ids) + renderSectionScores(result2, settings, ids) + renderDives(result2, settings, ids) + renderAxes(result2, settings, ids) + renderChecks(result2, settings, ids) + renderMeaningPanel(result2, settings, ids) + renderCertainty(result2, settings) + renderRunRecord(result2, settings, ids) + `</div></article>`;
}
function mount(root, result2, options) {
  if (!root || typeof root.querySelectorAll !== "function") throw new Error("checker_ui_mount_root_required");
  const settings = normaliseOptions(options);
  const listeners = [];
  const attach = (node, type, handler) => {
    node.addEventListener(type, handler);
    listeners.push(() => node.removeEventListener(type, handler));
  };
  const wire = () => {
    for (const button of root.querySelectorAll("[data-oaci-section-toggle]")) {
      attach(button, "click", () => {
        const panel = root.querySelector(`#${CSS && typeof CSS.escape === "function" ? CSS.escape(button.getAttribute("aria-controls")) : button.getAttribute("aria-controls")}`);
        const open = button.getAttribute("aria-expanded") !== "true";
        button.setAttribute("aria-expanded", String(open));
        if (panel) panel.hidden = !open;
        if (settings.onToggleSection) settings.onToggleSection(Number(button.dataset.oaciSectionToggle), open);
      });
    }
    for (const button of root.querySelectorAll("[data-oaci-action]")) {
      attach(button, "click", () => {
        const id = button.dataset.oaciAction;
        if (settings.onAction) settings.onAction(id, button);
        button.dispatchEvent(new CustomEvent("oaci:action", { bubbles: true, detail: { action: id } }));
      });
    }
  };
  const draw = (next) => {
    for (const remove of listeners.splice(0)) remove();
    root.innerHTML = renderCheckerResult(next, options);
    wire();
  };
  draw(result2);
  return {
    get element() {
      return root.querySelector("[data-oaci-result]");
    },
    update(next) {
      draw(next);
    },
    setActionStatus(text2) {
      const status = root.querySelector("[data-oaci-action-status]");
      if (status) status.textContent = text2 == null ? "" : String(text2);
    },
    destroy() {
      for (const remove of listeners.splice(0)) remove();
      root.innerHTML = "";
    }
  };
}

// ../../shared/report/logo.mjs
var LOGO_PNG_96_BASE64 = "iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAIAAABt+uBvAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAARGVYSWZNTQAqAAAACAABh2kABAAAAAEAAAAaAAAAAAADoAEAAwAAAAEAAQAAoAIABAAAAAEAAABgoAMABAAAAAEAAABgAAAAAKkzX04AAAHNaVRYdFhNTDpjb20uYWRvYmUueG1wAAAAAAA8eDp4bXBtZXRhIHhtbG5zOng9ImFkb2JlOm5zOm1ldGEvIiB4OnhtcHRrPSJYTVAgQ29yZSA2LjAuMCI+CiAgIDxyZGY6UkRGIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyI+CiAgICAgIDxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PSIiCiAgICAgICAgICAgIHhtbG5zOmV4aWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20vZXhpZi8xLjAvIj4KICAgICAgICAgPGV4aWY6Q29sb3JTcGFjZT4xPC9leGlmOkNvbG9yU3BhY2U+CiAgICAgICAgIDxleGlmOlBpeGVsWERpbWVuc2lvbj4xMDI0PC9leGlmOlBpeGVsWERpbWVuc2lvbj4KICAgICAgICAgPGV4aWY6UGl4ZWxZRGltZW5zaW9uPjEwMjQ8L2V4aWY6UGl4ZWxZRGltZW5zaW9uPgogICAgICA8L3JkZjpEZXNjcmlwdGlvbj4KICAgPC9yZGY6UkRGPgo8L3g6eG1wbWV0YT4Kwe07qQAAJ41JREFUeAGVfAmAXUWZbtVdekl3p7N2OgsQEQj7vsSFRVAGUeaBKMgO7yFCVBBQkUWf4ANxBmQcR0AWEVBkZ1A2URBkAmEPEIEECAkBQvat092371Lv+/6/qk6d283gFJ1z/vqX719OnTp1lostTDvUGGusNdwZpxt0IuHYYS/ZUVGagwFtpZvThFhtgib75DjjPOFctIWSML2yYAdY6VDu4I1NrJQbwAElAILDaNS3p9gXNPhWMsgFLmaDHuRJs6ZEKICzecyRiGbDqEMbYkbb/1aTXqDqlUkE22Af9qIpsMzI9/QwopNloSKpjkBpPxrQUJVFih5FnsbOm0sFlGu5C82aBgokHLrwxydIm/Y5p5DhkIxkoMeIcrGPQUQ0UYC0GS8qgEiDjHyNU4GbjKXbxIt2IxPqImAGj8Ex9gLnTKFZlIYHtWCRUuoxVEeVZBtYYhWNIxGg4ZrHCX9NTZnD+cEwU486apIJEirVSRAQpEqiPLEJJI++RliIrEAkxz7m4LHU5kOAU7YeTOV4PnZC+W7mLaFYuehT4kiBRFEZiY2QAdzzUQKtQnQGIoUShZGhFCIeap2DPDMPEiOlFyAGPL+Pvn1Q3EHUFIkyVUUt1Nyr6S4vCH58QWGbyhXKb1UQWYoW9Jt1gnIMQIsQrzDU1wQiID1jBAVL8JXMQlQWuAkLPV9fMJUv24SkBxUm2J7JXRpJk4aK41ZBYzclxHBE66ZIoJOphVMnA9axpsiZXvDkwimGSSGzCdJsr5Y5V15ISYIbFVXsMWUX8VUndjMvoJq4IfqMDUr/xCzj51DYgRf9U4k6BStaR1sOoryymtCTDQVSrGiT5hy0sz3U6E9sMhORe1HQjWFlcTUVAQb612SiXbnYZS4iJbgePBhm+w+/RErIqaLQApSPQpPD8SkxvMxTMtdEGC0wunEayvRDxDjpApkRqoYtRZlNBBbCizNmxMmAojAqQynx6DWHuVAoZYuFB/IwmafoQAgxCPoYQVFPqxPxoIxDEaV5EN+DcoADR01VlMKkHLprwgwgVEsh1KxpG5UVJ0XLw8YTx7Mll1w6w31F8Og0nmKeozbBMnqMhsrBFn9eK6OIEQFUM3YjEcx8mTxIDCglVKZAKf8fodVKtjkXoYM9ydAlpNLpOoPcUtBJ4wiqajVcQsNhLfqKBFQaDeqRI1weQPyBDkr+3Ex90CJpKhL9QqF58CV6eRL6YgiP/porCMFtohw0PStRk6kMtxrIIV7sNZoQ7ghw3i/RvFZQ0m50V62ZUsn0TjSlMpWppbNGAFeu6gcMXz2KgK+a2Iq4WjXLVhrXMKWicFIcNWjaBlAFCD0fduzSKHZENTgE21lM0iFRT6R+Yahd3Wo3MpviSbvVmt16i8Y3jnfbbmORT+7M14jk9pKxyfGVCOPwymZ8+pUhABkK9OLL9ue/Nu8uNeXhNRKIXC7KEQTiSDfyhI1NVhxyghj6nrRNVzGa5JrqaYFygmEdamKMWFNvmMk9jYvPMRMm2NnP2r4+vfopRsDziNixAMLVRx+EkD5EZGOc4zg26mbcWPPpPczE8eZbPzD9A6bg5dTQExkcltYjD4tP+F4Yx7IQGlOzgXIxgjQKL5YLmbpOHUEndiMBkxGhq1X3mU+a6T32ol+aOx8wBQZOeAHhQQo5BOu4fCC0wHuJTAI01UPrTjnKffNos8cO9s+zTWuLDwlF6WznPIGqEVnciBFpjlRFS+NO6SQ1WuWb4zrIxy8SccCAg5sIpYzAprL6jZraBxNHpWeCGzDmpddMuSRTRt6r2upTL8UfDp7hhwQqVfvyaxxb48dyJkoU3P89227sNz+8zBRx6qmgKW5hj7yJEeTFLAszxBwUGjTJQZMdxaF2KYiwVU+2MZTYw3Ejghw+XANk2GMmQh9cr24tZvEwtsQSotSNP/JiLC4hVX0NzNsYUyy43l6zcaPFNS5rdEV/+ehCapGfekz0o6HFHBQbMQU3ciKhBirMMJWrSkGme/Awc0AT89G0Xnfe6aar0+fvy+TMUy/Yq27GCcjZF2raYBLzF0f+lGyVS6F3FX1ITaFfq1lMUiDoUo682IbqiH40EhXvTvOFCExV0K2aCxdzkMoTpWAdjFRd3QvP22d60Zj4QZHnP6bPTaeYPbYzy9abNWtYDqjCfLNNeBt43e9NrW4+tavZZKpDjTjlEDqdtMnoHzSPzzFDG+iPcv5jAxDMR7WbcosbGrKFoqnXTWnYWinmrAQMQ8YEUZqihKuk+Eou81SKDcLEAGzOdkHqNWNf+ZKfDhAqhLkRmWNmuPUec/Pdpq2VaRWL7upLWCyUr6Vkzv6626rX1QjP2U+bOBcYY2rGnPyBfXouu/iHogwOob620XBTesxFZ9tJ44wZ635yjv3xz03fRpx0WdoAjJgR2fuQHb0qker56QG2mKQ1p9RIQcUAxmoIwgMlhBopH7QQOswDHIxlIsNZUKs75IaGunDYSs0rQ+a8fzGTJ+HSngUIikFRhzMLRtDrb2LZiSPgALDLdq6GVWjZVav2c/uYztH26+ealqK59Fxz4pfNFdebglzgYlT0FLIAjSb4Pi/tYpvTyUZDMoJoqi0LNUOBJLKViBFEvudk/UjxdMBli30S/g895P/3BfbFV/Xsk5oICnXDkcPc3DGKJmhV4w7azx6yH0ico0zqoqvMK6+ReuBRs+cuphwX7lT3TePIoklygQZRgmZuzzIlc1AEG64tMYscsqzjLRIHgWR2KQxPh1rd4nSDRhGZEwSXJdOouu23MlOn+MWeRwxB67w7MGCxYhiqUojBceefzBNPm9ZWUx2yxxyGNZd95ClTtG7PnezCxaZWNS0tEYYEXUljQDKcGZxGJzLNKQ3XG/AIJVexjKsWAhc2FAJNJ5boklxpgSNe2KGul7HjxnWbzTdxyAp8jJqWsquhWA3b2mp//N3GVpM50aDplRrGAZD6uMSdcr6ZM5dcTGcL3rR/+S/T3sbJaMVqe9n57tf/aoolXOnNDbeRSFuCI+xQGpY+0Yu0xh2tLN+LDW9RLoTvBYwoBIM0/gVRRIpTDKRSU3f8V8zRX1FdGrUb+9pimmFc/PRKO20yl0uKJLYeCccZ5xqWyG+87XiPKg1zMJbR/DPmjUXm6+e5K39iBwYLp//QrV7LpSmA6OPDmsiGhZxpZ7akmgrkk860U6oJ1ANFrvbR5anrhzBu6BcsMtffaUe185hBRT3gWvz3+RwCSPu5l3GFCn5UjBwFTVGwbSnjquUdBlXqwHzlatPXj4uXW7OOzw/Y4D7o6j7GGG2hA5GqpTrBv8fhI9esKYxsIyKNFSDT+xBKsNUQFrgq4bqE+XXdBvsfN8KEkgwJryx5opGFaTVZBhI8N4i8KXcYGUBQFzAEgT4GFBoccR/FlLEXW6TVPLqI/NRUrUSUFkh8R70IHSJq8p7JQXmvYQoEh+GhRhDhSsD7jOaGxPwwa5bk+mk86kVX3cmqgPrN+M39DFMBfcAhchU3GzGHWCCxiAeoWTXDJ+Wl6iqIlEkY/sPx1QmX4s2mubY2skIBWZmVa8yatTzyvkVC9ZIIQlTxqEsEUU1Aqa4IYphYk42ubtVXKlVaTVMdn2R2ikUjHvgQdNwHaU4U1DwudLQA0Qq3AjWz7cfdz/4fbgj4ZEUtePky9pkX7Pcu5jnCmSgcJyooCLZSGHB4uxsCiNggtHBV3IU1aDdUM7hlkyhYDm3oqqluwVciyDO1KIoEZenNamYTMdRP7EIDdGRyMiYjk8sx1q9+mKZDbnZ0lxnbbue8bOa9Hh99uC981kyawKcTruHO+prbdober+KSxbIEJ4BvgDU4aC6/xr65KAuQlzxUrYCbL/vFAwqbTjOVQXPg3uYvs/mwMZhn+v8IFbOQJIJFNoICh3vNO25BxBZhwBlxrIkma6QzDGuEOdg98aS94S7T3sroMT3vtSuvxxxIBTtpousZb2ocBUQXD9nsBKpasW2AkBsUSHE7ijs4TO24Qf1fBzbO/N/2vkdNuWB+eIarV+2jczj3M8k0bImqiaFdcSfi4Dt01CaMbfZkRGBP8KaTRbmig41ocM+WCyWNwQskV1tu5dKuDWtcubTJ1MPvy3AOXvAvBS2clFULpGFDzpiwOK4McR0E9Ioxxx7hDvsCPaP0UyYV7n7I/fRqzmVYChxxqHnsGV/jfGDUTxug1IdnSrBZ1lGWG0EyImDpjaMSMFI6+onMSAQRENCUzSPP+YQ85XspODhNkPMQ/6BOHZ45tGWsfqyzX8adquCBjblmI55JF2297gCOW1nMQZiIcCaywasgiHrgYE9vlHighKBQpD4Pv6MtH5hFA1BKYyvCkKJ241btI0q0AUctsfUQAcdYPBXzCciaBQ9ucKLRwrrTjjEztuCdB/z5EKK5YPb326t/a5YspXKrsbfeZW+9z4waxYceR3zBzTq2UK1hfLkDP2Mvu4rDCg0AckRiAEKEhAjPA0AmNUUYCen5DS/zKiYDFE0TA+l6ftRLmVT3VmoLocpFQEQcHBzePXbCMZf7ALL4imKdPAArFu2O2zVmbMlrmRjSTXSlrutVM/Y+s/g9n5ImhkeImInuedCWy41Tj8Nosv9+vXnoMVl8pggSB5AF058jDEtGqjqKAXsixkG1dA4CSmIRSX8oIowKNI/IlDiUBxDB4ahFLTBwhpzbf6Y9cCYYNMZYwUJ66QdUwxz0vYsLnaNEAAblCgrKo+Pp9YaN8i4McNokBnasufVed9D+BqPs7gdZMm0QiQp7wQYsIQU4Sr1B0I/KnvjIy7ygiTOlosPhHqKrSFgOmdffsqdfYNvbmT1nGSQpZVi6TK9iZrDCPzZKE+PoUS58MhbpNfMsFK7rrBvW69nKlCDgZZoRVYkokKlHfY6sryMI+qrUhEMPURCJqBQ56s93aQMyCvEM6IV5WpPI47oPiyBNyQ+LKERiATDjCSewPXrCizFlfiGFuZp4cVM/Q6dcNTN9ofjADC2vSU7aMpvIBUud6aQq9spIVZRGtuEZqw+CYwiDAmcanmAolKj6ukQIQYyuqCmnKPZowZ1Xwk6bSlM6px/MVCH2UisPJDu+OFSv/jCmwpFojxiBR9CBjJB0Kec8lm377eXaMcuAJRnCF/5buMS8hifNWPiqtpx5ARiqxJGbXRhJh75IaqhCcWovlHhDXxRzHAlcHD+iETgCkgBUbE3dcKshNlEpRyTRge+xdJe3Ik+UcTH25bauWre7bekuPsdhrIQJlPAYPS8sMKd933KdXeQ1G8a6VqI4VEFIPFo1G7HY0WrJWw2sm1AI2I4bY8/9pp06mdPZBWe4y35lh/DCIx9Yc85SHZ+I0Kqg28iXMLBB1OnMSLZkmexDVShralkkOWDxBY4MDbyNwDT6h8fd40+xFrI6dqeeYHB/b4sOz1MvPddtvRVXfXojFsLlXlBtrWrP/amZ+ypDRWWnT3Wf3NW0tJmhiv3SwW6L6fbMC01b2f3gdHvsYQYrJjxsHN7SAEekM2ZGASY9rL42IeuwH+5MOTGDTEFMgK+ZcfiiOQwfO/8NvHWwuKVAw8E/5nBXxIkhg2b+Qh6iOm9LKUUjwZORYwb3EAMDZkOfgDmDJfeRh7pjD8XaCldgfKRrL7nGPPksF9O7bGdm7m6uv9WnoVC6FbyUMUwHnoL3VM9P0pE1gs4I2F7dVwG9qBPccJ/DcgVr21pca4vmzMkJCigJZo1f3iix5fQzc6jhjQguefhDZfH6589PmxdeMeVWW6+6g/Z1u+9o//NhSrebYT5YxoVV+lYjRQWtAWLrY47iSMRaCJE8MMsLtKdJEs73xQNodRXYdBsbp1w8hxCH4HuRjg4ywz+QkPFTIOSDN66x3HCKJLE4lDPO1WFQwnjhybV0nXnwKXfbH83suVgx43WzeekN86/nu2v/jTf3eBh0+fU4bf0sLREkFQkRZsHK3JJ1g0KaXfMIijpK+KDhirlwi+hHQGwyi2WBjYSJmuFWAE+2ivJm1TYwjnB2sSj4NuNHZ5ptZ3A6R2b0Y3Hvai/8WWP+Ilsq7Dl9YJNxvL+ifuN18/sLbKnk9sO1D2tL64aeM9ed2Tjxq/gConjDravd0qfbOgareLEk4MH7sPgC4yNz+YgRFHDCXg8Keswjv1UmFSmQ8Hx1ECxe+X3hc2an7TG0OGQwrUyZbJavkHI3+D5r/QaWD5Y6ZisVN1TpbG1cedSK43ZfZ8qAU3cyJTEr6QIKROMD886TdHxwwRxsH3+z49ibet9bU8CVQZqGGkjsAxKJ4Y3guZafpHOi2EmMPKnY6TYqMwIZZqKK8b5ytX1/hevtcVN65YySKxHOnEXv4MoFM/uTKzHFZGGjRvV6o1Y69cC1x81cf/uzY+6bh+tdFoOerSgOi4l/lPBfo1HYZdOhs/Zf/aN/WnbyLb3WQ2qQSXgZkjDR5Xhm0IxB1ePxyL/2SVByJEwBwcx9iz4IKfzIUQ2NHVKsAxcusSd/h+cFljnga0oQ4cKEhq5czRhfgHKYjEvmszPcipWFr982bu0GvG/GDERtrYXQ0sX7WDyJxBCTJH/7tNtrk42f2aqOO7/BKrCh/z9o+STU18g3qwqaROMrGiag1K/S1E30BYD56oFeux6M1IhyLZYU2CcSNdjHKVIbqJX4JLZckweQYgJDPbMwEIfMzK0HZm5WufbJzv5qEXN6o17YMFSeZis8k//x8uiwyZeHEUobforFPPWABkUkqBAxjabjSX44t1SHjxIld4yID20ZnFdBYjJeYYo8fe1E1sAVDfcSEnJjyM7conLvyUt7uuuzF5afXdyBVaccpUZ4ZMBw/mcN+rkycVQ3FShVycNHSVa3ABb2MRq3cdBiSdjd6fAcA/diPlI99FFrRIJOWRV848Ovf5Et0Hl5w0pwi4lDm48fevj1LlO3O24ycNsJ7/aMMz9/eMxL77ZLdQIgLIaFFGS6h1iOJbz5IyDHJLMSBSo1n2KZiiBpVyqVSiItEqYfOaBKRfvcXHfSl80Zp5ibbncDFUnQR5gpqhniU5ZCsRyCNv89V3gfgwlNLFEse+khqw7fo+/bt9Xuf6X9jpOWbtpTv/rR7rPvGY+BhXOQlqqbRCO2wzei55XzUmXqSSeYTSMocyJ2I2IkiDFdKHoaU0bZzH0N90T2a8c2fnZu4Ac8qEUrRdKuj0yk4Hz/ykLrIuP6M2fWXPNk1wFbD1x+yKrv7GunTaje8ET36XdOwIUwFDEg+6izmDKQlIIXaop7TwdxDIanWDyGQTrCPhqozLsWaHLCcAWpnooFe9Pd+GyjsOM2DgtlWehRTSdbDBM15eiIdEyP92VuwVtuxyE3Sh3TR6HoHp7XddRvzO0nLJs2qXrbnO7TbptYxQUP55+PR92jG8cdDT+ixSSino9NYHGKCbjEocFkE4XmGu1CFKoGNisb4DOm6KOLG3c87nllfpQEgQIGQ+0lW3q1BVdssfUaaMxCUVhoaTz0Steh15u9Nuv/xRPjKw1Uh+qqINHw8YkQ/vIQbT+USLNIlcQthCXvP+ZBg+AxZ0DPoemiBb2MFUTJHoug+NI9Y8MWg8X7EDZoxSEhFAaRrTbMqJZ6S7mwsa/QYCHQaPnoy12Pzu3iFzOYl9RQk4RKwYxtq+MFUl3VxSbD9gDKlS0dpnkJk068Dob38DkosdeIcgx0NJkERhlUy6jMSbP58H60igSXfw/Nbz1o5/5fH7n84dda5NufiB7CVyQ5osgEs/jOU4dmbjl03RNdgwMFXQ3QhlVIQlOOt80Ho8CqHJzYwlT8z03k7juw8kYJtAji4KHniOhtonMQkDeNc2F6TYozspnCOs+NKttfHL7spN1WmzYNWSxgRNhorpiyxaZR+PPro078Xe/S9QX5+uZDXKRhg1aMGEPkkGhogaDSpBXVhVBhtKQyOvmWSYWfddW4CT81j+g5QL2F33naYE9nLT6MjWZi429ONHZMDesGCy++2z6Eu/nsTjUGA4tgrfvoVomc82iVfcSZHO2A402ivSd0h22qJ92UAeM0jpz74XoeOtXiFc8W5i7x7xS9KJpmc2WMHDKHFSOro3OcTmiwjPBQUTpyIkEHsRPdpI9clZnYgyQv5RNFG7migOdbdf5IAgnplIzg8LiLzwD1DgOa8ntBDHq8R9Tn7XgjBjZe2GOqAI3vEYDFD2JgO8TbOrwjhX51qIDTH1B4hMbAfES2WHJ1/W5YwsOlHrXARyDYWvn2BYCwwo2JXNUYMUuGNZp8PcR+U9NrIJjMi417/htpkmYobF7HR6U8lXkU7vAd76d3dYcfaOe8am77A4uCj32+dYK5/zEz+znJGe8hama3HdyR/4yvVczCRfbm/8RnvYTfd6Y7/PN8T//2EnvrvWbeG2Z8tzl9llm+ylx7Oyt13KGmq9vc/4ibdZx8LsVnr/wd1dU3u38+wEzfFA9hXcnaPz5m31rkZn3VPvI0/XZ3mnNnmSeeZRGBj/t6TGmtLYW33zH4fVFzC9mSjyPD05axMWv+0wIFJXLCcVKebLPhrMbcSgNOodD4yqFm353cx2aYhx+zq9eZCePN5/d2by6xf3uGF2N8ejFzFzwYNSs3mHmv2b0/YXbe3hz3bbPnzo0Lz7JLlpn5b5o9djaf2Nl844d4B+/23dt0lM2Ct+0Dj5u99nB4sfPY06aj0/RMNNMn2TfeMytXmdGj3ef2x6fF5s1FtqVo8RoDX1of8Emz7fbmpddNpWY+u69bvd4uWGg6OtxWU1EyO3+R6VjJIaZnn6YZ8uBeMg3XHRFwQYIbZtioGHupXrbVbmBHLbGWDZa8m03m0/LH55oJY+xuO3JA4QYTj0Nx3mnD+D/qUJxE9rsX2u9cZC/4qXnmRY6a475i3/3AfuNc+70f23MvwYLbHXGIwTcb+EUnnkCeejwq4vS3qW++bU/+nrn5Lqb2b9fa0843775rcbK8+JI9/Xz7rYsMHtoXnB00jfGjzanHmEbN4dcLOGHv/6s58Ww753mzdoP9zoX20qskIuat5fARcieVCfmiL0WhoKAFJZmI2U1bEHG5Ab7v8um6+/SeBXzddOVNhQ+Wm898AsB6o+eVoI4flH5sUxxq/o3udP/1nPnBFWaw323aa1+Zbz5YYTo7zLz5ZuF7ZvPppq0dv5K2Tz1nxnSbE/Bup8Zn9Zzd8EqDwx7wfImK+w48J9hjF3fXr9wtPzPbfBwLS/4W5E9/Mwfsbfbbo4DDA9eYA/HTK0TLSco4fcYYziFm4ZMJ4yZWJabIOSgOHGSe0rFAWg5so31Qs22tbr9PNdb2GY6dmtl1J9PbwwmbUKqNJzgNfryBd6flFnxVaEa1mvFjUEX8Osp04ce4GDJ129Hm8JPE5StpiwLhI/yX/u5OOcbhyK/hwzYJWAAVFUljDn5/uXnwUSaJ39NPnVTAL6IefKLR1WlnneDKrXhU4iNgUaGkB1d4WS6QyXQDtqhERzqrgKcXGonB4yW0BoYtRAohQm5wMPEudMvp7uPTOTFjLsSHvmO73O47WL6oUQ05+Os3mudetNtvZo482E3rtaefbG68gr/VmfNi4xO7msMPNpMnuJOONNMn2sef5HUN02Rrq/vdvfis1fbi97vhVIWAqSo2HtQWzapVFr9EnP0snz4iM0gH+zGW8XuWRkeLTB0at8Yjht7eo3AXD6TqhlFARfn34VcxGEAjAQ+0CuTatN9etrtsv3+JwQ++Jk8wN1xu9/80323iITKeIsMcfzgBb7rbTd/EnHGSmXVSo2zsPY+YJUvMVTcUpvW4879phvCtWBHvpjmVjO/GicBFML5C/OVvzM9/xLkGt1zw3ajjDS1PFdYJr6xrZq+d3K1X8qO8G+52L8zDoy3MO27eAnfTnYXvHsdbD4nA4dzkqoLp+hR8UjG9mKpevKhIU2nhVgOdtBZe2rRTjWCKJcaMzc3YMeb5ebyQo+20DRcjby0xO29t3nqHV2tZ7VGKT1x33xGf+9rF7/Pn4jiz8N1QR7vZdQeDx4IL3zGvLOD5hevRLtvaJUvd+/i8yvDMrVZ4+Ud6Y0ebbbakbX8/55Ttt3JdXQga7864aOgbNNtubl5+nZXFa8jdtsfSwby3jFFtvqnBj7Hwah8nO1ouTS0N2aGlHESAN1VTD/NGOcugL0MwP4lpgUQb8yK+BMcTMjbbqNRw8DHLgsCiUW4XIYYm2K6BkaKfp+D6Ahbvt7AIkEUmfuRVlic7iGgITzlkkYnbqRq/fm3g//4BTdjiCX4LuARs4Gf0sMc6CHfuAMSwwvoIBEYf7vFrFYSBNTWf3Tfwm2j5cSyDzBpQNBPPQkdykm4Uxv+PIoSpelDVPYZ1qBHMxRjBISYEwY+g2PCAfepEt3qgPDDkNplUrFRryzcU8X9dGNvewFfgy/uKm0x05ZI+tuC08sH6YrnYmDARflGvxmCNHDyWL7WUtukdGtVi3lheWr2hjCqPa6+PGcXgcBl4dx0uu8x9Wo9ZNdCK5HtGQ4QiIRrbVwFR6ChVlqxrw2KjXHBTx1RX95c2DCLIJD2QWbqaDlOgChMWTugiOPJCUxRa80zPuCQDEvZSsQyPL5Zn9A7O/vYH5943/pbnux6b9U61YT975ZR3lxcvPmLNPh8bPPSazsfOWDtxVKO/VsRH8W0ttaN/O3XnqZXTP7WqaAulQmP+yvJul28ydWz12qOW7b8lHmPbxSvMN+7suf/Fzp98dfUxu/UVGxyMD8zv/NrvJ/R0DT195vvn3Du2rVy/4ktrNlZKdVfoaq0/vrDjjrmtlx2+6pTf9tzyxOgzD1l23kEbPn/l5CffavNPP0JGIXb0JUutia9EzJvanPWymrGD5LnJaZEFDnioW9rA4YkCfluLHdtR72rlZy2j29yMKdUfHbQaj3XGtTV62ut91VHf+8OESx8ZPaat/thbo2bd3vv0W8XezkHM4N+9f8KJt/acd/84LPB+9dWVe28+cNY94758fS+G2cVfXFNqqQEBv2z91j3jr3+m68u7r/8/e63DLemYttrETveXBWNOu6NnwXJ8g+TO+ePYK/7aedsLo5etKZ2994ppkypnH9D/+Pz2OQvb+M4j5sMk5C/Ngxn4WpHNtHQX78UkcdVp0kQ3bepIh5DwlSF14kdgKC1fwa9YVzhxZt9vnunaWOEKb6BavGV258enlX74T+tmLyxd88hovA7Fwq1Wa6xcX91QaZn3fnn6hPoBW/b/+qnuKx7stu1mwYpprUVMUZzg+gbsdU92bTd56Fv7rJsyuo4RCyaq8uri4qtvd++z+eC00Rv/42+dlQo/+77wwa4bj15zwzHLu0r1H/0JXz5wBmSo3CSBsyTC9RlITzdewkrIZT7UgOkpDvXUjpONWFFbCIqEGbuBTQnp1pK78dnuHaZW/v1LqzBr4NsxzpzlYluJ1xEs6EyZd/8IfVSru+Ho9aXS0EUPjn3w9Q5bary5shUT9kOz3tlmolszUPjiNWXM+BPHmOfOWjJptFnZX77jpQ5OfZjzgAWoUr2Ex1rWYtrCFATi9rljTpm54bM79F/92JgXFrUW8FSZ84WGnItZUpKSga1ZkgiZCocLRV18g8g3kROQ/9CRvu+KJnn+hGRfgyA8Vo7rB+y37xq3Xe/gQTMGK3i8HK1FUXtQ21Ap7X7F5Ck/mH7JnyesHSjUh+zOU/rxNdDFD3Q/v6S44+RKuYTljMWPDp5d0jZ5TO3elzrmzO9oxasGjFMPJXHxRGcJcHHE89a7X+kEyO+e7/BHLDvKjJnBSgsnniIIi6Qg+568OGQBfNNaJBXzaPTPRk+ZAzK8Q74mxhsA5Ix6F21jVEvjxfltv3hy/Nn7rygVy6wj3/rgXx2fBBGK60HXXqqduHtfX8WsGyxe9WT33a+MOnLPDSs22teXte2yaX3hqtIHa8vtLY3+ip1158S2Vnv0bmsu/2sXrgAYkjqGgARAXB6TsLCAwCFpYKnPaiTZ0C8buIhBc9JglIktu5EFUk4x8JIW6kqWItFC/XMbO96GcNb1DRUWr2pZtq6OaeOt1eV31+JXXYVL/tT9yc02Yg0MJhA2VAqLVpXfX4crA4EXry0tGygdv/t6rJYXry1fN2f0N+6YhLXU8Xv0tbZsfGlp23fuHtu/0eIkXbi6iPXgpY+M22eLgWN2XXPV7O5Fa1rfW6tR2SXrS2+uLlfqXCCxWbO8v3XxqvL6wXgJUgEi1eBDinLcGP+wxvjAxBlbmHYYx5Riqzk7I1rRYhhUZNjRbfWNFVtzxa7W2mC1gGUdFmiYZfDDpb4KnmtxZdjdbvqH9NdzmJQcBhpcIYxqHSUu8sA71zum0VJ0S9cVq7VCodjAjIbpfCOkzo1uR26NDUMl+OofKuBxC0KCAkZQH77p8IOFn+F1lOvrK5xA8k3y0uSYSkybtKQttfNZYoeH9igQl580Qp0yW55OwvYgoYiCqmqQp00fb8JPIOiRKchNq2pShCbuIKEPxcKh8mH5+3AoacLQgZGeUJjXoeVdhIhQuKgQ4+HFa4STC3L1p4qMMJr4zMDwkVA5LhQznmCoFvwGoCgHIeyIEz2EDDHXqBUlgVaOdr0FtCTdqCzQMNFJyltQRwsqaN42hU0UPEKqGWDCnqdLDBmEjzWIvVSAcCTj/w1Y5NEuMYNmDgLgUIuagQj74Oej9jnMoIzCy/AK/ZH2zYa+z0qjfVgY4KsILkA0g+TtKBVtjkw9S9WYHhLT9LpAERqkmWqeTnsJiNqNvB1BjadT6mG4YU6axfMRVooTbSMR+KxayoyhcQSlAnS0y61Q2GSVUlk+aioETkoH3sh7mkSzVGVEZqogdKaFVPRvmI4yoJkpKxmzz0OBrcrBROziPB9lfrCm/kRTNgk3c5NJfKgZIw0usU3IRDfh/gMkDfEv/qHr3eeMNcxE4oeA8lU10olaAJEC5YLkKA/SuPeciASBsIKul2PnKbFM6QjVRACyySoq5MwT156fcDKTnI0ik6XsYJFxoqEXBQ3lU2+EhaI3ymHCMDvRgj8cMc75qkgrUPSQMTzUf7dLlb19QKBTMeWgTvV0Mky1VSFedHPqDAlN1D3texquSDx8fkdUFgj+M4G6EshkQ7noeEURqbd4/UhFialGljJydAwZ3Og7MAEpZAIdWOFQQK7aug2asaaqLyPdX91F0dMSilrmotIOwbCeSMeAL4NXbrYM3hkSZejHP5r4WgUudGTYNcN4dLFIaCGJnOmTynqqIEczRuIDgEgjob3oZRrscqyzkauSqKgSFetWNMNGvzCDQMxUISCkPeiLkvKCdeYsckTBa/kFZXpyRj0l1JXQIKNZ1PIc7KJm/jxqNgmxR30xjdhU9ybRRyCG83mo/GU+EyaBgGTP79RlFKsgaOjMnkxH9BoMubQZZkeFXMtCyLGlE6zD3mvEqUGV4MX/5fypEbaZdUbBMtfxyH4HER7B4Ua7KbOgBTnDlp2nERNeGoRkUjvP051o4zzHPmvBCnsYAsRjZhoJleCQG4EiIboBkp3MneJGWTLmkI/cEEsKjCM/oLSrLnRr/j9D+/8zP0TmOQAAAABJRU5ErkJggg==";
var LOGO_JPEG_128_BASE64 = "/9j/4AAQSkZJRgABAQAASABIAAD/4QBMRXhpZgAATU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAAgKADAAQAAAABAAAAgAAAAAD/wAARCACAAIADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9sAQwACAgICAgIDAgIDBAMDAwQFBAQEBAUGBQUFBQUGCAYGBgYGBggICAgICAgICQkJCQkJCwsLCwsMDAwMDAwMDAwM/9sAQwECAgIDAwMFAwMFDAgHCAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwM/90ABAAI/9oADAMBAAIRAxEAPwD8aAcUZNJRX78fnY8HtRmmUvamAZpd3rTaKVwHA807NMxS8U0wDPrSE5ooHWlcBcil4AzSYpccU0AmaM0mKO+DQA/NJnnim44zSUMD/9D8Z6KKK/fj87CiiimB6D8LPAsnxK8eaV4NS4+yJfSOZp8bjHDCjSysoPBbapCg8ZIzxXrN1qv7KWn3MtgnhzxVqAt3aL7V9tij87YdpkCb1wGxkDaPoOlZ/wCyn/yXHQ/+uGof+kclbfwotvBek/DLx78QPE3hey8TXWj6lYwW8N6zKoS5kKNhlzjlt3Qk4Ar1cLTXsotJXbldtX0ik/1Z+Q8X5hNZrXp1alZwpwwyhCjU9m5VK9arT1leN/hjbmkkld7szv8AhIv2Vf8AoUPFX/gxj/8AjlIPEP7Kv/QoeKv/AAYR/wDxyuws9S+HHxK+F3xB1Ow+H2leHL7w5p1tc2tzZySSSb5pivVguMBffOa8z8MaF+ztdaDZXHizxbr1jrDx5vLa209ZIYpMn5Y32tuXGOc8+g6VpLmvHl5Gmr3sl1t1sefhVh5Qr/Wfr8J0pqEoRrVask3CNRP91Oa5eWS1vvobn/CRfsrD/mUPFX/gwj/+OVqW/g74KfE/QtfT4Z2mt6Dr2g6bNq6RalMlxb3dvb481MqWKNyNpyOT0IzjN/4Rr9lX/od/Ev8A4LV/+N10v7P+k6Td/ETx3ongWe41OxuPCuqW2my3SLBPP5vlIm9M7VJY45xxgnHaqUXKpGnOMGpaaWvt5GGZYinhcvxGY4Kvjac6CU713WVNpSimmqvuyTTd1va7VrXXylp1le6te22mabC9zd3kiQwQxjLySSEKiKO5JIApdQsL7Sb+50rU4Htry0leCeGQYeOWMlXRh2IIINfTvgn4G+M/hrrVr8R/ijbnw7oPhia31GWXMV3LcSRzIIraGKCQnfIxA3MQAOa89+N2jWh8SJ8QtEvRf6J43ku9UspGjMMsTCcpcW80ZJw8TnGQcMDmuGpgpwpc81Z9nvbvbffQ/QMBxrgsdm8cFgasalFxdqkbyi6q9501NXg5Knebje9jxjr1pMUlFcR9qLyKTpRRSYH/0fxnooor9+R+dhRRRTA+iv2U/wDkuOif9e+of+kclV/hv8SfAfhvwn4r8CeP9I1HU9P1++t7nOnzJC6m1YkAs5Uj5gp4znkGp/2U/wDkuOhj/p31D/0kkrofhNL4e8PfCv4gePdS8OaV4hvtK1Swgt49UhE0apcSFHA7r97PHUgZr2MJf2NNxaWs91fTljfT0Pxji94f+1sfHEUpVLwwKioT5Jc7xFdQandctp2d7lS6+KXwa0PwJ4r8K/Dzw5rdld+J7SK0lmv7qKeJRFJvU4DEjGW6DniuY8L/ABzl8MaDZaCvgrwnqAso/L+1Xunebczck7pX3Dc3PJxXqOneJvDHxO+FXxGvZvA/h3Q7vw/pttcWlxplrslEk0xUneeRgL265Oa8s8MN+zYNAsv+Exl8VrrPl/6YLIWv2YSZP+q3fNtxjGefWqnKpzRlTqRStppZbvTbuZYDDZa8NjKGOy2vUqRrR5488q8+Z0YOMnKM/h9m4x30ehvn9pGbPPw+8Ff+Cv8A+zrb+BmvSeIPG/xD8QLZ2umPd+ENXmFtp8fkW8B2xYEKAnaOM9evNYW79kY9ZvGv5WddP+z5YaFq3xG8c6V4Ga4OmXvhbU7fTm1Jo0m2ymFFM7J8g+Y8kdF5NXSdWVamp1FLXpbs/I5M6w+U0MjzGpg8uq4d+zV5VIyjFrnjpeUpK/X0R5f8E/Fusw+O9K8PXkg1PSvElxbaTqdjqGbmCe2nmUH5HJ2up+ZHGCDUHxz1271D4gal4eEcFppPhi5udJ0qytYxFBbW0MzcKo6s5+Z2PLGvVvCfwO1f4VXZ+KHxFu7Y6V4TNvqKwaNcxXlzc3CzosMRHCxoXILux6cDnkeZ/G3S9KutVsPiZoE07ab47F3qcdvdqqXFrPHcGO4ibYSrIHOY3B5H0yeepTqwwnJPR3vbrbb7r/ie9lmZ5PjuK443L2p03B01OKvB1kudpNac/sU9f5fdv0PEqWkoryj9ZCiig0mB/9L8Z6KOlFfvqZ+dhRRRVXA+iv2U/wDkuWh/9e+of+kclUPhx8U/CPg/w54n8FeNfDs3iDTNevYLl0huzalWtWYqCQN33sHhh0wavfsqf8lx0T/r31D/ANI5K6j4Rahpnhb4S/EPxzLoOla1qGmapp8NuNUtVuI1SeQo45wwHzE/KRzjOa9jC39lTcZW1nur6csb6H4vxfLD/wBrY+OIoyq80MDGMYzdOXO8RXUGpppxtJp3T6GPf/GT4WWPgjxN4T8AeCbnRJ/E1rHaz3EupNcqFik3qdjgnjLdCM556Vz/AIX/AGiPHXhLw/ZeHNMsdCktbCPyonuNNjkmZck5d8jc3PJIye9eq6b42074p/Cb4kz6l4R8OaVcaFplrPaT6ZYLBKsksxBbeSxGNgxtI6nNeT+Frr9nJdAsl8X6d4rm1kR4vJLKa2Fs0uTzEGIIXGOCM06kqnNCUKqSa005dLvSyXczwGEyp4bGYbH5RVqzhWjzxc3iZczowcZ885XtyOMd9NrHQf8ADVfxIz/yDvDn/gqj/wDiq1/gh4gvfFXjX4i+ItSS3jutQ8H6xNKlrCsEIYrEMJGvCjj8Tyeaxvt37Jg4/srxpn3ntf8A4qt34CXPgT/hYvjZNPurjSfDV14Z1KGCXUXje6igfygxYJhXkA3MqrkkYHJqqTqutDnqqWvfyOXOMHlNDJMwnl2UTw0uRXk6ajzLni+VcspNvra3Q8o+BWualo3xL0C0sJAttrN5baZqEDokkNzaXEqrJDLG4Ksp6jIyDyMGpfjrrup6v8T9dsb2UG10W9uNN0+3jRIobW0glYRxRRoFVQOpwMk8mvbfAfg74W6KdT8TfCrWJfiB4s0O0W90vSbuyltVWRJkBuljyrTvCpLCJTnPOOleZ/HvT0F14e8TarpqaH4o8Q2U97r2lxlgI5/PKxXBics0TXCfO0ZPBGe9Z1KNSGEcXLrfR3Vtt1pe/T5ns5fneAx3GEcTSoOLdN0vfhyVOdL2nM4TtUUOT3VUcbN+4nqfP9FFFeQfroUUUUmB/9P8Z6KKK/fUj87CiiimB9E/sp/8lx0P/rhqH/pHLWZ8O/ixoXgjQfEvg/xP4YTxNpmu3kNxJE121qFa2ZtoJRGJGcMMEcjuK868AeNNT+HnjDTPGOkIktxp0pbypM7JY3UxyRsRyAyMRkdDz2r2q58Zfsw6jcS3934D163nuXaWWK21ICFHc5YRguMLnoMD6CvUwtVKlFQmoyTlvs00l2a6H5ZxPlblmterisDVxFCtTopexkoyjOjUqzTb9pTkvji4uL3TTt1h1T42+A4vBfiLwn4I+H8Xh5/EltHa3Nyuoy3HyxvvUlJE5xzjBHXnNc/4Y/aN+J3hDQLLw1o0umiy0+PyoBNp8EkgTJPzORljk9Tye9dB/wAJL+yz/wBCT4l/8Ga//HKP+Em/ZZ/6EnxJ/wCDMf8Ax2tZTquSkq8U0raXWm/SKPMp4HKVQnh6vD2JqxlLnfteSq3JRUE71MRJ6RSS12O3+GPiCD4lX3jf4w/FDSrDxFc+BvDqT2WmtAlvZTStKwjadIxhwhzw2c59hXPf8NRwn73wr8AH66T/APZ12/w/vvh9qPgD40SfDrSr/SrEeErYSQ38/wBokaUXEpZwQWwuNvGeME14H8EfGHw88MeJLqy+KGhQaz4e1y1NhdTMm+508O2RdWxHIZT97bh8cqcja34NnGV4fH5rnmMx+HnjJYeVJQhGck+X2NOclBc0Y3blKXeT0vsf0vw1ingslyjC5dFYKnUjO6lCHuv2korm5eeySSWjaS17n0F4M+OPjrXLbVPFngr4P+DGi8MQG+vL+100w/ZEUElhJ5qnftBbahLbQTjAqGXxdoX7Rfw7+Ius+I/COjaL4h8LadFrNpqukRPDNM3mFZIrjczGQMBjLMcdhkA1xHxk+NPhmPwzB8FfggHsfBFlhr28IZLnWbg4LSTFgr+XkDhgC5AyAiqoi/Z/5+GnxsbsPCkYJ9zM2BXzc8iWHyeWexwbwk/bUHRjz1faRg61OLdVObjzTTleFvdi+WV5Xt9IsdGrmUcA6yr/ALuoqkuSHK2oTlaDUVLli0rSvrJcysrHyzRRRX9DH5UFFFFSB//U/Geiiiv38/Oxwq5p2majrF5Hp+k2s17dTE+XBbxtLK+BuO1EBY4AJOB0qlX1n+zVpP8AY2l+K/ilPqFjo76dbLpGlX+psUtY7+9wzMzKrElIwBgKSd+K3wlD21RU72XX0R87xXn39j5ZVxyjzSVoxjr705NRitE3a7V7Ju12kfL0GjaxdXF1Z21jczT2SSSXMUcLs8CQnErSqBlAh+8WAA74qPTtPv8AVruLTtLtpry6mO2KC3jaWRz6KiAk/gK/Qy48OWumfFzxz4n0Z459K8XfD/UtZtprc7oZHkWNLgxt3BkXfn0cV4R+zZ9tl0f4gWXhKRY/Gtxoka6IQypOyh2N0tuzf8tCNmMc9D2zXa8uUakablu5fh29eh8XQ8SXXyvE5jSor93Gg9W0lKq+WXO7e7GlK/O7bRlsfO+qeHtf0PUV0jWdMvLG+fbttriCSKZt5wu2NlDHJ4GAcmp9b8KeKPDfk/8ACQ6Pf6Z9p/1P2y2lgEn+4XUZPsOa+2fh2nxL0rxz4PtPjPdQLftperr4Xj1N4n1CC+cKIjdMwMnzciLezc8DDcVhm3+JWkfB7xtD8d5LvN1e2A0OPVJRLcNqSz5lktcsxEYXBO35du4jjNX/AGdFxb1W+62sr6+vQ5f+Ik4iOJpULUZ600+So26ntKsqV6C5feVPl5qm9tY3tHmfgPw38UfE34T+MpD4b0uf+07m0eG80i9spJlu7N18xlmtSA5TC7twxgAnOM594tfjP8Rr+1ivbH4JeF7i2nQSRTReGJ3jdGGQyspIII5BB5r6bkn8N+KvjbqEThbTxN4Kspo1wOdQ0rULAHB/2reeT8Fb34+Q/BXjrxrbfs3eMb2213UY59K1fSLSylS5lD21u20GKFgcohHG1cDFfM534bcPY7FvF5hQU5tNcyum1DZOzV7XaV726aHVw547cTVcDCnl9KNJp4a8ZttJ4qUknH3X7tlCen8zT95M27f43fEC5sBqtt8FvCstkUaT7SnhqdodiZ3N5gO3AwcnOBiuH8cfG34l+K/DcfgOx8J6Z4V0/wASmGY2+haVJZy6sgYGEAncZU3Yx5Y56ZI4r3jUrfxJefAXwfJo1r4vupW8M3BMug3SQ2KucndqCMd0g6k7edu4dTXYeH7jw14j1L4UeCtY22mr6XoWieItDu8czNGCl3ZH18yKNXT3UntzzYTwk4ZoV6dajhUpx5ZRcnJrmummlKTV09U+js9GPF/SM4h+rV5VoqUFKtCSg1zRhTU1zSSV7Oy5tvc5nZpa/nTZ+AfHWowm4sPDurXMQd4y8NjO6h42KOmVQjcrAqw6ggg81zN3aXVhdS2V9DJb3EDmOWKVSkkbqcFXVgCCD1BGa+3PBXi3xXa33xysrXV72K30iy1e6sYkncJazG/kJlhUHCMSSSy4OTXxNf397ql7PqWpTyXV1cyNLNPMxeSSRjlndmySSepNfSYqhTpxi4t3d/wdj6HhjP8AH5ji8VSxNOEYU+S3K5NvnhGavdW0UrO3XyKuDQaU5pBXEz7Q/9X8Z6UdaBmlPrX78fnYDoasC7ultTZCaX7OX8ww728ouBjcUzt3Y4zjNVxk0pFNCcU90fYfhT9mzWvEvibwt4Vj8YS2o8Q+C/8AhI45TFIUtopXVTZbRMMxkkFmGAcfcNcLbfA268O6Dc+K/GmvP4YfRvF6eGL/AGW0k0lpmDz2vUaJ1dxjG1UGWUhg1epWH7QPgK11HQ7pvt4XTfhhP4TlKwDd/acg+UJ8/wDqs/8ALT9K5r4h/tBaT8Rv2f8ATvBOsQzDxnDqdpLf3QiHlXsVlbvbx3MkucmUxlEYEZJUnOMAfg2FzLj6eNo06ykqE5U4ylyQUqd51OaavFpx5FFSunyvka0lI/Tq2X8Jww1R0+X2ijJpc0uWfuxtF2d78zbWuq5l0Ra8c/AXwjp9x4Wc/E2bWdX8ZvpsmlJPplyHms764WAXBmkmbb5YYuEchjjHGao/EX4H2tr4msfAuh+O73xX4sk1aLRo9PvdOvLaGItnzHW8neSLZHgFghORkjpWL4l+LPhTVfEPwe1O1F15PgfS9JtNV3RAN5llciWUQjd842j5TxmvXfiN+0Z4SuvGGj/EHwv4q8R69No+vx6nbeHtTs4bbT4LdleOZIZUJcMI2KIW3feOazhjOOqFTCR9pVqOUKzlzQpqPtFJqlGbhQ0g0k3eVP4m/abRG8DwtUjWkqVOHI6ajaUm1BxTqOPNU3TbWiktEuXdnlHjn4U+EPC9jr99oHxWt9W8V+Gv3ep2Msc9k87A+TNFZXUkhNwyEFWQdQMccA9hqf7Llja2d74d0Lx+t14lg8Px+JpdBlsZ7eKW1EQk4uBI0Rdc4XcM59AcjW1/42fCDRPAvjrSvAd1reozeOvtUkekajY2sVvpVxqGPtM32tcyyEDiNQxUcd8tW54g/an8LeIrTXvBjXF/YaDqfhC00y0v7a0jS+t9TgjxLG7KQ8ltN9xwX6A7QASa895vx/OnReFjW5VJuUpwpqTVqN7wVBPli5VbQjaU0nyVZcsW+yOWcJxlNVVTu4pJRcrJp1LWl7R62UPed1FtXpq7PLtK+EFpb3HgnRPEXxFu9EtfG+g22oWEaWt1PGLi8nWFLHy4pguCGyZG2qeQQKv3PwD8Ny/E8/C/w/8AEqS+8TWNrex26yWE9sI9QsQGisEmebC+Yu8o8ZIXaRjJFct4m+K/hXV9W+Dl7ai58vwNpul2uq7ogCJLS6WWUQjd842r8p4z0rjfGHxA0/U/jtqHxM0GW5hsZfES6pbybfLuFhWdXztB4baDxn2NfV4SnxjiajlUxlSm3SrNJ06XIqsarjSTvT5rOFpW5k3a6aPBrUuG6EWoYWnL95BNqU+ZwcE5v4+W/NdX5dL7MZ4++HOpfDXw14ev9a1aaLxB4qtpby80bY8clrZGQrC11Jvy7zEFvLZOMHJJHPjtev8Ax48eWPxM+LHiDxlpMtxLp19NGLL7SuyRYIoUjVdmTtAIJAz3z1NeQdK/Q+F55hUyrD1s1f7+ceeSslyOfveztp/DT5Lv3ny3k7tny2c08HDHVoYBfu4vlT35lHTmv/etzaaK9loBopevWk+te8zzD//W/GkGkzRSV+/XPzskpCcU0HtS5HSncBQc0tM49aUECgB1FJkUce1MBaKTj1oyKAFopAQKQkd6VwFz2pvU80pxSDHegBR7UhPPFO49aZxSYH//2Q==";
var LOGO_PNG_96_DATA_URI = `data:image/png;base64,${LOGO_PNG_96_BASE64}`;
var LOOKUP = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
function decodeBase64(value) {
  const clean = String(value).replace(/[^A-Za-z0-9+/]/gu, "");
  const bytes = new Uint8Array(Math.floor(clean.length * 3 / 4));
  let cursor = 0;
  let buffer = 0;
  let bits = 0;
  for (const character of clean) {
    buffer = buffer << 6 | LOOKUP.indexOf(character);
    bits += 6;
    if (bits >= 8) {
      bits -= 8;
      bytes[cursor] = buffer >> bits & 255;
      cursor += 1;
    }
  }
  return bytes.subarray(0, cursor);
}
var logoJpegBytes = () => decodeBase64(LOGO_JPEG_128_BASE64);

// ../../shared/report/report-model.mjs
var LEVEL_ORDER = Object.freeze([
  "signal-likely-human",
  "signal-unclear",
  "signal-potentially-ai",
  "signal-likely-ai",
  "signal-strongly-ai"
]);
var LEVEL_LABELS = Object.freeze({
  "signal-likely-human": "Likely human",
  "signal-unclear": "Unclear",
  "signal-potentially-ai": "Potentially AI",
  "signal-likely-ai": "Likely AI",
  "signal-strongly-ai": "Strongly AI"
});
var LEVEL_COLOURS = Object.freeze({
  "signal-likely-human": Object.freeze({ hex: "#1a7349", rgb: Object.freeze([0.102, 0.451, 0.286]) }),
  "signal-unclear": Object.freeze({ hex: "#6d7877", rgb: Object.freeze([0.427, 0.471, 0.467]) }),
  "signal-potentially-ai": Object.freeze({ hex: "#b06603", rgb: Object.freeze([0.69, 0.4, 0.012]) }),
  "signal-likely-ai": Object.freeze({ hex: "#bf4705", rgb: Object.freeze([0.749, 0.278, 0.02]) }),
  "signal-strongly-ai": Object.freeze({ hex: "#a31f17", rgb: Object.freeze([0.639, 0.122, 0.09]) })
});
var NEUTRAL = Object.freeze({ hex: "#4f5a59", rgb: Object.freeze([0.31, 0.353, 0.349]) });
var TONE_BY_HEX = Object.freeze({
  "#1a7349": "human",
  "#6d7877": "unclear",
  "#b06603": "potential",
  "#bf4705": "likely",
  "#a31f17": "strong",
  "#4f5a59": "neutral",
  "#fb700a": "orange",
  "#0068b3": "blue",
  "#12557a": "blue"
});
var toneOf = (colour2) => {
  const hex = typeof colour2 === "string" ? colour2 : colour2?.hex;
  return TONE_BY_HEX[String(hex ?? "").toLowerCase()] ?? "neutral";
};
var REPORT_INKS = Object.freeze({
  human: Object.freeze({ hex: "#1c6e46", rgb: Object.freeze([0.11, 0.431, 0.275]) }),
  unclear: Object.freeze({ hex: "#5c6360", rgb: Object.freeze([0.361, 0.388, 0.376]) }),
  potential: Object.freeze({ hex: "#8a5a00", rgb: Object.freeze([0.541, 0.353, 0]) }),
  likely: Object.freeze({ hex: "#a84a08", rgb: Object.freeze([0.659, 0.29, 0.031]) }),
  strong: Object.freeze({ hex: "#96261b", rgb: Object.freeze([0.588, 0.149, 0.106]) }),
  neutral: Object.freeze({ hex: "#4f5a59", rgb: Object.freeze([0.31, 0.353, 0.349]) }),
  orange: Object.freeze({ hex: "#8b3f0b", rgb: Object.freeze([0.545, 0.247, 0.043]) }),
  blue: Object.freeze({ hex: "#12557a", rgb: Object.freeze([0.071, 0.333, 0.478]) })
});
var inkFor = (colour2) => {
  const hex = typeof colour2 === "string" ? colour2 : colour2?.hex;
  return REPORT_INKS[TONE_BY_HEX[String(hex ?? "").toLowerCase()]] ?? null;
};
var LEVEL_MEANING = Object.freeze({
  "signal-likely-human": "This draft reads the way human writing usually reads. That is not proof of authorship, and a carefully edited AI draft can read this way too.",
  "signal-unclear": "The reading sits in the middle of the scale. The patterns in this draft do not lean clearly towards either human or AI writing.",
  "signal-potentially-ai": "Parts of this draft carry patterns that are common in AI writing. Treat it as a reason to read the marked sections closely, not as a verdict.",
  "signal-likely-ai": "This draft matches AI writing patterns closely. The marked sections are the ones worth a careful read.",
  "signal-strongly-ai": "This draft very strongly matches AI writing, the kind of match we rarely see in human work."
});
var METHOD_STATUS_LABELS = Object.freeze({
  pass: "No issue found",
  attention: "Review evidence",
  fail: "Failed",
  inconclusive: "Inconclusive",
  unsupported: "Unavailable",
  not_configured: "Not configured",
  not_run: "Not run",
  error: "Error"
});
var INTEGRITY_READINGS2 = Object.freeze({
  clean: "Clean",
  attention: "Worth a look",
  manipulated: "Manipulation found",
  inconclusive: "Inconclusive",
  error: "Error"
});
var EDITORIAL_READINGS2 = Object.freeze({
  none: "No suggestions",
  some: "Some suggestions",
  many: "Many suggestions",
  not_assessed: "Not assessed",
  error: "Error"
});
var HONESTY_LINE = "No AI checker can prove who wrote a text. This is a pattern reading, and it is evidence, not a guarantee.";
var PRODUCT_NAME2 = "Opace AI Content Integrity";
var DEFAULT_PRODUCT_URL = "https://opace.agency/tools/ai/content-verification-integrity/checker/";
var isRecord = (value) => value !== null && typeof value === "object" && !Array.isArray(value);
var list = (value) => Array.isArray(value) ? value.filter((item) => typeof item === "string" && item.trim()) : [];
var text = (value, fallback = "") => typeof value === "string" && value.trim() ? value.trim() : fallback;
var unique2 = (values) => [...new Set(values.filter((value) => typeof value === "string" && value.trim()))];
var humanise = (value) => String(value ?? "").replaceAll("_", " ").replaceAll("-", " ").replace(/\b\w/gu, (letter) => letter.toUpperCase());
var number2 = (value) => Number.isFinite(value) ? Number(value).toLocaleString("en-GB") : "not recorded";
function formatMargin(value) {
  return Number.isFinite(value) ? value.toFixed(2) : "";
}
function pluralise(count, singular, plural = `${singular}s`) {
  return Math.abs(Number(count)) === 1 ? singular : plural;
}
function countPhrase(count, singular, plural, fallback = "Not recorded") {
  if (!Number.isFinite(count)) return fallback;
  return `${Number(count).toLocaleString("en-GB")} ${pluralise(count, singular, plural)}`;
}
function describeValue(value) {
  if (value === null || value === void 0 || value === "") return "Not recorded";
  if (typeof value === "boolean") return value ? "Yes" : "No";
  if (typeof value !== "object") return String(value);
  if (Array.isArray(value)) return value.length ? value.map(describeValue).join("; ") : "None";
  return Object.entries(value).map(([key, item]) => `${humanise(key)}: ${describeValue(item)}`).join("; ");
}
function assertReportInput(result2) {
  if (!isRecord(result2)) throw new Error("report_result_required");
  if (result2.schema_version !== "1.0") throw new Error("report_result_schema_unsupported");
  if (!isRecord(result2.source) || !isRecord(result2.route) || !isRecord(result2.axes)) throw new Error("report_result_structure_invalid");
  if (!isRecord(result2.axes.ai_pattern) || !isRecord(result2.axes.text_integrity) || !isRecord(result2.axes.editorial)) throw new Error("report_result_axes_invalid");
  if (!Array.isArray(result2.sections) || !Array.isArray(result2.methods)) throw new Error("report_result_collections_invalid");
  if (!isRecord(result2.provenance) || !isRecord(result2.exports)) throw new Error("report_result_supporting_invalid");
}
var dateLabel = (iso) => {
  const parsed = new Date(iso);
  if (Number.isNaN(parsed.getTime())) return "Date not recorded";
  return new Intl.DateTimeFormat("en-GB", {
    day: "2-digit",
    month: "long",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
    timeZone: "UTC"
  }).format(parsed).replace(", ", " at ") + " UTC";
};
var levelView = (levelId, labels) => {
  if (!levelId || !LEVEL_ORDER.includes(levelId)) {
    return Object.freeze({ id: null, label: "Not assessed", index: -1, colour: NEUTRAL, meaning: "" });
  }
  return Object.freeze({
    id: levelId,
    label: labels[levelId] ?? LEVEL_LABELS[levelId],
    index: LEVEL_ORDER.indexOf(levelId),
    colour: LEVEL_COLOURS[levelId],
    meaning: LEVEL_MEANING[levelId]
  });
};
var barFill = (rawScore) => {
  if (!Number.isFinite(rawScore)) return 0.04;
  return Math.min(1, Math.max(0.04, Math.abs(rawScore - 0.5) * 2));
};
var evidenceLines = (section) => (Array.isArray(section.evidence) ? section.evidence : []).map(
  (item) => [text(item?.summary), text(item?.detail), text(item?.basis) ? `Basis: ${item.basis}` : ""].filter(Boolean).join(" ")
).filter(Boolean);
function routeCopy(result2, overrides) {
  const route2 = result2.route;
  const retention = isRecord(route2.retention) ? route2.retention : {};
  const model = isRecord(route2.model) ? route2.model : null;
  return Object.freeze({
    name: text(route2.location, humanise(route2.kind)),
    kind: humanise(route2.kind),
    privacy: text(
      overrides.privacyStatement,
      text(retention.statement, `Content transfer: ${humanise(route2.content_transfer)}. Result retention: ${humanise(retention.result ?? "not recorded")}.`)
    ),
    consent: humanise(route2.consent),
    modelIdentity: model ? `${model.identity} (${model.registry_identity ?? "no registry identity"}, ${model.precision ?? "precision not recorded"})` : "No trained model ran",
    contracts: model ? [model.segmentation_contract, model.input_contract, model.features_contract, model.scoring_contract].filter(Boolean).join(", ") : "Not applicable",
    flagRule: model && isRecord(model.flag_rule) ? text(model.flag_rule.expression, "Not recorded") : "Not applicable",
    artefactHash: model ? text(model.artefact_hash, "Not recorded") : "Not applicable"
  });
}
function axesView(result2) {
  const ai = result2.axes.ai_pattern;
  const integrity = result2.axes.text_integrity;
  const editorial = result2.axes.editorial;
  const aiLevel = levelView(ai.level, LEVEL_LABELS);
  return Object.freeze([
    Object.freeze({
      id: "ai",
      label: "AI-pattern reading",
      value: ai.assessment_status === "assessed" ? aiLevel.label : "Not assessed",
      status: text(ai.method_status, "not_run"),
      statusLabel: METHOD_STATUS_LABELS[ai.method_status] ?? humanise(ai.method_status),
      detail: text(ai.reason, "No AI-pattern reason was recorded."),
      limitations: list(ai.limitations),
      colour: aiLevel.colour
    }),
    Object.freeze({
      id: "integrity",
      label: "Text integrity and provenance",
      value: INTEGRITY_READINGS2[integrity.reading] ?? humanise(integrity.reading),
      status: text(integrity.method_status, "not_run"),
      statusLabel: METHOD_STATUS_LABELS[integrity.method_status] ?? humanise(integrity.method_status),
      detail: text(integrity.reason, "No text-integrity reason was recorded."),
      limitations: list(integrity.limitations),
      colour: Object.freeze({ hex: "#12557a", rgb: Object.freeze([0.071, 0.333, 0.478]) })
    }),
    Object.freeze({
      id: "editorial",
      label: "Editorial suggestions",
      value: EDITORIAL_READINGS2[editorial.reading] ?? humanise(editorial.reading),
      status: text(editorial.method_status, "not_run"),
      statusLabel: METHOD_STATUS_LABELS[editorial.method_status] ?? humanise(editorial.method_status),
      detail: text(editorial.reason, "No editorial reason was recorded."),
      limitations: list(editorial.limitations),
      colour: NEUTRAL
    })
  ]);
}
function sectionsView(result2, labels, sourceText) {
  const strongestIndex = result2.axes.ai_pattern.strongest_section_index;
  const local = typeof sourceText === "string" && sourceText ? sourceText : null;
  return Object.freeze(
    result2.sections.map((section, position) => {
      const level2 = levelView(section.level, labels);
      let passage = text(section.passage, "");
      if (local) {
        const start = section.start_utf16;
        const end = section.end_utf16;
        if (!Number.isInteger(start) || !Number.isInteger(end) || start < 0 || end <= start || end > local.length) {
          throw new Error("report_source_text_bounds_invalid");
        }
        passage = local.slice(start, end);
      }
      return Object.freeze({
        index: Number.isInteger(section.index) ? section.index : position,
        number: position + 1,
        level: level2,
        displayScore: text(section.display_score, "not recorded"),
        rawMargin: Number.isFinite(section.raw_margin) ? section.raw_margin : null,
        rawMarginText: Number.isFinite(section.raw_margin) ? formatMargin(section.raw_margin) : "",
        words: Number.isFinite(section.word_count) ? section.word_count : null,
        wordsPhrase: Number.isFinite(section.word_count) ? countPhrase(section.word_count, "word") : null,
        locator: `UTF-16 ${section.start_utf16 ?? "?"} to ${section.end_utf16 ?? "?"}`,
        passage,
        evidence: Object.freeze(evidenceLines(section)),
        strongest: section.index === strongestIndex,
        barFill: barFill(section.raw_score)
      });
    })
  );
}
function watermarkView(result2) {
  const watermarks = Array.isArray(result2.provenance.watermarks) ? result2.provenance.watermarks : [];
  return Object.freeze(
    watermarks.map(
      (item) => Object.freeze({
        id: text(item.method_id, "watermark"),
        name: item.method_id === "watermark.anthropic" ? "Anthropic official watermark verifier" : `${humanise(String(item.method_id ?? "").replace(/^watermark\./u, "").replaceAll(".", " "))} watermark check`,
        outcome: humanise(item.outcome),
        status: text(item.method_status, "not_run"),
        statusLabel: METHOD_STATUS_LABELS[item.method_status] ?? humanise(item.method_status),
        keyScope: humanise(item.key_scope),
        limitations: Object.freeze(list(item.limitations))
      })
    )
  );
}
function methodsView(result2) {
  return Object.freeze(
    result2.methods.map(
      (method) => Object.freeze({
        id: text(method.id, "method"),
        name: method.id === "watermark.anthropic" ? "Anthropic official watermark verifier" : text(method.provider_or_method, humanise(method.id)),
        version: text(method.version, "no version recorded"),
        status: text(method.status, "not_run"),
        statusLabel: METHOD_STATUS_LABELS[method.status] ?? humanise(method.status),
        location: text(method.privacy_route ? humanise(method.privacy_route) : "", "Location not recorded"),
        startedAt: text(method.started_at, "not recorded"),
        completedAt: text(method.completed_at, "not recorded"),
        evidence: describeValue(method.evidence),
        limitations: Object.freeze(list(method.limitations))
      })
    )
  );
}
function buildReportModel(result2, options = {}) {
  assertReportInput(result2);
  const labels = { ...LEVEL_LABELS, ...isRecord(options.levelLabels) ? options.levelLabels : {} };
  const ai = result2.axes.ai_pattern;
  const assessed = ai.assessment_status === "assessed";
  const level2 = levelView(assessed ? ai.level : null, labels);
  const sections = sectionsView(result2, labels, options.sourceText);
  const strongest = sections.find((section) => section.strongest) ?? null;
  const route2 = routeCopy(result2, options);
  const generatedAt = text(options.generatedAt, text(result2.generated_at, "1970-01-01T00:00:00Z"));
  const protectedFacts = isRecord(result2.provenance.protected_facts) ? result2.provenance.protected_facts : { count: 0, categories: [] };
  const c2paText = isRecord(result2.provenance.c2pa_text) ? result2.provenance.c2pa_text : null;
  const c2paFiles = Array.isArray(result2.provenance.c2pa_files) ? result2.provenance.c2pa_files : [];
  const report = isRecord(result2.exports.report) ? result2.exports.report : {};
  const meaning = assessed ? level2.meaning : `No trained model reading is available for this run. ${text(ai.reason, "The model did not assess this text.")}`;
  const strongestSentence = assessed && strongest ? `The strongest evidence is in section ${strongest.number} of ${sections.length}, which scored ${strongest.displayScore} and sits in the ${strongest.level.label} band.` : null;
  return Object.freeze({
    productName: PRODUCT_NAME2,
    productUrl: text(options.productUrl, text(report.support_destination, DEFAULT_PRODUCT_URL)),
    surfaceName: text(options.surfaceName, "Opace AI Content Integrity"),
    title: text(options.title, "AI content integrity report"),
    strapline: "Evidence, not guarantees",
    honestyLine: HONESTY_LINE,
    generatedAt,
    dateLabel: dateLabel(generatedAt),
    resultId: text(result2.result_id, "not recorded"),
    profile: text(result2.profile, "not recorded"),
    assessed,
    level: level2,
    displayScore: assessed ? text(ai.display_score, "not recorded") : null,
    scoreScale: "Zero-to-one pattern similarity. This is not a percentage of AI-written text.",
    meaning,
    strongestSentence,
    modelReason: text(ai.reason, ""),
    gauge: Object.freeze({
      position: level2.index < 0 ? 0.5 : (level2.index + 0.5) / LEVEL_ORDER.length,
      bands: Object.freeze(LEVEL_ORDER.map((id) => Object.freeze({ id, label: labels[id] ?? LEVEL_LABELS[id], colour: LEVEL_COLOURS[id], current: id === level2.id })))
    }),
    axes: axesView(result2),
    draft: Object.freeze({
      words: number2(result2.source.word_count),
      characters: number2(result2.source.character_count),
      wordsPhrase: countPhrase(result2.source.word_count, "word"),
      charactersPhrase: countPhrase(result2.source.character_count, "character"),
      sectionCount: Number.isFinite(result2.source.section_count) ? result2.source.section_count : sections.length,
      sectionsPhrase: countPhrase(
        Number.isFinite(result2.source.section_count) ? result2.source.section_count : sections.length,
        "section"
      ),
      language: text(result2.source.language, "not recorded"),
      contentType: humanise(result2.source.content_type),
      contentHash: text(result2.source.content_hash, "not recorded"),
      normalisedHash: text(result2.source.normalised_hash, "not recorded")
    }),
    route: route2,
    sections,
    strongest,
    characterFindings: Object.freeze(
      (Array.isArray(result2.axes.text_integrity.findings) ? result2.axes.text_integrity.findings : []).map(describeValue)
    ),
    writingFindings: Object.freeze(
      (Array.isArray(result2.axes.editorial.findings) ? result2.axes.editorial.findings : []).map(describeValue)
    ),
    protectedFacts: (() => {
      const count = Number.isFinite(protectedFacts.count) ? protectedFacts.count : 0;
      const categories = list(protectedFacts.categories);
      return Object.freeze({
        count,
        categories: Object.freeze(categories),
        phrase: countPhrase(count, "protected item"),
        sentence: count === 0 ? "No protected items were identified in this draft." : `${countPhrase(count, "protected item")} ${pluralise(count, "was", "were")} identified and left untouched.`,
        categoriesSentence: categories.length ? `${pluralise(categories.length, "Category", "Categories")}: ${categories.map(humanise).join(", ")}.` : "No categories were recorded."
      });
    })(),
    c2paText: c2paText ? Object.freeze({
      status: humanise(c2paText.status),
      wrapperProtected: c2paText.wrapper_protected === true,
      limitations: Object.freeze(list(c2paText.limitations))
    }) : null,
    c2paFiles: Object.freeze(
      c2paFiles.map(
        (file, index) => Object.freeze({
          label: `File Content Credentials ${index + 1}`,
          status: humanise(file.status),
          trust: humanise(file.trust),
          mediaType: text(file.media_type, "not recorded"),
          fileHash: text(file.file_hash, "not recorded"),
          limitations: Object.freeze(list(file.limitations))
        })
      )
    ),
    watermarks: watermarkView(result2),
    methods: methodsView(result2),
    methodsPhrase: countPhrase(result2.methods.length, "named check"),
    meansPanel: Object.freeze({
      meansTitle: "What this means",
      means: Object.freeze(
        assessed ? [
          "Parts of the writing match patterns that are common in AI text.",
          "The marked sections carry the strongest match and are worth a careful read.",
          "Every other check on this page reports separately and did not change that reading."
        ] : [
          "No trained model reading is available for this run.",
          "The deterministic checks below still report exactly what they found."
        ]
      ),
      notTitle: "What this does not mean",
      not: Object.freeze([
        "It does not prove who wrote the draft.",
        "It says nothing about whether the content is accurate or good.",
        "Human writing polished with an AI tool is deliberately not flagged."
      ])
    }),
    correctUse: Object.freeze([
      "The AI-pattern reading is statistical and can be wrong. Read the marked sections before you act on it.",
      "The score is a position on a zero-to-one pattern-similarity scale. It is not the percentage of the draft written by AI.",
      "Character checks and writing suggestions are separate readings. Neither can raise or lower the AI-pattern reading.",
      "Content Credentials describe how a file was made and edited. Their absence proves nothing about authorship.",
      "A public watermark-key check cannot clear or accuse a private provider key."
    ]),
    /** PDF-only note about the built-in core fonts. The HTML report has no such constraint. */
    pdfCharacterNote: "This PDF uses the built-in WinAnsi character set. Anything outside it is printed as an explicit U+ code-point label rather than an ambiguous question mark.",
    limitations: Object.freeze(
      unique2([
        ...list(result2.limitations),
        ...list(result2.axes.ai_pattern.limitations),
        ...list(result2.axes.text_integrity.limitations),
        ...list(result2.axes.editorial.limitations),
        ...watermarkView(result2).flatMap((item) => item.limitations),
        "No result proves authorship."
      ])
    ),
    runRecord: Object.freeze([
      Object.freeze(["Result ID", text(result2.result_id, "not recorded")]),
      Object.freeze(["Created", dateLabel(generatedAt)]),
      Object.freeze(["Contract", `Schema ${text(result2.schema_version, "?")}, contract ${text(result2.contract_version, "?")}`]),
      Object.freeze(["Profile", humanise(result2.profile)]),
      Object.freeze(["Route", `${route2.kind}: ${route2.name}`]),
      Object.freeze(["Consent", route2.consent]),
      Object.freeze(["Model", route2.modelIdentity]),
      Object.freeze(["Contracts", route2.contracts]),
      Object.freeze(["Flag rule", route2.flagRule]),
      Object.freeze(["Model artefact hash", route2.artefactHash]),
      Object.freeze(["Source hash", text(result2.source.content_hash, "not recorded")]),
      Object.freeze(["Normalised hash", text(result2.source.normalised_hash, "not recorded")]),
      Object.freeze(["Privacy", route2.privacy]),
      Object.freeze(["Support", text(options.productUrl, text(report.support_destination, DEFAULT_PRODUCT_URL))])
    ])
  });
}

// ../../shared/report/checker-report-html.mjs
function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/gu, (character) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[character]);
}
var polar = (cx, cy, radius, degrees) => {
  const radians = degrees * Math.PI / 180;
  return [cx + radius * Math.cos(radians), cy - radius * Math.sin(radians)];
};
function bandPath(cx, cy, inner, outer, startDegrees, endDegrees) {
  const [ox1, oy1] = polar(cx, cy, outer, startDegrees);
  const [ox2, oy2] = polar(cx, cy, outer, endDegrees);
  const [ix2, iy2] = polar(cx, cy, inner, endDegrees);
  const [ix1, iy1] = polar(cx, cy, inner, startDegrees);
  const sweep = Math.abs(endDegrees - startDegrees) > 180 ? 1 : 0;
  return [
    `M ${ox1.toFixed(2)} ${oy1.toFixed(2)}`,
    `A ${outer} ${outer} 0 ${sweep} 1 ${ox2.toFixed(2)} ${oy2.toFixed(2)}`,
    `L ${ix2.toFixed(2)} ${iy2.toFixed(2)}`,
    `A ${inner} ${inner} 0 ${sweep} 0 ${ix1.toFixed(2)} ${iy1.toFixed(2)}`,
    "Z"
  ].join(" ");
}
function renderGauge(model) {
  const cx = 150;
  const cy = 132;
  const inner = 72;
  const outer = 116;
  const span = 180 / LEVEL_ORDER.length;
  const bands = model.gauge.bands.map((band, index) => {
    const start = 180 - index * span - 1.4;
    const end = 180 - (index + 1) * span + 1.4;
    const grow = band.current ? 7 : 0;
    return `<path d="${bandPath(cx, cy, inner, outer + grow, start, end)}" fill="${band.colour.hex}"${band.current ? ' class="oaci-band-current"' : ' opacity="0.82"'}></path>`;
  }).join("");
  const angle = 180 - model.gauge.position * 180;
  const [tipX, tipY] = polar(cx, cy, outer - 12, angle);
  const [leftX, leftY] = polar(cx, cy, 6, angle + 90);
  const [rightX, rightY] = polar(cx, cy, 6, angle - 90);
  const needle = model.assessed ? `<polygon points="${tipX.toFixed(2)},${tipY.toFixed(2)} ${leftX.toFixed(2)},${leftY.toFixed(2)} ${rightX.toFixed(2)},${rightY.toFixed(2)}" fill="#fff"></polygon><circle cx="${cx}" cy="${cy}" r="9" fill="#fff"></circle><circle cx="${cx}" cy="${cy}" r="3.6" fill="#0f1115"></circle>` : "";
  const alternative = model.assessed ? `AI-pattern dial: ${model.level.label}, display score ${model.displayScore} on a zero-to-one pattern-similarity scale.` : "AI-pattern dial: no trained model reading is available for this run.";
  return `<figure class="oaci-gauge">
      <svg viewBox="0 0 300 150" role="img" aria-label="${escapeHtml(alternative)}" focusable="false"><g>${bands}${needle}</g></svg>
      <figcaption class="oaci-gauge-legend">${model.gauge.bands.map((band) => `<span${band.current ? ' data-current="true"' : ""}><i style="background:${band.colour.hex}"></i>${escapeHtml(band.label)}</span>`).join("")}</figcaption>
    </figure>`;
}
function logoMarkHtml(dataUri = LOGO_PNG_96_DATA_URI, style = "img") {
  if (style === "background") return `<span class="oaci-mark" role="presentation" style="background-image:url(${escapeHtml(dataUri)})"></span>`;
  return `<img class="oaci-mark" src="${escapeHtml(dataUri)}" alt="" width="96" height="96">`;
}
var listOf = (items, className = "") => items.length ? `<ul${className ? ` class="${className}"` : ""}>${items.map((item) => `<li>${escapeHtml(item)}</li>`).join("")}</ul>` : "";
var paragraphs = (values) => values.filter(Boolean).map((value) => `<p>${escapeHtml(value)}</p>`).join("");
function renderSections(model) {
  if (!model.sections.length) {
    return `<div class="oaci-note"><h3>No scored passages</h3><p>${escapeHtml(model.modelReason || "No trained model reading is available for this run.")}</p><p>Nothing is inferred from the other checks to fill that gap.</p></div>`;
  }
  const bars = model.sections.map((section) => `<li data-tone="${toneOf(section.level.colour)}">
        <span class="oaci-bar-label">Section ${section.number}</span>
        <span class="oaci-bar-track"><i style="width:${(section.barFill * 100).toFixed(1)}%;background:${section.level.colour.hex}"></i></span>
        <b>${escapeHtml(section.displayScore)}</b>
        <em>${escapeHtml(section.level.label)}</em>
        <small>${escapeHtml(section.wordsPhrase ?? "")}${section.strongest ? " &middot; strongest section" : ""}</small>
      </li>`).join("");
  const cards = model.sections.map((section) => `<article class="oaci-section" data-tone="${toneOf(section.level.colour)}" style="--oaci-accent:${section.level.colour.hex}">
        <header>
          <h3>Inside section ${section.number} of ${model.sections.length}</h3>
          <p class="oaci-chips"><span class="oaci-chip">${escapeHtml(section.level.label)}</span><span class="oaci-score">Score ${escapeHtml(section.displayScore)}</span></p>
        </header>
        <p class="oaci-meta">${escapeHtml([
    section.wordsPhrase ?? "",
    `engine index ${section.index}`,
    section.rawMargin === null ? "" : `raw margin ${section.rawMarginText}`,
    section.locator
  ].filter(Boolean).join(" \xB7 "))}</p>
        <blockquote>${escapeHtml(section.passage || `Content-free locator only: ${section.locator}.`)}</blockquote>
        <h4>Why it reads this way</h4>
        ${section.evidence.length ? listOf([...section.evidence]) : "<p>No explanatory evidence was recorded for this section.</p>"}
        ${section.strongest ? '<p class="oaci-strongest">This is the strongest scored section. It set the overall reading.</p>' : ""}
      </article>`).join("");
  return `<ol class="oaci-bars">${bars}</ol>${cards}`;
}
function renderChecks2(model) {
  return `<div class="oaci-scroll" tabindex="0" role="group" aria-label="Checks included in this run. Scroll sideways to read every column.">
    <table class="oaci-table">
      <caption>${escapeHtml(model.methodsPhrase)} in this run, with the outcome, where it ran, the version and the limits</caption>
      <thead><tr><th scope="col">Check</th><th scope="col">Outcome</th><th scope="col">Ran</th><th scope="col">Version</th><th scope="col">Limits</th></tr></thead>
      <tbody>${model.methods.map((method) => `<tr>
        <th scope="row">${escapeHtml(method.name)}<span>${escapeHtml(method.id)}</span></th>
        <td>${escapeHtml(method.statusLabel)}</td>
        <td>${escapeHtml(method.location)}</td>
        <td>${escapeHtml(method.version)}</td>
        <td>${method.limitations.length ? listOf([...method.limitations]) : "None recorded"}</td>
      </tr>`).join("")}</tbody>
    </table>
  </div>`;
}
function buildCheckerReportHtml(result2, options = {}) {
  const model = buildReportModel(result2, options);
  const logo = typeof options.logoDataUri === "string" && options.logoDataUri ? options.logoDataUri : LOGO_PNG_96_DATA_URI;
  const mark = typeof options.logoHtml === "string" ? options.logoHtml : logoMarkHtml(logo, options.logoStyle === "background" ? "background" : "img");
  const body = `<article class="oaci-report">
    <header class="oaci-masthead">
      ${mark}
      <div>
        <p class="oaci-kicker">${escapeHtml(model.productName)}</p>
        <h1>${escapeHtml(model.title)}</h1>
        <p class="oaci-masthead-meta">${escapeHtml(model.surfaceName)} &middot; ${escapeHtml(model.dateLabel)}</p>
        <p class="oaci-masthead-link">${escapeHtml(model.productUrl)}</p>
      </div>
      <p class="oaci-strapline">${escapeHtml(model.strapline)}</p>
    </header>

    <section class="oaci-verdict" aria-labelledby="oaci-verdict-heading" style="--oaci-accent:${model.level.colour.hex}">
      ${renderGauge(model)}
      <div class="oaci-verdict-body">
        <p class="oaci-kicker">AI-pattern reading</p>
        <h2 id="oaci-verdict-heading">${escapeHtml(model.level.label)}</h2>
        <p class="oaci-verdict-score">${escapeHtml(model.assessed ? `Score ${model.displayScore}` : "No score recorded")}</p>
        <p class="oaci-verdict-scale">${escapeHtml(model.scoreScale)}</p>
        <p class="oaci-verdict-meaning">${escapeHtml(model.meaning)}</p>
        ${model.strongestSentence ? `<p class="oaci-verdict-strongest">${escapeHtml(model.strongestSentence)}</p>` : ""}
      </div>
    </section>

    <section class="oaci-axes" aria-label="Three independent readings">
      ${model.axes.map((axis) => `<article data-tone="${toneOf(axis.colour)}" style="--oaci-accent:${axis.colour.hex}">
        <p class="oaci-kicker">${escapeHtml(axis.label)}</p>
        <h3>${escapeHtml(axis.value)}</h3>
        <p class="oaci-axis-status">${escapeHtml(axis.statusLabel)}</p>
        <p>${escapeHtml(axis.detail)}</p>
        ${axis.limitations.length ? `<p class="oaci-axis-limits">${escapeHtml(axis.limitations.join(" "))}</p>` : ""}
      </article>`).join("")}
    </section>

    <section class="oaci-stats" aria-label="Draft, route and privacy">
      <dl>
        <div><dt>Draft</dt><dd>${escapeHtml(model.draft.wordsPhrase)}</dd></div>
        <div><dt>Characters</dt><dd>${escapeHtml(model.draft.characters)}</dd></div>
        <div><dt>Sections</dt><dd>${escapeHtml(model.draft.sectionCount ? model.draft.sectionsPhrase : "Not scored")}</dd></div>
        <div><dt>Route</dt><dd>${escapeHtml(model.route.name)}</dd></div>
      </dl>
      <p class="oaci-privacy">${escapeHtml(model.route.privacy)}</p>
      <p class="oaci-honesty">${escapeHtml(model.honestyLine)}</p>
    </section>

    <section class="oaci-part" aria-labelledby="oaci-part-01">
      <p class="oaci-part-number">01</p>
      <h2 id="oaci-part-01">Section scores</h2>
      <p class="oaci-part-intro">Every scored section appears in document order. The bar shows how far the section leans away from the middle of the scale; the printed number is the display score taken straight from the result, never recalculated here.</p>
      ${renderSections(model)}
    </section>

    <section class="oaci-part" aria-labelledby="oaci-part-02">
      <p class="oaci-part-number">02</p>
      <h2 id="oaci-part-02">Characters, writing and protected facts</h2>
      <p class="oaci-part-intro">These findings come from separate deterministic checks. They are evidence in their own right and they never change the AI-pattern reading.</p>
      <div class="oaci-note"><h3>Invisible and lookalike characters</h3><p>${escapeHtml(`${model.axes[1].value}. ${model.axes[1].detail}`)}</p>${model.characterFindings.length ? listOf([...model.characterFindings]) : "<p>No text-integrity finding was recorded.</p>"}${listOf([...model.axes[1].limitations], "oaci-limits")}</div>
      <div class="oaci-note"><h3>Writing suggestions</h3><p>${escapeHtml(`${model.axes[2].value}. ${model.axes[2].detail}`)}</p>${model.writingFindings.length ? listOf([...model.writingFindings]) : "<p>No editorial finding was recorded.</p>"}${listOf([...model.axes[2].limitations], "oaci-limits")}</div>
      <div class="oaci-note"><h3>Facts kept safe</h3>${paragraphs([
    model.protectedFacts.sentence,
    model.protectedFacts.categoriesSentence,
    "Names, organisations, figures, dates, links, quotations, citations and code are independent evidence. They never imply authorship."
  ])}</div>
    </section>

    <section class="oaci-part" aria-labelledby="oaci-part-03">
      <p class="oaci-part-number">03</p>
      <h2 id="oaci-part-03">Content Credentials and watermarks</h2>
      <p class="oaci-part-intro">File and text credentials, and public watermark-key results, are recorded separately from the AI-pattern reading. An absent credential proves nothing about how a text was written.</p>
      ${model.c2paText ? `<div class="oaci-note"><h3>C2PA text credential</h3><p>Status: ${escapeHtml(model.c2paText.status)}. Wrapper protected: ${model.c2paText.wrapperProtected ? "yes" : "no"}.</p>${listOf([...model.c2paText.limitations], "oaci-limits")}</div>` : ""}
      ${model.c2paFiles.length ? model.c2paFiles.map((file) => `<div class="oaci-note"><h3>${escapeHtml(file.label)}</h3><p>Status: ${escapeHtml(file.status)}. Trust: ${escapeHtml(file.trust)}.</p><p class="oaci-meta">${escapeHtml(file.mediaType)} &middot; ${escapeHtml(file.fileHash)}</p>${listOf([...file.limitations], "oaci-limits")}</div>`).join("") : '<div class="oaci-note"><h3>File Content Credentials</h3><p>No file-origin result was attached to this text run. Pasted text is never given a file provenance verdict.</p></div>'}
      ${model.watermarks.map((watermark) => `<div class="oaci-note"><h3>${escapeHtml(watermark.name)}</h3><p class="oaci-meta">${escapeHtml(watermark.id)} &middot; ${escapeHtml(watermark.statusLabel)}</p><p>Outcome: ${escapeHtml(watermark.outcome)}. Key scope: ${escapeHtml(watermark.keyScope)}.</p>${listOf([...watermark.limitations], "oaci-limits")}</div>`).join("")}
    </section>

    <section class="oaci-part" aria-labelledby="oaci-part-04">
      <p class="oaci-part-number">04</p>
      <h2 id="oaci-part-04">Checks included in this run</h2>
      <p class="oaci-part-intro">Every named check is recorded with its outcome, where it ran, its version and its limitations. A check that did not run is never counted as a pass.</p>
      ${renderChecks2(model)}
    </section>

    <section class="oaci-part" aria-labelledby="oaci-part-05">
      <p class="oaci-part-number">05</p>
      <h2 id="oaci-part-05">Reliability, limits and correct use</h2>
      <p class="oaci-part-intro">This report records what the named checks found in one run. It does not prove authorship, guarantee that writing is human, or clear a private watermark key.</p>
      <div class="oaci-means">
        <div><h3>${escapeHtml(model.meansPanel.meansTitle)}</h3>${listOf([...model.meansPanel.means])}</div>
        <div><h3>${escapeHtml(model.meansPanel.notTitle)}</h3>${listOf([...model.meansPanel.not])}</div>
      </div>
      <div class="oaci-note"><h3>How to use this report</h3>${listOf([...model.correctUse])}</div>
      <div class="oaci-note"><h3>Recorded limitations</h3>${listOf([...model.limitations])}</div>
    </section>

    ${typeof options.fullText === "string" && options.fullText.trim() ? `<section class="oaci-part" aria-labelledby="oaci-part-06">
      <p class="oaci-part-number">06</p>
      <h2 id="oaci-part-06">The complete checked draft</h2>
      <p class="oaci-part-intro">This content-bearing appendix is written only after an explicit export action. Nothing is clipped or replaced with an ellipsis. ${escapeHtml(`${model.draft.wordsPhrase}, ${model.draft.charactersPhrase}.`)}</p>
      <pre class="oaci-draft">${escapeHtml(options.fullText)}</pre>
    </section>` : ""}

    <section class="oaci-part" aria-labelledby="oaci-part-run">
      <p class="oaci-part-number">${typeof options.fullText === "string" && options.fullText.trim() ? "07" : "06"}</p>
      <h2 id="oaci-part-run">Run record and support</h2>
      <p class="oaci-part-intro">The identities below are what another person needs to reproduce and interpret this result.</p>
      <dl class="oaci-run">${model.runRecord.map(([label, value]) => `<div><dt>${escapeHtml(label)}</dt><dd>${escapeHtml(value)}</dd></div>`).join("")}</dl>
    </section>

    <footer class="oaci-report-footer">
      <p>${escapeHtml(model.productName)} &middot; ${escapeHtml(model.strapline)}</p>
      <p>${escapeHtml(model.productUrl)}</p>
    </footer>
  </article>`;
  if (options.fragment) return body;
  return `<!doctype html>
<html lang="en-GB">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${escapeHtml(`${model.title} \u2014 ${model.productName}`)}</title>
<meta name="description" content="${escapeHtml(`Complete ${model.productName} result, evidence and run record for ${model.resultId}.`)}">
<meta name="robots" content="noindex">
<style>${CHECKER_REPORT_CSS}</style>
</head>
<body>
<main>
${body}
</main>
</body>
</html>
`;
}
var CHECKER_REPORT_CSS = `
:root{
  --oaci-ink:#0f1115; --oaci-paper:#f7f4ef; --oaci-card:#fff; --oaci-line:#dcd5ca;
  --oaci-muted:#5a625f; --oaci-orange:#fb700a; --oaci-blue:#0068b3; --oaci-accent:var(--oaci-orange);
  --oaci-human:${LEVEL_COLOURS["signal-likely-human"].hex}; --oaci-strong:${LEVEL_COLOURS["signal-strongly-ai"].hex};
  /* Ink shades. The palette above fills shapes; these colour text, and every one of them clears
     4.5:1 against the paper, the card and the means panel. They are Lane D1's band inks, so the
     two shared layers name the same colours. */
  --oaci-orange-ink:${REPORT_INKS.orange.hex}; --oaci-blue-ink:${REPORT_INKS.blue.hex}; --oaci-chip-text:#fff;
  --oaci-band-human:${REPORT_INKS.human.hex}; --oaci-band-unclear:${REPORT_INKS.unclear.hex}; --oaci-band-potential:${REPORT_INKS.potential.hex};
  --oaci-band-likely:${REPORT_INKS.likely.hex}; --oaci-band-strong:${REPORT_INKS.strong.hex}; --oaci-band-neutral:${REPORT_INKS.neutral.hex};
  --oaci-tone-ink:var(--oaci-band-neutral);
}
[data-tone=human]{--oaci-tone-ink:var(--oaci-band-human)}
[data-tone=unclear]{--oaci-tone-ink:var(--oaci-band-unclear)}
[data-tone=potential]{--oaci-tone-ink:var(--oaci-band-potential)}
[data-tone=likely]{--oaci-tone-ink:var(--oaci-band-likely)}
[data-tone=strong]{--oaci-tone-ink:var(--oaci-band-strong)}
[data-tone=neutral]{--oaci-tone-ink:var(--oaci-band-neutral)}
[data-tone=blue]{--oaci-tone-ink:var(--oaci-blue-ink)}
@page{size:A4;margin:14mm 13mm 16mm;
  @bottom-left{content:"Opace AI Content Integrity \u2014 evidence, not guarantees";font:8pt/1 Helvetica,Arial,sans-serif;color:#5a625f}
  @bottom-right{content:"Page " counter(page) " of " counter(pages);font:8pt/1 Helvetica,Arial,sans-serif;color:#5a625f}}
*{box-sizing:border-box}
html{-webkit-text-size-adjust:100%}
body{margin:0;background:var(--oaci-paper);color:var(--oaci-ink);
  font:12px/1.55 "Helvetica Neue",Helvetica,Arial,"Segoe UI",system-ui,sans-serif}
.oaci-report{max-width:210mm;margin:0 auto;padding:16px 18px 30px}
h1,h2,h3,h4{margin:0;line-height:1.15;font-weight:800}
h1{font-size:26px;letter-spacing:-0.012em}
h2{font-size:20px}
h3{font-size:14px}
h4{font-size:11.5px;text-transform:uppercase;letter-spacing:.07em;color:var(--oaci-muted)}
p{margin:.45em 0}
ul{margin:.4em 0;padding-left:1.15em}
li{margin:.18em 0}
.oaci-kicker{margin:0 0 3px;color:var(--oaci-muted);font-size:9px;font-weight:800;letter-spacing:.13em;text-transform:uppercase}
.oaci-meta{color:var(--oaci-muted);font-size:10px;overflow-wrap:anywhere}
.oaci-masthead{display:grid;grid-template-columns:auto minmax(0,1fr) auto;gap:16px;align-items:start;
  padding:16px 18px;border-radius:6px;background:var(--oaci-ink);color:#fff;border-bottom:4px solid var(--oaci-orange)}
.oaci-masthead .oaci-kicker{color:#ffad7b}
.oaci-masthead h1{color:#fff}
.oaci-mark{display:block;width:52px;height:52px;border-radius:6px;background-size:cover;background-repeat:no-repeat;-webkit-print-color-adjust:exact;print-color-adjust:exact}
.oaci-masthead-meta{margin:6px 0 0;color:#c8ccca;font-size:11px}
.oaci-masthead-link{margin:2px 0 0;color:#ffad7b;font-size:10px;overflow-wrap:anywhere}
.oaci-strapline{margin:0;align-self:end;color:#c8ccca;font-size:9.5px;font-weight:800;letter-spacing:.1em;text-transform:uppercase;white-space:nowrap}
.oaci-verdict{display:grid;grid-template-columns:300px minmax(0,1fr);gap:22px;align-items:center;
  margin-top:14px;padding:18px;border-radius:6px;background:var(--oaci-ink);color:#fff;border-left:6px solid var(--oaci-accent)}
.oaci-verdict .oaci-kicker{color:#9aa2a0}
.oaci-gauge{margin:0}
.oaci-gauge svg{display:block;width:100%;height:auto}
.oaci-band-current{filter:none}
.oaci-gauge-legend{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:4px;margin-top:6px;
  color:#9aa2a0;font-size:7.6px;font-weight:700;line-height:1.25}
.oaci-gauge-legend span{display:block;min-width:0}
.oaci-gauge-legend span[data-current=true]{color:#fff}
.oaci-gauge-legend i{display:block;width:16px;height:3px;margin-bottom:3px;border-radius:2px}
.oaci-verdict h2{color:#fff;font-size:30px;letter-spacing:-0.015em}
.oaci-verdict-score{margin:6px 0 0;color:#ffad7b;font-size:14px;font-weight:800}
.oaci-verdict-scale{margin:2px 0 0;color:#9aa2a0;font-size:9.5px}
.oaci-verdict-meaning{margin:10px 0 0;color:#e2e0da;font-size:12px}
.oaci-verdict-strongest{margin:8px 0 0;color:#ffad7b;font-size:11px;font-weight:700}
.oaci-axes{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px;margin-top:12px}
.oaci-axes article{min-width:0;padding:12px 13px;border:1px solid var(--oaci-line);border-left:4px solid var(--oaci-accent);
  border-radius:5px;background:var(--oaci-card)}
.oaci-axes h3{margin:3px 0 5px;font-size:16px}
.oaci-axis-status{margin:0 0 5px;color:var(--oaci-tone-ink);font-size:9.5px;font-weight:800;text-transform:uppercase;letter-spacing:.05em}
.oaci-axes p{font-size:10.5px;color:var(--oaci-muted)}
.oaci-axis-limits{font-size:9.5px;font-style:italic}
.oaci-stats{margin-top:12px;padding:12px 14px;border:1px solid var(--oaci-line);border-radius:5px;background:var(--oaci-card)}
.oaci-stats dl{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px;margin:0}
.oaci-stats dt{color:var(--oaci-muted);font-size:9px;font-weight:800;letter-spacing:.08em;text-transform:uppercase}
.oaci-stats dd{margin:3px 0 0;font-size:13px;font-weight:800}
.oaci-privacy{margin:10px 0 0;padding-top:9px;border-top:1px solid var(--oaci-line);font-size:10.5px;color:var(--oaci-muted)}
.oaci-honesty{margin:3px 0 0;font-size:10.5px;font-weight:700}
.oaci-part{margin-top:24px;break-inside:auto}
.oaci-part-number{margin:0 0 4px;color:var(--oaci-orange-ink);font-size:10.5px;font-weight:800;letter-spacing:.18em}
.oaci-part-intro{margin:6px 0 12px;color:var(--oaci-muted);font-size:10.5px;max-width:62em}
.oaci-part h2{break-after:avoid}
.oaci-bars{margin:0 0 16px;padding:0;list-style:none}
.oaci-bars li{display:grid;grid-template-columns:74px minmax(0,1fr) 44px 84px;gap:10px;align-items:center;
  padding:5px 0;border-bottom:1px solid var(--oaci-line)}
.oaci-bar-label{font-size:11px;font-weight:800}
.oaci-bar-track{display:block;height:9px;border-radius:5px;background:#e6e0d6;overflow:hidden}
.oaci-bar-track i{display:block;height:100%;border-radius:5px}
.oaci-bars b{font-size:12px;font-weight:800;text-align:right}
.oaci-bars em{color:var(--oaci-tone-ink);font-size:10.5px;font-weight:800;font-style:normal}
.oaci-bars small{grid-column:2/-1;color:var(--oaci-muted);font-size:9px}
.oaci-section{margin:0 0 12px;padding:14px 15px;border:1px solid var(--oaci-line);border-left:4px solid var(--oaci-accent);
  border-radius:5px;background:var(--oaci-card);break-inside:avoid}
.oaci-section header{display:flex;flex-wrap:wrap;gap:8px;align-items:baseline;justify-content:space-between}
.oaci-chips{display:flex;gap:8px;align-items:center;margin:0}
.oaci-chip{display:inline-block;padding:2px 9px;border-radius:9px;background:var(--oaci-tone-ink);color:var(--oaci-chip-text);
  font-size:9.5px;font-weight:800;letter-spacing:.03em}
.oaci-score{font-size:11px;font-weight:700;color:var(--oaci-muted)}
.oaci-section blockquote{margin:9px 0;padding:9px 12px;border-left:3px solid var(--oaci-line);border-radius:0 4px 4px 0;
  background:var(--oaci-paper);font:italic 11.5px/1.55 Georgia,"Times New Roman",serif}
.oaci-section ul{font-size:10.5px;color:var(--oaci-muted)}
.oaci-strongest{margin:8px 0 0;color:var(--oaci-tone-ink);font-size:10px;font-weight:800;text-transform:uppercase;letter-spacing:.05em}
.oaci-note{margin:0 0 10px;padding:13px 15px;border:1px solid var(--oaci-line);border-left:4px solid var(--oaci-blue);
  border-radius:5px;background:var(--oaci-card);break-inside:avoid}
.oaci-note p,.oaci-note li{font-size:10.5px;color:var(--oaci-muted)}
.oaci-limits{font-style:italic}
.oaci-means{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px;margin:0 0 12px;padding:14px 16px;
  border-radius:5px;background:#efe9e0;break-inside:avoid}
.oaci-means h3{font-size:10px;text-transform:uppercase;letter-spacing:.09em;color:var(--oaci-muted)}
.oaci-means ul{margin-top:6px;font-size:11px}
.oaci-scroll{max-width:100%;overflow-x:auto}
.oaci-scroll:focus-visible{outline:2px solid var(--oaci-blue-ink);outline-offset:2px}
.oaci-table{width:100%;border-collapse:collapse;font-size:10px;background:var(--oaci-card)}
.oaci-table caption{margin-bottom:6px;color:var(--oaci-muted);font-size:10px;text-align:left}
.oaci-table th,.oaci-table td{padding:7px 9px;border:1px solid var(--oaci-line);text-align:left;vertical-align:top}
.oaci-table thead th{background:#efe9e0;font-size:9px;text-transform:uppercase;letter-spacing:.06em}
.oaci-table tbody th{font-weight:800;overflow-wrap:anywhere}
.oaci-table tbody th span{display:block;margin-top:2px;color:var(--oaci-muted);font-weight:400;font-size:9px}
.oaci-table ul{margin:0;padding-left:1em}
.oaci-table tr{break-inside:avoid}
.oaci-run{display:grid;grid-template-columns:150px minmax(0,1fr);margin:0;padding:14px 16px;
  border:1px solid var(--oaci-line);border-left:4px solid var(--oaci-ink);border-radius:5px;background:var(--oaci-card)}
.oaci-run>div{display:contents}
.oaci-run dt{padding:4px 0;font-size:10px;font-weight:800}
.oaci-run dd{margin:0;padding:4px 0;color:var(--oaci-muted);font-size:10px;overflow-wrap:anywhere}
.oaci-draft{margin:0;padding:14px 16px;border:1px solid var(--oaci-line);border-radius:5px;background:var(--oaci-card);
  font:10.5px/1.6 "SFMono-Regular",Consolas,"Liberation Mono",monospace;white-space:pre-wrap;overflow-wrap:anywhere}
.oaci-report-footer{margin-top:24px;padding-top:10px;border-top:2px solid var(--oaci-ink);
  display:flex;flex-wrap:wrap;gap:8px;justify-content:space-between;color:var(--oaci-muted);font-size:9.5px}
.oaci-report-footer p{margin:0}
@media (max-width:560px){
  .oaci-masthead{grid-template-columns:auto minmax(0,1fr)}
  .oaci-strapline{grid-column:1/-1}
  .oaci-verdict{grid-template-columns:1fr}
  .oaci-axes,.oaci-stats dl,.oaci-means{grid-template-columns:1fr}
  .oaci-bars li{grid-template-columns:64px minmax(0,1fr) 40px}
  .oaci-bars em{grid-column:2/-1}
  .oaci-run{grid-template-columns:1fr}
  .oaci-run dt{padding-bottom:0}
}
@media print{
  body{background:#fff}
  .oaci-report{max-width:none;margin:0;padding:0}
  .oaci-masthead{grid-template-columns:auto minmax(0,1fr) auto}
  .oaci-strapline{grid-column:auto}
  .oaci-verdict{grid-template-columns:250px minmax(0,1fr)}
  .oaci-axes,.oaci-means{grid-template-columns:repeat(3,minmax(0,1fr))}
  .oaci-means{grid-template-columns:repeat(2,minmax(0,1fr))}
  .oaci-stats dl{grid-template-columns:repeat(4,minmax(0,1fr))}
  .oaci-bars li{grid-template-columns:74px minmax(0,1fr) 44px 84px}
  .oaci-bars em{grid-column:auto}
  .oaci-run{grid-template-columns:150px minmax(0,1fr)}
  .oaci-masthead,.oaci-verdict{border-radius:0}
  .oaci-part{break-before:auto}
  .oaci-section,.oaci-note,.oaci-means,.oaci-table tr{break-inside:avoid}
  .oaci-scroll{overflow-x:visible}
  a{color:inherit;text-decoration:none}
}
@media (prefers-color-scheme:dark){
  :root:not([data-theme=light]){--oaci-paper:#14161a;--oaci-card:#1c1f24;--oaci-line:#333940;--oaci-ink:#f2efe9;--oaci-muted:#a8b0ad;
    --oaci-orange-ink:#ffa76b;--oaci-blue-ink:#6fb6ec;--oaci-chip-text:#0f1115;
    --oaci-band-human:#6fd6a2;--oaci-band-unclear:#b8bfbc;--oaci-band-potential:#f0bb5c;
    --oaci-band-likely:#ff9f68;--oaci-band-strong:#ff9083;--oaci-band-neutral:#b8bfbc}
  :root:not([data-theme=light]) .oaci-masthead,:root:not([data-theme=light]) .oaci-verdict{background:#090b0e;color:#fff}
  :root:not([data-theme=light]) .oaci-means{background:#22262b}
  :root:not([data-theme=light]) .oaci-table thead th{background:#22262b}
  :root:not([data-theme=light]) .oaci-bar-track{background:#333940}
}
@media (forced-colors:active){
  .oaci-masthead,.oaci-verdict,.oaci-axes article,.oaci-note,.oaci-section,.oaci-run,.oaci-table th,.oaci-table td{border:1px solid CanvasText}
  .oaci-chip{border:1px solid CanvasText}
}
`;

// ../../shared/report/helvetica-metrics.mjs
var HELVETICA_WIDTHS = Object.freeze([
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  278,
  278,
  355,
  556,
  556,
  889,
  667,
  191,
  333,
  333,
  389,
  584,
  278,
  333,
  278,
  278,
  556,
  556,
  556,
  556,
  556,
  556,
  556,
  556,
  556,
  556,
  278,
  278,
  584,
  584,
  584,
  556,
  1015,
  667,
  667,
  722,
  722,
  667,
  611,
  778,
  722,
  278,
  500,
  667,
  556,
  833,
  722,
  778,
  667,
  778,
  722,
  667,
  611,
  722,
  667,
  944,
  667,
  667,
  611,
  278,
  278,
  278,
  469,
  556,
  333,
  556,
  556,
  500,
  556,
  556,
  278,
  556,
  556,
  222,
  222,
  500,
  222,
  833,
  556,
  556,
  556,
  556,
  333,
  500,
  278,
  556,
  500,
  722,
  500,
  500,
  500,
  334,
  260,
  334,
  584,
  0,
  556,
  0,
  222,
  556,
  333,
  1e3,
  556,
  556,
  333,
  1e3,
  667,
  333,
  1e3,
  0,
  611,
  0,
  0,
  222,
  222,
  333,
  333,
  350,
  556,
  1e3,
  333,
  1e3,
  500,
  333,
  944,
  0,
  500,
  667,
  278,
  333,
  556,
  556,
  556,
  556,
  260,
  556,
  333,
  737,
  370,
  556,
  584,
  333,
  737,
  333,
  400,
  584,
  333,
  333,
  333,
  556,
  537,
  278,
  333,
  333,
  365,
  556,
  834,
  834,
  834,
  611,
  667,
  667,
  667,
  667,
  667,
  667,
  1e3,
  722,
  667,
  667,
  667,
  667,
  278,
  278,
  278,
  278,
  722,
  722,
  778,
  778,
  778,
  778,
  778,
  584,
  778,
  722,
  722,
  722,
  722,
  667,
  667,
  611,
  556,
  556,
  556,
  556,
  556,
  556,
  889,
  500,
  556,
  556,
  556,
  556,
  278,
  278,
  278,
  278,
  556,
  556,
  556,
  556,
  556,
  556,
  556,
  584,
  611,
  556,
  556,
  556,
  556,
  500,
  556,
  500
]);
var HELVETICA_BOLD_WIDTHS = Object.freeze([
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  278,
  333,
  474,
  556,
  556,
  889,
  722,
  238,
  333,
  333,
  389,
  584,
  278,
  333,
  278,
  278,
  556,
  556,
  556,
  556,
  556,
  556,
  556,
  556,
  556,
  556,
  333,
  333,
  584,
  584,
  584,
  611,
  975,
  722,
  722,
  722,
  722,
  667,
  611,
  778,
  722,
  278,
  556,
  722,
  611,
  833,
  722,
  778,
  667,
  778,
  722,
  667,
  611,
  722,
  667,
  944,
  667,
  667,
  611,
  333,
  278,
  333,
  584,
  556,
  333,
  556,
  611,
  556,
  611,
  556,
  333,
  611,
  611,
  278,
  278,
  556,
  278,
  889,
  611,
  611,
  611,
  611,
  389,
  556,
  333,
  611,
  556,
  778,
  556,
  556,
  500,
  389,
  280,
  389,
  584,
  0,
  556,
  0,
  278,
  556,
  500,
  1e3,
  556,
  556,
  333,
  1e3,
  667,
  333,
  1e3,
  0,
  611,
  0,
  0,
  278,
  278,
  500,
  500,
  350,
  556,
  1e3,
  333,
  1e3,
  556,
  333,
  944,
  0,
  500,
  667,
  278,
  333,
  556,
  556,
  556,
  556,
  280,
  556,
  333,
  737,
  370,
  556,
  584,
  333,
  737,
  333,
  400,
  584,
  333,
  333,
  333,
  611,
  556,
  278,
  333,
  333,
  365,
  556,
  834,
  834,
  834,
  611,
  722,
  722,
  722,
  722,
  722,
  722,
  1e3,
  722,
  667,
  667,
  667,
  667,
  278,
  278,
  278,
  278,
  722,
  722,
  778,
  778,
  778,
  778,
  778,
  584,
  778,
  722,
  722,
  722,
  722,
  667,
  667,
  611,
  556,
  556,
  556,
  556,
  556,
  556,
  889,
  556,
  556,
  556,
  556,
  556,
  278,
  278,
  278,
  278,
  611,
  611,
  611,
  611,
  611,
  611,
  611,
  584,
  611,
  611,
  611,
  611,
  611,
  556,
  611,
  556
]);
var WIDTH_TABLES = Object.freeze({
  regular: HELVETICA_WIDTHS,
  bold: HELVETICA_BOLD_WIDTHS
});
function measureWinAnsi(text2, weight, size) {
  const widths = WIDTH_TABLES[weight] ?? HELVETICA_WIDTHS;
  let total = 0;
  const value = String(text2 ?? "");
  for (let index = 0; index < value.length; index += 1) {
    total += widths[value.charCodeAt(index) & 255] || 0;
  }
  return total * size / 1e3;
}

// ../../shared/report/pdf-writer.mjs
var A4 = Object.freeze({ width: 595.28, height: 841.89 });
var WINDOWS_1252 = new Map(Object.entries({
  "\u20AC": 128,
  "\u201A": 130,
  "\u0192": 131,
  "\u201E": 132,
  "\u2026": 133,
  "\u2020": 134,
  "\u2021": 135,
  "\u02C6": 136,
  "\u2030": 137,
  "\u0160": 138,
  "\u2039": 139,
  "\u0152": 140,
  "\u017D": 142,
  "\u2018": 145,
  "\u2019": 146,
  "\u201C": 147,
  "\u201D": 148,
  "\u2022": 149,
  "\u2013": 150,
  "\u2014": 151,
  "\u02DC": 152,
  "\u2122": 153,
  "\u0161": 154,
  "\u203A": 155,
  "\u0153": 156,
  "\u017E": 158,
  "\u0178": 159
}));
var WINDOWS_1252_BYTES = /* @__PURE__ */ new Set([...WINDOWS_1252.values()]);
var codePointLabel = (character) => {
  const codePoint = character.codePointAt(0);
  return `[U+${codePoint.toString(16).toUpperCase().padStart(codePoint > 65535 ? 6 : 4, "0")}]`;
};
var inWinAnsi = (character) => {
  const point = character.codePointAt(0);
  return point >= 32 && point <= 126 || point >= 160 && point <= 255 || WINDOWS_1252.has(character);
};
var winAnsiCharacter = (character) => {
  const codePoint = character.codePointAt(0);
  if (character === "\n") return "\n";
  if (character === "\r") return "";
  if (character === "	") return " ";
  if (codePoint >= 32 && codePoint <= 126 || codePoint >= 160 && codePoint <= 255) return character;
  if (WINDOWS_1252.has(character)) return String.fromCharCode(WINDOWS_1252.get(character));
  if (WINDOWS_1252_BYTES.has(codePoint)) return character;
  const decomposed = character.normalize("NFKD").replace(new RegExp("\\p{Mark}", "gu"), "");
  if (decomposed && decomposed !== character && [...decomposed].every(inWinAnsi)) {
    return [...decomposed].map((item) => WINDOWS_1252.has(item) ? String.fromCharCode(WINDOWS_1252.get(item)) : item).join("");
  }
  return codePointLabel(character);
};
var encodeWinAnsi = (value) => [...String(value ?? "").normalize("NFC")].map(winAnsiCharacter).join("");
var escapePdfString = (value) => String(value).replace(/([\\()])/gu, "\\$1").replace(/\r/gu, "");
var round = (value) => {
  const fixed = Number(value).toFixed(3);
  return fixed.replace(/\.?0+$/u, "") || "0";
};
var colour = (rgb) => `${round(rgb[0])} ${round(rgb[1])} ${round(rgb[2])}`;
var latin1 = (value) => {
  const bytes = new Uint8Array(value.length);
  for (let index = 0; index < value.length; index += 1) bytes[index] = value.charCodeAt(index) & 255;
  return bytes;
};
var measureText = (value, weight, size, characterSpacing = 0) => {
  const encoded = encodeWinAnsi(value);
  return measureWinAnsi(encoded, weight, size) + (characterSpacing ? encoded.length * characterSpacing : 0);
};
function readJpegHeader(bytes) {
  if (!bytes || bytes.length < 4 || bytes[0] !== 255 || bytes[1] !== 216) return null;
  let offset = 2;
  while (offset + 9 < bytes.length) {
    if (bytes[offset] !== 255) {
      offset += 1;
      continue;
    }
    const marker = bytes[offset + 1];
    if (marker === 216 || marker === 1 || marker >= 208 && marker <= 215) {
      offset += 2;
      continue;
    }
    const length = bytes[offset + 2] << 8 | bytes[offset + 3];
    const isFrame = marker >= 192 && marker <= 207 && marker !== 196 && marker !== 200 && marker !== 204;
    if (isFrame) {
      return {
        bits: bytes[offset + 4],
        height: bytes[offset + 5] << 8 | bytes[offset + 6],
        width: bytes[offset + 7] << 8 | bytes[offset + 8],
        components: bytes[offset + 9]
      };
    }
    if (length < 2) return null;
    offset += 2 + length;
  }
  return null;
}
var PdfPage = class {
  constructor({ trace = false } = {}) {
    this.operations = [];
    this.minimumY = A4.height;
    this.trace = trace ? [] : null;
  }
  #touch(y) {
    if (Number.isFinite(y) && y < this.minimumY) this.minimumY = y;
  }
  /** Record a painted area for the contrast probe. Bounds are [left, bottom, right, top]. */
  #paint(type, fill, x0, y0, x1, y1) {
    if (!this.trace) return;
    this.trace.push({
      type,
      fill: fill ? [...fill] : null,
      box: [Math.min(x0, x1), Math.min(y0, y1), Math.max(x0, x1), Math.max(y0, y1)]
    });
  }
  raw(operation) {
    this.operations.push(operation);
    return this;
  }
  /** Fill a rectangle. */
  rect(x, y, width, height, fill) {
    this.#touch(y);
    this.#paint("fill", fill, x, y, x + width, y + height);
    return this.raw(`q ${colour(fill)} rg ${round(x)} ${round(y)} ${round(width)} ${round(height)} re f Q`);
  }
  /** Stroke a rectangle outline. */
  strokeRect(x, y, width, height, stroke, lineWidth = 0.6) {
    this.#touch(y);
    return this.raw(`q ${colour(stroke)} RG ${round(lineWidth)} w ${round(x)} ${round(y)} ${round(width)} ${round(height)} re S Q`);
  }
  /** Rounded rectangle, filled and optionally outlined. */
  roundedRect(x, y, width, height, radius, fill, stroke = null, lineWidth = 0.6) {
    this.#touch(y);
    this.#paint("fill", fill, x, y, x + width, y + height);
    const r = Math.max(0, Math.min(radius, width / 2, height / 2));
    const k = r * 0.5523;
    const path = [
      `${round(x + r)} ${round(y)} m`,
      `${round(x + width - r)} ${round(y)} l`,
      `${round(x + width - r + k)} ${round(y)} ${round(x + width)} ${round(y + r - k)} ${round(x + width)} ${round(y + r)} c`,
      `${round(x + width)} ${round(y + height - r)} l`,
      `${round(x + width)} ${round(y + height - r + k)} ${round(x + width - r + k)} ${round(y + height)} ${round(x + width - r)} ${round(y + height)} c`,
      `${round(x + r)} ${round(y + height)} l`,
      `${round(x + r - k)} ${round(y + height)} ${round(x)} ${round(y + height - r + k)} ${round(x)} ${round(y + height - r)} c`,
      `${round(x)} ${round(y + r)} l`,
      `${round(x)} ${round(y + r - k)} ${round(x + r - k)} ${round(y)} ${round(x + r)} ${round(y)} c`,
      "h"
    ].join(" ");
    const paint = stroke ? `${colour(fill)} rg ${colour(stroke)} RG ${round(lineWidth)} w B` : `${colour(fill)} rg f`;
    return this.raw(`q ${path} ${paint} Q`);
  }
  /** Straight line. */
  line(x1, y1, x2, y2, stroke, lineWidth = 0.6) {
    this.#touch(Math.min(y1, y2));
    return this.raw(`q ${colour(stroke)} RG ${round(lineWidth)} w 1 J ${round(x1)} ${round(y1)} m ${round(x2)} ${round(y2)} l S Q`);
  }
  /** Filled polygon from [x, y] pairs. */
  polygon(points, fill) {
    if (points.length < 3) return this;
    for (const point of points) this.#touch(point[1]);
    this.#paint(
      "fill",
      fill,
      Math.min(...points.map((point) => point[0])),
      Math.min(...points.map((point) => point[1])),
      Math.max(...points.map((point) => point[0])),
      Math.max(...points.map((point) => point[1]))
    );
    const path = points.map(([x, y], index) => `${round(x)} ${round(y)} ${index ? "l" : "m"}`).join(" ");
    return this.raw(`q ${colour(fill)} rg ${path} h f Q`);
  }
  /** Filled circle, drawn with four Bezier quadrants. */
  circle(cx, cy, radius, fill) {
    this.#touch(cy - radius);
    this.#paint("fill", fill, cx - radius, cy - radius, cx + radius, cy + radius);
    const k = radius * 0.5523;
    const path = [
      `${round(cx + radius)} ${round(cy)} m`,
      `${round(cx + radius)} ${round(cy + k)} ${round(cx + k)} ${round(cy + radius)} ${round(cx)} ${round(cy + radius)} c`,
      `${round(cx - k)} ${round(cy + radius)} ${round(cx - radius)} ${round(cy + k)} ${round(cx - radius)} ${round(cy)} c`,
      `${round(cx - radius)} ${round(cy - k)} ${round(cx - k)} ${round(cy - radius)} ${round(cx)} ${round(cy - radius)} c`,
      `${round(cx + k)} ${round(cy - radius)} ${round(cx + radius)} ${round(cy - k)} ${round(cx + radius)} ${round(cy)} c`,
      "h"
    ].join(" ");
    return this.raw(`q ${colour(fill)} rg ${path} f Q`);
  }
  /**
   * Filled annular wedge: the building block of the dial gauge. Angles are degrees, measured
   * anticlockwise from the positive x axis, so 180 to 0 sweeps the top half.
   */
  arcBand(cx, cy, innerRadius, outerRadius, startDegrees, endDegrees, fill, steps2 = 18) {
    const points = [];
    for (let step = 0; step <= steps2; step += 1) {
      const angle = (startDegrees + (endDegrees - startDegrees) * step / steps2) * Math.PI / 180;
      points.push([cx + outerRadius * Math.cos(angle), cy + outerRadius * Math.sin(angle)]);
    }
    for (let step = steps2; step >= 0; step -= 1) {
      const angle = (startDegrees + (endDegrees - startDegrees) * step / steps2) * Math.PI / 180;
      points.push([cx + innerRadius * Math.cos(angle), cy + innerRadius * Math.sin(angle)]);
    }
    return this.polygon(points, fill);
  }
  /** One line of text at a baseline. */
  text(value, x, y, { weight = "regular", size = 9, fill = [0, 0, 0], characterSpacing = 0 } = {}) {
    this.#touch(y);
    const encoded = escapePdfString(encodeWinAnsi(value).replaceAll("\n", " "));
    if (!encoded) return this;
    const font = weight === "bold" ? "/F2" : "/F1";
    const spacing = characterSpacing ? `${round(characterSpacing)} Tc ` : "";
    if (this.trace) {
      this.trace.push({
        type: "text",
        text: String(value ?? ""),
        x,
        y,
        size,
        weight,
        fill: [...fill],
        width: measureText(value, weight, size, characterSpacing)
      });
    }
    return this.raw(`q BT ${spacing}${font} ${round(size)} Tf ${colour(fill)} rg ${round(x)} ${round(y)} Td (${encoded}) Tj ET Q`);
  }
  /** Draw the logo XObject into a width x height box with its lower-left corner at (x, y). */
  image(name, x, y, width, height) {
    this.#touch(y);
    this.#paint("image", null, x, y, x + width, y + height);
    return this.raw(`q ${round(width)} 0 0 ${round(height)} ${round(x)} ${round(y)} cm /${name} Do Q`);
  }
  stream() {
    return this.operations.join("\n");
  }
};
var PdfDocument = class {
  constructor({ title, author, subject, creator, creationDate, pageSize = A4, trace = false } = {}) {
    this.pageSize = pageSize;
    this.trace = Boolean(trace);
    this.pages = [];
    this.images = /* @__PURE__ */ new Map();
    this.info = {
      title: title ?? "Report",
      author: author ?? "Opace Digital Agency",
      subject: subject ?? "",
      creator: creator ?? "Opace AI Content Integrity",
      creationDate: creationDate ?? "1970-01-01T00:00:00Z"
    };
  }
  addPage() {
    const page = new PdfPage({ trace: this.trace });
    this.pages.push(page);
    return page;
  }
  /** Register a JPEG for use as an XObject. Ignored silently when the bytes are unusable. */
  addJpeg(name, bytes) {
    const header = readJpegHeader(bytes);
    if (!header || !header.width || !header.height) return false;
    this.images.set(name, { bytes, header });
    return true;
  }
  #pdfDate() {
    const parsed = new Date(this.info.creationDate);
    const iso = Number.isNaN(parsed.getTime()) ? "1970-01-01T00:00:00.000Z" : parsed.toISOString();
    return `D:${iso.slice(0, 4)}${iso.slice(5, 7)}${iso.slice(8, 10)}${iso.slice(11, 13)}${iso.slice(14, 16)}${iso.slice(17, 19)}Z00'00'`;
  }
  /** Serialise to PDF bytes. */
  build() {
    if (!this.pages.length) throw new Error("pdf_document_has_no_pages");
    const objects = [];
    const add = (value) => {
      objects.push(value);
      return objects.length;
    };
    const catalogId = add(null);
    const pagesId = add(null);
    const regularFontId = add("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>");
    const boldFontId = add("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>");
    const imageIds = /* @__PURE__ */ new Map();
    for (const [name, { bytes, header }] of this.images) {
      const space = header.components === 1 ? "/DeviceGray" : header.components === 4 ? "/DeviceCMYK" : "/DeviceRGB";
      const dictionary = `<< /Type /XObject /Subtype /Image /Width ${header.width} /Height ${header.height} /ColorSpace ${space} /BitsPerComponent ${header.bits || 8} /Filter /DCTDecode /Length ${bytes.length} >>`;
      imageIds.set(name, add({ dictionary, bytes }));
    }
    const xObjectEntry = imageIds.size ? ` /XObject << ${[...imageIds].map(([name, id]) => `/${name} ${id} 0 R`).join(" ")} >>` : "";
    const pageIds = [];
    for (const page of this.pages) {
      const stream = page.stream();
      const streamId = add({ dictionary: `<< /Length ${stream.length} >>`, bytes: latin1(stream) });
      pageIds.push(add(
        `<< /Type /Page /Parent ${pagesId} 0 R /MediaBox [0 0 ${round(this.pageSize.width)} ${round(this.pageSize.height)}] /Resources << /Font << /F1 ${regularFontId} 0 R /F2 ${boldFontId} 0 R >>${xObjectEntry} >> /Contents ${streamId} 0 R >>`
      ));
    }
    objects[catalogId - 1] = `<< /Type /Catalog /Pages ${pagesId} 0 R >>`;
    objects[pagesId - 1] = `<< /Type /Pages /Kids [${pageIds.map((id) => `${id} 0 R`).join(" ")}] /Count ${pageIds.length} >>`;
    const date = this.#pdfDate();
    const infoId = add(
      `<< /Title (${escapePdfString(encodeWinAnsi(this.info.title))}) /Author (${escapePdfString(encodeWinAnsi(this.info.author))}) /Subject (${escapePdfString(encodeWinAnsi(this.info.subject))}) /Creator (${escapePdfString(encodeWinAnsi(this.info.creator))}) /Producer (${escapePdfString(encodeWinAnsi(this.info.creator))}) /CreationDate (${date}) /ModDate (${date}) >>`
    );
    const parts = [];
    let length = 0;
    const push = (value) => {
      const bytes = typeof value === "string" ? latin1(value) : value;
      parts.push(bytes);
      length += bytes.length;
    };
    push("%PDF-1.4\n%\xE2\xE3\xCF\xD3\n");
    const offsets = new Array(objects.length + 1).fill(0);
    objects.forEach((value, index) => {
      offsets[index + 1] = length;
      push(`${index + 1} 0 obj
`);
      if (typeof value === "string") {
        push(`${value}
`);
      } else {
        push(`${value.dictionary}
stream
`);
        push(value.bytes);
        push("\nendstream\n");
      }
      push("endobj\n");
    });
    const xrefOffset = length;
    let xref = `xref
0 ${objects.length + 1}
0000000000 65535 f 
`;
    for (let index = 1; index <= objects.length; index += 1) xref += `${String(offsets[index]).padStart(10, "0")} 00000 n 
`;
    push(xref);
    push(`trailer
<< /Size ${objects.length + 1} /Root ${catalogId} 0 R /Info ${infoId} 0 R >>
startxref
${xrefOffset}
%%EOF
`);
    const output = new Uint8Array(length);
    let cursor = 0;
    for (const part of parts) {
      output.set(part, cursor);
      cursor += part.length;
    }
    return output;
  }
};
function wrapLines(value, weight, size, width) {
  const lines = [];
  const source = encodeWinAnsi(value).replace(/\r/gu, "");
  for (const paragraph of source.split("\n")) {
    const words = paragraph.split(/\s+/u).filter(Boolean);
    if (!words.length) continue;
    let line = "";
    for (const word of words) {
      const candidate2 = line ? `${line} ${word}` : word;
      if (measureWinAnsi(candidate2, weight, size) <= width) {
        line = candidate2;
        continue;
      }
      if (line) lines.push(line);
      if (measureWinAnsi(word, weight, size) <= width) {
        line = word;
        continue;
      }
      let piece = "";
      for (const character of word) {
        const next = piece + character;
        if (piece && measureWinAnsi(next, weight, size) > width) {
          lines.push(piece);
          piece = character;
        } else piece = next;
      }
      line = piece;
    }
    if (line) lines.push(line);
  }
  return lines;
}
var rgbToHex = (rgb) => `#${rgb.map((channel) => Math.round(Math.min(1, Math.max(0, channel)) * 255).toString(16).padStart(2, "0")).join("")}`;

// ../../shared/report/checker-pdf.mjs
var MARGIN = 44;
var CONTENT_WIDTH = A4.width - MARGIN * 2;
var CONTENT_TOP = 760;
var CONTENT_BOTTOM = 62;
var HEADER_HEIGHT = 52;
var INK = [0.059, 0.067, 0.082];
var PAPER = [0.976, 0.965, 0.945];
var WHITE = [1, 1, 1];
var MUTED = [0.353, 0.376, 0.376];
var LINE = [0.827, 0.8, 0.757];
var SOFT = [0.925, 0.91, 0.886];
var ORANGE = [0.984, 0.439, 0.039];
var BLUE = [0, 0.408, 0.702];
var GREEN = [0.102, 0.451, 0.286];
var LIGHT_INK = [0.878, 0.871, 0.847];
var DIM_INK = [0.686, 0.706, 0.702];
var HIGHLIGHT = [1, 0.671, 0.451];
var STATUS_COLOURS = Object.freeze({
  pass: GREEN,
  attention: [0.749, 0.278, 0.02],
  fail: [0.639, 0.122, 0.09],
  error: [0.639, 0.122, 0.09],
  inconclusive: MUTED,
  unsupported: MUTED,
  not_configured: MUTED,
  not_run: MUTED
});
var statusColour = (status) => STATUS_COLOURS[status] ?? MUTED;
var textInk = (fill) => inkFor(rgbToHex(fill))?.rgb ?? fill;
var ORANGE_INK = textInk(ORANGE);
var BLUE_INK = textInk(BLUE);
var ReportLayout = class {
  constructor(document2, { productName, subtitle, logoName }) {
    this.document = document2;
    this.productName = productName;
    this.subtitle = subtitle;
    this.logoName = logoName;
    this.runningSection = "Report";
    this.page = null;
    this.y = 0;
  }
  newPage(section = this.runningSection) {
    this.runningSection = section;
    this.page = this.document.addPage();
    this.page.rect(0, 0, A4.width, A4.height, PAPER);
    this.page.rect(0, A4.height - HEADER_HEIGHT, A4.width, HEADER_HEIGHT, INK);
    this.page.rect(0, A4.height - HEADER_HEIGHT - 3.5, A4.width, 3.5, ORANGE);
    let textLeft = MARGIN;
    if (this.logoName) {
      this.page.image(this.logoName, MARGIN, A4.height - 42, 30, 30);
      textLeft = MARGIN + 39;
    }
    this.page.text("OPACE", textLeft, A4.height - 24, { weight: "bold", size: 13, fill: WHITE });
    this.page.text("AI CONTENT INTEGRITY", textLeft, A4.height - 36, { weight: "bold", size: 7.4, fill: HIGHLIGHT, characterSpacing: 1.1 });
    const label = encodeWinAnsi(this.runningSection).toUpperCase();
    this.page.text(label, A4.width - MARGIN - measureText(label, "bold", 6.8, 0.5), A4.height - 31, { weight: "bold", size: 6.8, fill: DIM_INK, characterSpacing: 0.5 });
    this.y = CONTENT_TOP;
    return this.page;
  }
  ensure(height, section = this.runningSection) {
    if (!this.page) {
      this.newPage(section);
      return;
    }
    if (this.y - height < CONTENT_BOTTOM) this.newPage(section);
  }
  gap(height) {
    this.y -= height;
  }
  /** Free height left on the current page. */
  get available() {
    return this.y - CONTENT_BOTTOM;
  }
  /** Wrapped paragraph flow; splits across pages one line at a time. */
  paragraph(value, { weight = "regular", size = 8.8, leading = 11.8, fill = MUTED, x = MARGIN, width = CONTENT_WIDTH, gapAfter = 0, maxLines = 0 } = {}) {
    let lines = wrapLines(value, weight, size, width);
    if (maxLines > 0) lines = lines.slice(0, maxLines);
    for (const line of lines) {
      this.ensure(leading);
      this.page.text(line, x, this.y - size, { weight, size, fill });
      this.y -= leading;
    }
    if (lines.length) this.y -= gapAfter;
    return lines.length;
  }
  /**
   * Numbered part heading with an orange kicker rule.
   * `keepWith` reserves room for the first block underneath so a heading is never orphaned.
   */
  heading(number3, title, intro, keepWith = 64) {
    const titleLines = wrapLines(title, "bold", 18, CONTENT_WIDTH);
    const introLines = intro ? wrapLines(intro, "regular", 8.8, CONTENT_WIDTH) : [];
    this.ensure(24 + titleLines.length * 21 + introLines.length * 11.6 + 14 + keepWith, title);
    this.runningSection = title;
    this.page.rect(MARGIN, this.y - 2, 22, 3, ORANGE);
    this.page.text(number3, MARGIN + 30, this.y - 3, { weight: "bold", size: 7.4, fill: ORANGE_INK, characterSpacing: 0.9 });
    this.y -= 20;
    for (const line of titleLines) {
      this.ensure(21);
      this.page.text(line, MARGIN, this.y - 18, { weight: "bold", size: 18, fill: INK });
      this.y -= 21;
    }
    if (introLines.length) {
      this.y -= 3;
      this.paragraph(intro, { size: 8.8, leading: 11.6, fill: MUTED });
    }
    this.y -= 10;
  }
  /**
   * Panel with an accent spine, a title, an optional meta line and a body that can span pages.
   *
   * The body is plain text; three conventions give it structure without a markup language:
   * a short ALL-CAPS line becomes a bold accent sub-heading, a line starting "- " becomes a
   * hanging-indent bullet, and with `labelledRows` a "Label: value" line prints the label in
   * bold ink and hangs the value in its own column.
   */
  card(title, body, { accent = ORANGE, meta = "", fill = WHITE, section = this.runningSection, labelledRows = false } = {}) {
    const innerWidth = CONTENT_WIDTH - 34;
    const accentInk = textInk(accent);
    const bodyLines = layoutCardBody(body ?? "", innerWidth, accentInk, labelledRows);
    const heightOf = (lines) => lines.reduce((total, line) => total + line.leading + line.spaceBefore, 0);
    let cursor = 0;
    let part = 0;
    do {
      const heading = part ? `${title} (continued)` : title;
      const titleLines = wrapLines(heading, "bold", 11, innerWidth);
      const metaLines = meta && !part ? wrapLines(meta, "bold", 7.2, innerWidth) : [];
      const fixed = 17 + titleLines.length * 13.6 + (metaLines.length ? metaLines.length * 9.2 + 5 : 0);
      const remaining = bodyLines.slice(cursor);
      if (this.available < fixed + 26 || remaining.length <= 16 && this.available < fixed + heightOf(remaining) + 12) {
        if (this.y < CONTENT_TOP) this.newPage(section);
      }
      const room = this.available - fixed - 12;
      const chunk = [];
      let used = 0;
      for (const line of remaining) {
        const next = used + line.leading + line.spaceBefore;
        if (chunk.length && next > room) break;
        chunk.push(line);
        used = next;
      }
      const height = fixed + used + 11;
      this.page.roundedRect(MARGIN, this.y - height, CONTENT_WIDTH, height, 3, fill, LINE, 0.55);
      this.page.rect(MARGIN, this.y - height, 3.6, height, accent);
      let cardY = this.y - 17;
      for (const line of titleLines) {
        this.page.text(line, MARGIN + 17, cardY, { weight: "bold", size: 11, fill: INK });
        cardY -= 13.6;
      }
      for (const line of metaLines) {
        this.page.text(line, MARGIN + 17, cardY, { weight: "bold", size: 7.2, fill: accentInk });
        cardY -= 9.2;
      }
      if (metaLines.length) cardY -= 5;
      for (const line of chunk) {
        cardY -= line.spaceBefore;
        if (line.label) this.page.text(line.label, MARGIN + 17, cardY, { weight: "bold", size: line.size, fill: INK });
        this.page.text(line.text, MARGIN + 17 + line.indent, cardY, { weight: line.weight, size: line.size, fill: line.fill });
        cardY -= line.leading;
      }
      this.y -= height + 9;
      cursor += chunk.length;
      part += 1;
      if (cursor < bodyLines.length) this.newPage(section);
    } while (cursor < bodyLines.length);
  }
};
var LABEL_LINE = /^[A-Z][A-Z0-9 ,.'()/-]{2,46}$/u;
var LABELLED_ROW = /^([^:]{1,34}): (.+)$/su;
function layoutCardBody(body, innerWidth, accentInk, labelledRows) {
  const lines = [];
  const paragraphs2 = String(body ?? "").split("\n");
  paragraphs2.forEach((paragraph, index) => {
    const value = paragraph.trim();
    if (!value) return;
    const first = lines.length === 0;
    if (LABEL_LINE.test(value)) {
      lines.push({ text: value, weight: "bold", size: 7.2, fill: accentInk, leading: 10.4, indent: 0, spaceBefore: first ? 0 : 4, label: "" });
      return;
    }
    if (labelledRows) {
      const match = LABELLED_ROW.exec(value);
      if (match) {
        const label = `${match[1]}`;
        const column = Math.max(96, measureText(`${label}  `, "bold", 8.6));
        const wrapped2 = wrapLines(match[2], "regular", 8.6, innerWidth - column);
        wrapped2.forEach((line, lineIndex) => {
          lines.push({
            text: line,
            weight: "regular",
            size: 8.6,
            fill: MUTED,
            leading: 11.4,
            indent: column,
            spaceBefore: lineIndex === 0 && !first ? 1.6 : 0,
            label: lineIndex === 0 ? label : ""
          });
        });
        return;
      }
    }
    const isBullet = value.startsWith("- ");
    const indent = isBullet ? 9 : 0;
    const wrapped = wrapLines(isBullet ? value.slice(2) : value, "regular", 8.6, innerWidth - indent);
    wrapped.forEach((line, lineIndex) => {
      lines.push({
        text: line,
        weight: "regular",
        size: 8.6,
        fill: MUTED,
        leading: 11.4,
        indent,
        spaceBefore: lineIndex === 0 && !first && index > 0 ? 1.4 : 0,
        label: lineIndex === 0 && isBullet ? "-" : ""
      });
    });
  });
  return lines;
}
function drawChip(page, x, y, label, fillColour, size = 7.6) {
  const width = measureText(label, "bold", size) + 15;
  const height = size + 8;
  page.roundedRect(x, y, width, height, height / 2, fillColour);
  page.text(label, x + 7.5, y + 5.6, { weight: "bold", size, fill: WHITE });
  return width;
}
function drawGauge(page, cx, cy, outerRadius, innerRadius, gauge, assessed) {
  const bands = gauge.bands;
  const span = 180 / bands.length;
  bands.forEach((band, index) => {
    const start = 180 - index * span - 1.2;
    const end = 180 - (index + 1) * span + 1.2;
    const grow = band.current ? 5 : 0;
    page.arcBand(cx, cy, innerRadius, outerRadius + grow, start, end, band.colour.rgb, 16);
  });
  if (!assessed) return;
  const angle = (180 - gauge.position * 180) * Math.PI / 180;
  const tip = outerRadius - 6;
  const base = 5.2;
  const normal = angle + Math.PI / 2;
  page.polygon(
    [
      [cx + tip * Math.cos(angle), cy + tip * Math.sin(angle)],
      [cx + base * Math.cos(normal), cy + base * Math.sin(normal)],
      [cx - base * Math.cos(normal), cy - base * Math.sin(normal)]
    ],
    WHITE
  );
  page.circle(cx, cy, 7, WHITE);
  page.circle(cx, cy, 3.2, INK);
}
function drawGaugeLegend(page, x, y, width, gauge) {
  const cell = width / gauge.bands.length;
  gauge.bands.forEach((band, index) => {
    const left = x + index * cell;
    page.rect(left, y + 7, 13, 3.2, band.colour.rgb);
    const lines = wrapLines(band.label, "bold", 5.6, cell - 20);
    lines.slice(0, 2).forEach((line, lineIndex) => {
      page.text(line, left + 17, y + 6 - lineIndex * 7, { weight: "bold", size: 5.6, fill: band.current ? WHITE : DIM_INK, characterSpacing: 0.25 });
    });
  });
}
function drawHero(layout, model) {
  const height = 174;
  layout.ensure(height, "Result summary");
  const page = layout.page;
  const top = layout.y;
  page.roundedRect(MARGIN, top - height, CONTENT_WIDTH, height, 4, INK);
  page.rect(MARGIN, top - height, 6, height, model.level.colour.rgb);
  drawGauge(page, MARGIN + 128, top - 140, 104, 68, model.gauge, model.assessed);
  drawGaugeLegend(page, MARGIN + 20, top - 164, CONTENT_WIDTH - 40, model.gauge);
  const left = MARGIN + 262;
  const width = CONTENT_WIDTH - 262 - 22;
  page.text("AI-PATTERN READING", left, top - 26, { weight: "bold", size: 6.9, fill: DIM_INK, characterSpacing: 0.9 });
  let y = top - 50;
  for (const line of wrapLines(model.level.label, "bold", 21, width).slice(0, 2)) {
    page.text(line, left, y, { weight: "bold", size: 21, fill: WHITE });
    y -= 23;
  }
  const score = model.assessed ? `Score ${model.displayScore}` : "No score recorded";
  page.text(score, left, y, { weight: "bold", size: 10.5, fill: HIGHLIGHT });
  y -= 13;
  page.text("Zero-to-one pattern similarity, not a percentage", left, y, { weight: "regular", size: 6.9, fill: DIM_INK });
  y -= 17;
  for (const line of wrapLines(model.meaning, "regular", 8.6, width).slice(0, 5)) {
    page.text(line, left, y, { weight: "regular", size: 8.6, fill: LIGHT_INK });
    y -= 11.4;
  }
  if (model.strongestSentence) {
    y -= 6;
    for (const line of wrapLines(model.strongestSentence, "bold", 7.8, width).slice(0, 3)) {
      page.text(line, left, y, { weight: "bold", size: 7.8, fill: HIGHLIGHT });
      y -= 10.2;
    }
  }
  layout.y -= height + 13;
}
function drawAxisCards(layout, model) {
  const height = 96;
  layout.ensure(height + 12, "Result summary");
  const page = layout.page;
  const gap = 9;
  const width = (CONTENT_WIDTH - gap * 2) / 3;
  model.axes.forEach((axis, index) => {
    const x = MARGIN + index * (width + gap);
    page.roundedRect(x, layout.y - height, width, height, 3, WHITE, LINE, 0.55);
    page.rect(x, layout.y - height, 3.6, height, axis.colour.rgb);
    page.text(axis.label.toUpperCase(), x + 13, layout.y - 20, { weight: "bold", size: 6.2, fill: MUTED, characterSpacing: 0.5 });
    let y = layout.y - 36;
    for (const line of wrapLines(axis.value, "bold", 11.5, width - 26).slice(0, 2)) {
      page.text(line, x + 13, y, { weight: "bold", size: 11.5, fill: INK });
      y -= 13.5;
    }
    drawChip(page, x + 13, y - 12, axis.statusLabel, statusColour(axis.status), 6.2);
    y -= 26;
    for (const line of wrapLines(axis.detail, "regular", 7.4, width - 26).slice(0, 3)) {
      page.text(line, x + 13, y, { weight: "regular", size: 7.4, fill: MUTED });
      y -= 9.4;
    }
  });
  layout.y -= height + 12;
}
function drawStatTiles(layout, model) {
  const height = 44;
  layout.ensure(height + 10, "Result summary");
  const page = layout.page;
  const gap = 8;
  const width = (CONTENT_WIDTH - gap * 3) / 4;
  const tiles = [
    ["DRAFT", model.draft.wordsPhrase],
    ["CHARACTERS", model.draft.characters],
    ["SECTIONS", String(model.draft.sectionCount || "Not scored")],
    ["ROUTE", model.route.name]
  ];
  tiles.forEach(([label, value], index) => {
    const x = MARGIN + index * (width + gap);
    page.roundedRect(x, layout.y - height, width, height, 3, SOFT);
    page.text(label, x + 11, layout.y - 15, { weight: "bold", size: 6, fill: MUTED, characterSpacing: 0.5 });
    wrapLines(value, "bold", 8.6, width - 22).slice(0, 2).forEach((line, lineIndex) => {
      page.text(line, x + 11, layout.y - 27 - lineIndex * 10, { weight: "bold", size: 8.6, fill: INK });
    });
  });
  layout.y -= height + 12;
}
function drawSectionBars(layout, model) {
  const page = layout.page;
  const labelWidth = 74;
  const trackLeft = MARGIN + labelWidth;
  const trackWidth = 250;
  for (const section of model.sections) {
    layout.ensure(30, "Section scores");
    const y = layout.y - 12;
    layout.page.text(`Section ${section.number}`, MARGIN, y, { weight: "bold", size: 8.4, fill: INK });
    layout.page.roundedRect(trackLeft, y - 2, trackWidth, 8, 4, SOFT);
    layout.page.roundedRect(trackLeft, y - 2, Math.max(8, trackWidth * section.barFill), 8, 4, section.level.colour.rgb);
    layout.page.text(section.displayScore, trackLeft + trackWidth + 12, y, { weight: "bold", size: 8.4, fill: INK });
    layout.page.text(section.level.label, trackLeft + trackWidth + 48, y, { weight: "bold", size: 7.8, fill: textInk(section.level.colour.rgb) });
    const words = section.wordsPhrase ?? "";
    const suffix = section.strongest ? `${words}${words ? "  |  " : ""}strongest section` : words;
    if (suffix) layout.page.text(suffix, trackLeft, y - 11, { weight: "regular", size: 6.8, fill: MUTED });
    layout.y -= 30;
  }
  void page;
}
function drawSectionEvidence(layout, model) {
  for (const section of model.sections) {
    const passage = section.passage || `Content-free locator only: ${section.locator}.`;
    const evidence = section.evidence.length ? section.evidence.map((item) => `- ${item}`).join("\n") : "No explanatory evidence was recorded for this section.";
    const body = [
      "THE SCORED PASSAGE",
      passage,
      "WHY IT READS THIS WAY",
      evidence,
      section.strongest ? "This is the strongest scored section; it set the overall reading." : ""
    ].filter(Boolean).join("\n");
    const meta = [
      `${section.level.label}  |  score ${section.displayScore}`,
      section.wordsPhrase ?? "",
      `engine index ${section.index}`,
      section.rawMargin === null ? "" : `raw margin ${section.rawMarginText}`,
      `location ${section.locator}`
    ].filter(Boolean).join("  |  ");
    layout.card(`Section ${section.number} of ${model.sections.length}`, body, {
      accent: section.level.colour.rgb,
      meta,
      section: "Section evidence"
    });
  }
}
var bullet = (values) => values.map((value) => `- ${value}`).join("\n");
function drawMeaningPanel(layout, model) {
  const panel = model.meansPanel;
  const gap = 12;
  const columnWidth = (CONTENT_WIDTH - gap) / 2 - 26;
  const wrapColumn = (title, items) => [
    { text: title.toUpperCase(), weight: "bold", size: 6.8, fill: MUTED, leading: 13 },
    ...items.flatMap((item) => wrapLines(item, "regular", 8.4, columnWidth).map((line, index) => ({
      text: line,
      weight: "regular",
      size: 8.4,
      fill: INK,
      leading: 11.2,
      spaceBefore: index === 0 ? 3 : 0
    })))
  ];
  const left = wrapColumn(panel.meansTitle, panel.means);
  const right = wrapColumn(panel.notTitle, panel.not);
  const columnHeight = (lines) => lines.reduce((total, line) => total + line.leading + (line.spaceBefore ?? 0), 0);
  const height = Math.max(columnHeight(left), columnHeight(right)) + 26;
  layout.ensure(height + 10, "Reliability and limits");
  const page = layout.page;
  const top = layout.y;
  page.roundedRect(MARGIN, top - height, CONTENT_WIDTH, height, 3, SOFT);
  [left, right].forEach((lines, column) => {
    const x = MARGIN + 18 + column * ((CONTENT_WIDTH - gap) / 2 + gap);
    let y = top - 17;
    for (const line of lines) {
      y -= line.spaceBefore ?? 0;
      page.text(line.text, x, y, { weight: line.weight, size: line.size, fill: line.fill });
      y -= line.leading;
    }
  });
  layout.y -= height + 10;
}
function buildCheckerPdf(result2, options = {}) {
  return composeCheckerPdf(result2, options).build();
}
function composeCheckerPdf(result2, options = {}) {
  const model = buildReportModel(result2, options);
  const document2 = new PdfDocument({
    title: `${PRODUCT_NAME2} report`,
    author: "Opace Digital Agency",
    subject: "Complete AI content integrity result, evidence and run record",
    creator: PRODUCT_NAME2,
    creationDate: model.generatedAt,
    trace: options.trace === true
  });
  const hasLogo = options.logoJpegBytes ? document2.addJpeg("Logo", options.logoJpegBytes) : false;
  const layout = new ReportLayout(document2, { productName: PRODUCT_NAME2, subtitle: model.title, logoName: hasLogo ? "Logo" : null });
  layout.newPage("Result summary");
  layout.page.text(model.title, MARGIN, layout.y - 22, { weight: "bold", size: 23, fill: INK });
  layout.y -= 30;
  layout.page.text(`${model.surfaceName}  |  ${model.dateLabel}`, MARGIN, layout.y - 8, { weight: "regular", size: 8.4, fill: MUTED });
  layout.y -= 15;
  layout.page.text(model.productUrl, MARGIN, layout.y - 8, { weight: "bold", size: 7.6, fill: BLUE_INK });
  layout.y -= 18;
  drawHero(layout, model);
  drawAxisCards(layout, model);
  drawStatTiles(layout, model);
  layout.card("How to read this result", [
    model.honestyLine,
    model.scoreScale,
    "Character checks and writing suggestions are separate readings. Neither can raise or lower the AI-pattern reading.",
    model.route.privacy
  ].join("\n"), { accent: model.level.colour.rgb, section: "Result summary" });
  layout.heading("01", "Section scores", "Every scored section appears in document order. The bar shows how far the section leans away from the middle of the scale; the printed number is the display score taken straight from the result, never recalculated here.");
  if (model.sections.length) drawSectionBars(layout, model);
  else layout.card("No section scores", "The trained model did not produce section scores for this run. The remaining checks and the run record are still complete.", { accent: MUTED, section: "Section scores" });
  layout.heading("02", "Section evidence", "The complete scored passage is printed for every section, with the evidence that explains the reading. Evidence describes the reading; it did not set the score.");
  if (model.sections.length) drawSectionEvidence(layout, model);
  else layout.card("No scored passages", `${model.modelReason || "No trained model reading is available."} Nothing is inferred from the other checks to fill the gap.`, { accent: MUTED, section: "Section evidence" });
  layout.heading("03", "Characters, writing and protected facts", "These findings come from separate deterministic checks. They are evidence in their own right and they never change the AI-pattern reading.");
  layout.card("Invisible and lookalike characters", [
    `${model.axes[1].value}. ${model.axes[1].detail}`,
    model.characterFindings.length ? bullet(model.characterFindings) : "No text-integrity finding was recorded.",
    model.axes[1].limitations.length ? `LIMITS
${bullet(model.axes[1].limitations)}` : ""
  ].filter(Boolean).join("\n"), { accent: BLUE, meta: model.axes[1].statusLabel, section: "Separate findings" });
  layout.card("Writing suggestions", [
    `${model.axes[2].value}. ${model.axes[2].detail}`,
    model.writingFindings.length ? bullet(model.writingFindings) : "No editorial finding was recorded.",
    model.axes[2].limitations.length ? `LIMITS
${bullet(model.axes[2].limitations)}` : ""
  ].filter(Boolean).join("\n"), { accent: MUTED, meta: model.axes[2].statusLabel, section: "Separate findings" });
  layout.card("Facts kept safe", [
    model.protectedFacts.sentence,
    model.protectedFacts.categoriesSentence,
    "Names, organisations, figures, dates, links, quotations, citations and code are independent evidence. They never imply authorship."
  ].join("\n"), { accent: BLUE, section: "Separate findings" });
  layout.heading("04", "Content Credentials and watermarks", "File and text credentials, and public watermark-key results, are recorded separately from the AI-pattern reading. An absent credential proves nothing about how a text was written.");
  if (model.c2paText) {
    layout.card("C2PA text credential", [
      `Status: ${model.c2paText.status}.`,
      `Wrapper protected: ${model.c2paText.wrapperProtected ? "yes" : "no"}.`,
      model.c2paText.limitations.length ? `LIMITS
${bullet(model.c2paText.limitations)}` : ""
    ].filter(Boolean).join("\n"), { accent: BLUE, section: "Credentials and watermarks" });
  }
  if (model.c2paFiles.length) {
    for (const file of model.c2paFiles) {
      layout.card(file.label, [
        `Status: ${file.status}. Trust: ${file.trust}.`,
        `Media type: ${file.mediaType}`,
        `File hash: ${file.fileHash}`,
        file.limitations.length ? `LIMITS
${bullet(file.limitations)}` : ""
      ].filter(Boolean).join("\n"), { accent: BLUE, section: "Credentials and watermarks" });
    }
  } else {
    layout.card("File Content Credentials", "No file-origin result was attached to this text run. Pasted text is never given a file provenance verdict.", { accent: MUTED, section: "Credentials and watermarks" });
  }
  for (const watermark of model.watermarks) {
    layout.card(watermark.name, [
      `Outcome: ${watermark.outcome}.`,
      `Key scope: ${watermark.keyScope}.`,
      watermark.limitations.length ? `LIMITS
${bullet(watermark.limitations)}` : ""
    ].filter(Boolean).join("\n"), { accent: statusColour(watermark.status), meta: `${watermark.id}  |  ${watermark.statusLabel}`, section: "Credentials and watermarks" });
  }
  layout.heading("05", "Checks included in this run", `${model.methodsPhrase} ran. ${pluralise(model.methods.length, "It is", "Each is")} recorded with its outcome, where it ran, its version and its limitations. A check that did not run is never counted as a pass.`);
  for (const method of model.methods) {
    layout.card(method.name, [
      `Identifier: ${method.id}`,
      `Version: ${method.version}`,
      `Ran: ${method.location}`,
      `Started: ${method.startedAt}`,
      `Completed: ${method.completedAt}`,
      `Evidence: ${method.evidence}`,
      method.limitations.length ? `LIMITS
${bullet(method.limitations)}` : ""
    ].filter(Boolean).join("\n"), { accent: statusColour(method.status), meta: `${method.statusLabel}  |  ${method.location}`, section: "Checks in this run" });
  }
  layout.heading("06", "Reliability, limits and correct use", "This report records what the named checks found in one run. It does not prove authorship, guarantee that writing is human, or clear a private watermark key.");
  drawMeaningPanel(layout, model);
  layout.card("How to use this report", bullet([...model.correctUse, model.pdfCharacterNote]), { accent: ORANGE, section: "Reliability and limits" });
  layout.card("Recorded limitations", bullet([...model.limitations]), { accent: statusColour("attention"), section: "Reliability and limits" });
  if (typeof options.fullText === "string" && options.fullText.trim()) {
    layout.heading("07", "The complete checked draft", "This content-bearing appendix is written only after an explicit download action. Nothing is clipped or replaced with an ellipsis.");
    layout.card("Full submitted text", options.fullText, { accent: INK, meta: `${model.draft.wordsPhrase}  |  ${model.draft.charactersPhrase}`, section: "Complete checked draft" });
  }
  layout.heading(options.fullText ? "08" : "07", "Run record and support", "The identities below are what another person needs to reproduce and interpret this result.");
  layout.card("Run record", model.runRecord.map(([label, value]) => `${label}: ${value}`).join("\n"), { accent: INK, section: "Run record", labelledRows: true });
  layout.card("Product and support", [
    `${PRODUCT_NAME2} - ${model.strapline}`,
    model.productUrl,
    `Reported from: ${model.surfaceName}`
  ].join("\n"), { accent: ORANGE, section: "Run record" });
  drawFooters(document2, model.dateLabel);
  return document2;
}
function drawFooters(document2, dateText) {
  const total = document2.pages.length;
  document2.pages.forEach((page, index) => {
    page.line(MARGIN, 44, A4.width - MARGIN, 44, LINE, 0.55);
    page.text(`opace.agency  |  ${PRODUCT_NAME2}  |  ${dateText}`, MARGIN, 31, { weight: "regular", size: 6.6, fill: MUTED });
    const label = `Page ${index + 1} of ${total}`;
    page.text(label, A4.width - MARGIN - measureText(label, "bold", 6.6), 31, { weight: "bold", size: 6.6, fill: MUTED });
  });
}
function checkerPdfFilename(generatedAt) {
  const parsed = new Date(generatedAt);
  const stamp = Number.isNaN(parsed.getTime()) ? "undated" : parsed.toISOString().slice(0, 10);
  return `opace-ai-content-integrity-${stamp}.pdf`;
}
var PROVENANCE_STATUSES = /* @__PURE__ */ new Set(["present", "absent", "invalid", "untrusted", "error", "unsupported"]);
function buildProvenanceExport(file, result2, generatedAt = "1970-01-01T00:00:00Z") {
  if (!result2 || !PROVENANCE_STATUSES.has(result2.status) || !/^sha256:[0-9a-f]{64}$/u.test(result2.file_hash || "") || !Number.isInteger(file?.size) || file.size < 0 || file.size > 20 * 1024 * 1024) {
    throw new Error("The provenance result is not safe to export.");
  }
  return Object.freeze({
    schema_version: "oaci-provenance-report:1",
    generated_at: generatedAt,
    contains_content: false,
    product: PRODUCT_NAME2,
    file: { hash: result2.file_hash, media_type: result2.media_type, size_bytes: file.size },
    provenance: {
      status: result2.status,
      trust: result2.trust,
      reason: result2.reason,
      manifest_summary: result2.manifest_summary || null,
      issues: Array.isArray(result2.issues) ? result2.issues : [],
      limitations: Array.isArray(result2.limitations) ? result2.limitations : []
    }
  });
}
var PROVENANCE_ACCENTS = Object.freeze({
  present: GREEN,
  absent: MUTED,
  invalid: [0.639, 0.122, 0.09],
  untrusted: [0.749, 0.278, 0.02],
  error: [0.639, 0.122, 0.09],
  unsupported: MUTED
});
var PDF_CHIP_FILLS = Object.freeze([
  ...new Map(
    [...Object.values(STATUS_COLOURS), ...Object.values(PROVENANCE_ACCENTS)].map((fill) => [rgbToHex(fill), fill])
  ).values()
]);
function buildProvenancePdf(record2, options = {}) {
  return composeProvenancePdf(record2, options).build();
}
function composeProvenancePdf(record2, options = {}) {
  if (!record2?.provenance || !record2?.file) throw new Error("The provenance record is not printable.");
  const accent = PROVENANCE_ACCENTS[record2.provenance.status] ?? MUTED;
  const document2 = new PdfDocument({
    title: `${PRODUCT_NAME2} - File Content Credentials report`,
    author: "Opace Digital Agency",
    subject: "Content-free C2PA file inspection record",
    creator: PRODUCT_NAME2,
    creationDate: record2.generated_at,
    trace: options.trace === true
  });
  const hasLogo = options.logoJpegBytes ? document2.addJpeg("Logo", options.logoJpegBytes) : false;
  const layout = new ReportLayout(document2, { productName: PRODUCT_NAME2, subtitle: "File Content Credentials report", logoName: hasLogo ? "Logo" : null });
  layout.newPage("File Content Credentials");
  layout.page.text("File Content Credentials report", MARGIN, layout.y - 21, { weight: "bold", size: 22, fill: INK });
  layout.y -= 29;
  layout.page.text(`${PRODUCT_NAME2}  |  Created ${record2.generated_at}`, MARGIN, layout.y - 8, { weight: "regular", size: 8.2, fill: MUTED });
  layout.y -= 20;
  const heroHeight = 92;
  layout.ensure(heroHeight + 12);
  layout.page.roundedRect(MARGIN, layout.y - heroHeight, CONTENT_WIDTH, heroHeight, 4, INK);
  layout.page.rect(MARGIN, layout.y - heroHeight, 6, heroHeight, accent);
  layout.page.text("CREDENTIAL STATUS", MARGIN + 22, layout.y - 22, { weight: "bold", size: 6.8, fill: DIM_INK, characterSpacing: 0.9 });
  layout.page.text(humanise(record2.provenance.status), MARGIN + 22, layout.y - 48, { weight: "bold", size: 20, fill: WHITE });
  drawChip(layout.page, MARGIN + 22, layout.y - 74, `Trust: ${humanise(record2.provenance.trust)}`, accent, 7);
  wrapLines(record2.provenance.reason ?? "", "regular", 8.4, CONTENT_WIDTH - 250).slice(0, 5).forEach((line, index) => {
    layout.page.text(line, MARGIN + 250, layout.y - 30 - index * 11.2, { weight: "regular", size: 8.4, fill: LIGHT_INK });
  });
  layout.y -= heroHeight + 14;
  layout.card("The file that was inspected", [
    `File type: ${record2.file.media_type}`,
    `File size: ${record2.file.size_bytes} ${pluralise(record2.file.size_bytes, "byte")}`,
    `File hash: ${record2.file.hash}`,
    "The filename and the file bytes are deliberately absent from this report."
  ].join("\n"), { accent: BLUE, meta: "CONTENT-FREE RECORD", section: "File Content Credentials" });
  layout.card("Manifest summary", JSON.stringify(record2.provenance.manifest_summary || { recorded: false }), { accent: MUTED, section: "File Content Credentials" });
  layout.card("Validation issues", record2.provenance.issues.length ? [
    `${countPhrase(record2.provenance.issues.length, "validation issue")} ${pluralise(record2.provenance.issues.length, "was", "were")} recorded.`,
    ...record2.provenance.issues.map((item) => `- ${item.code}: ${item.explanation || "No explanation recorded"}`)
  ].join("\n") : "None recorded.", { accent, section: "File Content Credentials" });
  layout.card("Limits of this check", [
    ...record2.provenance.limitations.length ? record2.provenance.limitations.map((item) => `- ${item}`) : ["- No additional limitation was recorded."],
    "",
    "The file itself is not embedded in this report. Certificate trust lists, remote manifests and online certificate status were not fetched.",
    "Content Credentials describe how a file was made and edited. Their absence proves nothing about how a file was made."
  ].join("\n"), { accent: ORANGE, section: "File Content Credentials" });
  drawFooters(document2, record2.generated_at.slice(0, 10));
  return document2;
}
function provenancePdfFilename(generatedAt) {
  return `opace-content-credentials-${String(generatedAt).slice(0, 10)}.pdf`;
}

// src/checker-exports.ts
var level = (value) => value ? CHECKER_LEVEL_LABELS[value] ?? "Not assessed" : "Not assessed";
function buildContentFreeCheckerReceipt(result2) {
  return Object.freeze({
    schema: "opace-checker-receipt-1.0",
    result_id: result2.result_id,
    generated_at: result2.generated_at,
    contains_content: false,
    source: {
      content_hash: result2.source.content_hash,
      normalised_hash: result2.source.normalised_hash,
      content_type: result2.source.content_type,
      language: result2.source.language,
      word_count: result2.source.word_count,
      character_count: result2.source.character_count,
      section_count: result2.source.section_count
    },
    route: result2.route,
    axes: {
      ai_pattern: result2.axes.ai_pattern,
      text_integrity: { ...result2.axes.text_integrity, findings: result2.axes.text_integrity.findings.length },
      editorial: { ...result2.axes.editorial, findings: result2.axes.editorial.findings.length }
    },
    sections: result2.sections.map((item) => ({
      index: item.index,
      start_utf16: item.start_utf16,
      end_utf16: item.end_utf16,
      word_count: item.word_count,
      raw_score: item.raw_score,
      raw_margin: item.raw_margin,
      display_score: item.display_score,
      level: item.level,
      band_id: item.band_id
    })),
    methods: result2.methods.map((method) => ({
      id: method.id,
      provider_or_method: method.provider_or_method,
      version: method.version,
      status: method.status,
      privacy_route: method.privacy_route,
      started_at: method.started_at,
      completed_at: method.completed_at,
      limitations: method.limitations
    })),
    provenance: {
      protected_facts: result2.provenance.protected_facts,
      c2pa_text: result2.provenance.c2pa_text,
      c2pa_files: result2.provenance.c2pa_files,
      watermarks: result2.provenance.watermarks,
      safe_fixes: result2.provenance.safe_fixes
    },
    abuse_controls: result2.abuse_controls,
    limitations: result2.limitations
  });
}
function buildShareSummary(result2) {
  const payload = result2.exports.share.payload;
  if (!result2.exports.share.available || !payload || payload.contains_content !== false) throw new Error("This run has no content-free summary to share.");
  return `Opace AI Content Integrity: ${level(String(payload.level ?? ""))} (score ${String(payload.display_score ?? "not assessed")} on a zero-to-one pattern scale). ${String(payload.honesty_line ?? "No result proves authorship.")} Result ${String(payload.result_id ?? result2.result_id)}, ${String(payload.date ?? result2.generated_at.slice(0, 10))}.`;
}

// src/eu-service.ts
var CHROME_SERVICE_ORIGIN = "https://opace-detector-877422072168.europe-west1.run.app";
var CHROME_SERVICE_PERMISSION = `${CHROME_SERVICE_ORIGIN}/*`;
var INSTALL_KEY = "chrome_service_install_id";
var MAX_RESPONSE_BYTES = 65536;
var REQUEST_TIMEOUT_MS = 45e3;
var ChromeServiceError = class extends Error {
  constructor(message, code, retryable = false, retryAfter) {
    super(message);
    this.code = code;
    this.retryable = retryable;
    this.retryAfter = retryAfter;
    this.name = "ChromeServiceError";
  }
  code;
  retryable;
  retryAfter;
};
var randomId = (prefix) => {
  const bytes = crypto.getRandomValues(new Uint8Array(18));
  const encoded = btoa(String.fromCharCode(...bytes)).replaceAll("+", "-").replaceAll("/", "_").replaceAll("=", "");
  return `${prefix}${encoded}`;
};
var installId = async () => {
  const stored = await chrome.storage.local.get(INSTALL_KEY);
  const candidate2 = stored[INSTALL_KEY];
  if (typeof candidate2 === "string" && /^cx_[A-Za-z0-9_-]{16,64}$/u.test(candidate2)) return candidate2;
  const created = randomId("cx_");
  await chrome.storage.local.set({ [INSTALL_KEY]: created });
  return created;
};
var readBoundedJson = async (response) => {
  const declared = Number(response.headers.get("content-length"));
  if (Number.isFinite(declared) && declared > MAX_RESPONSE_BYTES) throw new ChromeServiceError("The EU service returned an oversized response.", "response_too_large");
  const reader = response.body?.getReader();
  if (!reader) return response.json();
  const chunks = [];
  let total = 0;
  for (; ; ) {
    const { done, value } = await reader.read();
    if (done) break;
    if (!value) continue;
    total += value.byteLength;
    if (total > MAX_RESPONSE_BYTES) {
      await reader.cancel().catch(() => void 0);
      throw new ChromeServiceError("The EU service returned an oversized response.", "response_too_large");
    }
    chunks.push(value);
  }
  const bytes = new Uint8Array(total);
  let offset = 0;
  for (const chunk of chunks) {
    bytes.set(chunk, offset);
    offset += chunk.byteLength;
  }
  try {
    return JSON.parse(new TextDecoder().decode(bytes));
  } catch {
    throw new ChromeServiceError("The EU service returned invalid JSON.", "bad_response");
  }
};
var post = async (path, body, signal, token) => {
  const response = await fetch(`${CHROME_SERVICE_ORIGIN}${path}`, {
    method: "POST",
    headers: { "content-type": "application/json", ...token ? { "x-opace-chrome-token": token } : {} },
    body: JSON.stringify(body),
    credentials: "omit",
    cache: "no-store",
    redirect: "error",
    referrerPolicy: "no-referrer",
    signal
  });
  const payload = await readBoundedJson(response);
  if (!response.ok) {
    const error = payload;
    throw new ChromeServiceError(
      typeof error.message === "string" ? error.message : `The EU service returned HTTP ${response.status}.`,
      typeof error.error === "string" ? error.error : "server_refused",
      error.retryable === true,
      typeof error.retry_after === "number" ? error.retry_after : void 0
    );
  }
  return payload;
};
var solveChallenge = (challenge, difficultyBits, signal, onPhase) => new Promise((resolve, reject) => {
  const worker = new Worker(new URL("./eu-pow-worker.js", import.meta.url), { type: "module" });
  const onAbort = () => finish(new DOMException("The EU service check was cancelled.", "AbortError"));
  let timer;
  const finish = (error, nonce) => {
    clearTimeout(timer);
    signal.removeEventListener("abort", onAbort);
    worker.terminate();
    if (error) reject(error);
    else resolve(nonce);
  };
  timer = setTimeout(() => finish(new ChromeServiceError("The EU service proof-of-work timed out.", "challenge_timeout")), 3e4);
  worker.onmessage = (event) => {
    if (event.data.type === "solution" && typeof event.data.nonce === "string") finish(void 0, event.data.nonce);
    else if (event.data.type === "progress") onPhase?.(`Authorising the EU route locally\u2026 ${Number(event.data.attempts).toLocaleString("en-GB")} attempts`);
    else if (event.data.type === "error") finish(new ChromeServiceError("The EU service challenge could not be solved.", event.data.code ?? "challenge_failed"));
  };
  worker.onerror = () => finish(new ChromeServiceError("The EU service authorisation worker failed safely.", "challenge_worker_failed"));
  signal.addEventListener("abort", onAbort, { once: true });
  if (signal.aborted) onAbort();
  else worker.postMessage({ challenge, difficultyBits });
});
var requestChromeServicePermission = () => chrome.permissions.request({ origins: [CHROME_SERVICE_PERMISSION] });
async function requestChromeServerScore(text2, signal, onPhase) {
  const timeout = new AbortController();
  const timer = setTimeout(() => timeout.abort(), REQUEST_TIMEOUT_MS);
  const onAbort = () => timeout.abort();
  signal?.addEventListener("abort", onAbort, { once: true });
  try {
    const extensionId = chrome.runtime.id;
    if (!/^[a-p]{32}$/u.test(extensionId)) throw new ChromeServiceError("This extension build has no valid Chrome extension identity.", "extension_identity_invalid");
    const currentInstallId = await installId();
    const requestId = randomId("req_");
    const bodyHash = prefixedSha2562(text2);
    onPhase?.("Requesting a body-bound EU service challenge\u2026");
    const challengePayload = await post("/v1/chrome/challenge", { extension_id: extensionId, install_id: currentInstallId, request_id: requestId, body_sha256: bodyHash }, timeout.signal);
    if (challengePayload.channel !== "chrome-extension-v1" || typeof challengePayload.challenge !== "string" || !Number.isInteger(challengePayload.difficulty_bits)) {
      throw new ChromeServiceError("The EU service returned an invalid challenge.", "challenge_invalid");
    }
    const nonce = await solveChallenge(challengePayload.challenge, Number(challengePayload.difficulty_bits), timeout.signal, onPhase);
    onPhase?.("Exchanging the one-use EU service challenge\u2026");
    const tokenPayload = await post("/v1/chrome/token", { challenge: challengePayload.challenge, nonce }, timeout.signal);
    if (tokenPayload.channel !== "chrome-extension-v1" || tokenPayload.header !== "x-opace-chrome-token" || typeof tokenPayload.token !== "string" || tokenPayload.max_checks !== 1) {
      throw new ChromeServiceError("The EU service returned an invalid one-use token.", "token_invalid");
    }
    onPhase?.("Scoring complete sections once in the Opace EU service\u2026");
    const response = await post("/v1/chrome/check", {
      text: text2,
      full_word_count: text2.match(/\S+/gu)?.length ?? 0,
      extension_id: extensionId,
      install_id: currentInstallId,
      request_id: requestId
    }, timeout.signal, tokenPayload.token);
    return parseCycle5ChromeServerResponse(response, text2);
  } catch (cause) {
    if (timeout.signal.aborted) {
      if (signal?.aborted) throw new DOMException("The EU service check was cancelled.", "AbortError");
      throw new ChromeServiceError("The EU service did not complete within 45 seconds.", "timeout", true);
    }
    throw cause;
  } finally {
    clearTimeout(timer);
    signal?.removeEventListener("abort", onAbort);
  }
}

// src/provenance.ts
var MAX_PROVENANCE_BYTES = 20 * 1024 * 1024;
var MIME_BY_EXTENSION = Object.freeze({
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".png": "image/png",
  ".webp": "image/webp",
  ".pdf": "application/pdf"
});
var SUPPORTED_MIME = new Set(Object.values(MIME_BY_EXTENSION));
var LIMITATIONS = Object.freeze([
  "Content Credentials describe recorded provenance; they do not prove authorship or whether AI was used.",
  "Certificate trust lists, remote manifests and online certificate status are not fetched by this local check.",
  "The selected file stays in this extension and no file bytes or filename are included in exports."
]);
var ProvenanceInspectionError = class extends Error {
  constructor(code, message) {
    super(message);
    this.code = code;
    this.name = "ProvenanceInspectionError";
  }
  code;
};
var clipped = (value, maximum = 300) => {
  const text2 = typeof value === "string" ? value.trim() : "";
  return text2 ? text2.slice(0, maximum) : null;
};
var formatFor = (file) => {
  const extension = file.name.toLowerCase().match(/\.[^.]+$/u)?.[0] ?? "";
  return MIME_BY_EXTENSION[extension] ?? (SUPPORTED_MIME.has(file.type.toLowerCase()) ? file.type.toLowerCase() : null);
};
var abortError = () => new DOMException("The local file inspection was cancelled.", "AbortError");
var throwIfAborted2 = (signal) => {
  if (signal?.aborted) throw abortError();
};
async function raceWithSignal(work, signal, onAbort) {
  if (!signal) return work;
  throwIfAborted2(signal);
  let abort;
  const stopped = new Promise((_resolve, reject) => {
    abort = () => {
      try {
        onAbort?.();
      } finally {
        reject(abortError());
      }
    };
    signal.addEventListener("abort", abort, { once: true });
  });
  try {
    return await Promise.race([work, stopped]);
  } finally {
    if (abort) signal.removeEventListener("abort", abort);
  }
}
async function digest(file) {
  const hash = await crypto.subtle.digest("SHA-256", await file.arrayBuffer());
  return [...new Uint8Array(hash)].map((byte) => byte.toString(16).padStart(2, "0")).join("");
}
var baseResult = (fileHash, file, mediaType, status, reason) => Object.freeze({
  file_hash: `sha256:${fileHash}`,
  media_type: mediaType ?? (file.type || "application/octet-stream"),
  file_size: file.size,
  status,
  trust: status === "present" ? "not_validated" : status === "untrusted" ? "untrusted" : "not_applicable",
  reason,
  issues: Object.freeze([]),
  manifest_summary: null,
  limitations: LIMITATIONS
});
function canonicalResult(fileHash, file, mediaType, store) {
  const activeLabel = clipped(store?.active_manifest);
  const manifest = activeLabel && store?.manifests && typeof store.manifests === "object" ? store.manifests[activeLabel] : null;
  if (!manifest) return baseResult(fileHash, file, mediaType, "absent", "No Content Credentials were found. Their absence is normal and proves nothing about how the file was made.");
  const collected = [];
  const seen = /* @__PURE__ */ new Set();
  const push = (status2, successOverride) => {
    const code = clipped(String(status2?.code ?? ""), 120);
    if (!code) return;
    const explanation = clipped(status2?.explanation, 500);
    const key = `${code}|${explanation ?? ""}`;
    if (seen.has(key) || collected.length >= 25) return;
    seen.add(key);
    collected.push({ code, explanation, success: typeof status2?.success === "boolean" ? status2.success : successOverride ?? null });
  };
  const active = store.validation_results?.activeManifest;
  for (const status2 of Array.isArray(active?.failure) ? active.failure : []) push(status2, false);
  for (const status2 of Array.isArray(active?.informational) ? active.informational : []) push(status2, true);
  for (const status2 of Array.isArray(store.validation_status) ? store.validation_status : []) push(status2);
  const failures = collected.filter((issue) => issue.success === false);
  const trustIssue = (issue) => /(?:untrusted|trust)/iu.test(issue.code);
  const hasUntrusted = collected.some((issue) => /untrusted/iu.test(issue.code));
  const hasNonTrustFailure = failures.some((issue) => !trustIssue(issue));
  const invalidState = String(store.validation_state ?? "").toLowerCase() === "invalid";
  const status = hasNonTrustFailure || invalidState && !hasUntrusted ? "invalid" : hasUntrusted ? "untrusted" : "present";
  const signature = manifest.signature_info ?? {};
  const generator = manifest.claim_generator_info?.[0];
  return Object.freeze({
    ...baseResult(fileHash, file, mediaType, status, status === "invalid" ? "Content Credentials are present, but local signature or manifest validation reported a problem." : status === "untrusted" ? "Content Credentials are present, but the signer was not established as trusted. No trust list was fetched." : "Content Credentials are present and the signature validated locally. Certificate trust was not checked."),
    issues: Object.freeze(collected),
    manifest_summary: Object.freeze({
      claim_generator: clipped(generator ? [generator.name, generator.version].filter(Boolean).join(" ") : manifest.claim_generator, 200),
      signer: clipped(signature.issuer ?? signature.common_name, 200),
      signed_on: clipped(signature.time, 100),
      assertions_count: Math.min(1e4, Math.max(0, Number(manifest.assertions?.length ?? 0))),
      ingredients_count: Math.min(1e4, Math.max(0, Number(manifest.ingredients?.length ?? 0))),
      validation_state: clipped(store.validation_state, 100)
    })
  });
}
function createProvenanceInspector() {
  let sdk = null;
  let sdkPromise = null;
  const dispose = () => {
    try {
      sdk?.dispose?.();
    } finally {
      sdk = null;
      sdkPromise = null;
    }
  };
  const load = (signal) => {
    if (!sdkPromise) {
      sdkPromise = (async () => {
        const moduleUrl = chrome.runtime.getURL("runtime/c2pa/index.js");
        const wasmUrl = chrome.runtime.getURL("runtime/c2pa/c2pa_bg.wasm");
        const [runtime, response] = await Promise.all([import(moduleUrl), fetch(wasmUrl, { cache: "force-cache", signal })]);
        if (!response.ok) throw new Error("The packaged Content Credentials runtime could not be loaded.");
        const wasm = await WebAssembly.compile(await response.arrayBuffer());
        throwIfAborted2(signal);
        sdk = await runtime.createC2pa({
          wasmSrc: wasm,
          settings: { verify: { remoteManifestFetch: false, ocspFetch: false, verifyTrust: false, verifyTimestampTrust: false } }
        });
        return sdk;
      })().catch((error) => {
        sdkPromise = null;
        throw error;
      });
    }
    return raceWithSignal(sdkPromise, signal, dispose);
  };
  const inspect = async (file, signal) => {
    throwIfAborted2(signal);
    if (file.size > MAX_PROVENANCE_BYTES) throw new ProvenanceInspectionError("file_too_large", "Choose a file no larger than 20 MB.");
    const mediaType = formatFor(file);
    const fileHash = await raceWithSignal(digest(file), signal);
    if (!mediaType) return baseResult(fileHash, file, null, "unsupported", "This release inspects JPEG, PNG, WebP and PDF files only.");
    let reader = null;
    try {
      const activeSdk = await load(signal);
      reader = await raceWithSignal(activeSdk.reader.fromBlob(mediaType, file), signal, dispose);
      if (!reader) return baseResult(fileHash, file, mediaType, "absent", "No Content Credentials were found. Their absence is normal and proves nothing about how the file was made.");
      return canonicalResult(fileHash, file, mediaType, await raceWithSignal(reader.manifestStore(), signal, dispose));
    } catch (error) {
      if (error.name === "AbortError") throw error;
      const message = String(error.message ?? error);
      const invalid = /(?:UnknownAlgorithm|Invalid.*(?:claim|manifest|signature)|C2pa\((?:BadParam|ClaimVerification|Jumbf|Signature))/iu.test(message);
      return baseResult(fileHash, file, mediaType, invalid ? "invalid" : "error", invalid ? "The file contains Content Credentials that the local validator could not validate." : "The local Content Credentials check could not complete. No judgement was made.");
    } finally {
      try {
        await reader?.free?.();
      } catch {
      }
    }
  };
  return Object.freeze({ inspect, dispose });
}

// ../shared/types.ts
var MAX_TEXT_LENGTH = 5e4;
var DEFAULT_SETTINGS = Object.freeze({
  receiptHistory: false,
  highContrast: false
});
var sourceLabel = (capture2) => {
  if (capture2.kind === "paste") return "Pasted text";
  const noun = capture2.kind === "selection" ? "Selected text" : "Visible article text";
  return `${noun} from ${capture2.host || "this page"}`;
};
var validateCapture = (capture2) => {
  if (!capture2.text.trim()) return capture2.kind === "selection" ? "Select at least one sentence, or choose Check this article." : "Paste or capture some text before inspection.";
  if (capture2.text.length > MAX_TEXT_LENGTH) {
    return `This text is ${capture2.text.length.toLocaleString("en-GB")} characters. The local browser limit is ${MAX_TEXT_LENGTH.toLocaleString("en-GB")}; choose or paste a smaller scope. Nothing was truncated.`;
  }
  for (let index = 0; index < capture2.text.length; index += 1) {
    const current = capture2.text.charCodeAt(index);
    if (current >= 55296 && current <= 56319) {
      const next = capture2.text.charCodeAt(index + 1);
      if (!(next >= 56320 && next <= 57343)) return "The text contains an unpaired Unicode surrogate and cannot be inspected safely.";
      index += 1;
    } else if (current >= 56320 && current <= 57343) {
      return "The text contains an unpaired Unicode surrogate and cannot be inspected safely.";
    }
  }
  return null;
};

// ../shared/eu-allowance.mjs
var EU_ALLOWANCE = Object.freeze({
  perMinute: 3,
  perHour: 20,
  minuteWindowMs: 6e4,
  hourWindowMs: 36e5,
  /** The service's own daily ceiling across every caller, quoted for honesty. */
  serviceDailySegmentInferences: 12e3,
  maxCharacters: 5e4
});
var HOUR_KEEP = EU_ALLOWANCE.hourWindowMs;
var timestamps = (state) => Array.isArray(state?.requests) ? state.requests.filter((value) => Number.isFinite(value)) : [];
function pruneEuAllowance(state, now) {
  return { requests: timestamps(state).filter((value) => now - value < HOUR_KEEP).sort((a, b) => a - b) };
}
function evaluateEuAllowance(state, now) {
  const pruned = pruneEuAllowance(state, now).requests;
  const inMinute = pruned.filter((value) => now - value < EU_ALLOWANCE.minuteWindowMs);
  const inHour = pruned;
  const waitFor = (oldest, window) => Math.max(1, Math.ceil((window - (now - oldest)) / 1e3));
  if (inMinute.length >= EU_ALLOWANCE.perMinute) {
    return {
      allowed: false,
      scope: "minute",
      retryAfterSeconds: waitFor(inMinute[0], EU_ALLOWANCE.minuteWindowMs),
      remainingMinute: 0,
      remainingHour: Math.max(0, EU_ALLOWANCE.perHour - inHour.length)
    };
  }
  if (inHour.length >= EU_ALLOWANCE.perHour) {
    return {
      allowed: false,
      scope: "hour",
      retryAfterSeconds: waitFor(inHour[0], EU_ALLOWANCE.hourWindowMs),
      remainingMinute: Math.max(0, EU_ALLOWANCE.perMinute - inMinute.length),
      remainingHour: 0
    };
  }
  return {
    allowed: true,
    scope: null,
    retryAfterSeconds: 0,
    remainingMinute: EU_ALLOWANCE.perMinute - inMinute.length,
    remainingHour: EU_ALLOWANCE.perHour - inHour.length
  };
}
function recordEuAllowance(state, now) {
  const pruned = pruneEuAllowance(state, now).requests;
  return { requests: [...pruned, now].slice(-EU_ALLOWANCE.perHour * 2) };
}
function describeWait(seconds) {
  if (seconds <= 1) return "in a moment";
  if (seconds < 60) return `in about ${seconds} seconds`;
  const minutes = Math.ceil(seconds / 60);
  return minutes === 1 ? "in about a minute" : `in about ${minutes} minutes`;
}
function euAllowanceNotice(decision) {
  const when = describeWait(decision.retryAfterSeconds);
  const window = decision.scope === "minute" ? `${EU_ALLOWANCE.perMinute} checks a minute` : `${EU_ALLOWANCE.perHour} checks an hour`;
  return {
    title: "You have reached this install's pace for the EU route",
    body: `To keep the shared service fair, each installation sends at most ${window} to Opace's EU server. Nothing was sent. You can try the EU route again ${when} \u2014 or run the full check on this device now, which has no limit and never sends your text.`
  };
}

// ../shared/storage.ts
var SETTINGS_KEY = "settings";
var EU_ALLOWANCE_KEY = "eu_allowance";
var loadSettings = async () => {
  const stored = await chrome.storage.local.get(SETTINGS_KEY);
  const candidate2 = stored[SETTINGS_KEY];
  return {
    receiptHistory: false,
    highContrast: candidate2?.highContrast === true
  };
};
var saveSettings = async (settings) => {
  await chrome.storage.local.set({ [SETTINGS_KEY]: { ...settings, receiptHistory: false } });
};
var loadEuAllowance = async (now = Date.now()) => {
  const stored = await chrome.storage.local.get(EU_ALLOWANCE_KEY);
  return pruneEuAllowance(stored[EU_ALLOWANCE_KEY], now);
};
var noteEuRequest = async (now = Date.now()) => {
  const next = recordEuAllowance(await loadEuAllowance(now), now);
  await chrome.storage.local.set({ [EU_ALLOWANCE_KEY]: next });
  return next;
};
var clearAllExtensionData = async () => {
  const [local, session] = await Promise.all([
    chrome.storage.local.get(null),
    chrome.storage.session.get(null)
  ]);
  await Promise.all([chrome.storage.local.clear(), chrome.storage.session.clear()]);
  return { local: Object.keys(local).length, session: Object.keys(session).length };
};

// src/panel.ts
var modelBase = "" ? "" : CYCLE5_MODEL_BASE;
var modelBaseIsShipped = modelBase === CYCLE5_MODEL_BASE;
var app = document.querySelector("#app");
var live = document.querySelector("#live");
var steps = ["Capture", "Inspect", "Protect", "Improve", "Compare", "Export"];
var escapeHtml2 = escapeResultHtml;
var capture = null;
var result = null;
var checkerResult = null;
var mounted = null;
var route = "cycle5";
var captureMode = "paste";
var notice = null;
var candidate = "";
var receipt = null;
var abortController = null;
var provenanceResult = null;
var provenanceFile = null;
var provenanceNotice = "";
var euRemaining = "";
var modelRuntime = createCycle5BrowserRuntime({
  modelBaseUrl: modelBase,
  allowedModelBaseUrls: [.../* @__PURE__ */ new Set([CYCLE5_MODEL_BASE, modelBase])],
  wasmUrl: chrome.runtime.getURL("runtime/ort-wasm-simd-threaded.wasm")
});
var provenanceInspector = createProvenanceInspector();
var logoUrl = chrome.runtime.getURL("assets/icon-128.png");
var SURFACE = "Chrome extension";
var announce = (message) => {
  live.textContent = "";
  requestAnimationFrame(() => {
    live.textContent = message;
  });
};
var rail = (active) => `<nav class="rail" aria-label="Where you are"><ol>${steps.map((step, index) => `<li ${index === active ? 'aria-current="step"' : index < active ? 'data-state="done"' : ""}><span>${step}</span></li>`).join("")}</ol></nav>`;
var shell = (active, body) => {
  mounted?.destroy();
  mounted = null;
  app.innerHTML = `${rail(active)}<main tabindex="-1"><div class="sheet">${body}</div></main>`;
  app.querySelector("main")?.focus({ preventScroll: true });
};
var noticeHtml = () => notice ? `<div class="notice ${notice.tone}" role="status"><b>${escapeHtml2(notice.title)}</b><p>${escapeHtml2(notice.body)}</p></div>` : "";
var saveFile = (bytes, name, type, spoken) => {
  const url = URL.createObjectURL(new Blob([bytes], { type }));
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = name;
  anchor.click();
  setTimeout(() => URL.revokeObjectURL(url), 1e4);
  announce(spoken);
};
var preview = (text2) => escapeHtml2(text2.slice(0, 1200)) + (text2.length > 1200 ? "\u2026" : "");
var icon = (name) => {
  const paths = {
    article: '<path d="M4 4h16v16H4z"/><path d="M8 9h8M8 13h8M8 17h5"/>',
    selection: '<path d="M4 6V4h4M20 6V4h-4M4 18v2h4M20 18v2h-4"/><path d="M8 10h8M8 14h5"/>',
    paste: '<path d="M9 4h6v3H9z"/><path d="M7 6H5v14h14V6h-2"/><path d="M9 12h6M9 16h4"/>'
  };
  return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[name]}</svg>`;
};
var refreshEuAllowance = async () => {
  const decision = evaluateEuAllowance(await loadEuAllowance(), Date.now());
  euRemaining = decision.allowed ? `You have ${decision.remainingMinute} of ${EU_ALLOWANCE.perMinute} checks left this minute and ${decision.remainingHour} of ${EU_ALLOWANCE.perHour} this hour on this installation.` : "This installation has used its EU checks for now. The full check on this device has no limit.";
};
var renderCapture = () => {
  const isPaste = capture?.kind === "paste" || !capture;
  const text2 = capture?.text ?? "";
  const editable = isPaste;
  const displayText = !editable && text2.length > MAX_TEXT_LENGTH ? text2.slice(0, MAX_TEXT_LENGTH) : text2;
  const limitation = capture?.limitations[0] ?? "";
  captureMode = capture?.kind === "article" ? "article" : capture?.kind === "selection" ? "selection" : "paste";
  shell(0, `<p class="eyebrow">Step 1 of 6</p><h1>Choose the text to check</h1>
    <p class="lede">Nothing runs until you say so, and nothing leaves this browser unless you pick the server route.</p>
    ${noticeHtml()}
    ${limitation ? `<div class="notice attention" role="status"><b>We could not read that page</b><p>${escapeHtml2(limitation)}</p></div>` : ""}
    <section class="card">
      <div class="tabs" role="tablist" aria-label="Where the text comes from">
        <button type="button" role="tab" data-mode="article" aria-selected="${captureMode === "article"}">${icon("article")}<b>This page</b><small>Visible article text</small></button>
        <button type="button" role="tab" data-mode="selection" aria-selected="${captureMode === "selection"}">${icon("selection")}<b>Selection</b><small>Only what you highlight</small></button>
        <button type="button" role="tab" data-mode="paste" aria-selected="${captureMode === "paste"}">${icon("paste")}<b>Paste</b><small>No page access</small></button>
      </div>
      <label for="source">${escapeHtml2(capture && !isPaste ? sourceLabel(capture) : "Paste or edit the text")}</label>
      <textarea id="source" ${editable ? "" : "readonly"} maxlength="250001" aria-describedby="count privacy">${escapeHtml2(displayText)}</textarea>
      <p class="meta"><span id="count">${text2.length.toLocaleString("en-GB")} of ${MAX_TEXT_LENGTH.toLocaleString("en-GB")} characters</span><span id="privacy">Held in memory only</span></p>
      <div id="capture-error" class="notice error" role="alert" tabindex="-1" hidden></div>
    </section>
    <section class="card">
      <fieldset class="routes"><legend>How would you like it checked?</legend>
        <label class="route"><input type="radio" name="checker-route" value="cycle5" ${route === "cycle5" ? "checked" : ""}><b>On this device<em>Recommended</em></b><span>The full Opace model runs here in your browser. Your draft stays here and is not sent for scoring. There is no limit on how often you can use it, and no queue to wait in. Up to ${MAX_TEXT_LENGTH.toLocaleString("en-GB")} characters a check.</span></label>
        <label class="route"><input type="radio" name="checker-route" value="eu-server" ${route === "eu-server" ? "checked" : ""}><b>Private EU analysis<em data-tone="held">Not available yet</em></b><span>Your text goes once to Opace's server in Belgium, scored in memory, kept nowhere. Chrome asks permission for that address first. The shared server is paced: ${MAX_TEXT_LENGTH.toLocaleString("en-GB")} characters a check, ${EU_ALLOWANCE.perMinute} checks a minute and ${EU_ALLOWANCE.perHour} an hour from this installation, within ${EU_ALLOWANCE.serviceDailySegmentInferences.toLocaleString("en-GB")} section readings a day service-wide. It replies only to this extension, after a small piece of work from your browser, so automated traffic stays out. Not switched on yet, and it says so plainly.</span></label>
        <label class="route"><input type="radio" name="checker-route" value="deterministic" ${route === "deterministic" ? "checked" : ""}><b>Quick checks only</b><span>Hidden characters and writing suggestions, with no trained model. The AI reading stays Not assessed. No limit and no network.</span></label>
      </fieldset>
      <label class="consent" data-consent="cycle5"><input id="model-consent" type="checkbox"><span><b>Download the model to this device</b>${escapeHtml2(CYCLE5_MODEL_DOWNLOAD_LABEL)} of model weights and a word list. These are data files, not a program: the software that reads them is already inside the extension and nothing new is executed. They come from opace.agency, and their exact size and SHA-256 fingerprint (starting ${escapeHtml2(CYCLE5_MODEL_SHA256.slice(0, 8))}) are checked before anything is loaded \u2014 a file that does not match is thrown away. They are downloaded once, kept in this browser's cache, and removed in one click with <b>Clear everything stored</b>. Your draft is not uploaded.</span></label>
      <label class="consent" data-consent="eu-server" hidden><input id="server-consent" type="checkbox"><span><b>Send this text to the EU server once</b>It is scored in memory in Belgium and discarded straight afterwards. Chrome will ask you to allow the exact address ${escapeHtml2(CHROME_SERVICE_PERMISSION)} before anything is sent. <span data-eu-remaining>${escapeHtml2(euRemaining)}</span></span></label>
      ${modelBaseIsShipped ? "" : '<div class="notice attention" role="status"><b>Test build</b><p>Model files are being read from a local mirror instead of the shipped Opace address. This build is for testing only.</p></div>'}
      <div class="actions"><button type="button" class="primary" id="inspect">Check this text</button><button type="button" id="clear-capture">Start again</button></div>
    </section>`);
  notice = null;
  const input = app.querySelector("#source");
  const count = app.querySelector("#count");
  const errorBox = app.querySelector("#capture-error");
  const updateRouteControls = () => {
    const selected = app.querySelector('input[name="checker-route"]:checked')?.value ?? "cycle5";
    for (const control of app.querySelectorAll("[data-consent]")) control.hidden = control.dataset.consent !== selected;
  };
  const clearValidationError = () => {
    input.removeAttribute("aria-invalid");
    input.setAttribute("aria-describedby", "count privacy");
    errorBox.hidden = true;
    errorBox.textContent = "";
  };
  const fail = (message) => {
    input.setAttribute("aria-invalid", "true");
    input.setAttribute("aria-describedby", "count privacy capture-error");
    errorBox.hidden = false;
    errorBox.innerHTML = `<b>Nothing has run</b><p>${escapeHtml2(message)}</p>`;
    errorBox.focus();
  };
  input.addEventListener("input", () => {
    count.textContent = `${input.value.length.toLocaleString("en-GB")} of ${MAX_TEXT_LENGTH.toLocaleString("en-GB")} characters`;
    clearValidationError();
  });
  for (const tab of app.querySelectorAll(".tabs button")) {
    tab.addEventListener("click", () => void startCapture(tab.dataset.mode));
  }
  for (const control of app.querySelectorAll('input[name="checker-route"]')) {
    control.addEventListener("change", () => {
      updateRouteControls();
      if (control.value === "eu-server" && control.checked) {
        void refreshEuAllowance().then(() => {
          const target = app.querySelector('[data-consent="eu-server"] span');
          const line = target?.querySelector("[data-eu-remaining]");
          if (line) line.textContent = euRemaining;
        });
      }
    });
  }
  app.querySelector("#clear-capture")?.addEventListener("click", () => {
    capture = { kind: "paste", text: "", host: "", title: "Pasted text", limitations: [] };
    result = null;
    checkerResult = null;
    renderCapture();
  });
  app.querySelector("#inspect")?.addEventListener("click", () => {
    const selected = app.querySelector('input[name="checker-route"]:checked')?.value;
    route = selected === "deterministic" ? "deterministic" : selected === "eu-server" ? "eu-server" : "cycle5";
    if (route === "cycle5" && !(app.querySelector("#model-consent")?.checked ?? false)) {
      fail("Tick the download box to run the full check on this device, or choose quick checks only.");
      return;
    }
    if (route === "eu-server" && !(app.querySelector("#server-consent")?.checked ?? false)) {
      fail("Tick the box to send this text to the EU server, or choose one of the on-device options.");
      return;
    }
    capture = { ...capture ?? { kind: "paste", host: "", title: "Pasted text", limitations: [] }, text: input.readOnly ? text2 : input.value };
    const error = validateCapture(capture);
    if (error) {
      fail(error);
      return;
    }
    clearValidationError();
    if (route === "eu-server") {
      void loadEuAllowance().then((state) => {
        const decision = evaluateEuAllowance(state, Date.now());
        if (!decision.allowed) {
          const { title, body } = euAllowanceNotice(decision);
          fail(`${title}. ${body}`);
          return void 0;
        }
        return requestChromeServicePermission().then(async (granted) => {
          if (!granted) {
            fail("Chrome did not allow the Opace EU address. Nothing was sent \u2014 the on-device check is still available.");
            return void 0;
          }
          await noteEuRequest();
          return inspectCapture();
        });
      }).catch(() => fail("Chrome could not ask for the Opace EU address. Nothing was sent \u2014 the on-device check is still available."));
      return;
    }
    void inspectCapture();
  });
  updateRouteControls();
};
var startCapture = async (mode) => {
  if (mode === "paste") {
    capture = { kind: "paste", text: capture?.kind === "paste" ? capture.text : "", host: "", title: "Pasted text", limitations: [] };
    renderCapture();
    app.querySelector("#source")?.focus();
    return;
  }
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (typeof tab?.id !== "number") {
    notice = { tone: "attention", title: "No page is open", body: "Open a page in this window, or paste the text instead." };
    renderCapture();
    return;
  }
  await chrome.runtime.sendMessage({ type: "START_CAPTURE", tabId: tab.id, kind: mode });
  const pending = await new Promise((resolve) => {
    setTimeout(() => {
      void chrome.runtime.sendMessage({ type: "GET_PENDING" }).then(resolve).catch(() => resolve(void 0));
    }, 320);
  });
  if (pending?.capture) capture = pending.capture;
  else notice = { tone: "attention", title: "Nothing came back", body: "Chrome did not return any text from that page. Paste the text instead." };
  renderCapture();
};
var routeStrapline = () => route === "eu-server" ? "Private EU analysis \xB7 sent once, kept nowhere" : route === "cycle5" ? "On this device \xB7 only model files are fetched" : "On this device \xB7 nothing is fetched";
var friendlyModelFailure = (code, reason) => {
  switch (code) {
    case "too_short":
      return { title: "That is too short to score", body: "The model needs a few paragraphs to read a pattern. Add more text, or read the quick checks below." };
    case "too_long":
      return { title: "That is longer than we can score", body: reason };
    case "offline":
      return { title: "You appear to be offline", body: "The model files could not be fetched. Reconnect and try again \u2014 nothing was sent anywhere." };
    case "integrity_error":
      return { title: "The model files did not match", body: "The downloaded files failed their fingerprint check, so nothing was loaded. Clear the saved model in Export and try again." };
    case "consent_required":
      return { title: "The download was not agreed", body: "Tick the download box on the previous step to run the full check on this device." };
    case "cancelled":
      return { title: "Check cancelled", body: "Nothing was kept." };
    default:
      return { title: "The model did not run", body: `${reason} The quick checks below still ran, and the AI reading stays Not assessed.` };
  }
};
var inspectCapture = async () => {
  if (!capture) return;
  abortController?.abort();
  abortController = new AbortController();
  shell(1, `<p class="eyebrow">${escapeHtml2(routeStrapline())}</p><h1>Reading your text</h1>
    <section class="card"><div class="progress" aria-hidden="true"><i></i></div><p class="phase" id="phase" role="status">Checking what you gave us\u2026</p>
    <div class="actions"><button type="button" id="cancel">Stop and keep nothing</button></div></section>`);
  const phaseText = (message) => {
    const target = app.querySelector("#phase");
    if (target) target.textContent = message;
  };
  app.querySelector("#cancel")?.addEventListener("click", () => abortController?.abort());
  const worker = createInspectionWorker({ workerUrl: new URL("./worker.js", import.meta.url) });
  try {
    checkerResult = null;
    notice = null;
    result = await worker.inspect({
      schema_version: "1.0",
      contract_version: "1.0.0",
      request_id: `ext_${Date.now()}`,
      created_at: (/* @__PURE__ */ new Date()).toISOString(),
      source: { content: capture.text, content_type: "plain_text", language: "en-GB" },
      checks: ["unicode.invisible", "style.patterns", "watermark.anthropic"],
      privacy: { allowed_routes: ["browser"], save_receipt: false, retain_content: false },
      context: { caller: "chrome-extension", correlation_id: "private-session" }
    }, {
      signal: abortController.signal,
      onProgress: (phase) => phaseText(`${String(phase).replaceAll("_", " ")}\u2026`)
    });
    const primitive = adaptLegacyAnalysisResult(result, { surface: SURFACE, characterCount: capture.text.length, maxCharacters: MAX_TEXT_LENGTH, refuseNotTruncate: true });
    checkerResult = primitive;
    if (route === "cycle5") {
      try {
        phaseText("Looking for the model already saved here\u2026");
        const cached = await modelRuntime.prepareFromCache(abortController.signal);
        if (!cached) {
          await modelRuntime.prepareWithConsent({
            consent: true,
            signal: abortController.signal,
            onProgress: (progress) => phaseText(`Downloading and checking file ${progress.fileIndex} of ${progress.fileCount} \u2014 ${(progress.receivedBytes / 1e6).toFixed(1)} of ${(progress.totalBytes / 1e6).toFixed(1)} MB`)
          });
        }
        phaseText("Reading each section on this device\u2026");
        const score = await modelRuntime.score(capture.text, {
          signal: abortController.signal,
          onSection: (done, total) => phaseText(`Reading section ${done} of ${total} on this device\u2026`)
        });
        if (score.status === "scored") {
          checkerResult = composeCycle5BrowserCheckerResult(primitive, score, capture.text, {
            surface: SURFACE,
            resultId: `chrome_cycle5_${Date.now()}`,
            reportFormat: "pdf",
            maxCharacters: MAX_TEXT_LENGTH
          });
        } else {
          notice = { tone: "attention", ...friendlyModelFailure(score.code, score.reason) };
        }
      } catch (error) {
        if (error.name === "AbortError" || abortController.signal.aborted) throw error;
        const code = error.code ?? "engine_error";
        notice = { tone: "attention", ...friendlyModelFailure(code, error.message) };
      }
    } else if (route === "eu-server") {
      try {
        const score = await requestChromeServerScore(capture.text, abortController.signal, phaseText);
        checkerResult = composeCycle5ServerCheckerResult(primitive, score, capture.text, {
          surface: SURFACE,
          resultId: `chrome_server_${Date.now()}`,
          reportFormat: "pdf",
          maxCharacters: MAX_TEXT_LENGTH,
          maxWords: 8e3
        });
      } catch (error) {
        if (error.name === "AbortError" || abortController.signal.aborted) throw error;
        notice = {
          tone: "attention",
          title: "The EU service is not available yet",
          body: `${error.message} No text was kept. The full check on this device is still available, and the quick checks below already ran.`
        };
      }
    }
    renderResults();
    announce("The check has finished. Your result is ready.");
  } catch (error) {
    if (error.name === "AbortError" || abortController.signal.aborted || error.code === "cancelled") {
      shell(1, `<p class="eyebrow">Stopped</p><h1>Check cancelled</h1>
        <section class="card"><p class="lede">Nothing was kept: no result, no copy of your text.</p>
        <div class="actions"><button type="button" class="primary" id="return">Back to the text</button></div></section>`);
      app.querySelector("#return")?.addEventListener("click", () => renderCapture());
      announce("Check cancelled.");
    } else {
      notice = { tone: "error", title: "The check stopped safely", body: error.message };
      renderCapture();
    }
  } finally {
    worker.dispose();
    abortController = null;
  }
};
var renderResults = () => {
  if (!result || !capture || !checkerResult) return;
  shell(1, `<p class="eyebrow">Evidence, not guarantees</p><h1>Your result</h1>
    ${noticeHtml()}
    <div id="result-slot"></div>`);
  notice = null;
  const slot = app.querySelector("#result-slot");
  mounted = mount(slot, checkerResult, {
    surface: SURFACE,
    logoDataUri: logoUrl,
    headingLevel: 2,
    actions: [
      { id: "protect", label: "Protect the facts", glyph: "\u{1F512}" },
      { id: "export", label: "Save or share", glyph: "\u2B73" },
      { id: "restart", label: "Check something else", glyph: "\u21BA" }
    ],
    onAction: (actionId) => {
      if (actionId === "protect") renderProtect();
      else if (actionId === "export") void renderExport();
      else renderCapture();
    },
    onToggleSection: (sectionIndex, expanded) => {
      if (expanded) announce(`Section ${sectionIndex + 1} opened.`);
    }
  });
};
var renderProtect = () => {
  if (!result) return;
  const spans = result.protected_spans;
  shell(2, `<p class="eyebrow">Step 3 of 6</p><h1>Facts we will not touch</h1>
    <p class="lede">Names, figures, dates, links, quotations, citations and code are locked before anything is suggested.</p>
    <section class="card">
      <p>${spans.length} ${spans.length === 1 ? "item is" : "items are"} locked.</p>
      <ul class="facts">${spans.slice(0, 12).map((span) => `<li><b>${escapeHtml2(String(span.kind).replaceAll("_", " "))}</b><span>characters ${span.start_utf16}\u2013${span.end_utf16}</span></li>`).join("") || "<li>Nothing in this draft needed locking.</li>"}</ul>
      ${spans.length > 12 ? `<p class="fine">${spans.length - 12} more are locked and not listed here.</p>` : ""}
    </section>
    <div class="actions"><button type="button" class="primary" id="improve">See suggested changes</button><button type="button" id="results">Back to the result</button></div>`);
  app.querySelector("#results")?.addEventListener("click", renderResults);
  app.querySelector("#improve")?.addEventListener("click", renderImprove);
};
var renderImprove = () => {
  if (!result || !capture) return;
  const unicodeEvidence = result.methods.flatMap((method) => method.evidence).filter((item) => item?.type === "unicode_finding");
  const selected = unicodeEvidence.filter((item) => item.fix !== "review").map((item) => item.id);
  const fix = previewSafeFixes(capture.text, unicodeEvidence, selected, result.protected_spans);
  candidate = fix.candidate;
  const changed = fix.applied_finding_ids.length > 0;
  shell(3, `<p class="eyebrow">Step 4 of 6</p><h1>${changed ? "A cleaned-up copy is ready" : "No automatic change to suggest"}</h1>
    <section class="card">
      <p class="lede">${changed ? `${fix.applied_finding_ids.length} character ${fix.applied_finding_ids.length === 1 ? "problem was" : "problems were"} tidied outside the locked facts. Your original is untouched \u2014 this is a copy for you to review.` : "The browser checks found nothing safe to change on their own. Your original text stays as the copyable version."}</p>
      <div class="notice"><b>Look-alike characters are never swapped for you</b><p>Homoglyph replacements always need your decision, so they are shown rather than applied.</p></div>
    </section>
    <div class="actions"><button type="button" class="primary" id="compare">Compare the two</button><button type="button" id="protect-back">Back</button></div>`);
  app.querySelector("#protect-back")?.addEventListener("click", renderProtect);
  app.querySelector("#compare")?.addEventListener("click", renderCompare);
};
var renderCompare = () => {
  if (!result || !capture) return;
  const gates = validateCandidate({ content: capture.text, content_hash: result.source.content_hash, content_type: "plain_text", language: "en-GB" }, candidate, result.protected_spans, { expected_source_hash: result.source.content_hash });
  const blocking = gates.filter((gate) => gate.hard && gate.status !== "pass" && gate.id !== "semantic_entailment");
  shell(4, `<p class="eyebrow">Step 5 of 6</p><h1>Compare before you copy</h1>
    <div class="rails">
      <section><h2>Your original</h2><pre>${preview(capture.text)}</pre></section>
      <section><h2>Suggested copy</h2><pre>${preview(candidate)}</pre></section>
    </div>
    <p class="gate ${blocking.length ? "fail" : "pass"}"><b>${blocking.length ? "Held back" : "Safe to copy"}</b> \u2014 ${gates.length} checks ran on the copy. Meaning-matching is not set up in the browser and is reported as such.</p>
    <div id="copy-fallback" hidden><label for="fallback">Your browser blocked the clipboard. Select all and copy:</label><textarea id="fallback" readonly>${escapeHtml2(candidate)}</textarea></div>
    <div class="actions"><button type="button" class="primary" id="copy" ${blocking.length ? "disabled" : ""}>Copy the suggested text</button><button type="button" id="export">Save or share</button><button type="button" id="improve-back">Back</button></div>`);
  app.querySelector("#improve-back")?.addEventListener("click", renderImprove);
  app.querySelector("#copy")?.addEventListener("click", async () => {
    try {
      await navigator.clipboard.writeText(candidate);
      announce("Copied. The page you were on was not changed.");
    } catch {
      const fallback = app.querySelector("#copy-fallback");
      fallback.hidden = false;
      app.querySelector("#fallback")?.focus();
      announce("The clipboard was blocked. A read-only copy box is ready.");
    }
  });
  app.querySelector("#export")?.addEventListener("click", () => void renderExport(gates));
};
var reportOptions = () => ({
  surfaceName: SURFACE,
  sourceText: capture?.text,
  generatedAt: checkerResult?.generated_at
});
var renderExport = async (gates) => {
  if (!result || !capture) return;
  receipt = await buildReceipt({
    receipt_id: `ext_receipt_${Date.now()}`,
    product_version: "1.1.0",
    created_at: (/* @__PURE__ */ new Date()).toISOString(),
    source: { content: capture.text, content_type: "plain_text", language: "en-GB", normalised_text: capture.text.normalize("NFC") },
    policy: { id: "extension-browser", version: "1.1.0", requested_checks: result.methods.map((method) => method.id), allowed_routes: ["browser"], retain_content: false },
    methods: result.methods,
    rewrite: candidate && candidate !== capture.text ? { source_hash: result.source.content_hash, candidate_hash: prefixedSha2562(candidate), generator: { route: "browser", provider: "Opace deterministic core", model: "none", prompt_template: "safe-unicode-preview" }, gates: gates ?? [], selected_candidate: "candidate_1", candidate_content: candidate } : null,
    approval: { scope: "none" },
    limitations: ["This receipt holds hashes and check states only. It contains no web address and no text, and it does not prove human authorship."],
    contains_content: false
  });
  const full = checkerResult?.profile === "full_checker";
  const shareable = Boolean(checkerResult?.exports.share.available);
  shell(5, `<p class="eyebrow">Step 6 of 6</p><h1>Save or share the evidence</h1>
    <p class="lede">Everything except the full report is content-free: hashes, check states and limits, never your words.</p>
    ${noticeHtml()}
    <section class="card">
      <h2>Files you can keep</h2>
      <div class="exports">
        <button type="button" class="primary" id="download-pdf" ${full ? "" : "disabled"}>Branded PDF report</button>
        <button type="button" id="download-html" ${full ? "" : "disabled"}>Complete HTML report</button>
        <button type="button" id="download-result-json" ${full ? "" : "disabled"}>Result receipt (JSON, content-free)</button>
        <button type="button" id="download-receipt">Check receipt (JSON, content-free)</button>
      </div>
      ${full ? '<p class="fine">The PDF and HTML reports include the passages that were scored, because that is the evidence. Everything else here is content-free.</p>' : '<p class="fine">Reports need a model reading. This run has quick checks only, so only the content-free check receipt is available.</p>'}
    </section>
    <section class="card">
      <h2>Share the reading, not the draft</h2>
      <p class="fine" style="margin-top:0">A one-line summary with the level, the score and the honesty line. No part of your text travels with it.</p>
      <div class="actions"><button type="button" id="copy-share" ${shareable ? "" : "disabled"}>Copy share summary</button></div>
      <div id="share-out" hidden><label for="share-text">Copy this summary:</label><textarea id="share-text" class="share-box" readonly></textarea></div>
    </section>
    <section class="card">
      <h2>Check a file's Content Credentials</h2>
      <p class="fine" style="margin-top:0">JPEG, PNG, WebP or PDF, up to ${Math.round(MAX_PROVENANCE_BYTES / (1024 * 1024))} MB. The file is read inside this extension and is not sent anywhere on this route, and no file name or file bytes appear in any export.</p>
      <div class="file-drop"><label for="prov-file">Choose a file to inspect</label><input id="prov-file" type="file" accept=".jpg,.jpeg,.png,.webp,.pdf,image/jpeg,image/png,image/webp,application/pdf"></div>
      <div id="prov-out">${renderProvenance()}</div>
    </section>
    <section class="card">
      <h2>Your data</h2>
      <p class="fine" style="margin-top:0">Your text and result live in this panel only. Settings are the only thing stored, receipt history is off, and clearing removes the saved model too.</p>
      <div class="actions"><button type="button" id="clear-data">Clear everything stored</button><button type="button" id="results-back">Back to the result</button></div>
      <p id="clear-result" class="fine" role="status"></p>
    </section>`);
  notice = null;
  app.querySelector("#results-back")?.addEventListener("click", () => checkerResult ? renderResults() : renderCapture());
  app.querySelector("#download-receipt")?.addEventListener("click", () => {
    saveFile(`${JSON.stringify(receipt, null, 2)}
`, `${receipt.receipt_id}.json`, "application/json", "Content-free check receipt saved.");
  });
  app.querySelector("#download-result-json")?.addEventListener("click", () => {
    if (!checkerResult) return;
    saveFile(`${JSON.stringify(buildContentFreeCheckerReceipt(checkerResult), null, 2)}
`, `${checkerResult.result_id}-receipt.json`, "application/json", "Content-free result receipt saved.");
  });
  app.querySelector("#download-html")?.addEventListener("click", () => {
    if (!checkerResult) return;
    const html = buildCheckerReportHtml(checkerResult, reportOptions());
    saveFile(html, `${checkerResult.result_id}.html`, "text/html;charset=utf-8", "Complete HTML report saved.");
  });
  app.querySelector("#download-pdf")?.addEventListener("click", () => {
    if (!checkerResult || !capture) return;
    try {
      const bytes = buildCheckerPdf(checkerResult, { ...reportOptions(), fullText: capture.text, logoJpegBytes: logoJpegBytes() });
      saveFile(bytes, checkerPdfFilename(checkerResult.generated_at), "application/pdf", "Branded PDF report saved.");
    } catch (error) {
      notice = { tone: "error", title: "The PDF could not be made", body: error.message };
      void renderExport(gates);
    }
  });
  app.querySelector("#copy-share")?.addEventListener("click", async () => {
    if (!checkerResult) return;
    const summary = buildShareSummary(checkerResult);
    const output = app.querySelector("#share-out");
    const box = app.querySelector("#share-text");
    box.value = summary;
    output.hidden = false;
    try {
      await navigator.clipboard.writeText(summary);
      announce("Share summary copied. It carries no part of your text.");
    } catch {
      box.focus();
      box.select();
      announce("The clipboard was blocked. The summary is ready to copy by hand.");
    }
  });
  app.querySelector("#prov-file")?.addEventListener("change", (event) => {
    const file = event.target.files?.[0];
    if (file) void inspectFile(file);
  });
  app.querySelector("#clear-data")?.addEventListener("click", async () => {
    const [counts, clearedModelCache] = await Promise.all([clearAllExtensionData(), modelRuntime.clearCache()]);
    const target = app.querySelector("#clear-result");
    target.textContent = `Cleared ${counts.local} stored setting ${counts.local === 1 ? "group" : "groups"} and ${counts.session} session ${counts.session === 1 ? "marker" : "markers"}${clearedModelCache ? ", and removed the saved model files" : ""}. There was no text history to clear, and the EU route\u2019s pace record has been reset. Files you have already downloaded are still on your computer.`;
    announce("Stored data cleared.");
  });
  bindProvenanceActions();
};
var PROVENANCE_HEADLINE = Object.freeze({
  present: "Content Credentials found",
  absent: "No Content Credentials",
  invalid: "Content Credentials did not check out",
  untrusted: "Signer not recognised",
  error: "The check could not finish",
  unsupported: "File type not supported"
});
function renderProvenance() {
  if (provenanceNotice) return `<div class="notice attention" role="status"><b>Nothing was inspected</b><p>${escapeHtml2(provenanceNotice)}</p></div>`;
  if (!provenanceResult) return "";
  const summary = provenanceResult.manifest_summary;
  const rows = [
    ["File type", provenanceResult.media_type],
    ["Size", `${(provenanceResult.file_size / 1024).toFixed(0)} KB`],
    ["Fingerprint", provenanceResult.file_hash]
  ];
  if (summary) {
    rows.push(["Made with", summary.claim_generator ?? "Not recorded"]);
    rows.push(["Signed by", summary.signer ?? "Not recorded"]);
    rows.push(["Signed on", summary.signed_on ?? "Not recorded"]);
    rows.push(["Recorded steps", `${summary.assertions_count} ${summary.assertions_count === 1 ? "entry" : "entries"}, ${summary.ingredients_count} ${summary.ingredients_count === 1 ? "ingredient" : "ingredients"}`]);
  }
  return `<div class="prov" role="status">
    <span class="chip" data-state="${escapeHtml2(provenanceResult.status)}">${escapeHtml2(PROVENANCE_HEADLINE[provenanceResult.status])}</span>
    <p>${escapeHtml2(provenanceResult.reason)}</p>
    <dl>${rows.map(([term, value]) => `<div><dt>${escapeHtml2(term)}</dt><dd>${escapeHtml2(value)}</dd></div>`).join("")}</dl>
    ${provenanceResult.issues.length ? `<ul class="checks">${provenanceResult.issues.slice(0, 6).map((issue) => `<li class="check"><b>${escapeHtml2(issue.code)}</b><span class="state" data-state="${issue.success === false ? "fail" : "pass"}">${issue.success === false ? "Problem" : "Note"}</span><p>${escapeHtml2(issue.explanation ?? "No further explanation was recorded.")}</p></li>`).join("")}</ul>` : ""}
    <ul class="checks" aria-label="Limits of this file check">${provenanceResult.limitations.map((limitation) => `<li class="check"><p>${escapeHtml2(limitation)}</p></li>`).join("")}</ul>
    <div class="exports"><button type="button" id="prov-pdf">Save file report (PDF)</button><button type="button" id="prov-json">Save file record (JSON)</button></div>
  </div>`;
}
var provenanceRecord = () => buildProvenanceExport(
  { size: provenanceFile?.size ?? provenanceResult.file_size },
  provenanceResult,
  (/* @__PURE__ */ new Date()).toISOString()
);
var bindProvenanceActions = () => {
  app.querySelector("#prov-pdf")?.addEventListener("click", () => {
    if (!provenanceResult) return;
    const record2 = provenanceRecord();
    const bytes = buildProvenancePdf(record2, { logoJpegBytes: logoJpegBytes() });
    saveFile(bytes, provenancePdfFilename(record2.generated_at), "application/pdf", "Content-free file report saved.");
  });
  app.querySelector("#prov-json")?.addEventListener("click", () => {
    if (!provenanceResult) return;
    saveFile(`${JSON.stringify(provenanceRecord(), null, 2)}
`, `opace-content-credentials-${provenanceResult.file_hash.slice(7, 19)}.json`, "application/json", "Content-free file record saved.");
  });
};
var inspectFile = async (file) => {
  const output = app.querySelector("#prov-out");
  if (!output) return;
  provenanceNotice = "";
  provenanceResult = null;
  provenanceFile = { size: file.size };
  output.innerHTML = '<div class="notice" role="status"><b>Reading the file here</b><p>The file stays inside this extension and is not sent anywhere on this route.</p></div>';
  try {
    provenanceResult = await provenanceInspector.inspect(file);
  } catch (error) {
    provenanceNotice = error.code === "file_too_large" ? `That file is larger than ${Math.round(MAX_PROVENANCE_BYTES / (1024 * 1024))} MB. Choose a smaller one.` : `${error.message} No judgement was made about the file.`;
  }
  output.innerHTML = renderProvenance();
  bindProvenanceActions();
  announce(provenanceResult ? PROVENANCE_HEADLINE[provenanceResult.status] : "The file could not be inspected.");
};
var initialise = async () => {
  const settings = await loadSettings();
  document.documentElement.dataset.contrast = settings.highContrast ? "high" : "normal";
  await saveSettings(settings);
  await refreshEuAllowance();
  const pending = await chrome.runtime.sendMessage({ type: "GET_PENDING" }).catch(() => void 0);
  if (pending?.capture) {
    capture = pending.capture;
    renderCapture();
    return;
  }
  if (pending?.interrupted) {
    capture = { kind: "paste", text: "", host: "", title: "Interrupted", limitations: [] };
    notice = { tone: "attention", title: "That capture did not finish", body: "Chrome interrupted it. Nothing was kept \u2014 capture or paste the text again." };
    renderCapture();
    return;
  }
  capture = { kind: "paste", text: "", host: "", title: "Pasted text", limitations: [] };
  renderCapture();
};
void initialise();
